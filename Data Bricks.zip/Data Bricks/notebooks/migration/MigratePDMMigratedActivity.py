# Databricks notebook source
#File Name: LoadCuratedMigratedActivity
#ADF Pipeline Name: PDM_ADL_Plan-Activity-MigratedOneTime
#SQLDW Table: NA
#Description:
  #Store Migrated ACTIVITY data in curated layer of ADL

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

# MAGIC %run /source/Planisware/PLWConfig

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "lry43-hrow2-vsio1-d3kdm")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

curatedFilePath = "dbfs:/mnt/curated/pdm/pdm_migrated_activity.txt"

# read new activity data file 1
activity = spark.read.format("csv")\
          .option("inferSchema", "false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(curatedFilePath)

# COMMAND ----------

activity = activity.withColumn('ACTIVITY_SCOPE_NAME',F.when(activity.ACTIVITY_SCOPE_NAME.isNotNull(),activity.ACTIVITY_SCOPE_NAME).otherwise(F.when(activity.WBS_TYPE.like('mdp.pm.projmilestone.%') | activity.WBS_TYPE.like('mdp.pm.ProjTerm.%'),"Project Milestone").when(activity.WBS_TYPE.like('mdp.pm.legacymilestones.%'),"Legacy Milestone").otherwise(activity.ACTIVITY_SCOPE_NAME)))

# COMMAND ----------

# write to curated
rawPath = 'dbfs:/mnt/raw/planisware/'
unique_run_id = runid + '-CuratedMigratedActivity/'
csv_temp_curated = rawPath + unique_run_id
curatedPath = 'dbfs:/mnt/curated/pdm/'
#
activity.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + "pdm_migrated_activity.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)

# COMMAND ----------

unifiedFilePath = "dbfs:/mnt/unified/project_management/task_migrated.txt"

# read new activity data file 1
task_migrated = spark.read.format("csv")\
                          .option("inferSchema", "false")\
                          .option("header","true")\
                          .option("multiLine","true")\
                          .option("delimiter","|")\
                          .option("quote", '"')\
                          .option("escape",'"')\
                          .option("nullValue","null")\
                    .load(unifiedFilePath)

# COMMAND ----------

task_migrated = task_migrated.withColumn('ACTIVITY_SCOPE_NAME',F.when(task_migrated.ACTIVITY_SCOPE_NAME.isNotNull(),task_migrated.ACTIVITY_SCOPE_NAME).otherwise(F.when(task_migrated.WBS_TYPE.like('mdp.pm.projmilestone.%') | task_migrated.WBS_TYPE.like('mdp.pm.ProjTerm.%'),"Project Milestone").when(task_migrated.WBS_TYPE.like('mdp.pm.legacymilestones.%'),"Legacy Milestone").otherwise(task_migrated.ACTIVITY_SCOPE_NAME)))

# COMMAND ----------

# write to curated
raw_path = 'dbfs:/mnt/raw/planisware/'
unique_run_id = runid + '-UnifiedMigratedActivity/'
csv_temp_curated = raw_path + unique_run_id + '/' + 'curated/'
unified_path = 'dbfs:/mnt/unified/project_management/'

task_migrated.coalesce(1).write\
                        .option("sep", "|")\
                        .option("header", "true")\
                        .option("quote",  '"')\
                        .option("escape", '"')\
                        .option("nullValue", "null")\
                        .option("quoteAll", "true")\
                        .mode('overwrite')\
                      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], unified_path + "task_migrated.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)