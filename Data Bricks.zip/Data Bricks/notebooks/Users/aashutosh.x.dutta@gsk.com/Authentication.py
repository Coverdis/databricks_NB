# Databricks notebook source
# Data lake gen 2 account access settings

configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": "aashutosh.x.dutta@gsk.com",
          
           "fs.azure.account.oauth2.client.endpoint": "https://login.microsoftonline.com/63982aff-fb6c-4c22-973b-70e4acfb63e6/oauth2/v2.0/authorize"}


mountName = 'plan'
mounts = [str(i) for i in dbutils.fs.ls('/mnt/')] 
if "FileInfo(path='dbfs:/mnt/" +mountName + "/', name='" +mountName + "/', size=0)" in mounts:
  print(mountName + " is already mounted") 
else:
  dbutils.fs.mount(
  source = "abfss://irm@irmdatalakegen2.dfs.core.windows.net",
  mount_point= "/mnt/" + mountName,
  extra_configs = configs)
  print(mountName + " is mounted")

# COMMAND ----------

import com.microsoft.azure.sqldb.spark.config.Config
import com.microsoft.azure.sqldb.spark.connect._

val config = Config(Map(
  "url"            -> "gsk-us6-rd-irm-sqlsrv-devtest.database.windows.net",
  "databaseName"   -> "rd-irm-sqldb",
  "dbTable"        -> "dbo.PROJECT_PLAN"
  "user"           -> "aashutosh.x.dutta@gsk.com",
  "password"       -> "pwd",
  "connectTimeout" -> "5", //seconds
  "queryTimeout"   -> "5"  //seconds
))

val collection = spark.read.sqlDB(config)
collection.show()