# Databricks notebook source
jdbcUrl="jdbc:sqlserver://gsk-us6-rd-irm-sqlsrv-devtest.database.windows.net:1433;database=rd-irm-sqldb;user=;password=;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;authentication=ActiveDirectoryPassword;driver=com.microsoft.azure:adal4j:1.6.3;"

# COMMAND ----------

df = spark.read \
  .format("jdbc") \
  .option("url", jdbcUrl) \
  .option("query", "select creation_date from  project_plan") \
  .load()

# COMMAND ----------

display(df)

# COMMAND ----------

# MAGIC %scala
# MAGIC Class.forName("org.mariadb.jdbc.Driver") // Databricks Runtime 3.4 and above
# MAGIC Class.forName("com.mysql.jdbc.Driver") // Databricks Runtime 3.3 and below

# COMMAND ----------

import pymysql


# COMMAND ----------

conn = pymysql.connect(server='gsk-us6-rd-irm-sqlsrv-devtest.database.windows.net', user='irm_devtest@gsk-us6-rd-irm-sqlsrv-devtest', password='Project1!', database='rd-irm-sqldb')  
cursor = conn.cursor()  
cursor.execute('select creation_date from  project_plan;')  
row = cursor.fetchone()  
     

# COMMAND ----------

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

 

SQLServerDataSource ds = new SQLServerDataSource();
ds.setServerName("gsk-us6-rd-irm-sqlsrv-devtest.database.windows.net"); // Replace with your server name
ds.setDatabaseName("rd-irm-sqldb"); // Replace with your database name
ds.setAuthentication("ActiveDirectoryPassword");
        #// Optional
        #ds.setMsiClientId("94de34e9-8e8c-470a-96df-08110924b814"); // Replace with Client ID of User-Assigned MSI to be used

        try (Connection connection = ds.getConnection(); 
                Statement stmt = connection.createStatement();
                ResultSet rs = stmt.executeQuery("select creation_date from  project_plan")) {
            if (rs.next()) {
                System.out.println("You have successfully logged on as: " + rs.getString(1));
            }
        }
    }
}

# COMMAND ----------

#

jdbcHostname = "gsk-us6-rd-irm-sqlsrv-devtest.database.windows.net"
jdbcPort = 1433
jdbcDatabase = "rd-irm-sqldb"
jdbcUsername = "irm_devtest@gsk-us6-rd-irm-sqlsrv-devtest"
jdbcPassword = "Project1!"
#// Create the JDBC URL without passing in the user and password parameters.
jdbcUrl = "jdbc:sqlserver://{0}:{1};{2}".format(jdbcHostname, jdbcPort, jdbcDatabase)
print(jdbcUrl)

connectionProperties = {
  "user" : jdbcUsername,
  "password" : jdbcPassword,
  "driver" : "org.mariadb.jdbc.Driver"
}




# COMMAND ----------

pushdown_query = "(select * from project_plan)"
df = spark.read.jdbc(url=jdbcUrl, table=pushdown_query, properties=connectionProperties)
display(df)