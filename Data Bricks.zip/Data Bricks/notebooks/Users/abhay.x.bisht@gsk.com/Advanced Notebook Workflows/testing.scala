// Databricks notebook source
// MAGIC %md Hello

// COMMAND ----------

dbutils.notebook.exit("SUCCESS")