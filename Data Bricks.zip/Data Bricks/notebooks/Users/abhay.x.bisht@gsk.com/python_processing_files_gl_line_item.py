# Databricks notebook source
dwDatabase = "irmdb"
dwServer = "irmdwserver" 
dwUser =  "irm_sandbox@irmdwserver"
dwPass = "Experiments1!"
dwJdbcPort =  "1433"
dwJdbcExtraOptions = "encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;"
sqlDwUrl = "jdbc:sqlserver://" + dwServer + ".database.windows.net:" + dwJdbcPort + ";database=" + dwDatabase + ";"+dwJdbcExtraOptions + ";user=" + dwUser+";password=" + dwPass

sqlDwUrlSmall = "jdbc:sqlserver://" + dwServer + ".database.windows.net:" + dwJdbcPort + ";database=" + dwDatabase + ";user=" + dwUser+";password=" +dwPass

tempDir = "wasbs://irm@rdirmstorage.blob.core.windows.net/TempDir"

storage_account_name = "rdirmstorage"
storage_account_access_key =  "JOQxgP2dP88LgxlkAl6wywErX/sI5PNg0ZMvMX3/3GGvwJbXs45BnOipDlmFqpUiEc+RYwRTPFWXjpsEFTHabA=="

file_type = "csv"
spark.conf.set(
  "fs.azure.account.key."+storage_account_name+".blob.core.windows.net",
  storage_account_access_key)


import  pyspark.sql.functions  as fn 
from pyspark.sql.functions import *

# COMMAND ----------

#  loaded the file from Blob Storage in Dataframe: file_to_process_GlLineItem
file_to_process_GlLineItem = spark.read.format("csv").option ("header","true").option("delimiter","|").option("inferSchema","true").option("quote", '"').option("escape",'"').option("nullValue","null").option("multiLine","true").option( "forward_spark_azure_storage_credentials","True").option("tempdir", tempDir).load("wasbs://irm@rdirmstorage.blob.core.windows.net/raw/cerps/GLLineItem")
#GLLineItemArchive
#GLLineItem

# COMMAND ----------

#  Read the Full Parquet file-- This is the File in-sync with SQLDW table
cerps_gllineitem_parquet_df = sqlContext.read.parquet("/irm/prod/incremental_cerps_gllineitem_sqldw_df.parquet")

# COMMAND ----------



# COMMAND ----------

#  for emergency need to add the columns which are not present in blob file but present in  ssqldw table


from pyspark.sql.functions import *
file_to_process_GlLineItem=file_to_process_GlLineItem.withColumn("RNK", lit(2))
file_to_process_GlLineItem=file_to_process_GlLineItem.withColumn("IDENTITYKEY", lit(14041))
file_to_process_GlLineItem=file_to_process_GlLineItem.withColumn("BALANCEGBP", lit(413.12000))
file_to_process_GlLineItem=file_to_process_GlLineItem.withColumn("INTEXT", lit("IPE"))
file_to_process_GlLineItem=file_to_process_GlLineItem.withColumn("ROWKEY", lit("CC-1415000-WBS-2018004"))

# len(file_to_process_GlLineItem.columns)     please make the count to 125
# len(cerps_gllineitem_parquet_df.columns)

# COMMAND ----------


# 1. Calculating the length of the COSTCENTER column and making a corresponding length column i.e LENCOSTCENTER.
# 2. Making a new column TRFM_COSTCENTER, which consist of the valid values, i.e max 8 characters after removing leading 2 zeroes.

file_to_process_GlLineItem = file_to_process_GlLineItem.withColumn("LENCOSTCENTER",fn.length(file_to_process_GlLineItem["COSTCENTER"])) 

file_to_process_GlLineItem = file_to_process_GlLineItem.withColumn("TRFM_COSTCENTER", when(file_to_process_GlLineItem['LENCOSTCENTER'] == 8,fn.substring(file_to_process_GlLineItem["COSTCENTER"], 1, 8)).when(((file_to_process_GlLineItem['LENCOSTCENTER'] == 10) & (fn.substring(file_to_process_GlLineItem["COSTCENTER"], 1, 2) =='00')),fn.substring(file_to_process_GlLineItem["COSTCENTER"], 3, 10)).when( (file_to_process_GlLineItem['LENCOSTCENTER'] == 9) & (fn.substring(file_to_process_GlLineItem["COSTCENTER"], 1, 1) =='0'),fn.substring(file_to_process_GlLineItem["COSTCENTER"], 2, 9)) )

# COMMAND ----------

# 1. Calculating the length of the GL_Account column and making a corresponding length column i.e LENGL_Account.
# 2. Making a new column TRFM_GL_Account, which consist of the valid values, i.e max 7 characters after removing leading 3 zeroes.

file_to_process_GlLineItem = file_to_process_GlLineItem.withColumn("LENGL_Account",fn.length(file_to_process_GlLineItem["GL_Account"])) 

file_to_process_GlLineItem = file_to_process_GlLineItem.withColumn("TRFM_GL_Account", when(file_to_process_GlLineItem['LENGL_Account'] == 7,fn.substring(file_to_process_GlLineItem["GL_Account"], 1, 7)).when(((file_to_process_GlLineItem['LENGL_Account'] == 8) & (fn.substring(file_to_process_GlLineItem["GL_Account"], 1, 1) =='0')),fn.substring(file_to_process_GlLineItem["GL_Account"], 2, 8)).when( (file_to_process_GlLineItem['LENGL_Account'] == 9) & (fn.substring(file_to_process_GlLineItem["GL_Account"], 1, 2) =='00'),fn.substring(file_to_process_GlLineItem["GL_Account"], 3, 9)).when( (file_to_process_GlLineItem['LENGL_Account'] == 10) & (fn.substring(file_to_process_GlLineItem["GL_Account"], 1, 3) =='000'),fn.substring(file_to_process_GlLineItem["GL_Account"], 4, 10)) )

# COMMAND ----------

# 1. Calculating the length of the PROFIT_CTR column and making a corresponding length column i.e LENPROFIT_CTR.
# 2. Making a new column TRFM_PROFIT_CTR, which consist of the valid values, i.e max 4 characters after removing leading 6 zeroes.

file_to_process_GlLineItem = file_to_process_GlLineItem.withColumn("LENPROFIT_CTR",fn.length(file_to_process_GlLineItem["PROFIT_CTR"])) 


file_to_process_GlLineItem = file_to_process_GlLineItem.withColumn("TRFM_PROFIT_CTR", when(file_to_process_GlLineItem['LENPROFIT_CTR'] == 4,fn.substring(file_to_process_GlLineItem["PROFIT_CTR"], 1, 4)).when(((file_to_process_GlLineItem['LENPROFIT_CTR'] == 5) & (fn.substring(file_to_process_GlLineItem["PROFIT_CTR"], 1, 1) =='0')),fn.substring(file_to_process_GlLineItem["PROFIT_CTR"], 2, 5)).when( (file_to_process_GlLineItem['LENPROFIT_CTR'] == 6) & (fn.substring(file_to_process_GlLineItem["PROFIT_CTR"], 1, 2) =='00'),fn.substring(file_to_process_GlLineItem["PROFIT_CTR"], 3, 6)).when( (file_to_process_GlLineItem['LENPROFIT_CTR'] == 7) & (fn.substring(file_to_process_GlLineItem["PROFIT_CTR"], 1, 3) =='000'),fn.substring(file_to_process_GlLineItem["PROFIT_CTR"], 4, 7)) .when( (file_to_process_GlLineItem['LENPROFIT_CTR'] == 8) & (fn.substring(file_to_process_GlLineItem["PROFIT_CTR"], 1, 4) =='0000'),fn.substring(file_to_process_GlLineItem["PROFIT_CTR"], 5, 8)).when( (file_to_process_GlLineItem['LENPROFIT_CTR'] == 9) & (fn.substring(file_to_process_GlLineItem["PROFIT_CTR"], 1, 5) =='00000'),fn.substring(file_to_process_GlLineItem["PROFIT_CTR"], 6, 9)).when( (file_to_process_GlLineItem['LENPROFIT_CTR'] == 10) & (fn.substring(file_to_process_GlLineItem["PROFIT_CTR"], 1, 6) =='000000'),fn.substring(file_to_process_GlLineItem["PROFIT_CTR"], 7, 10))   )

# COMMAND ----------

# 1. Inserting a new column as CreationTimestamp, which consists of the current timestamp while the file is being written.

import time
import datetime
from pyspark.sql.functions import lit,unix_timestamp
timestamp = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
type(timestamp)
timestamp
file_to_process_GlLineItem = file_to_process_GlLineItem.withColumn('CreationTimestamp',unix_timestamp(lit(timestamp),'yyyy-MM-dd HH:mm:ss').cast("timestamp"))

# COMMAND ----------

# 1. Inserting a new column as CreatedBy, which consists of the corresponding value while the file is being written.

file_to_process_GlLineItem = file_to_process_GlLineItem.withColumn("CreatedBy", lit('DataFromBlobFile'))

# COMMAND ----------

Delta_NewRecord_GlLineItem = file_to_process_GlLineItem.join(cerps_gllineitem_parquet_df, ["AC_DOC_NO","ITEM_NUM","COMP_CODE","FISCPER","FISCVARNT","RECTYPE","AC_LEDGER","BW_RECORDMODE","BW_REQUEST_ID" ], "left_anti")


# COMMAND ----------

# len(Delta_NewRecord_GlLineItem.columns)--133
# Delta_NewRecord_GlLineItem.count()---  0 records

# file_to_process_GlLineItem.

# COMMAND ----------

# append the newly found records to the parquet file  --this is delta insert

if (Delta_NewRecord_GlLineItem.count() != 0):
  Delta_NewRecord_GlLineItem.write.mode('append').parquet('/irm/prod/incremental_cerps_gllineitem_sqldw_df.parquet')

# COMMAND ----------

# append records to the sqlDW table 

Delta_NewRecord_GlLineItem.write\
    .format("com.databricks.spark.sqldw")\
    .option("url", sqlDwUrl)\
    .option("dbtable", "Cerps_GlLineItem_Processed_parquet")\
    .option( "forward_spark_azure_storage_credentials","True")\
    .option("tempdir", tempDir)\
    .mode("Append")\
    .save()

# COMMAND ----------

