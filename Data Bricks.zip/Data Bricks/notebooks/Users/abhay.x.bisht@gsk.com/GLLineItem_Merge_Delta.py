# Databricks notebook source
deltaFilesName = [file[1] for file in dbutils.fs.ls('dbfs:/mnt/raw/Cerps/GLLineitem/')]
deltaFilesPath = [file[0] for file in dbutils.fs.ls('dbfs:/mnt/raw/Cerps/GLLineitem/')]

for index, file in enumerate(deltaFilesName):
  # split file names to get year and month
  try:
    prefixText = file.split('-')[0]
    year = file.split('-')[1]
    month = file.split('-')[2].split('.')[0]
  except:
    # exception while splitting file names
    print('Warning: One or more file(s) does not have proper naming convention in raw folder and same has not been processed. Format: GLLineitem-<YYYY>-<M>.txt')
  else:
    # check if year folder is present in foundation
    try:
      dbutils.fs.ls('/mnt/foundation/Cerps/GLLineitem/'+year)
      # check if file with name in delta folder is present in foundation
      try:
        dbutils.fs.ls('/mnt/foundation/Cerps/GLLineitem/' + year +'/'+deltaFilesName[index])
        # read base file from foundation
        baseFile = spark.read.format('csv')\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
        .load('dbfs:/mnt/foundation/Cerps/GLLineitem/' + year +'/'+deltaFilesName[index])
        # read delta file from raw
        deltaFile = spark.read.format('csv')\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
        .load(deltaFilesPath[index])
        # find rows that are not in base but are in delta
#         df = deltaFile.subtract(baseFile)
        # merge with base data
        merged = baseFile.union(deltaFile)
        # write to text file
#         merged.write.format("csv").save(deltaFilesName[index])
        # temp csv folder
        csv_location = deltaFilesPath+'/tmp/'
        merged.coalesce(1).write\
                  .option("sep","|")\
                  .option("header","true")\
                  .option("quote", '"')\
                  .option("escape",'"')\
                  .option("nullValue","null")\
                .csv(csv_location)
        # copy part-* csv file and rename
        dbutils.fs.cp(dbutils.fs.ls(csv_location)[-1][0], '/mnt/foundation/Cerps/GLLineitem/' + year +'/'+deltaFilesName[index], True)
        # remove temp folder
        dbutils.fs.rm(csv_location, recurse = True)
        # remove file from raw
        dbutils.fs.rm(deltaFilesPath[index])
      except:
        # file does not exist in foundation, move fom raw
        dbutils.fs.mv(deltaFilesPath[index], '/mnt/foundation/Cerps/GLLineitem/' + year +'/'+deltaFilesName[index])
    except:
      # year folder does not exisit, create folder and move file from raw
      dbutils.fs.mkdirs('dbfs:/mnt/foundation/Cerps/GLLineitem/'+year)
      dbutils.fs.mv(deltaFilesPath[index], 'dbfs:/mnt/foundation/Cerps/GLLineitem/' + year +'/'+deltaFilesName[index])

# COMMAND ----------

deltaFileName = 'GLLineitem-2019-1.txt'
deltaFileMonth = '1'
deltaFileYear = '2019'
rawFilePath = 'dbfs:/data/raw/GLLineitem/'
foundationFilePath = 'dbfs:/mnt/foundation/Cerps/GLLineitem/'


# check if year folder is present in foundation
try:
  dbutils.fs.ls(foundationFilePath+deltaFileYear)
  # check if file with name in delta folder is present in foundation
  try:
    dbutils.fs.ls(foundationFilePath + deltaFileYear + '/' + deltaFileName)
    # read base file from foundation
    baseFile = spark.read.format('csv')\
      .option("inferSchema","false")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
    .load(foundationFilePath + deltaFileYear +'/' + deltaFileName)
    # read delta file from raw
    deltaFile = spark.read.format('csv')\
      .option("inferSchema","false")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
    .load(rawFilePath + deltaFileName)
    # find rows that are not in base but are in delta
#         df = deltaFile.subtract(baseFile)
    # merge with base data
    merged = baseFile.union(deltaFile)
    # write to text file
#         merged.write.format("csv").save(deltaFilesName[index])
    # temp csv folder
    csv_location = rawFilePath+'/tmp/'
    merged.coalesce(1).write\
              .option("sep","|")\
              .option("header","true")\
              .option("quote", '"')\
              .option("escape",'"')\
              .option("nullValue","null")\
            .csv(csv_location)
    # copy part-* csv file and rename
    dbutils.fs.cp(dbutils.fs.ls(csv_location)[-1][0], foundationFilePath + deltaFileYear + '/' + deltaFileName, True)
    # remove temp folder
    dbutils.fs.rm(csv_location, recurse = True)
    # remove file from raw
    dbutils.fs.rm(rawFilePath + deltaFileName)
  except:
    # file does not exist in foundation, move fom raw
    dbutils.fs.mv(rawFilePath + deltaFileName, foundationFilePath + deltaFileYear + '/' + deltaFileName)
except:
  # year folder does not exisit, create folder and move file from raw
  dbutils.fs.mkdirs(foundationFilePath+year)
  dbutils.fs.mv(rawFilePath + deltaFileName, foundationFilePath + deltaFileYear + '/' + deltaFileName)