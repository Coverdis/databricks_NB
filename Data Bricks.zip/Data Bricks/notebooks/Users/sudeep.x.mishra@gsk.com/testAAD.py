# Databricks notebook source
# MAGIC %scala
# MAGIC import com.microsoft.azure.sqldb.spark.config.Config
# MAGIC import com.microsoft.azure.sqldb.spark.connect._
# MAGIC import com.nimbusds.oauth2.sdk.AuthorizationGrant
# MAGIC import com.nimbusds.oauth2.sdk.JWTBearerGrant
# MAGIC Class.forName("com.nimbusds.oauth2.sdk.JWTBearerGrant")
# MAGIC 
# MAGIC // jdbc:sqlserver://testdbserversudeep.database.windows.net:1433;database=testdb1;user={your_username_here};password={your_password_here};encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;authentication=ActiveDirectoryPassword
# MAGIC 
# MAGIC val config = Config(Map(
# MAGIC   "url"            -> "testdbserversudeep.database.windows.net",
# MAGIC   "databaseName"   -> "testdb1",
# MAGIC   "dbTable"        -> "student",
# MAGIC   "user"           -> "sudeep.x.mishra@gsk.com",
# MAGIC   "password"       -> "Feb2019@new",
# MAGIC   "authentication" -> "ActiveDirectoryPassword",
# MAGIC   "connectTimeout" -> "30", //seconds
# MAGIC   "queryTimeout"   -> "30",  //seconds
# MAGIC   "encrypt"        -> "true",
# MAGIC   "trustServerCertificate" -> "false",
# MAGIC   "hostNameInCertificate" -> "*.database.windows.net"
# MAGIC ))
# MAGIC 
# MAGIC val collection = sqlContext.read.sqlDB(config)
# MAGIC collection.show()
# MAGIC 
# MAGIC // tenant id 63982aff-fb6c-4c22-973b-70e4acfb63e6

# COMMAND ----------

# MAGIC %scala
# MAGIC import com.nimbusds.oauth2.sdk.AuthorizationGrant
# MAGIC import com.nimbusds.oauth2.sdk.JWTBearerGrant

# COMMAND ----------

sqlserver = 'testdbserversudeep.database.windows.net'
port = '1433'
database = 'testdb1'
user = 'sudeep.x.mishra@gsk.com'
pswd = "Feb2019@new"
query = '(select top 100 * from student) Cust'




# COMMAND ----------

df1 = spark.read \
  .option('user', user) \
  .option('password', pswd) \
  .jdbc('jdbc:sqlserver://' + sql
        30
        
        
        server + ':' + port + ';database=' + database+';encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;authentication=ActiveDirectoryPassword', query)

# COMMAND ----------

# MAGIC %scala
# MAGIC Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver")

# COMMAND ----------

# MAGIC %scala
# MAGIC Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver")
# MAGIC import com.microsoft.sqlserver.jdbc.SQLServerDriver
# MAGIC import java.sql.DriverManager
# MAGIC import org.apache.spark.sql.SQLContext
# MAGIC import sqlContext.implicits._
# MAGIC // MS SQL JDBC Connection String ... 
# MAGIC val jdbcSqlConnStr = "jdbc:sqlserver://testdbserversudeep.database.windows.net:1433;database=testdb1;user=sudeep.x.mishra@gsk.com;password=Feb2019@new;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;authentication=ActiveDirectoryPassword"
# MAGIC // Loading the ms sql table via spark context into dataframe
# MAGIC val jdbcDF = sqlContext.read.format("jdbc").options(
# MAGIC   Map("url" -> jdbcSqlConnStr,
# MAGIC   "driver" -> "com.microsoft.sqlserver.jdbc.SQLServerDriver",
# MAGIC   "dbtable" -> "student")).load()
# MAGIC // Registering the temp table so that we can SQL like query against the table 
# MAGIC jdbcDF.createOrReplaceTempView("student_tbbb")
# MAGIC // selecting only top 10 rows here but you can use any sql statement
# MAGIC val yourdata = sqlContext.sql("SELECT * FROM student_tbbb LIMIT 10")
# MAGIC // display the data 
# MAGIC yourdata.show()
# MAGIC // Simple write to mount location which could be pointing to S3 or any other storage 
# MAGIC // If you planning to overwrite the same file then its important that you use overwrite

# COMMAND ----------

