# Databricks notebook source
import uuid
import datetime

from datacollectorapi import client
from datacollectorapi import helper

dbutils.widgets.text("runid", "")

log_customer_id =  dbutils.secrets.get(scope = "azurekeyvault-databricks", key = "log-analytics-workspace-id")
log_shared_key = dbutils.secrets.get(scope = "azurekeyvault-databricks", key = "log-analytics-shared-key")

# COMMAND ----------

def log(level,msg):
  pipelineRunId = dbutils.widgets.get("runid")
  activityRunId = dbutils.notebook.entry_point.getDbutils().notebook().getContext().currentRunId().toString()
  json_records = []
  json_records.append(
    {
      "PipelineRunId":pipelineRunId,
      "ActivityRunId":activityRunId,
      "Level":level,
      "Message": msg
    })

  api = client.DataCollectorAPIClient(log_customer_id, log_shared_key)   
  response = api.post_data('DatabricksLog', json_records)
  if (helper.is_success(response.status_code)):
      print('Logged ' + level + ': ' + msg)
  else:
      print("Failure: Error code:{}".format(response.status_code))

# COMMAND ----------

def logDebug(msg):
  log('debug', msg)
  
def logWarning(msg):
  log('warning', msg)

def logError(msg):
  log('error', msg)

def logInfo(msg):
  log('info', msg)