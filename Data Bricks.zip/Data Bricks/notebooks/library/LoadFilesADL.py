# Databricks notebook source
dbutils.widgets.text('args', '')
dbutils.widgets.text('dataset', '')
dbutils.widgets.text('path', '')

args = dbutils.widgets.get('args')
dataset = dbutils.widgets.get('dataset')
path = dbutils.widgets.get('path')

# COMMAND ----------

df = spark.sql("select * from global_temp." + dataset)
df = df.filter(args) 

# COMMAND ----------

from random import choice
from string import ascii_uppercase

csv_temp_path = 'dbfs:/mnt/raw/TempWriteFilesADL/' + ''.join(choice(ascii_uppercase) for i in range(12))
csv_path = path

df.coalesce(1).write\
    .option("sep", "|")\
    .option("header", "true")\
    .option("quote",  '"')\
    .option("escape", '"')\
    .option("nullValue", "null")\
    .option("quoteAll", "true")\
    .mode('overwrite')\
  .csv(csv_temp_path)

# copy part-* csv file to curated and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_path)[-1][0], csv_path, recurse = True)

# remove temp folders
dbutils.fs.rm(csv_temp_path, recurse = True)