# Databricks notebook source
# Filename: hyp_recon
# Description:
    # Reconciles Hyperion EPE budget and forecast data between source and staging table

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

# MAGIC %run /library/logs

# COMMAND ----------

import pytz
from datetime import *
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
from pyspark.sql.functions import explode
import os
from glob import glob
import re

# foundation_path = 'dbfs:/mnt/foundation/hyperion_essbase/esb_epe_est_3pd/'
foundation_path = 'dbfs:/mnt/foundation/hyperion_essbase/esb_epe_budu1u2u3/esb_epe_budu1u2u3.txt'
dbutils.widgets.text("runid", "")
runid = dbutils.widgets.get("runid")
log_msg = '|'


# COMMAND ----------

# Loading EPE Forecast data from  source 
epe_source = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/hyperion_essbase/esb_epe_est_3pd/')
epe_source = epe_source.toDF(*(col.replace('\r', '') for col in epe_source.columns))

for col_name in epe_source.columns:
  epe_source = epe_source.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ' '))
  
epe_source = epe_source.withColumn('Entity', F.regexp_replace(epe_source.Entity, 'CC.',''))
epe_source = epe_source.withColumn('ACCOUNT', F.regexp_replace(epe_source.Account, 'AC.',''))
epe_source = epe_source.withColumn('Project', F.regexp_replace(epe_source.Project, '^\w{2}\.', ''))
epe_source = epe_source.withColumn('Years', (2000 + F.regexp_extract(epe_source.Years, r'\d+', 0)).cast(IntegerType()))

# COMMAND ----------

# Function for comparing budid count
def compare_budid(source,staging):
  if source == staging:
    return "Count of BUDID are same"
  else:
    return "Count of BUDID are not same"

# COMMAND ----------

# Function for comparing Sum of amount gbp
def compare_sum(source,staging):
  if source == staging:
    return "Sum is same"
  else:
    x = abs(float(source) - float(staging))
    str = f'Sum is diefferent by {float(x)}'
    return str

# COMMAND ----------

# DBTITLE 1,EPE Forecast Validation
#  Filtering the epe source for different scenarios
epe_source_current = epe_source.filter((epe_source.Scenario == 'Current Estimate') & (epe_source.Currency == 'GBP-Current-Budget'))

epe_source_review = epe_source.filter((epe_source.Scenario == 'Review Estimate') & (epe_source.Currency == 'GBP-Current-Budget'))

epe_source_approved = epe_source.filter((epe_source.Scenario == 'Approved Estimate') & (epe_source.Currency == 'GBP-Current-Budget'))

# COMMAND ----------

# Getting min year from source
min_year = epe_source.select('years').distinct()
min_year = min_year.collect()
l = []
for i in min_year:
  l.append(i[0])
min_year = min(l)
print(min_year)

# COMMAND ----------

#  count of budid for review estimate
source_review_budid_count = epe_source_review.select('project').distinct().count()

# getting sum for review_estimate in source
epe_source_review.createOrReplaceTempView('review')

query = '''
select sum(amount) as sum_review_estimate from (
select  project,entity,account,scenario ,sum(amount) as amount
from review
group by  project,entity,account,scenario )
'''
source_sum_review = sqlContext.sql(query)
source_sum_review = source_sum_review.collect()
source_sum_review = float(source_sum_review[0][0])
source_sum_review = round(source_sum_review,3)

# COMMAND ----------

# count of budid for current estimate
source_current_budid_count = epe_source_current.select('project').distinct().count()

# getting sum for current estimate in source
epe_source_current.createOrReplaceTempView('current')

query = '''
select sum(amount) as sum_current_estimate from (
select  project,entity,account,scenario ,sum(amount) as amount
from current
group by  project,entity,account,scenario )
'''

source_sum_current = sqlContext.sql(query)
source_sum_current = source_sum_current.collect()
source_sum_current = float(source_sum_current[0][0])
source_sum_current = round(source_sum_current,3)

# COMMAND ----------

# count of budid for approved estimate
source_approved_budid_count = epe_source_approved.select('project').distinct().count()

# getting sum for current estimate in source
epe_source_approved.createOrReplaceTempView('approved')

query = '''
select sum(amount) as sum_current_estimate from (
select  project,entity,account,scenario ,sum(amount) as amount
from approved
group by  project,entity,account,scenario )
'''

source_sum_approved = sqlContext.sql(query)
source_sum_approved = source_sum_approved.collect()
source_sum_approved = float(source_sum_approved[0][0])
source_sum_approved = round(source_sum_approved,3)

# COMMAND ----------

# read epe data from irm_stg.expense
epe_staging = spark.read \
  .format("com.databricks.spark.sqldw") \
  .option("url", sqlDwUrl) \
  .option("tempDir", tempDir) \
  .option("dbtable", "irm_stg.expense")\
  .option("forwardSparkAzureStorageCredentials", "true") \
  .load()

# COMMAND ----------

# filtering staging table for review_estimate
epe_staging_review = epe_staging.filter((epe_staging.SOURCE == 'Hyperion-Forecast') & (epe_staging.COST_TYPE == 'EPE') & (epe_staging.ACTUAL_OR_ESTIMATE_CODE == 'Review Estimate') & (epe_staging.FISCYEAR >= str(min_year)))

# filtering staging table for current_estimate
epe_staging_current = epe_staging.filter((epe_staging.SOURCE == 'Hyperion-Forecast') & (epe_staging.COST_TYPE == 'EPE') & (epe_staging.ACTUAL_OR_ESTIMATE_CODE == 'Current Estimate') & (epe_staging.FISCYEAR >= str(min_year)))

# filtering staging table for approved_estimate
epe_staging_approved = epe_staging.filter((epe_staging.SOURCE == 'Hyperion-Forecast') & (epe_staging.COST_TYPE == 'EPE') & (epe_staging.ACTUAL_OR_ESTIMATE_CODE == 'Approved Estimate') & (epe_staging.FISCYEAR >= str(min_year)))

# COMMAND ----------

# count of budid for review estimate in staging
staging_review_budid_count = epe_staging_review.select('budid_code').distinct().count()

#  getting sum of review estimate from staging
epe_staging_review.createOrReplaceTempView('review_staging')
query = '''
select sum(amount) as sum_review_estimate_staging from(
select  budid_code,cost_center_code,account_code,actual_or_estimate_code as scenario ,sum(amount_gbp) as amount
from review_staging
group by  budid_code,cost_center_code,account_code,actual_or_estimate_code)
'''

staging_sum_review = sqlContext.sql(query)
staging_sum_review = staging_sum_review.collect()
staging_sum_review = float(staging_sum_review[0][0])
staging_sum_review = round(staging_sum_review,3)

# COMMAND ----------

# count of budid for current estimate in staging
staging_current_budid_count = epe_staging_current.select('budid_code').distinct().count()

#  getting sum of current estimate from staging
epe_staging_current.createOrReplaceTempView('current_staging')
query = '''
select sum(amount) as sum_current_estimate_staging from(
select  budid_code,cost_center_code,account_code,actual_or_estimate_code as scenario ,sum(amount_gbp) as amount
from current_staging
group by  budid_code,cost_center_code,account_code,actual_or_estimate_code)
'''
staging_sum_current = sqlContext.sql(query)
staging_sum_current = staging_sum_current.collect()
staging_sum_current = float(staging_sum_current[0][0])
staging_sum_current = round(staging_sum_current,3)

# COMMAND ----------

# count of budid for approved estimate for staging
staging_approved_budid_count = epe_staging_approved.select('budid_code').distinct().count()

#  getting sum of current estimate from staging
epe_staging_approved.createOrReplaceTempView('approved_staging')
query = '''
select sum(amount) as sum_current_estimate_staging from(
select  budid_code,cost_center_code,account_code,actual_or_estimate_code as scenario ,sum(amount_gbp) as amount
from approved_staging
group by  budid_code,cost_center_code,account_code,actual_or_estimate_code)
'''
staging_sum_approved = sqlContext.sql(query)
staging_sum_approved = staging_sum_approved.collect()
staging_sum_approved = float(staging_sum_approved[0][0])
staging_sum_approved = round(staging_sum_approved,3)

# COMMAND ----------

# comparing budid code and sum of amount gbp for review estimate b/w source and staging
print(compare_budid(source_review_budid_count,staging_review_budid_count))
print(compare_sum(source_sum_review,staging_sum_review))

# COMMAND ----------

# comparing budid code and sum of amount gbp for current estimate b/w source and staging
print(compare_budid(source_current_budid_count,staging_current_budid_count))
print(compare_sum(source_sum_current,staging_sum_current))

# COMMAND ----------

# comparing budid code and sum of amount gbp for approved estimate b/w source and staging
print(compare_budid(source_approved_budid_count,staging_approved_budid_count))
print(compare_sum(source_sum_approved,staging_sum_approved))

# COMMAND ----------

# log for missing bud id in review estimate
# getting column only in epe_source
new_df1 = epe_source_review.join(epe_staging_review, epe_staging_review.BUDID_CODE == epe_source_review.Project,'leftanti')
new_df1 = new_df1.select('project').distinct()
msg = ', '.join(map(str, [row['project'] for row in new_df1.collect() ]))
row = [row['project'] for row in new_df1.collect() ]
if len(row) == 0:
  logWarning('Notebook: hyp_recon, ' +'RunId: '+ str(runid) + ' - BUDID count for Forecast(review estimate) is matching today between Hyperion and OA ' + str(msg))
  review_bud_flag = True
else:
  logError('Notebook: hyp_recon, ' +'RunId: '+ str(runid) + ' - Following BUDID for Forcast(review estimate) are missing from OA:- ' + str(msg))
  review_bud_flag = False

# COMMAND ----------

# Sum off amount per budid in staging for review estimate
epe_staging_review.createOrReplaceTempView('staging_review')
query = '''
select  budid_code,cost_center_code,account_code,actual_or_estimate_code as scenario ,sum(amount_gbp) as amount
from staging_review
group by  budid_code,cost_center_code,account_code,actual_or_estimate_code
'''
epe_stag_rev = sqlContext.sql(query)

# Sum off amount per budid in source for review estimate
epe_source_review.createOrReplaceTempView('source_review')
query = '''
select  project,entity,account,scenario ,sum(amount) as amount
from source_review
group by  project,entity,account,scenario
'''
epe_source_rev = sqlContext.sql(query)

# Joining both the columns
epe_source_rev.createOrReplaceTempView('sr')
epe_stag_rev.createOrReplaceTempView('r')

query = '''
select * from r
join sr
on r.budid_code = sr.project and 
sr.entity = r.cost_center_code and 
sr.account = r.account_code
'''
x = sqlContext.sql(query)
x = x.withColumn('FLAG',(F.when((epe_source_rev.amount) == (epe_stag_rev.amount),'TRUE').when((epe_source_rev.amount) - (epe_stag_rev.amount) <= 0.9,'TRUE').otherwise('FALSE')))

msg = ', '.join(map(str, [row['project'] for row in x.collect() if row['FLAG'] == 'FALSE']))
row = [row['project'] for row in x.collect() if row['FLAG'] == 'FALSE']
if len(row) == 0:
  logWarning('Notebook: hyp_recon, ' +'RunID: ' + str(runid) +' - Forecast(review estimate) in OA and Hyperion is matching today. ')
  review_sum_flag = True
else:
  logError('Notebook: hyp_recon, ' +'RunID: ' + str(runid) +' Forecast(review estimate) in OA and Hyperion is not matching today for following budids:- ' + str(msg))
  review_sum_flag = False

# COMMAND ----------

if ((review_bud_flag == True) and (review_sum_flag == True)):
  review_flag = True
else:
  review_flag = False

# COMMAND ----------

# log for missing bud id for current estimate
# getting column only in epe_source for sceanrio current estimate
new_df1 = epe_source_current.join(epe_staging_current, epe_staging_current.BUDID_CODE == epe_source_current.Project,'leftanti')
new_df1 = new_df1.select('project').distinct()

msg = ', '.join(map(str, [row['project'] for row in new_df1.collect() ]))
row = [row['project'] for row in new_df1.collect() ]
if len(row) == 0:
  logWarning('Notebook: hyp_recon, ' + 'RunId: '+ str(runid) + ' - BUDID count for Forecast(current estimate) is matching today between Hyperion and OA ')
  current_bud_flag = True
else:
  logError('Notebook: hyp_recon, ' +'RunId: '+ str(runid) + ' - Following BUDID for Forcast(current estimate) are missing from OA  ' + str(msg))
  current_bud_flag = False

# COMMAND ----------

# Sum off amount per budid in staging for current estimate
epe_staging_current.createOrReplaceTempView('staging_current')
query = '''
select  budid_code,cost_center_code,account_code,actual_or_estimate_code as scenario ,sum(amount_gbp) as amount
from staging_current
group by  budid_code,cost_center_code,account_code,actual_or_estimate_code

'''
epe_stag_curr = sqlContext.sql(query)

# Sum off amount per budid in source for current estimate
epe_source_current.createOrReplaceTempView('source_current')
query = '''
select  project,entity,account,scenario ,sum(amount) as amount
from source_current
group by  project,entity,account,scenario
'''
epe_source_curr = sqlContext.sql(query)

# Joining both the columns
epe_source_curr.createOrReplaceTempView('sc')
epe_stag_curr.createOrReplaceTempView('c')

query = '''
select * from c
join sc
on c.budid_code = sc.project and 
sc.entity = c.cost_center_code and 
sc.account = c.account_code
'''
x = sqlContext.sql(query)
x = x.withColumn('FLAG',(F.when((epe_source_curr.amount) == (epe_stag_curr.amount),'TRUE').when((epe_source_curr.amount) - (epe_stag_curr.amount) <= 0.9,'TRUE').otherwise('FALSE')))

msg = ', '.join(map(str, [row['project'] for row in x.collect() if row['FLAG'] == 'FALSE']))
row = [row['project'] for row in x.collect() if row['FLAG'] == 'FALSE']
if len(row) == 0:
  logWarning('Notebook: hyp_recon, ' +'RunID: ' + str(runid) +' - Forecast(current estimate) in OA and Hyperion is matching today. ')
  current_sum_flag = True
else:
  logError('Notebook: hyp_recon, ' +'RunID: ' + str(runid) +' Forecast(current estimate) in OA and Hyperion is not matching today for following budids:- ' + str(msg))
  current_sum_flag = False

# COMMAND ----------

if ((current_bud_flag == True) and (current_sum_flag == True)):
  current_flag = True
else:
  current_flag = False

# COMMAND ----------

# log for missing bud id for approved estimate
# getting column only in epe_source for scenario approved estimate
new_df1 = epe_source_approved.join(epe_staging_approved, epe_staging_approved.BUDID_CODE == epe_source_approved.Project,'leftanti')
new_df1 = new_df1.select('project').distinct()

msg = ', '.join(map(str, [row['project'] for row in new_df1.collect() ]))
row = [row['project'] for row in new_df1.collect() ]
if len(row) == 0:
  logWarning('Notebook: hyp_recon, ' + 'RunId: '+ str(runid) + ' - BUDID count for Forecast(approved estimate) is matching today between Hyperion and OA ')
  approved_bud_flag = True
else:
  logError('Notebook: hyp_recon, ' +'RunId: '+ str(runid) + ' - Following BUDID for Forcast(approved estimate) are missing from OA  ' + str(msg))
  approved_bud_flag = False

# COMMAND ----------

# Sum off amount per budid in staging for approved estimate
epe_staging_approved.createOrReplaceTempView('staging_approved')
query = '''
select  budid_code,cost_center_code,account_code,actual_or_estimate_code as scenario ,sum(amount_gbp) as amount
from staging_approved
group by  budid_code,cost_center_code,account_code,actual_or_estimate_code
'''
epe_stag_appr = sqlContext.sql(query)

# Sum off amount per budid in source for approved estimate
epe_source_approved.createOrReplaceTempView('source_approved')
query = '''
select  project,entity,account,scenario ,sum(amount) as amount
from source_approved
group by  project,entity,account,scenario
'''
epe_source_appr = sqlContext.sql(query)

# Joining both the columns
epe_source_appr.createOrReplaceTempView('sa')
epe_stag_appr.createOrReplaceTempView('a')

query = '''
select * from a
join sa
on a.budid_code = sa.project and 
sa.entity = a.cost_center_code and 
sa.account = a.account_code
'''
x = sqlContext.sql(query)
x = x.withColumn('FLAG',(F.when((epe_source_appr.amount) == (epe_stag_appr.amount),'TRUE').when((epe_source_appr.amount) - (epe_stag_appr.amount) <= 0.9,'TRUE').otherwise('FALSE')))

msg = ', '.join(map(str, [row['project'] for row in x.collect() if row['FLAG'] == 'FALSE']))
row = [row['project'] for row in x.collect() if row['FLAG'] == 'FALSE']
if len(row) == 0:
  logWarning('Notebook: hyp_recon, ' +'RunID: ' + str(runid) +' - Forecast(approved estimate) in OA and Hyperion is matching today. ')
  approved_sum_flag = True
else:
  logError('Notebook: hyp_recon, ' +'RunID: ' + str(runid) +' Forecast(approved estimate) in OA and Hyperion is not matching today for following budids:- ' + str(msg))
  approved_sum_flag = False

# COMMAND ----------

if ((approved_bud_flag == True) and (approved_sum_flag == True)):
  approved_flag = True
else:
  approved_flag = False

# COMMAND ----------

if ((review_flag == True) and (current_flag == True) and (approved_flag == True)):
  forecast_flag = True
else:
  forecast_flag = False
  log_msg = log_msg + 'Forecast|'

# COMMAND ----------

# Loading EPE buget source data
epe_budget_source = spark.read.format('csv') \
      .option('header', 'true') \
      .option("inferSchema","false")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
    .load(foundation_path)

epe_budget_source = epe_budget_source.toDF(*(col.replace('\r', '') for col in epe_budget_source.columns))
for col_name in epe_budget_source.columns:
  epe_budget_source = epe_budget_source.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', '')) 

  
epe_budget_source = epe_budget_source.withColumn('Years', (2000 + F.regexp_extract(epe_budget_source.Years, r'\d+', 0)).cast(IntegerType()))  
epe_budget_source = epe_budget_source.withColumn('Project', F.regexp_replace(epe_budget_source.Project, 'PR.', ''))
epe_budget_source = epe_budget_source.withColumn('Entity', F.regexp_replace(epe_budget_source.Entity, 'CC.', ''))
epe_budget_source = epe_budget_source.withColumn('Account', F.regexp_replace(epe_budget_source.Account, 'AC.', ''))

# COMMAND ----------

# creating new df for scenario Budget - Hyperion Management Adjustments
epe_budget_hma = epe_budget_source.filter((epe_budget_source.Scenario == 'Budget - Hyperion Management Adjustments') & (epe_budget_source.Currency == 'GBP-Current-Budget'))

# creating new df for scenario Budget - Management Adjustments
epe_budget_ma = epe_budget_source.filter((epe_budget_source.Scenario == 'Budget - Management Adjustments') & (epe_budget_source.Currency == 'GBP-Current-Budget'))

# creating new df for scenario Budget - Source
epe_budget_s = epe_budget_source.filter((epe_budget_source.Scenario == 'Budget - Source') & (epe_budget_source.Currency == 'GBP-Current-Budget'))

# creating new df for scenario Update 1 - Hyperion Management Adjustments
epe_budget_u_one_hma = epe_budget_source.filter((epe_budget_source.Scenario == 'Update 1 - Hyperion Management Adjustments') & (epe_budget_source.Currency == 'GBP-Current-Budget'))

# creating new df for scenario Update 1 - Management Adjustments
epe_budget_u_one_ma = epe_budget_source.filter((epe_budget_source.Scenario == 'Update 1 - Management Adjustments') & (epe_budget_source.Currency == 'GBP-Current-Budget'))

# creating new df for scenario Update 1 - Source
epe_budget_u_one_s = epe_budget_source.filter((epe_budget_source.Scenario == 'Update 1 - Source') & (epe_budget_source.Currency == 'GBP-Current-Budget'))

# creating new df for scenario Update 2 - Hyperion Management Adjustments
epe_budget_u_two_hma = epe_budget_source.filter((epe_budget_source.Scenario == 'Update 2 - Hyperion Management Adjustments') & (epe_budget_source.Currency == 'GBP-Current-Budget'))

# creating new df for scenario Update 2 - Management Adjustments
epe_budget_u_two_ma = epe_budget_source.filter((epe_budget_source.Scenario == 'Update 2 - Management Adjustments') & (epe_budget_source.Currency == 'GBP-Current-Budget'))

# creating new df for scenario Update 2 - Source
epe_budget_u_two_s = epe_budget_source.filter((epe_budget_source.Scenario == 'Update 2 - Source') & (epe_budget_source.Currency == 'GBP-Current-Budget'))

# COMMAND ----------

# DBTITLE 1,EPE Budget Validation
# count of budid for Budget - Hyperion Management Adjustments in source
epe_budget_hma_budid_count = epe_budget_hma.select('project').distinct().count()

# getting sum for Budget - Hyperion Management Adjustments in source
epe_budget_hma.createOrReplaceTempView('bhma')

query = '''
select sum(amount) as sum_bhma from (
select  project,entity,account,scenario ,sum(amount) as amount
from bhma
group by  project,entity,account,scenario )
'''
source_sum_bhma = sqlContext.sql(query)
source_sum_bhma = source_sum_bhma.collect()
source_sum_bhma = float(source_sum_bhma[0][0])
source_sum_bhma = round(source_sum_bhma,3)

# COMMAND ----------

# count of budid for Budget -  Management Adjustments in source
epe_budget_ma_budid_count = epe_budget_ma.select('project').distinct().count()

# getting sum for Budget -  Management Adjustments in source
epe_budget_ma.createOrReplaceTempView('bma')

query = '''
select sum(amount) as sum_bma from (
select  project,entity,account,scenario ,sum(amount) as amount
from bma
group by  project,entity,account,scenario )
'''
source_sum_bma = sqlContext.sql(query)
source_sum_bma = source_sum_bma.collect()
source_sum_bma = float(source_sum_bma[0][0])
source_sum_bma = round(source_sum_bma,3)

# COMMAND ----------

# count of budid for Budget - Source in source

epe_budget_s_budid_count = epe_budget_s.select('project').distinct().count()

# getting sum for Budget -  Source in source
epe_budget_s.createOrReplaceTempView('bs')
query = '''
select sum(amount) as sum_bs from (
select  project,entity,account,scenario ,sum(amount) as amount
from bs
group by  project,entity,account,scenario )
'''
source_sum_bs = sqlContext.sql(query)
source_sum_bs = source_sum_bs.collect()
source_sum_bs = float(source_sum_bs[0][0])
source_sum_bs = round(source_sum_bs,3)

# COMMAND ----------

# count of budid for update 1 -hyperion managment adjustments for source 
epe_budget_u_one_hma_budid_count = epe_budget_u_one_hma.select('project').distinct().count()

# getting sum for update 1 - hyperion managment adjustments in source
epe_budget_u_one_hma.createOrReplaceTempView('buohma')
query = '''
select sum(amount) as sum_buohma from (
select  project,entity,account,scenario ,sum(amount) as amount
from buohma
group by  project,entity,account,scenario )
'''
source_sum_buohma = sqlContext.sql(query)
source_sum_buohma = source_sum_buohma.collect()
source_sum_buohma = float(source_sum_buohma[0][0])
source_sum_buohma = round(source_sum_buohma,3)

# COMMAND ----------

# count of budid for update 1 - managment adjustments in source
epe_budget_u_one_ma_budid_count = epe_budget_u_one_ma.select('project').distinct().count()

# getting sum for Update 1  -  Management Adjustments in source
epe_budget_u_one_ma.createOrReplaceTempView('buoma')

query = '''
select sum(amount) as sum_buoma from (
select  project,entity,account,scenario ,sum(amount) as amount
from buoma
group by  project,entity,account,scenario )
'''
source_sum_buoma = sqlContext.sql(query)
source_sum_buoma = source_sum_buoma.collect()
source_sum_buoma = float(source_sum_buoma[0][0])
source_sum_buoma = round(source_sum_buoma,3)

# COMMAND ----------

# count of budid for update 1  - Source
epe_budget_u_one_s_budid_count = epe_budget_u_one_s.select('project').distinct().count()

# getting sum for update 1 - source in source
epe_budget_u_one_s.createOrReplaceTempView('buos')
query = '''
select sum(amount) as sum_buos from (
select  project,entity,account,scenario ,sum(amount) as amount
from buos
group by  project,entity,account,scenario )
'''
source_sum_buos = sqlContext.sql(query)
source_sum_buos = source_sum_buos.collect()
source_sum_buos = float(source_sum_buos[0][0])
source_sum_buos = round(source_sum_buos,3)

# COMMAND ----------

# count of budid for update 2 - hyperion managment adjustments
epe_budget_u_two_hma_budid_count = epe_budget_u_two_hma.select('project').distinct().count()

# getting sum for update 2  - Hyperion  Management Adjustments in source
epe_budget_u_two_hma.createOrReplaceTempView('buthma')

query = '''
select sum(amount) as sum_buthma from (
select  project,entity,account,scenario ,sum(amount) as amount
from buthma
group by  project,entity,account,scenario )
'''

source_sum_buthma = sqlContext.sql(query)
source_sum_buthma = source_sum_buthma.collect()
source_sum_buthma = float(source_sum_buthma[0][0])
source_sum_buthma = round(source_sum_buthma,3)

# COMMAND ----------

# count of budid for update 2 - managment adjustments
epe_budget_u_two_ma_budid_count = epe_budget_u_two_ma.select('project').distinct().count()

# getting sum for update 2 -  Management Adjustments in source
epe_budget_u_two_ma.createOrReplaceTempView('butma')
query = '''
select sum(amount) as sum_butma from (
select  project,entity,account,scenario ,sum(amount) as amount
from butma
group by  project,entity,account,scenario )
'''
source_sum_butma = sqlContext.sql(query)
source_sum_butma = source_sum_butma.collect()
source_sum_butma = float(source_sum_butma[0][0])
source_sum_butma = round(source_sum_butma,3)

# COMMAND ----------

# count of budid for update 2  - Source
epe_budget_u_two_s_budid_count = epe_budget_u_two_s.select('project').distinct().count()

# getting sum for update 2 - source in source
epe_budget_u_two_s.createOrReplaceTempView('buts')
query = '''
select sum(amount) as sum_buts from (
select  project,entity,account,scenario ,sum(amount) as amount
from buts
group by  project,entity,account,scenario )
'''
source_sum_buts = sqlContext.sql(query)
source_sum_buts = source_sum_buts.collect()
source_sum_buts = float(source_sum_buts[0][0])
source_sum_buts = round(source_sum_buts,3)

# COMMAND ----------

# filtering staging table for hyperion budget 
# 1. for Budget - Hyperion Management Adjustments
epe_staging_b_hma = epe_staging.filter((epe_staging.SOURCE == 'Hyperion-Budget') & (epe_staging.COST_TYPE == 'EPE') & (epe_staging.ACTUAL_OR_ESTIMATE_CODE == 'Budget - Hyperion Management Adjustments') & (epe_staging.FISCYEAR >= str(min_year)))

# 2. for Budget - Management Adjustments
epe_staging_b_ma = epe_staging.filter((epe_staging.SOURCE == 'Hyperion-Budget') & (epe_staging.COST_TYPE == 'EPE') & (epe_staging.ACTUAL_OR_ESTIMATE_CODE == 'Budget - Management Adjustments') & (epe_staging.FISCYEAR >= str(min_year)))

# 3. for Budget - Source

epe_staging_b_s = epe_staging.filter((epe_staging.SOURCE == 'Hyperion-Budget') & (epe_staging.COST_TYPE == 'EPE') & (epe_staging.ACTUAL_OR_ESTIMATE_CODE == 'Budget - Source') & (epe_staging.FISCYEAR >= str(min_year)))

# 4. for Update 1 - Hyperion Management Adjustments
epe_staging_u_one_hma = epe_staging.filter((epe_staging.SOURCE == 'Hyperion-Budget') & (epe_staging.COST_TYPE == 'EPE') & (epe_staging.ACTUAL_OR_ESTIMATE_CODE == 'Update 1 - Hyperion Management Adjustments') & (epe_staging.FISCYEAR >= str(min_year)))

# 5. for update 1 - Management Adjustments
epe_staging_u_one_ma = epe_staging.filter((epe_staging.SOURCE == 'Hyperion-Budget') & (epe_staging.COST_TYPE == 'EPE') & (epe_staging.ACTUAL_OR_ESTIMATE_CODE == 'Update 1 - Management Adjustments') & (epe_staging.FISCYEAR >= str(min_year)))

# 6. for Update 1 - Source
epe_staging_u_one_s = epe_staging.filter((epe_staging.SOURCE == 'Hyperion-Budget') & (epe_staging.COST_TYPE == 'EPE') & (epe_staging.ACTUAL_OR_ESTIMATE_CODE == 'Update 1 - Source') & (epe_staging.FISCYEAR >= str(min_year)))

# 7. for update 2 - hyperion managment adjustments
epe_staging_u_two_hma = epe_staging.filter((epe_staging.SOURCE == 'Hyperion-Budget') & (epe_staging.COST_TYPE == 'EPE') & (epe_staging.ACTUAL_OR_ESTIMATE_CODE == 'Update 2 - Hyperion Management Adjustments') & (epe_staging.FISCYEAR >= str(min_year)))

# 8. for Update 2 - Management Adjustments
epe_staging_u_two_ma = epe_staging.filter((epe_staging.SOURCE == 'Hyperion-Budget') & (epe_staging.COST_TYPE == 'EPE') & (epe_staging.ACTUAL_OR_ESTIMATE_CODE == 'Update 2 - Management Adjustments') & (epe_staging.FISCYEAR >= str(min_year)))

# 9. for update 2 - source
epe_staging_u_two_s = epe_staging.filter((epe_staging.SOURCE == 'Hyperion-Budget') & (epe_staging.COST_TYPE == 'EPE') & (epe_staging.ACTUAL_OR_ESTIMATE_CODE == 'Update 2 - Source') & (epe_staging.FISCYEAR >= str(min_year)))

# COMMAND ----------

# count of budid for Budget - Hyperion Management Adjustmentsin staging
epe_staging_budget_hma_budid_count = epe_staging_b_hma.select('budid_code').distinct().count()

# getting sum for Budget - Hyperion Management Adjustments in staging
epe_staging_b_hma.createOrReplaceTempView('bhma')
query = '''
select sum(amount) as sum_bhma from (
select  budid_code,cost_center_code,account_code,actual_or_estimate_code as scenario ,sum(amount_gbp) as amount
from bhma
group by  budid_code,cost_center_code,account_code,actual_or_estimate_code )
'''
staging_sum_bhma = sqlContext.sql(query)
staging_sum_bhma = staging_sum_bhma.collect()
staging_sum_bhma = float(staging_sum_bhma[0][0])
staging_sum_bhma = round(staging_sum_bhma,3)

# COMMAND ----------

# count of budid for Budget -  Management Adjustments in staging
epe_staging_b_ma_budid_count = epe_staging_b_ma.select('budid_code').distinct().count()

# getting sum for Budget - Management Adjustments in staging
epe_staging_b_ma.createOrReplaceTempView('bma')
query = '''
select sum(amount) as sum_bma from (
select  budid_code,cost_center_code,account_code,actual_or_estimate_code as scenario ,sum(amount_gbp) as amount
from bma
group by  budid_code,cost_center_code,account_code,actual_or_estimate_code )
'''
staging_sum_bma = sqlContext.sql(query)
staging_sum_bma = staging_sum_bma.collect()
staging_sum_bma = float(staging_sum_bma[0][0])
staging_sum_bma = round(staging_sum_bma,3)

# COMMAND ----------

# count of budid for Budget -  source for staging
epe_staging_b_s_budid_count = epe_staging_b_s.select('budid_code').distinct().count()

# getting sum for Budget - source in staging
epe_staging_b_s.createOrReplaceTempView('bs')
query = '''
select sum(amount) as sum_bs from (
select  budid_code,cost_center_code,account_code,actual_or_estimate_code as scenario ,sum(amount_gbp) as amount
from bs
group by  budid_code,cost_center_code,account_code,actual_or_estimate_code )
'''
staging_sum_bs = sqlContext.sql(query)
staging_sum_bs = staging_sum_bs.collect()
staging_sum_bs = float(staging_sum_bs[0][0])
staging_sum_bs = round(staging_sum_bs,3)

# COMMAND ----------

# count of budid for Update 1 - Hyperion Management Adjustments in staging
epe_staging_u_one_hma_budid_count = epe_staging_u_one_hma.select('budid_code').distinct().count()

# getting sum for Update 1 - Hyperion Management Adjustments in staging
epe_staging_u_one_hma.createOrReplaceTempView('buohma')

query = '''
select sum(amount) as sum_buohma from (
select  budid_code,cost_center_code,account_code,actual_or_estimate_code as scenario ,sum(amount_gbp) as amount
from buohma
group by  budid_code,cost_center_code,account_code,actual_or_estimate_code )
'''
staging_sum_buohma = sqlContext.sql(query)
staging_sum_buohma = staging_sum_buohma.collect()
staging_sum_buohma = float(staging_sum_buohma[0][0])
staging_sum_buohma = round(staging_sum_buohma,3)

# COMMAND ----------

# count of budid for Update 1  -  Management Adjustments in Staging
epe_staging_u_one_ma_budid_count = epe_staging_u_one_ma.select('budid_code').distinct().count()

# getting sum for Update 1 - Management Adjustments in Staging
epe_staging_u_one_ma.createOrReplaceTempView('buoma')
query = '''
select sum(amount) as sum_buoma from (
select  budid_code,cost_center_code,account_code,actual_or_estimate_code as scenario ,sum(amount_gbp) as amount
from buoma
group by  budid_code,cost_center_code,account_code,actual_or_estimate_code )
'''
staging_sum_buoma = sqlContext.sql(query)
staging_sum_buoma = staging_sum_buoma.collect()
staging_sum_buoma = float(staging_sum_buoma[0][0])
staging_sum_buoma = round(staging_sum_buoma,3)

# COMMAND ----------

# count of budid for Update 1 -Source for staging 
epe_staging_u_one_s_budid_count = epe_staging_u_one_s.select('budid_code').distinct().count()

# getting sum for Update 1 - source for staging
epe_staging_u_one_s.createOrReplaceTempView('buos')
query = '''
select sum(amount) as sum_buos from (
select  budid_code,cost_center_code,account_code,actual_or_estimate_code as scenario ,sum(amount_gbp) as amount
from buos
group by  budid_code,cost_center_code,account_code,actual_or_estimate_code )
'''
staging_sum_buos = sqlContext.sql(query)
staging_sum_buos = staging_sum_buos.collect()
staging_sum_buos = float(staging_sum_buos[0][0])
staging_sum_buos = round(staging_sum_buos,3)

# COMMAND ----------

# count of budid for Update 2  - Hyperion  Management Adjustments in staging
epe_staging_u_two_hma_budid_count = epe_staging_u_two_hma.select('budid_code').distinct().count()

# getting sum for Update 2 - Hyperion Management Adjustments in staging
epe_staging_u_two_hma.createOrReplaceTempView('buthma')
query = '''
select sum(amount) as sum_buthma from (
select  budid_code,cost_center_code,account_code,actual_or_estimate_code as scenario ,sum(amount_gbp) as amount
from buthma
group by  budid_code,cost_center_code,account_code,actual_or_estimate_code )
'''
staging_sum_buthma = sqlContext.sql(query)
staging_sum_buthma = staging_sum_buthma.collect()
staging_sum_buthma = float(staging_sum_buthma[0][0])
staging_sum_buthma = round(staging_sum_buthma,3)

# COMMAND ----------

# count of budid for update 2 - Managment adjustments in staging
epe_staging_u_two_ma_budid_count = epe_staging_u_two_ma.select('budid_code').distinct().count()

# getting sum for update 2 - Management Adjustments in staging
epe_staging_u_two_ma.createOrReplaceTempView('butma')
query = '''
select sum(amount) as sum_butma from (
select  budid_code,cost_center_code,account_code,actual_or_estimate_code as scenario ,sum(amount_gbp) as amount
from butma
group by  budid_code,cost_center_code,account_code,actual_or_estimate_code )
'''
staging_sum_butma = sqlContext.sql(query)
staging_sum_butma = staging_sum_butma.collect()
staging_sum_butma = float(staging_sum_butma[0][0])
staging_sum_butma = round(staging_sum_butma,3)

# COMMAND ----------

# count of budid for Update 2 - source in staging
epe_staging_u_two_s_budid_count = epe_staging_u_two_s.select('budid_code').distinct().count()

# getting sum for update 2 - source in staging
epe_staging_u_two_s.createOrReplaceTempView('buts')
query = '''
select sum(amount) as sum_buts from (
select  budid_code,cost_center_code,account_code,actual_or_estimate_code as scenario ,sum(amount_gbp) as amount
from buts
group by  budid_code,cost_center_code,account_code,actual_or_estimate_code )
'''
staging_sum_buts = sqlContext.sql(query)
staging_sum_buts = staging_sum_buts.collect()
staging_sum_buts = float(staging_sum_buts[0][0])
staging_sum_buts = round(staging_sum_buts,3)

# COMMAND ----------

# log for missing bud id
# getting column only in epe_source
new_df1 = epe_budget_hma.join(epe_staging_b_hma, epe_staging_b_hma.BUDID_CODE == epe_budget_hma.Project,'leftanti')
new_df1 = new_df1.select('project').distinct()
msg = ', '.join(map(str, [row['project'] for row in new_df1.collect() ]))
row = [row['project'] for row in new_df1.collect() ]
if len(row) == 0:
  logWarning('Notebook: hyp_recon, ' + 'RunId: '+ str(runid) + ' - BUDID count for Budget(budget - hyperion managment adjustments) is matching today between Hyperion and OA ')
  bhma_bud_flag = True
else:
  logError('Notebook: hyp_recon, ' +'RunId: '+ str(runid) + ' - Following BUDID for Budget(budget - hyperion managment adjustments) are missing from OA  ' + str(msg))
  bhma_bud_flag = False

# COMMAND ----------

# Sum off amount per budid in staging for budget - hyperion managment adjustments
epe_staging_b_hma.createOrReplaceTempView('bhma')
query = '''
select  budid_code,cost_center_code,account_code,actual_or_estimate_code as scenario ,sum(amount_gbp) as amount
from bhma
group by  budid_code,cost_center_code,account_code,actual_or_estimate_code

'''
epe_staging_bhma = sqlContext.sql(query)
# display(activity_df)

# Sum off amount per budid in source for budget - hyperion managment adjustments
epe_budget_hma.createOrReplaceTempView('sbhma')
query = '''
select  project,entity,account,scenario ,sum(amount) as amount
from sbhma
group by  project,entity,account,scenario
'''
epe_source_hma = sqlContext.sql(query)

# Joining both the columns
epe_source_hma.createOrReplaceTempView('shma')
epe_staging_bhma.createOrReplaceTempView('hma')

query = '''
select * from hma
join shma
on hma.budid_code = shma.project and 
shma.entity = hma.cost_center_code and 
shma.account = hma.account_code
'''
x = sqlContext.sql(query)
x = x.withColumn('FLAG',(F.when((epe_source_hma.amount) == (epe_staging_bhma.amount),'TRUE').when((epe_source_hma.amount) - (epe_staging_bhma.amount) <= 0.9,'TRUE').otherwise('FALSE')))

msg = ', '.join(map(str, [row['project'] for row in x.collect() if row['FLAG'] == 'FALSE']))
row = [row['project'] for row in x.collect() if row['FLAG'] == 'FALSE']
if len(row) == 0:
  logWarning('Notebook: hyp_recon, ' +'RunID: ' + str(runid) +' - Budget(budget - hyperion managment adjustments) in OA and Hyperion is matching today. ')
  bhma_sum_flag = True
else:
  logError('Notebook: hyp_recon, ' +'RunID: ' + str(runid) +' Budget(budget - hyperion managment adjustments) in OA and Hyperion is not matching today for following budids:- ' + str(msg))
  bhma_sum_flag = False

# COMMAND ----------

if ((bhma_bud_flag == True) and (bhma_sum_flag == True)):
  bhma_flag = True
else:
  bhma_flag = False

# COMMAND ----------

#  for budget - managment adjustments.
# log for missing bud id
# getting column only in epe_source
new_df1 = epe_budget_ma.join(epe_staging_b_ma, epe_staging_b_ma.BUDID_CODE == epe_budget_ma.Project,'leftanti')
new_df1 = new_df1.select('project').distinct()
msg = ', '.join(map(str, [row['project'] for row in new_df1.collect() ]))
row = [row['project'] for row in new_df1.collect() ]
if len(row) == 0:
  logWarning('Notebook: hyp_recon, ' + 'RunId: '+ str(runid) + ' - BUDID count for Budget(budget - managment adjustments) is matching today between Hyperion and OA ')
  bma_bud_flag = True
else:
  logError('Notebook: hyp_recon, ' +'RunId: '+ str(runid) + ' - Following BUDID for Budget(budget - managment adjustments) are missing from OA:-  ' + str(msg))
  bma_bud_flag = False

# COMMAND ----------

#  for budget managment adjustments
# Sum off amount per budid in staging
epe_staging_b_ma.createOrReplaceTempView('bma')
query = '''
select  budid_code,cost_center_code,account_code,actual_or_estimate_code as scenario ,sum(amount_gbp) as amount
from bma
group by  budid_code,cost_center_code,account_code,actual_or_estimate_code
'''
epe_staging_bma = sqlContext.sql(query)

# Sum off amount per budid in source
epe_budget_ma.createOrReplaceTempView('sbma')
query = '''
select  project,entity,account,scenario ,sum(amount) as amount
from sbma
group by  project,entity,account,scenario
'''
epe_source_ma = sqlContext.sql(query)

# Joining both the columns
epe_source_ma.createOrReplaceTempView('sma')
epe_staging_bma.createOrReplaceTempView('ma')

query = '''
select * from ma
join sma
on ma.budid_code = sma.project and 
sma.entity = ma.cost_center_code and 
sma.account = ma.account_code
'''
x = sqlContext.sql(query)
x = x.withColumn('FLAG',(F.when((epe_source_ma.amount) == (epe_staging_bma.amount),'TRUE').when((epe_source_ma.amount) - (epe_staging_bma.amount) <= 0.9,'TRUE').otherwise('FALSE')))

msg = ', '.join(map(str, [row['project'] for row in x.collect() if row['FLAG'] == 'FALSE']))
row = [row['project'] for row in x.collect() if row['FLAG'] == 'FALSE']
# print(len(row))
if len(row) == 0:
  logWarning('Notebook: hyp_recon, ' +'RunID: ' + str(runid) +' - Budget(budget - managment adjustments) in OA and Hyperion is matching today. ')
  bma_sum_flag = True
else:
  logError('Notebook: hyp_recon, ' +'RunID: ' + str(runid) +' Budget(budget - managment adjustments) in OA and Hyperion is not matching today for following budids:- ' + str(msg))
  bma_sum_flag = False

# COMMAND ----------

if ((bma_bud_flag == True) and (bma_sum_flag == True)):
  bma_flag = True
else:
  bma_flag = False

# COMMAND ----------

#  for budget - source
# log for missing bud id
# getting column only in epe_source
new_df1 = epe_budget_s.join(epe_staging_b_s, epe_staging_b_s.BUDID_CODE == epe_budget_s.Project,'leftanti')
new_df1 = new_df1.select('project').distinct()
msg = ', '.join(map(str, [row['project'] for row in new_df1.collect() ]))
row = [row['project'] for row in new_df1.collect() ]
if len(row) == 0:
  logWarning('Notebook: hyp_recon, ' + 'RunId: '+ str(runid) + ' - BUDID count for Budget(budget - source) is matching today between Hyperion and OA ')
  bs_bud_flag = True
else:
  logError('Notebook: hyp_recon, ' +'RunId: '+ str(runid) + ' - Following BUDID for Budget(budget - source) are missing from OA:-  ' + str(msg))
  bs_bud_flag = False

# COMMAND ----------

#  for budget source
# Sum off amount per budid in staging
epe_staging_b_s.createOrReplaceTempView('bs')
query = '''
select  budid_code,cost_center_code,account_code,actual_or_estimate_code as scenario ,sum(amount_gbp) as amount
from bs
group by  budid_code,cost_center_code,account_code,actual_or_estimate_code
'''
epe_staging_s = sqlContext.sql(query)

# Sum off amount per budid in source
epe_budget_s.createOrReplaceTempView('ss')
query = '''
select  project,entity,account,scenario ,sum(amount) as amount
from ss
group by  project,entity,account,scenario
'''
epe_source_s = sqlContext.sql(query)

# Joining both the columns
epe_source_s.createOrReplaceTempView('ss')
epe_staging_s.createOrReplaceTempView('bs')

query = '''
select * from bs
join ss
on bs.budid_code = ss.project and 
ss.entity = bs.cost_center_code and 
ss.account = bs.account_code
'''
x = sqlContext.sql(query)
x = x.withColumn('FLAG',(F.when((epe_source_s.amount) == (epe_staging_s.amount),'TRUE').when((epe_source_s.amount) - (epe_staging_s.amount) <= 0.9,'TRUE').otherwise('FALSE')))
# display(x.filter('FLAG <> "TRUE"'))

msg = ', '.join(map(str, [row['project'] for row in x.collect() if row['FLAG'] == 'FALSE']))
row = [row['project'] for row in x.collect() if row['FLAG'] == 'FALSE']
if len(row) == 0:
  logWarning('Notebook: hyp_recon, ' +'RunID: ' + str(runid) +' - Budget(budget - source) in OA and Hyperion is matching today. ')
  bs_sum_flag = True
else:
  logError('Notebook: hyp_recon, ' +'RunID: ' + str(runid) +' Budget(budget - source) in OA and Hyperion is not matching today for following budids:- ' + str(msg))
  bs_sum_flag = False

# COMMAND ----------

if ((bs_bud_flag == True) and (bs_sum_flag == True)):
  bs_flag = True
else:
  bs_flag = False

# COMMAND ----------

if ((bhma_flag == True) and (bma_flag == True) and (bs_flag == True)):
  bud_flag = True
else:
  bud_flag = False

# COMMAND ----------

#  for update 1 - hyperion managment adjustments
# log for missing bud id
# getting column only in epe_source
new_df1 = epe_budget_u_one_hma.join(epe_staging_u_one_hma, epe_staging_u_one_hma.BUDID_CODE == epe_budget_u_one_hma.Project,'leftanti')
new_df1 = new_df1.select('project').distinct()
msg = ', '.join(map(str, [row['project'] for row in new_df1.collect() ]))
row = [row['project'] for row in new_df1.collect() ]
if len(row) == 0:
  logWarning('Notebook: hyp_recon, ' + 'RunId: '+ str(runid) + ' - BUDID count for Budget(update 1 - hyperion managment adjustments) is matching today between Hyperion and OA ')
  uohma_bud_flag = True
else:
  logError('Notebook: hyp_recon, ' +'RunId: '+ str(runid) + ' - Following BUDID for Budget(update 1 - hyperion managment adjustments) are missing from OA:-  ' + str(msg))
  uohma_bud_flag = False

# COMMAND ----------

#  for budget source
# Sum off amount per budid in staging
epe_staging_u_one_hma.createOrReplaceTempView('buohma')
query = '''
select  budid_code,cost_center_code,account_code,actual_or_estimate_code as scenario ,sum(amount_gbp) as amount
from buohma
group by  budid_code,cost_center_code,account_code,actual_or_estimate_code

'''
epe_staging_buohma = sqlContext.sql(query)


# Sum off amount per budid in source
epe_budget_u_one_hma.createOrReplaceTempView('sbuohma')
query = '''
select  project,entity,account,scenario ,sum(amount) as amount
from sbuohma
group by  project,entity,account,scenario
'''
epe_source_sbuohma = sqlContext.sql(query)

# Joining both the columns
epe_source_sbuohma.createOrReplaceTempView('suohma')
epe_staging_buohma.createOrReplaceTempView('uohma')

query = '''
select * from uohma
join suohma
on uohma.budid_code = suohma.project and 
suohma.entity = uohma.cost_center_code and 
suohma.account = uohma.account_code
'''
x = sqlContext.sql(query)
x = x.withColumn('FLAG',(F.when((epe_source_sbuohma.amount) == (epe_staging_buohma.amount),'TRUE').when((epe_source_sbuohma.amount) - (epe_staging_buohma.amount) <= 0.9,'TRUE').otherwise('FALSE')))

msg = ', '.join(map(str, [row['project'] for row in x.collect() if row['FLAG'] == 'FALSE']))
row = [row['project'] for row in x.collect() if row['FLAG'] == 'FALSE']
if len(row) == 0:
  logWarning('Notebook: hyp_recon, ' +'RunID: ' + str(runid) +' - Budget(update 1 - hyperion managment adjustments) in OA and Hyperion is matching today. ')
  uohma_sum_flag = True
else:
  logError('Notebook: hyp_recon, ' +'RunID: ' + str(runid) +' Budget(update 1 - hyperion managment adjustments) in OA and Hyperion is not matching today for following budids:- ' + str(msg))
  uohma_sum_flag = False

# COMMAND ----------

if ((uohma_bud_flag == True) and (uohma_sum_flag == True)):
  uohma_flag = True
else:
  uohma_flag = False

# COMMAND ----------

#  for update 1 -  managment adjustments
# log for missing bud id
# getting column only in epe_source
new_df1 = epe_budget_u_one_ma.join(epe_staging_u_one_ma, epe_staging_u_one_ma.BUDID_CODE == epe_budget_u_one_ma.Project,'leftanti')
new_df1 = new_df1.select('project').distinct()
msg = ', '.join(map(str, [row['project'] for row in new_df1.collect() ]))
row = [row['project'] for row in new_df1.collect() ]
if len(row) == 0:
  logWarning('Notebook: hyp_recon, ' + 'RunId: '+ str(runid) + ' - BUDID count for Budget(update 1 - managment adjustments) is matching today between Hyperion and OA ')
  uoma_bud_flag = True
else:
  logError('Notebook: hyp_recon, ' +'RunId: '+ str(runid) + ' - Following BUDID for Budget(update 1 - managment adjustments) are missing from OA:-  ' + str(msg))
  uoma_bud_flag = False

# COMMAND ----------

#  for update 1 - managment adjustments
# Sum off amount per budid in staging
epe_staging_u_one_ma.createOrReplaceTempView('buoma')
query = '''
select  budid_code,cost_center_code,account_code,actual_or_estimate_code as scenario ,sum(amount_gbp) as amount
from buoma
group by  budid_code,cost_center_code,account_code,actual_or_estimate_code
'''
epe_staging_buoma = sqlContext.sql(query)

# Sum off amount per budid in source
epe_budget_u_one_ma.createOrReplaceTempView('sbuoma')
query = '''
select  project,entity,account,scenario ,sum(amount) as amount
from sbuoma
group by  project,entity,account,scenario
'''
epe_source_sbuoma = sqlContext.sql(query)

# Joining both the columns
epe_source_sbuoma.createOrReplaceTempView('suoma')
epe_staging_buoma.createOrReplaceTempView('uoma')

query = '''
select * from uoma
join suoma
on uoma.budid_code = suoma.project and 
suoma.entity = uoma.cost_center_code and 
suoma.account = uoma.account_code
'''
x = sqlContext.sql(query)
x = x.withColumn('FLAG',(F.when((epe_source_sbuoma.amount) == (epe_staging_buoma.amount),'TRUE').when((epe_source_sbuoma.amount) - (epe_staging_buoma.amount) <= 0.9,'TRUE').otherwise('FALSE')))

msg = ', '.join(map(str, [row['project'] for row in x.collect() if row['FLAG'] == 'FALSE']))
row = [row['project'] for row in x.collect() if row['FLAG'] == 'FALSE']
if len(row) == 0:
  logWarning('Notebook: hyp_recon, ' +'RunID: ' + str(runid) +' - Budget(update 1 - managment adjustments) in OA and Hyperion is matching today. ')
  uoma_sum_flag = True
else:
  logError('Notebook: hyp_recon, ' +'RunID: ' + str(runid) +' Budget(update 1 - managment adjustments) in OA and Hyperion is not matching today for following budids:- ' + str(msg))
  uoma_sum_flag = False

# COMMAND ----------

if ((uoma_bud_flag == True) and (uoma_sum_flag == True)):
  uoma_flag = True
else:
  uoma_flag = False

# COMMAND ----------

#  for update 1 -  source
# log for missing bud id
# getting column only in epe_source
new_df1 = epe_budget_u_one_s.join(epe_staging_u_one_s, epe_staging_u_one_s.BUDID_CODE == epe_budget_u_one_s.Project,'leftanti')
new_df1 = new_df1.select('project').distinct()
msg = ', '.join(map(str, [row['project'] for row in new_df1.collect() ]))
row = [row['project'] for row in new_df1.collect() ]
if len(row) == 0:
  logWarning('Notebook: hyp_recon, ' + 'RunId: '+ str(runid) + ' - BUDID count for Budget(update 1 - source) is matching today between Hyperion and OA ')
  uos_bud_flag = True
else:
  logError('Notebook: hyp_recon, ' +'RunId: '+ str(runid) + ' - Following BUDID for Budget(update 1 - source) are missing from OA:-  ' + str(msg))
  uos_bud_flag = False

# COMMAND ----------

#  for update 1 - source
# Sum off amount per budid in staging
epe_staging_u_one_s.createOrReplaceTempView('buos')
query = '''
select  budid_code,cost_center_code,account_code,actual_or_estimate_code as scenario ,sum(amount_gbp) as amount
from buos
group by  budid_code,cost_center_code,account_code,actual_or_estimate_code

'''
epe_staging_buos = sqlContext.sql(query)

# Sum off amount per budid in source
epe_budget_u_one_s.createOrReplaceTempView('sbuos')
query = '''
select  project,entity,account,scenario ,sum(amount) as amount
from sbuos
group by  project,entity,account,scenario
'''
epe_source_sbuos = sqlContext.sql(query)

# Joining both the columns
epe_source_sbuos.createOrReplaceTempView('suos')
epe_staging_buos.createOrReplaceTempView('uos')

query = '''
select * from uos
join suos
on uos.budid_code = suos.project and 
suos.entity = uos.cost_center_code and 
suos.account = uos.account_code
'''
x = sqlContext.sql(query)
x = x.withColumn('FLAG',(F.when((epe_source_sbuos.amount) == (epe_staging_buos.amount),'TRUE').when((epe_source_sbuos.amount) - (epe_staging_buos.amount) <= 0.9,'TRUE').otherwise('FALSE')))

msg = ', '.join(map(str, [row['project'] for row in x.collect() if row['FLAG'] == 'FALSE']))
row = [row['project'] for row in x.collect() if row['FLAG'] == 'FALSE']
if len(row) == 0:
  logWarning('Notebook: hyp_recon, ' +'RunID: ' + str(runid) +' - Budget(update 1 - source) in OA and Hyperion is matching today. ')
  uos_sum_flag = True
else:
  logError('Notebook: hyp_recon, ' +'RunID: ' + str(runid) +' Budget(update 1 - source) in OA and Hyperion is not matching today for following budids:- ' + str(msg))
  uos_sum_flag = False

# COMMAND ----------

if ((uos_bud_flag == True) and (uos_sum_flag == True)):
  uos_flag = True
else:
  uos_flag = False

# COMMAND ----------

if ((uohma_flag == True) and (uoma_flag == True) and (uos_flag == True)):
  update_one_flag = True
else:
  update_one_flag = False

# COMMAND ----------

#  for update 2 - hyperion managment adjustments
# log for missing bud id
# getting column only in epe_source
new_df1 = epe_budget_u_two_hma.join(epe_staging_u_two_hma, epe_staging_u_two_hma.BUDID_CODE == epe_budget_u_two_hma.Project,'leftanti')
new_df1 = new_df1.select('project').distinct()
msg = ', '.join(map(str, [row['project'] for row in new_df1.collect() ]))
row = [row['project'] for row in new_df1.collect()]
if len(row) == 0:
  logWarning('Notebook: hyp_recon, ' + 'RunId: '+ str(runid) + ' - BUDID count for Budget(update 2 - hyperion managment adjustments) is matching today between Hyperion and OA ')
  uthma_bud_flag = True
else:
  logError('Notebook: hyp_recon, ' +'RunId: '+ str(runid) + ' - Following BUDID for Budget(update 2 - hyperion managment adjustments) are missing from OA:-  ' + str(msg))
  uthma_bud_flag = False

# COMMAND ----------

#  for update 2 - hyperion managment adjustments
# Sum off amount per budid in staging
epe_staging_u_two_hma.createOrReplaceTempView('buthma')
query = '''
select  budid_code,cost_center_code,account_code,actual_or_estimate_code as scenario ,sum(amount_gbp) as amount
from buthma
group by  budid_code,cost_center_code,account_code,actual_or_estimate_code

'''
epe_staging_buthma = sqlContext.sql(query)

# Sum off amount per budid in source
epe_budget_u_two_hma.createOrReplaceTempView('sbuthma')
query = '''
select  project,entity,account,scenario ,sum(amount) as amount
from sbuthma
group by  project,entity,account,scenario
'''
epe_source_sbuthma = sqlContext.sql(query)

# Joining both the columns
epe_source_sbuthma.createOrReplaceTempView('suthma')
epe_staging_buthma.createOrReplaceTempView('uthma')

query = '''
select * from uthma
join suthma
on uthma.budid_code = suthma.project and 
suthma.entity = uthma.cost_center_code and 
suthma.account = uthma.account_code
'''
x = sqlContext.sql(query)
x = x.withColumn('FLAG',(F.when((epe_source_sbuthma.amount) == (epe_staging_buthma.amount),'TRUE').when((epe_source_sbuthma.amount) - (epe_staging_buthma.amount) <= 0.9,'TRUE').otherwise('FALSE')))

msg = ', '.join(map(str, [row['project'] for row in x.collect() if row['FLAG'] == 'FALSE']))
row = [row['project'] for row in x.collect() if row['FLAG'] == 'FALSE']
if len(row) == 0:
  logWarning('Notebook: hyp_recon, ' +'RunID: ' + str(runid) +' - Budget(update 2 - hyperion managment adjustments) in OA and Hyperion is matching today. ')
  uthma_sum_flag = True
else:
  logError('Notebook: hyp_recon, ' +'RunID: ' + str(runid) +' Budget(update 2 - hyperion managment adjustments) in OA and Hyperion is not matching today for following budids:- ' + str(msg))
  uthma_sum_flag = False

# COMMAND ----------

if ((uthma_bud_flag == True) and (uthma_sum_flag == True)):
  uthma_flag = True
else:
  uthma_flag = False

# COMMAND ----------

#  for update 2 - managment adjustments
# log for missing bud id
# getting column only in epe_source
new_df1 = epe_budget_u_two_ma.join(epe_staging_u_two_ma, epe_staging_u_two_ma.BUDID_CODE == epe_budget_u_two_ma.Project,'leftanti')
new_df1 = new_df1.select('project').distinct()
msg = ', '.join(map(str, [row['project'] for row in new_df1.collect() ]))
row = [row['project'] for row in new_df1.collect()]
if len(row) == 0:
  logWarning('Notebook: hyp_recon, ' + 'RunId: '+ str(runid) + ' - BUDID count for Budget(update 2 -  managment adjustments) is matching today between Hyperion and OA ')
  utma_bud_flag = True
else:
  logError('Notebook: hyp_recon, ' +'RunId: '+ str(runid) + ' - Following BUDID for Budget(update 2 -  managment adjustments) are missing from OA:-  ' + str(msg))
  utma_bud_flag = False

# COMMAND ----------

#  for update 2 -  managment adjustments
# Sum off amount per budid in staging
epe_staging_u_two_ma.createOrReplaceTempView('butma')
query = '''
select  budid_code,cost_center_code,account_code,actual_or_estimate_code as scenario ,sum(amount_gbp) as amount
from butma
group by  budid_code,cost_center_code,account_code,actual_or_estimate_code
'''
epe_staging_butma = sqlContext.sql(query)

# Sum off amount per budid in source
epe_budget_u_two_ma.createOrReplaceTempView('sbutma')
query = '''
select  project,entity,account,scenario ,sum(amount) as amount
from sbutma
group by  project,entity,account,scenario
'''
epe_source_sbutma = sqlContext.sql(query)

# Joining both the columns
epe_source_sbutma.createOrReplaceTempView('sutma')
epe_staging_butma.createOrReplaceTempView('utma')

query = '''
select * from utma
join sutma
on utma.budid_code = sutma.project and 
sutma.entity = utma.cost_center_code and 
sutma.account = utma.account_code
'''
x = sqlContext.sql(query)
x = x.withColumn('FLAG',(F.when((epe_source_sbutma.amount) == (epe_staging_butma.amount),'TRUE').when((epe_source_sbutma.amount) - (epe_staging_butma.amount) <= 0.9,'TRUE').otherwise('FALSE')))

msg = ', '.join(map(str, [row['project'] for row in x.collect() if row['FLAG'] == 'FALSE']))
row = [row['project'] for row in x.collect() if row['FLAG'] == 'FALSE']
if len(row) == 0:
  logWarning('Notebook: hyp_recon, ' +'RunID: ' + str(runid) +' - Budget(update 2 - managment adjustments) in OA and Hyperion is matching today. ')
  utma_sum_flag = True
else:
  logError('Notebook: hyp_recon, ' +'RunID: ' + str(runid) +' Budget(update 2 - managment adjustments) in OA and Hyperion is not matching today for following budids:- ' + str(msg))
  utma_sum_flag = False

# COMMAND ----------

if ((utma_bud_flag == True) and (utma_sum_flag == True)):
  utma_flag = True
else:
  utma_flag = False

# COMMAND ----------

#  for update 2 -Source
# log for missing bud id
# getting column only in epe_source
new_df1 = epe_budget_u_two_s.join(epe_staging_u_two_s, epe_staging_u_two_s.BUDID_CODE == epe_budget_u_two_s.Project,'leftanti')
new_df1 = new_df1.select('project').distinct()
msg = ', '.join(map(str, [row['project'] for row in new_df1.collect() ]))
row = [row['project'] for row in new_df1.collect()]
if len(row) == 0:
  logWarning('Notebook: hyp_recon, ' + 'RunId: '+ str(runid) + ' - BUDID count for Budget(update 2 - source) is matching today between Hyperion and OA ')
  utos_bud_flag = True
else:
  logError('Notebook: hyp_recon, ' +'RunId: '+ str(runid) + ' - Following BUDID for Budget(update 2 - source) are missing from OA:-  ' + str(msg))
  utos_bud_flag = False

# COMMAND ----------

#  for update 2 -  Source
# Sum off amount per budid in staging
epe_staging_u_two_s.createOrReplaceTempView('buts')
query = '''
select  budid_code,cost_center_code,account_code,actual_or_estimate_code as scenario ,sum(amount_gbp) as amount
from buts
group by  budid_code,cost_center_code,account_code,actual_or_estimate_code
'''
epe_staging_buts = sqlContext.sql(query)

# Sum off amount per budid in source
epe_budget_u_two_s.createOrReplaceTempView('sbuts')
query = '''
select  project,entity,account,scenario ,sum(amount) as amount
from sbuts
group by  project,entity,account,scenario
'''
epe_source_sbuts = sqlContext.sql(query)

# Joining both the columns
epe_source_sbuts.createOrReplaceTempView('suts')
epe_staging_buts.createOrReplaceTempView('uts')

query = '''
select * from uts
join suts
on uts.budid_code = suts.project and 
suts.entity = uts.cost_center_code and 
suts.account = uts.account_code
'''
x = sqlContext.sql(query)
x = x.withColumn('FLAG',(F.when((epe_source_sbuts.amount) == (epe_staging_buts.amount),'TRUE').when((epe_source_sbuts.amount) - (epe_staging_buts.amount) <= 0.9,'TRUE').otherwise('FALSE')))

msg = ', '.join(map(str, [row['project'] for row in x.collect() if row['FLAG'] == 'FALSE']))
row = [row['project'] for row in x.collect() if row['FLAG'] == 'FALSE']
if len(row) == 0:
  logWarning('Notebook: hyp_recon, ' +'RunID: ' + str(runid) +' - Budget(update 2 - source) in OA and Hyperion is matching today. ')
  utos_sum_flag = True
else:
  logError('Notebook: hyp_recon, ' +'RunID: ' + str(runid) +' Budget(update 2 - source) in OA and Hyperion is not matching today for following budids:- ' + str(msg))
  utos_sum_flag = False

# COMMAND ----------

if((utos_bud_flag == True) and (utos_sum_flag == True)):
  utos_flag = True
else:
  utos_flag = False

# COMMAND ----------

if ((uthma_flag == True) and (utma_flag == True) and (utos_flag == True)):
  update_two_flag = True
else:
  update_two_flag = False

# COMMAND ----------

if ((bud_flag == True) and (update_one_flag == True) and (update_two_flag == True)):
  budget_flag = True
else:
  budget_flag = False
  log_msg = log_msg + 'Budget|'

# COMMAND ----------

if ((forecast_flag == True) and (budget_flag == True)):
  logInfo('Notebook: hyp_recon '+'RunID: ' + str(runid) + ' -There is no variance between OA and Hyperion for EPE budget and EPE forecast in ' + environment + ' environment.')
else:
  logInfo('Notebook: hyp_recon '+'RunID: ' + str(runid) + '-There is variance between OA and Hyperion for EPE' + log_msg + ' in ' + environment + ' environment.')

# COMMAND ----------

# comparing budid code and sum of amount gbp for budget - hyperion managment adjustments b/w source and staging
print(compare_budid(epe_budget_hma_budid_count,epe_staging_budget_hma_budid_count) + ' -for budget - hyperion managment adjustments')
print(compare_sum(source_sum_bhma,staging_sum_bhma) + ' -for budget - hyperion managment adjustments')

# COMMAND ----------

# comparing budid code and sum of amount gbp for budget - managment adjustments b/w source and staging
print(compare_budid(epe_budget_ma_budid_count,epe_staging_b_ma_budid_count)+ ' -for budget - managment adjustments')
print(compare_sum(source_sum_bma,staging_sum_bma)+ ' -for budget - managment adjustments')

# COMMAND ----------

# comparing budid code and sum of amount gbp for budget - source b/w source and staging
print(compare_budid(epe_budget_s_budid_count,epe_staging_b_s_budid_count)+ ' -for budget - source')
print(compare_sum(source_sum_bs,staging_sum_bs)+ ' -for budget - source')

# COMMAND ----------

# comparing budid code and sum of amount gbp for update 1 - hyperion managment adjustments b/w source and staging
print(compare_budid(epe_budget_u_one_hma_budid_count,epe_staging_u_one_hma_budid_count)+ ' -for update 1 - hyperion managment adjustments')
print(compare_sum(source_sum_buohma,staging_sum_buohma)+ ' -for update 1 - hyperion managment adjustments')

# COMMAND ----------

# comparing budid code and sum of amount gbp for update 1 - managment adjustments b/w source and staging
print(compare_budid(epe_budget_u_one_ma_budid_count,epe_staging_u_one_ma_budid_count)+ ' -for update 1 - managment adjustments')
print(compare_sum(source_sum_buoma,staging_sum_buoma)+ ' -for update 1 - managment adjustments')

# COMMAND ----------

# comparing budid code and sum of amount gbp for update 1 - source b/w source and staging
print(compare_budid(epe_budget_u_one_s_budid_count,epe_staging_u_one_s_budid_count)+ ' -for update 1 - source')
print(compare_sum(source_sum_buos,staging_sum_buos)+ ' -for update 1 - source')

# COMMAND ----------

# comparing budid code and sum of amount gbp for update 2 - hyperion managment adjustments b/w source and staging
print(compare_budid(epe_budget_u_two_hma_budid_count,epe_staging_u_two_hma_budid_count)+ ' -for update 2 - hyperion managment adjustments')
print(compare_sum(source_sum_buthma,staging_sum_buthma)+ ' -for update 2 - hyperion managment adjustments')

# COMMAND ----------

# comparing budid code and sum of amount gbp for update 2 - managment adjustments b/w source and staging
print(compare_budid(epe_budget_u_two_ma_budid_count,epe_staging_u_two_ma_budid_count)+ ' -for update 2 - managment adjustments')
print(compare_sum(source_sum_butma,staging_sum_butma)+ ' -for update 2 - managment adjustments')

# COMMAND ----------

# comparing budid code and sum of amount gbp for update 2 - managment adjustments b/w source and staging
print(compare_budid(epe_budget_u_two_s_budid_count,epe_staging_u_two_s_budid_count)+ ' -for update 2 - source')
print(compare_sum(source_sum_buts,staging_sum_buts)+ ' -for update 2 -source')