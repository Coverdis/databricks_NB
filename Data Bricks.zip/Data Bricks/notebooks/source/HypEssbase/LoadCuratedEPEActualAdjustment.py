# Databricks notebook source
#File Name:LoadCuratedEPEActualAdjustment
#ADF Pipeline Name: HypEssbase_ADL
#ADW Table name: NA
#Description:
  #Writes final file in curated layer

# COMMAND ----------

dbutils.widgets.text('runid', 'sdchs-dv83q-dsj22-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *

rawPath = 'dbfs:/mnt/raw/hyperion_essbase/'
foundationPath = 'dbfs:/mnt/foundation/hyperion_essbase/'
curatedPath = 'dbfs:/mnt/curated/hyperion_essbase/'

# COMMAND ----------

df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(foundationPath + "esb_epe_act_adj/esb_epe_act_adj.txt")

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

# COMMAND ----------

from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
# create a new dataframe if foundation file is empty
if len(df.columns)==0:
  schema = StructType([
      StructField("Project",StringType(),True),
      StructField("Entity",StringType(),True),
      StructField("Currency",StringType(),True),
      StructField("Scenario",StringType(),True),
      StructField("Years",StringType(),True),
      StructField("Version",StringType(),True),
      StructField("Account",StringType(),True),
      StructField("BegBalance",StringType(),True),
      StructField("Month",StringType(),True),
      StructField("Amount",StringType(),True)
  ])
  df = spark.createDataFrame(sc.emptyRDD(), schema)  

# COMMAND ----------

df = df.withColumn('Project', F.regexp_replace(df.Project, 'PR.', ''))
df = df.withColumn('Entity', F.regexp_replace(df.Entity, 'CC.', ''))
df = df.withColumn('Account', F.regexp_replace(df.Account, 'AC.', ''))

# COMMAND ----------

df = df.withColumnRenamed('Project', 'project_code')
df = df.withColumnRenamed('Entity', 'cost_center_code')
df = df.withColumnRenamed('Currency', 'currency')
df = df.withColumnRenamed('Scenario', 'scenario')
df = df.withColumnRenamed('Years', 'financial_year')
df = df.withColumnRenamed('Version', 'version')
df = df.withColumnRenamed('Account', 'account_code')
df = df.withColumnRenamed('BegBalance', 'beginning_balance')
df = df.withColumnRenamed('Month', 'month')
df = df.withColumnRenamed('Amount', 'adjustment_amount')

# COMMAND ----------

# write to curated

unique_run_id = runid + '-LoadCuratedEPEActualAdjustment/'
csv_temp_curated = rawPath + unique_run_id + 'curated/'

df.coalesce(1).write\
          .option("sep", "|")\
          .option("header", "true")\
          .option("quote",  '"')\
          .option("escape", '"')\
          .option("nullValue", "null")\
          .option("quoteAll", "true")\
          .mode('overwrite')\
        .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + "epe_actual_adjustment.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)