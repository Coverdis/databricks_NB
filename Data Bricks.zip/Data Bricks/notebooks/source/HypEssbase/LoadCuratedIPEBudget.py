# Databricks notebook source
# Load IPE_Budget data to curated

# COMMAND ----------

dbutils.widgets.text('runid', 'sdchs-dv83q-pasjs-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

dbutils.fs.cp('dbfs:/mnt/foundation/hyperion_essbase/esb_ipe_budu1u2u3/', 'dbfs:/mnt/curated/hyperion_essbase/esb_ipe_budu1u2u3/', recurse = True)