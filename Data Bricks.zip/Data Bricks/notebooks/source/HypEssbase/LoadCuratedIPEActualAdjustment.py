# Databricks notebook source
# Load IPE_Actual_Adjustment data to curated

# COMMAND ----------

dbutils.widgets.text('runid', 'sdchs-dv83q-c1xms-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

dbutils.fs.cp('dbfs:/mnt/foundation/hyperion_essbase/esb_ipe_act_adj/', 'dbfs:/mnt/curated/hyperion_essbase/esb_ipe_act_adj/', recurse = True)