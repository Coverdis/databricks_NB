# Databricks notebook source
#File Name: LoadCuratedPLWActivity
#ADF Pipeline Name: Planisware_ADL
#SQLDW Table: NA
#Description:
  #Store Planisware ACTIVITY data in curated layer of ADL
  #loadflag: full - will truncate and reload all the data in each layer
  #loadflag: incremental - will append the data to the existing in curated layer replacing the modified plans from the incremental load

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

# MAGIC %run /source/Planisware/PLWConfig

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
from pyspark.sql.functions import explode
import os
from glob import glob
import re

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "lry43-hrow2-vsio1-d3kdm")
dbutils.widgets.dropdown("fullloadflag", "true", ['true', 'false'])

runid = dbutils.widgets.get("runid")
fullloadflag = dbutils.widgets.get("fullloadflag")

# COMMAND ----------

# read activity data
activity = spark.read.format("csv")\
      .option("inferSchema","false")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/curated/planisware/new/plw_activity.txt')

activity = activity.toDF(*(col.replace('\r', '') for col in activity.columns))

# COMMAND ----------

# on full load the data loaded from curated will be deleted
if fullloadflag == 'true':
  activity = activity.limit(0)

# COMMAND ----------

# read delta activity data - having newly modified activities
delta_activity = spark.read.format("csv")\
      .option("inferSchema","false")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/planisware/new/plw_activity.txt')

delta_activity = delta_activity.toDF(*(col.replace('\r', '') for col in delta_activity.columns))

for col_name in delta_activity.columns:
  delta_activity = delta_activity.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ' '))
 

# code to convert all the column names to upper-case
delta_activity = delta_activity.toDF(*[c.upper() for c in delta_activity.columns])

# COMMAND ----------

# droppping below from df to avoid duplicacy issue
delta_activity = delta_activity.drop('ACTIVITY_PLANNED_START_DATE')
delta_activity = delta_activity.drop('ACTIVITY_PLANNED_END_DATE')
delta_activity = delta_activity.drop('CLINICAL_STUDY_ID')

# COMMAND ----------

delta_activity = delta_activity.withColumnRenamed('ACTIVITY_OBJECT_NUMBER', 'PERSISTANT_OBJECT_NUMBER')
delta_activity = delta_activity.withColumnRenamed('ACTIVITY_INTERNAL_NUMBER', 'ACTIVITY_OBJECT_NUMBER')

# delta_activity = delta_activity.withColumn('EXPORT_ID', F.lit(delta_activity.EXPORT_ID.cast(IntegerType())))

# COMMAND ----------

# max_exp_df = delta_activity.groupby('PLAN_INTERNAL_NUMBER').agg({'EXPORT_ID': 'max'})
# max_exp_df = max_exp_df.withColumnRenamed('max(EXPORT_ID)', 'MAX_EXPORT_ID')
# max_exp_df = max_exp_df.withColumnRenamed('PLAN_INTERNAL_NUMBER', 'PLAN_INTERNAL_NUMBER0')

# COMMAND ----------

# delta_activity = delta_activity.join(max_exp_df, (delta_activity.EXPORT_ID == max_exp_df['MAX_EXPORT_ID']) & (delta_activity.PLAN_INTERNAL_NUMBER == max_exp_df['PLAN_INTERNAL_NUMBER0']), 'rightouter')

# COMMAND ----------

delta_activity = delta_activity.drop('EXPORT_ID')

# COMMAND ----------

# column renaming and adding null references
delta_activity = colRename(new_act_dict , delta_activity)

delta_activity = addNullReference(delta_activity, spark.createDataFrame([activity_cols], activity_cols))

# COMMAND ----------

delta_activity = delta_activity.withColumn('WORK_PACKAGE_CODE', delta_activity.ACTIVITY_SUB_TYPE_NAME)

# COMMAND ----------

#create a date which is non null based on actual and planned dates
delta_activity = delta_activity.withColumn('MilestoneDate',(F.when(delta_activity.ACTIVITY_ACTUAL_END_DATE.isNotNull(), delta_activity.ACTIVITY_ACTUAL_END_DATE) .when(delta_activity.ACTIVITY_ACTUAL_START_DATE.isNotNull(),delta_activity.ACTIVITY_ACTUAL_START_DATE).when(delta_activity.ACTIVITY_PLANNED_END_DATE.isNotNull(),delta_activity.ACTIVITY_PLANNED_END_DATE).otherwise(delta_activity.ACTIVITY_PLANNED_START_DATE)))

#create date which is non null based on planned dates
delta_activity = delta_activity.withColumn('PlannedMilestoneDate',(F.when(delta_activity.ACTIVITY_PLANNED_END_DATE.isNotNull(),delta_activity.ACTIVITY_PLANNED_END_DATE).otherwise(delta_activity.ACTIVITY_PLANNED_START_DATE)))

#create date which is non null based on actual dates
delta_activity=delta_activity.withColumn('ActualMilestoneDate',(F.when(delta_activity.ACTIVITY_ACTUAL_END_DATE.isNotNull(),delta_activity.ACTIVITY_ACTUAL_END_DATE).otherwise(delta_activity.ACTIVITY_ACTUAL_START_DATE)))

# COMMAND ----------

#create a date which is non null based on actual and planned dates
delta_activity = delta_activity.withColumn('InflectionDate',(F.when(delta_activity.ACTIVITY_ACTUAL_END_DATE.isNotNull(), delta_activity.ACTIVITY_ACTUAL_END_DATE) .when(delta_activity.ACTIVITY_ACTUAL_START_DATE.isNotNull(),delta_activity.ACTIVITY_ACTUAL_START_DATE).when(delta_activity.ACTIVITY_PLANNED_END_DATE.isNotNull(),delta_activity.ACTIVITY_PLANNED_END_DATE).otherwise(delta_activity.ACTIVITY_PLANNED_START_DATE)))

#create date which is non null based on planned dates
delta_activity = delta_activity.withColumn('PlannedInflectionDate',(F.when(delta_activity.ACTIVITY_PLANNED_END_DATE.isNotNull(),delta_activity.ACTIVITY_PLANNED_END_DATE).otherwise(delta_activity.ACTIVITY_PLANNED_START_DATE)))

#create date which is non null based on actual dates
delta_activity=delta_activity.withColumn('ActualInflectionDate',(F.when(delta_activity.ACTIVITY_ACTUAL_END_DATE.isNotNull(),delta_activity.ACTIVITY_ACTUAL_END_DATE).otherwise(delta_activity.ACTIVITY_ACTUAL_START_DATE)))

# COMMAND ----------

delta_activity = delta_activity.withColumn("ACTIVITY_LINE_ID", delta_activity['ACTIVITY_LINE_ID'].cast(IntegerType()))

# COMMAND ----------

mapping = spark.read.format("csv")\
        .option("inferSchema", "false")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter",",")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
    .load("dbfs:/mnt/curated/dish/PDR_DEX_Milestone_PLW-NEW.csv")

mapping=mapping.drop('PLANISWARE_ACTIVITY_TYPE')
mapping=mapping.withColumnRenamed('NEW_PLW_ACTIVITY_TYPE','PLANISWARE_ACTIVITY_TYPE')
mapping=mapping.select('PLANISWARE_ACTIVITY_TYPE','MILESTONE_SORT_ORDER')
mapping = mapping.withColumn("MILESTONE_SORT_ORDER", mapping['MILESTONE_SORT_ORDER'].cast(IntegerType()))

# COMMAND ----------

delta_activity = delta_activity.join(mapping, delta_activity.WBS_TYPE == mapping.PLANISWARE_ACTIVITY_TYPE, 'left')

# COMMAND ----------

# condition for milestone fields
# condition_first_submission_milestone = F.upper(delta_activity.ACTIVITY_SCOPE_NAME).contains('PROJECT MILESTONE') & F.upper(delta_activity.ACTIVITY_SUB_TYPE_NAME).contains('SUBMIT')
# condition_first_approval_milestone = F.upper(delta_activity.ACTIVITY_SCOPE_NAME).contains('PROJECT MILESTONE') & F.upper(delta_activity.ACTIVITY_SUB_TYPE_NAME).contains('APPROVAL')
# condition_first_launch_milestone = F.upper(delta_activity.ACTIVITY_SCOPE_NAME).contains('PROJECT MILESTONE') & F.upper(delta_activity.ACTIVITY_SUB_TYPE_NAME).contains('LAUNCH')

condition_next_planned_milestone = F.upper(delta_activity.ACTIVITY_SCOPE_NAME).contains('PROJECT MILESTONE') & delta_activity.ACTIVITY_ACTUAL_START_DATE.isNull() & delta_activity.ACTIVITY_ACTUAL_END_DATE.isNull()

condition_next_planned_decision_point_milestone = F.upper(delta_activity.ACTIVITY_SCOPE_NAME).contains('PROJECT MILESTONE') & F.upper(delta_activity.ACTIVITY_SUB_TYPE_NAME).contains('COMMIT') & delta_activity.ACTIVITY_ACTUAL_START_DATE.isNull() & delta_activity.ACTIVITY_ACTUAL_END_DATE.isNull()
condition_latest_achieved_milestone = F.upper(delta_activity.ACTIVITY_SCOPE_NAME).contains('PROJECT MILESTONE') & delta_activity.ActualMilestoneDate.isNotNull()
condition_latest_achieved_commit_to_milestone = F.upper(delta_activity.ACTIVITY_SCOPE_NAME).contains('PROJECT MILESTONE') & F.upper(delta_activity.ACTIVITY_SUB_TYPE_NAME).contains('COMMIT') & delta_activity.ActualMilestoneDate.isNotNull()

# ranking for milestone fields
# rank_first_submission_milestone = Window.partitionBy('PLAN_OBJECT_NUMBER').orderBy(*[F.when(condition_first_submission_milestone, F.lit(1)).desc(), delta_activity.MilestoneDate])
# rank_first_approval_milestone = Window.partitionBy('PLAN_OBJECT_NUMBER').orderBy(*[F.when(condition_first_approval_milestone, F.lit(1)).desc(), delta_activity.MilestoneDate])
# rank_first_launch_milestone = Window.partitionBy('PLAN_OBJECT_NUMBER').orderBy(*[F.when(condition_first_launch_milestone, F.lit(1)).desc(), delta_activity.MilestoneDate])

rank_next_planned_milestone = Window.partitionBy('PLAN_OBJECT_NUMBER').orderBy(*[F.when(condition_next_planned_milestone, F.lit(1)).desc(), delta_activity.PlannedMilestoneDate,delta_activity.MILESTONE_SORT_ORDER,delta_activity.ACTIVITY_LINE_ID])

rank_next_planned_decision_point_milestone = Window.partitionBy('PLAN_OBJECT_NUMBER').orderBy(*[F.when(condition_next_planned_decision_point_milestone, F.lit(1)).desc(), delta_activity.PlannedMilestoneDate])

rank_latest_achieved_milestone = Window.partitionBy('PLAN_OBJECT_NUMBER').orderBy(*[F.when(condition_latest_achieved_milestone, F.lit(1)).desc(), delta_activity.ActualMilestoneDate.desc()])

rank_latest_achieved_commit_to_milestone = Window.partitionBy('PLAN_OBJECT_NUMBER').orderBy(*[F.when(condition_latest_achieved_commit_to_milestone, F.lit(1)).desc(), delta_activity.ActualMilestoneDate.desc()])

# creating calculated milestone fields
# delta_activity = delta_activity.withColumn('FIRST_SUBMISSION_MILESTONE', F.when(condition_first_submission_milestone, F.rank().over(rank_first_submission_milestone)))
# delta_activity = delta_activity.withColumn('FIRST_SUBMISSION_MILESTONE', F.when(delta_activity.FIRST_SUBMISSION_MILESTONE == 1, 'True').otherwise('False')) 

# delta_activity = delta_activity.withColumn('FIRST_APPROVAL_MILESTONE', F.when(condition_first_approval_milestone, F.rank().over(rank_first_approval_milestone)))
# delta_activity = delta_activity.withColumn('FIRST_APPROVAL_MILESTONE', F.when(delta_activity.FIRST_APPROVAL_MILESTONE == 1, 'True').otherwise('False')) 

# delta_activity = delta_activity.withColumn('FIRST_LAUNCH_MILESTONE', F.when(condition_first_launch_milestone, F.rank().over(rank_first_launch_milestone)))
# delta_activity = delta_activity.withColumn('FIRST_LAUNCH_MILESTONE', F.when(delta_activity.FIRST_LAUNCH_MILESTONE == 1, 'True').otherwise('False')) 

delta_activity = delta_activity.withColumn('NEXT_PLANNED_MILESTONE', F.when(condition_next_planned_milestone, F.rank().over(rank_next_planned_milestone)))
delta_activity = delta_activity.withColumn('NEXT_PLANNED_MILESTONE', F.when(delta_activity.NEXT_PLANNED_MILESTONE == 1, 'True').otherwise('False')) 

delta_activity = delta_activity.withColumn('NEXT_PLANNED_DECISION_POINT_MILESTONE', F.when(condition_next_planned_decision_point_milestone, F.rank().over(rank_next_planned_decision_point_milestone)))
delta_activity = delta_activity.withColumn('NEXT_PLANNED_DECISION_POINT_MILESTONE', F.when(delta_activity.NEXT_PLANNED_DECISION_POINT_MILESTONE == 1, 'True').otherwise('False')) 

delta_activity = delta_activity.withColumn('LATEST_ACHIEVED_MILESTONE', F.when(condition_latest_achieved_milestone, F.rank().over(rank_latest_achieved_milestone)))
delta_activity = delta_activity.withColumn('LATEST_ACHIEVED_MILESTONE', F.when(delta_activity.LATEST_ACHIEVED_MILESTONE == 1, 'True').otherwise('False')) 

delta_activity = delta_activity.withColumn('LATEST_ACHIEVED_COMMIT_TO_MILESTONE', F.when(condition_latest_achieved_commit_to_milestone, F.rank().over(rank_latest_achieved_commit_to_milestone)))
delta_activity = delta_activity.withColumn('LATEST_ACHIEVED_COMMIT_TO_MILESTONE', F.when(delta_activity.LATEST_ACHIEVED_COMMIT_TO_MILESTONE == 1, 'True').otherwise('False'))

# COMMAND ----------

# condition for inflection fields
condition_next_planned_inflection_point = F.upper(delta_activity.WORK_PACKAGE_CODE).contains('INFLECTION') & delta_activity.ACTIVITY_ACTUAL_START_DATE.isNull() & delta_activity.ACTIVITY_ACTUAL_END_DATE.isNull()

# ranking inflection field
rank_next_planned_inflection = Window.partitionBy('PLAN_OBJECT_NUMBER').orderBy(*[F.when(condition_next_planned_inflection_point, F.lit(1)).desc(), delta_activity.PlannedInflectionDate])

# creating calculated inflection field
delta_activity = delta_activity.withColumn('NEXT_PLANNED_INFLECTION_POINT', F.when(condition_next_planned_inflection_point, F.rank().over(rank_next_planned_inflection)))
delta_activity = delta_activity.withColumn('NEXT_PLANNED_INFLECTION_POINT', F.when(delta_activity.NEXT_PLANNED_INFLECTION_POINT == 1, 'True').otherwise('False')) 

# COMMAND ----------

delta_activity = delta_activity.select(activity_cols)

# adding null reference to curated file if a new column is being added
if len(delta_activity.columns) != len(activity.columns):
  activity = addNullReference(activity, spark.createDataFrame([activity_cols], activity_cols))
activity = activity.select(activity_cols)

# COMMAND ----------

# appending newly modified activities to the activity df
act = activity.join(delta_activity, activity.PLAN_OBJECT_NUMBER == delta_activity.PLAN_OBJECT_NUMBER, 'leftanti')
activity = act.union(delta_activity)

# COMMAND ----------

# replace flag values with true/false
activity = activity.withColumn("WBS_ELEMENT_FLAG", F.when(activity.WBS_ELEMENT_FLAG=="YES",'true').otherwise("false"))

# COMMAND ----------

activity = activity.withColumn('SOURCE', F.lit('PLW-NEW').cast(StringType()))

# COMMAND ----------

# loading the file with all deleted flagged plans
deletedPlans = spark.read.format("csv")\
      .option("inferSchema","false")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/planisware/new/plw_plan_deleted.txt')

deletedPlans = deletedPlans.toDF(*(col.replace('\r', '') for col in deletedPlans.columns))
print(deletedPlans.count())

# COMMAND ----------

# removing all deletd plans from the activity df
activity = activity.join(deletedPlans, activity.PLAN_OBJECT_NUMBER == deletedPlans.PLAN_INTERNAL_NUMBER, 'leftanti')
print(activity.count())

# COMMAND ----------

for field in activity_date_fields:
  activity = activity.withColumn(field, activity[field].cast(TimestampType()))

# COMMAND ----------

activity = activity.select(activity_cols)

# COMMAND ----------

# write to curated
rawPath = 'dbfs:/mnt/raw/planisware/'
unique_run_id = runid + '-LoadCuratedPLWActivity/'
csv_temp_curated = rawPath + unique_run_id
curatedPath = 'dbfs:/mnt/curated/planisware/new/'

activity.repartition(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + "plw_activity.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)