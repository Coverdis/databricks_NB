# Databricks notebook source
#File Name: LoadCuratedPLWEPEForecast
#ADF Pipeline Name: Planisware_ADL
#SQLDW Table: NA
#Description:
  #Store Planisware EPE data in curated layer of ADL
  #loadflag: full - will truncate and reload all the data in each layer
  #loadflag: incremental - will append the data to the existing in curated layer replacing the modified plans from the incremental load

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
from pyspark.sql.functions import explode
import os
from glob import glob
import re

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "")
dbutils.widgets.dropdown("baselineflag", "false", ['true', 'false'])
dbutils.widgets.text("reference_object_number", "")
dbutils.widgets.dropdown("fullloadflag", "true", ['true', 'false'])

runid = dbutils.widgets.get("runid")
baselineflag=dbutils.widgets.get("baselineflag")
referenceobjectnumber=dbutils.widgets.get("reference_object_number")
fullloadflag = dbutils.widgets.get("fullloadflag") # this is only applicable for non baseline data

# COMMAND ----------

if baselineflag=='true':
  sourcefilepath='foundation/planisware/new/reference_epe_forecast/'+referenceobjectnumber+'.json'
  targetfilepath='curated/planisware/new/reference_epe_forecast/'+referenceobjectnumber+'.txt'
  expense_json = spark.read.format("json")\
          .option("multiLine","true")\
          .option("nullValue","null")\
    .load('dbfs:/mnt/'+sourcefilepath)

  expense_json=expense_json.withColumnRenamed('@odata.context','context')
  #convert json array in to column
  tempDf = expense_json.select(explode("value").alias("value_exploded"))
  if len(tempDf.collect())==0: dbutils.notebook.exit('EmptyEPEJSON')
  expense = tempDf.selectExpr( 'value_exploded.*')
  expense=expense.drop('@odata.id')


# COMMAND ----------

if baselineflag != 'true':
  # read cost forecast data from curated layer
  epe = spark.read.format("csv")\
        .option("inferSchema","false")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
      .load('dbfs:/mnt/curated/planisware/new/epe_forecast.txt')

  epe = epe.toDF(*(col.replace('\r', '') for col in epe.columns))

# COMMAND ----------

if baselineflag != 'true' and fullloadflag == 'true':
  epe = epe.limit(0)

# COMMAND ----------

if baselineflag!='true': 
  sourcefilepath='foundation/planisware/new/epe_forecast/epe_forecast.txt'
  targetfilepath='curated/planisware/new/epe_forecast.txt'
  expense = spark.read.format('csv')\
      .option("inferSchema", "false")\
      .option("header", "true")\
      .option("multiLine", "true")\
      .option("delimiter", "|")\
      .option("quote", '"')\
      .option("escape", '"')\
      .option("nullValue", "null")\
    .load('dbfs:/mnt/'+ sourcefilepath)

  expense = expense.toDF(*(col.replace('\r', '') for col in expense.columns))
  #--create/update entry in DW log table
#   sql="Update DW_load_log set Last_execution='"+ planisware_status_date +"' where Table_name='prod_stage.cost_forecast_master'"
#   dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})  

# COMMAND ----------

# rename fields
expense = expense.withColumnRenamed('COST_ACCT_NAME', 'COST_BREAKDOWN_STRUCTURE')
expense = expense.withColumnRenamed('AEAC_GBP', 'AMOUNT_LOC') 
expense = expense.withColumnRenamed('start_date', 'GL_PERIOD') 
expense = expense.withColumnRenamed('end_date', 'END_MONTH')
expense = expense.withColumnRenamed('PROJECT_GROUP', 'PROJECT_ID') 
expense = expense.withColumnRenamed('PLAN_TYPE', 'PLAN_TYPE') 

expense = expense.withColumnRenamed('PROJECT_ONB', 'PLAN_OBJECT_NUMBER')
expense = expense.withColumnRenamed('PLANNED_NUM_PT', 'work_structure_num_of_pt')
expense = expense.withColumnRenamed('ACTIVITY_ONB', 'ACTIVITY_OBJECT_NUMBER') 
expense = expense.withColumnRenamed('STUDY_NB', 'CLINICAL_STUDY_ID') 
#expense = expense.withColumnRenamed('work_structure_gsk_ra_act_study_phase', 'plan_phase_name')
expense = expense.withColumnRenamed('ACT_RES_ID', 'ACTIVITY_RESOURCE_ID') 
expense = expense.withColumnRenamed('act_ledger_code_prop', 'LEDGER_CODE')
expense = expense.withColumnRenamed('COST_CENTER_NAME', 'COST_CENTER_CODE')

expense = expense.withColumnRenamed('ACTIVITY_NAME', 'activity_name') 
expense = expense.withColumnRenamed('ACTIVITY_TYPE', 'wbs_type')
expense = expense.withColumnRenamed('REFERENCE_ONB', 'REFERENCE_OBJECT_NUMBER')

if baselineflag!='true':  
  expense = expense.withColumn('REFERENCE_OBJECT_NUMBER',F.lit(None).cast(IntegerType()))
  expense = expense.withColumnRenamed('cost_acct_desc', 'ACCOUNT_CODE')
  expense = expense.withColumnRenamed('po', 'PURCHASE_DOCUMENT_NUMBER')
  expense = expense.withColumnRenamed('po_comments', 'PURCHASE_DOCUMENT_NUMBER_COMMENTS')
  #expense = expense.withColumn("GL_PERIOD", F.to_date(expense['GL_PERIOD'], "mm/dd/yyyy"))
  #expense = expense.withColumn("END_MONTH", F.to_date(expense['END_MONTH'], "mm/dd/yyyy"))
  
if baselineflag=='true':  
  expense = expense.withColumn('ACCOUNT_CODE',F.lit(None).cast(StringType()))
  expense = expense.withColumn('PURCHASE_DOCUMENT_NUMBER',F.lit(None).cast(IntegerType()))
  expense = expense.withColumn('PURCHASE_DOCUMENT_NUMBER_COMMENTS',F.lit(None).cast(StringType()))
  expense = expense.withColumn("GL_PERIOD", F.to_date(expense['GL_PERIOD'], "dd-MMM-yyyy"))
  expense = expense.withColumn("END_MONTH", F.to_date(expense['END_MONTH'], "dd-MMM-yyyy"))
  


expense = expense.withColumn('CURRENCY_CODE',F.lit('GBP').cast(StringType()))
expense = expense.withColumn("AMOUNT_LOC", expense.AMOUNT_LOC.cast("Decimal(31,5)"))
expense = expense.withColumn('AMOUNT_GBP', expense['AMOUNT_LOC'])
expense = expense.withColumn('ACTUAL_OR_ESTIMATE_CODE', F.lit('Forecast').cast(StringType()))
expense = expense.withColumn('COST_TYPE', F.lit('EPE').cast(StringType()))
expense = expense.withColumn('SOURCE', F.lit('PLW-NEW').cast(StringType()))

expense = expense.withColumn('FISCMONTH', F.month(expense['GL_PERIOD']))
expense = expense.withColumn('FISCYEAR', F.year(expense['GL_PERIOD']))

# COMMAND ----------

if baselineflag != 'true':
  expense = expense.union(epe)

# COMMAND ----------

if baselineflag != 'true':
  # loading the file with all deleted flagged plans using pp_deleted_date from planisware table
  deletedPlans = spark.read.format("csv")\
        .option("inferSchema","false")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/planisware/new/plw_plan_deleted.txt')

  deletedPlans = deletedPlans.toDF(*(col.replace('\r', '') for col in deletedPlans.columns))
  print(deletedPlans.count())

# COMMAND ----------

if baselineflag != 'true':
  # removing all deletd plans from df
  expense = expense.join(deletedPlans, expense.PLAN_OBJECT_NUMBER == deletedPlans.PLAN_INTERNAL_NUMBER, 'leftanti')
  print(expense.count())

# COMMAND ----------

# write to curated
rawPath = 'dbfs:/mnt/raw/planisware/'
unique_run_id = runid + '-LoadCuratedPLWEPEForecast/'
if baselineflag=='true': unique_run_id=runid + referenceobjectnumber + '-LoadCuratedPLWEPEForecast/'
csv_temp_curated = rawPath + unique_run_id
curatedPath = 'dbfs:/mnt/curated/planisware/new/'

expense.repartition(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], 'dbfs:/mnt/' + targetfilepath, recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)

# COMMAND ----------

dbutils.notebook.exit('Success')