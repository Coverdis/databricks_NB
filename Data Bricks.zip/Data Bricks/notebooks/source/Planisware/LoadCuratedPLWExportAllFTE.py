# Databricks notebook source
#File Name: LoadCuratedPLWExportAllFTE
#ADF Pipeline Name: Planisware_Legacy_ADL
#SQLDW Table: NA
  #Read Legacy Planisware Resource Forecast data from ADL and load to curated layer

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

# MAGIC %run /library/logs

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "111")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

# read new project data file 1
plw_res = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/planisware/plw_export_all_fte.txt')

if plw_res.count() == 0:
  logWarning('LoadCuratedPLWExportAllFTE: foundation/planisware/plw_export_all_fte.txt is empty')
else:
  logDebug('LoadCuratedPLWExportAllFTE: foundation/planisware/plw_export_all_fte.txt rows: ' + str(plw_res.count()))
  
plw_res = plw_res.toDF(*(col.upper().replace('\r', '') for col in plw_res.columns))
for col_name in plw_res.columns:
  plw_res = plw_res.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ''))
  plw_res = plw_res.withColumn(col_name, F.regexp_replace(F.col(col_name), '[\\r\\n]', ' '))
  

# remove rows where object_number is null
#project = project_1.filter('OBJECT_NUMBER IS NOT NULL')

# COMMAND ----------

# select fields

plw_res = plw_res.select(
  'LOAD',
  'YEAR',
  'MONTH',
  'RBS',
  'FUNDING_STATUS',
  'ACTIVITY_NAME',
  'ACTIVITY_START_DATE',
  'ACTIVITY_FINISH_DATE',
  'ACTIVITY_ACTUAL_START',
  'ACTIVITY_ACTUAL_FINISH',
  'TYPE',
  'ACTIVITY_VERSION_TYPE',
  'ACTIVITY_BASELINE_NAME',
  'ACTIVITY_BASELINE_TYPE',
  'ORIGINAL_RATE',
  'ACTIVITY_ONB',
  'PLAN_TYPE'
)

# COMMAND ----------

plw_res = plw_res.withColumn('MONTH', F.when(plw_res.MONTH == 'JAN', '1').when(plw_res.MONTH == 'FEB', '2').when(plw_res.MONTH == 'MAR', '3').when(plw_res.MONTH == 'APR', '4').when(plw_res.MONTH == 'MAY', '5').when(plw_res.MONTH == 'JUN', '6').when(plw_res.MONTH == 'JUL', '6').when(plw_res.MONTH == 'AUG', '7').when(plw_res.MONTH == 'SEP', '9').when(plw_res.MONTH == 'OCT', '10').when(plw_res.MONTH == 'NOV', '11').when(plw_res.MONTH == 'DEC', '12').otherwise(plw_res['MONTH']))

# COMMAND ----------

# rename fields
plw_res = plw_res.withColumnRenamed('ACTIVITY_ONB', 'ACTIVITY_OBJECT_NUMBER')
plw_res = plw_res.withColumnRenamed('LOAD', 'STD_FTES_FORECAST')
plw_res = plw_res.withColumnRenamed('TYPE', 'RESOURCE_TYPE')
plw_res = plw_res.withColumn('SOURCE', F.lit('PLW-LEGACY').cast(StringType()))

#select required columns
plw_res=plw_res.select ('ACTIVITY_OBJECT_NUMBER','RBS','STD_FTES_FORECAST','YEAR','MONTH','RESOURCE_TYPE','ACTIVITY_VERSION_TYPE','ACTIVITY_BASELINE_NAME','ACTIVITY_BASELINE_TYPE','ORIGINAL_RATE','SOURCE')

# COMMAND ----------

# write to curated
rawPath = 'dbfs:/mnt/raw/planisware/'
unique_run_id = runid + '-LoadPLWPlanLegacy/'
csv_temp_curated = rawPath + unique_run_id + '/' + 'curated/'
curatedPath = 'dbfs:/mnt/curated/planisware/legacy/'

plw_res.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
source = dbutils.fs.ls(csv_temp_curated)[-1][0]
destination = curatedPath + "plw_export_all_fte.txt"
dbutils.fs.cp(source, destination, recurse = True)
logDebug('LoadCuratedPLWExportAllFTE: Copied files from ' + source + ' to ' + destination)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)