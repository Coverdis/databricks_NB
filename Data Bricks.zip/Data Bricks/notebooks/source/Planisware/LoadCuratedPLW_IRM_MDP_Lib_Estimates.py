# Databricks notebook source
# Load PLW_IRM_MDP_Lib_Estimates to curated

# COMMAND ----------

dbutils.widgets.text('runid', 'sdchs-d82ss-cdn82-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

dbutils.fs.cp('dbfs:/mnt/foundation/planisware/plw_irm_mdp_lib_estimates.txt', 'dbfs:/mnt/curated/planisware/plw_irm_mdp_lib_estimates.txt', recurse = True)