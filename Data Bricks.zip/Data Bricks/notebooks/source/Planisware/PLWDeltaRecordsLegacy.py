# Databricks notebook source
#File Name: DeltaRecordsLegacy
#ADF Pipeline Name: Planisware_ADL
#SQLDW Table: NA
#Description:
  #Store Finds object number of activity have changed since last load

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime, timedelta
from pyspark.sql import functions as F
from pyspark.sql.types import *
import re
from pyspark.sql.functions import explode

dbutils.widgets.text("runid", "csd8923-ko34903-mop2342-vdfk22190")
dbutils.widgets.text("file_path", "")
dbutils.widgets.text("one_time_flag", "true")


file_path = dbutils.widgets.get("file_path")
runid = dbutils.widgets.get("runid")
one_time_flag = dbutils.widgets.get("one_time_flag")

# COMMAND ----------

# read current project_object_numbers and plan state in planisware
project_list_df = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/planisware/legacy/project_list.txt')
project_list_df = project_list_df.toDF(*(col.upper().replace('\r', '') for col in project_list_df.columns))

project_list_df.createOrReplaceTempView('project_list')

# COMMAND ----------

delta='true'
# read current project_object_numbers in datalake
try:
  project_df = spark.createDataFrame(dbutils.fs.ls('dbfs:/mnt/foundation/planisware/legacy/project/'))
  project_df = project_df.withColumn('object_number', F.split(project_df.name, '\.')[0]).select('object_number')
  project_df.createOrReplaceTempView('project_dl')
except Exception as exception:
  delta='false'
  print(delta)

# COMMAND ----------

if delta=='true':
  if one_time_flag=='true':
      query="select object_number,gsk_ra_plan_state from project_list where object_number not in (select object_number from project_dl) limit 200"
  
  else :      
    query="select object_number,gsk_ra_plan_state from project_list where gsk_ra_plan_state not in ('Version','Closed','Template')union select object_number,gsk_ra_plan_state from project_list where gsk_ra_plan_state in ('Version','Closed','Template') and object_number not in (select object_number from project_dl)" 
else :
  if one_time_flag=='true':
    query="select object_number,gsk_ra_plan_state from project_list limit 200"
  else : 
    query="select object_number,gsk_ra_plan_state from project_list"

project_delta = sqlContext.sql(query)
print(query)

# COMMAND ----------

if delta=='true':
  query="select object_number from project_dl where object_number not in (select object_number from project_list)" 
else :
  query="select '' as object_number"
project_delete = sqlContext.sql(query)

# COMMAND ----------

# write to foundation
fnd_path = 'dbfs:/mnt/foundation/planisware/legacy/'
unique_run_id = runid + '-DeltaRecords/'
temp_path = 'dbfs:/mnt/raw/' + unique_run_id


project_delta.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(temp_path)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(temp_path)[-1][0], fnd_path + "project_delta.txt", recurse = True)

# COMMAND ----------

unique_run_id = runid + '-DeleteRecords/'
temp_path = 'dbfs:/mnt/raw/' + unique_run_id
project_delete.write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(temp_path)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(temp_path)[-1][0], fnd_path + "project_delete.txt", recurse = True)