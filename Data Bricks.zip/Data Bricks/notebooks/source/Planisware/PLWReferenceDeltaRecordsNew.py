# Databricks notebook source
#File Name: PLWReferenceDeltaRecordsNew
#ADF Pipeline Name: Planisware_Baseline_ADL
#SQLDW Table: NA
#Description:
  #It compares all references retrieved from new Planisware. Below are the flags used
  #Cutoffdate- Reference having archive date prior to cut off date are being filtered out
  #If fullloadflag=true then no action is being taken. All references are being ingested.
  #If fullloadflag=false then only delta references are being considered. It check, if plan references already exist in foundation layer and then  removes it from reference list in order to avoid ingesting them again in Azure from plansiware
 #Limt- This limits number reference to be ingested in Azure. 

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

dbutils.widgets.text('runid', 'pxnjs2-xdsd32-fdf223-cedsh2')
dbutils.widgets.text('FullLoadFlag', '')
dbutils.widgets.text('CutOffDate', '')
dbutils.widgets.text('Limit', '')

runid = dbutils.widgets.get('runid')
FullLoadFlag=dbutils.widgets.get('FullLoadFlag')
CutOffDate=dbutils.widgets.get('CutOffDate')
Limit=dbutils.widgets.get('Limit')

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

reference_list = spark.read.format("json")\
          .option("multiLine","true")\
          .option("nullValue","null")\
    .load('dbfs:/mnt/raw/planisware/new/reference/plw_reference_list.json')

tempDf = reference_list.select(explode("value").alias("value_exploded"))
reference_list = tempDf.selectExpr( 'value_exploded.*')
 

reference_list = reference_list.toDF(*(col.upper().replace('\r', '') for col in reference_list.columns))

field = 'archive_date'
reference_list=reference_list.drop('@ODATA.ID')
reference_list = reference_list.withColumn(field, F.from_unixtime(F.regexp_extract(reference_list[field], '\d+', 0)/1000).cast(TimestampType()))
reference_list = reference_list.withColumn(field, 
                       F.when(F.datediff(F.to_date(F.lit("1970-01-01")), F.to_date(reference_list[field], "yyyy-MM-dd")) == 0, 
                              None
                             ).otherwise(reference_list[field])
             )


# COMMAND ----------

#filter records prior to cutoff date
reference_list=reference_list.filter(reference_list.archive_date.cast(DateType()) >= lit(CutOffDate )) 

# COMMAND ----------

path='dbfs:/mnt/foundation/planisware/new/reference'
if file_exists(path) and FullLoadFlag=='false':
  print (1)
  ref_json = spark.read.format("json")\
          .option("multiLine","true")\
          .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/planisware/new/reference/*.json')

  tempDf = ref_json.select(explode("value").alias("value_exploded"))
  ref_old = tempDf.selectExpr( 'value_exploded.*')

  ref_old=ref_old.select('OBJECT_NUMBER','name')
  reference_list = reference_list.join(ref_old, ['OBJECT_NUMBER'], 'left')
  reference_list = reference_list.filter('name is null')


# COMMAND ----------

if Limit!='': reference_list=reference_list.limit(int(Limit))

# COMMAND ----------

# write to curated

tmp_file_path = 'dbfs:/mnt/raw/planisware/new/' + 'plw_reference-' + runid
rawPath = 'dbfs:/mnt/raw/planisware/new/'
reference_list=reference_list.select('object_number')
reference_list.coalesce(1).write\
            .option("sep", "|")\
            .option("header", "true")\
            .option("quote",  '"')\
            .option("escape", '"')\
            .option("nullValue", "null")\
            .option("quoteAll", "true")\
        .csv(tmp_file_path)
# copy part-* csv file to curated and rename
dbutils.fs.cp(dbutils.fs.ls(tmp_file_path)[-1][0], rawPath + 'plw_reference.txt', recurse = True)

# remove temp folders
dbutils.fs.rm(tmp_file_path, recurse = True)