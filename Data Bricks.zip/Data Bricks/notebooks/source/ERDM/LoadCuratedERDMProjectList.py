# Databricks notebook source
# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
from pyspark.sql.functions import explode
import os
from glob import glob
import re

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "")
runid = dbutils.widgets.get("runid")

sourcefilepath='foundation/erdm/milestones.json'
sourcefilepathPP='foundation/erdm/phase_progression_milestones.json'
targetfilepath='curated/erdm/project_milestones.txt'
targetfilepathPP='curated/erdm/phase_progression_milestones.json'

# COMMAND ----------

project_milestones_json = spark.read.format("json")\
          .option("multiLine","true")\
          .option("nullValue","null")\
    .load('dbfs:/mnt/'+sourcefilepath)

# COMMAND ----------

#convert json array in to column
tempdf2 = project_milestones_json.select(explode("data").alias("data_exploded2"))

# COMMAND ----------

# tempdf2 = tempDf.select(F.col("data_exploded").alias("data_exploded2"))

# display(tempdf2.select("data_exploded2.*", "data_exploded2.extraAttributes", "data_exploded2.synonyms"))
tempdf3 = tempdf2.select("data_exploded2.*")
tempdf4 = tempdf3.select("*", "extraAttributes.*")
tempdf5 = tempdf4.select("*", F.col("miscAttributes").getItem(0).alias("misc1"), F.col("miscAttributes").getItem(1).alias("misc2"), F.col("synonyms").getItem(0).alias("syn1"), F.col("synonyms").getItem(1).alias("syn2"))
tempdf6 = tempdf5.select("*", F.col("misc1.value").alias('SORT_ORDER'), F.col("misc2.value").alias('INDUSTRY_PHASE'))
tempdf7 = tempdf6.withColumn("PLANISWARE_ACTIVITY_TYPE", F.when(F.col("syn1.source") == "Legacy Planisware", F.col("syn1.name")))
tempdf7 = tempdf7.withColumn("NEW_PLANISWARE_ACTIVITY_TYPE", F.when(F.col("syn1.source") == "Planisware", F.col("syn1.name")).otherwise(F.col("syn2.name")))

tempdf7 = tempdf7.drop(*["extraAttributes", "miscAttributes", "synonyms", "syn1", "syn1_name", "syn2", "misc1", "misc2"])

# COMMAND ----------

projectms = tempdf7.select('abbreviation','description','lastModified','listId','listName','longName','preferredName','shortName','status','termId','version','SORT_ORDER','INDUSTRY_PHASE','PLANISWARE_ACTIVITY_TYPE','NEW_PLANISWARE_ACTIVITY_TYPE')

# COMMAND ----------

projectms = projectms.withColumnRenamed("listName","MILESTONE_TYPE")
projectms = projectms.withColumnRenamed("longName","MILESTONE_LONG_NAME")
projectms = projectms.withColumnRenamed("preferredName","PREFERRED_NAME")
projectms = projectms.withColumnRenamed("shortName","MILESTONE_SHORT_NAME")
projectms = projectms.withColumn("MILESTONE_ABBREVIATION",F.lit(projectms.MILESTONE_SHORT_NAME))
projectms = projectms.withColumnRenamed("SORT_ORDER","MILESTONE_SORT_ORDER")
projectms = projectms.withColumnRenamed("termId","CD_ITEM_LSID")
projectms = projectms.withColumnRenamed("NEW_PLANISWARE_ACTIVITY_TYPE","NEW_PLW_ACTIVITY_TYPE")
projectms = projectms.withColumn("MODIFIED_DATE",F.lit(projectms.lastModified).cast('date'))

# COMMAND ----------

projectms=projectms.select('CD_ITEM_LSID','PREFERRED_NAME','MILESTONE_ABBREVIATION','MILESTONE_LONG_NAME','MILESTONE_SHORT_NAME','PLANISWARE_ACTIVITY_TYPE','NEW_PLW_ACTIVITY_TYPE','MILESTONE_SORT_ORDER','MODIFIED_DATE','INDUSTRY_PHASE','MILESTONE_TYPE')

# COMMAND ----------

phase_progression_milestones_json = spark.read.format("json")\
          .option("multiLine","true")\
          .option("nullValue","null")\
    .load('dbfs:/mnt/'+sourcefilepathPP)

# COMMAND ----------

#convert json array in to column
df = phase_progression_milestones_json.select(explode("data").alias("data_exploded"))

# COMMAND ----------

df1 = df.select("data_exploded.*")

# COMMAND ----------

pp = df1.select('termId')
pp = pp.withColumn("flag",F.lit("Y"))

# COMMAND ----------

pp1 = projectms.join(pp, projectms.CD_ITEM_LSID == pp.termId, 'leftouter')
pp1 = pp1.withColumn('MILESTONE_PHASE_PROGRESSION', F.when((pp1.flag == "Y"),pp1.INDUSTRY_PHASE).otherwise("null"))
pp1 = pp1.withColumn('MILESTONE_SYNONYM',F.lit("null"))
pp1 = pp1.withColumn('MILESTONE_CALC_GROUP',F.lit("null"))
pp1 = pp1.withColumn('MILESTONE_CALC_MEMBER',F.lit("null"))
#'MILESTONE_SYNONYM', 'MILESTONE_CALC_GROUP', 'MILESTONE_CALC_MEMBER'
project_milestone = pp1.select('CD_ITEM_LSID','PREFERRED_NAME','MILESTONE_ABBREVIATION','MILESTONE_LONG_NAME','MILESTONE_SHORT_NAME','PLANISWARE_ACTIVITY_TYPE','NEW_PLW_ACTIVITY_TYPE','MILESTONE_SORT_ORDER','MILESTONE_SYNONYM','MODIFIED_DATE','MILESTONE_PHASE_PROGRESSION','INDUSTRY_PHASE','MILESTONE_CALC_GROUP','MILESTONE_CALC_MEMBER','MILESTONE_TYPE')

# COMMAND ----------

raw_path = 'dbfs:/mnt/raw/erdm/'
unique_run_id = runid + '-LoadCuratedERDMProjectList/'
csv_temp_curated = raw_path + unique_run_id + 'curated/'

curated_path = 'dbfs:/mnt/curated/erdm/'

project_milestone.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curated_path + "project_milestone_list.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)