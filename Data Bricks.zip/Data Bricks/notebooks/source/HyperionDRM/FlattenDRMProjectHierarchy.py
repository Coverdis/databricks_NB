# Databricks notebook source
#File Name:FlattenDRMProjectHierarchy
#ADF Pipeline Name: HypDRM_ADL
#Description:
  #Flatten project hierarchy file comming from Hyperion DRM
  #Writes flatten project hierarchy file in curated layer  

# COMMAND ----------

# MAGIC %run "/library/configFile"

# COMMAND ----------

dbutils.widgets.text("runid", "1sdw2-we23d-qkgn9-uhbg2-hdj22")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql import functions as F

rawPath = 'dbfs:/mnt/raw/hyperion_drm'
foundationPath = 'dbfs:/mnt/foundation/hyperion_drm/'
curatedPath = 'dbfs:/mnt/curated/hyperion_drm/'

df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(foundationPath + "project_to_fdr.txt")

df = df.toDF(*(c.replace('\r', '') for c in df.columns))

# COMMAND ----------

df.createOrReplaceTempView("PROJECT_HIERARCHY")

query = "SELECT p.PROJECT as STUDY_CODE, p.DESCRIPTION as STUDY_DESCRIPTION,lvl4.PROJECT as PROJECT_CODE,PROJECT_DESCRIPTION,REPORTING_GROUP,REPORTING_GROUP_DESCRIPTION,THERAPY_AREA,THERAPY_AREA_DESCRIPTION,MANAGING_ORG as MANAGING_ORGANISATION,MANAGING_ORG_DESCRIPTION as MANAGING_ORGANISATION_DESCRIPTION,ROOT,ROOT_DESCRIPTION,FUNDINGORG as FUNDING_ORGANISATION,PCUDA,CEFLEXCOMM,SOURCE_FLAG FROM  PROJECT_HIERARCHY p, (SELECT p.PROJECT as PROJECT,p.DESCRIPTION as PROJECT_DESCRIPTION,REPORTING_GROUP,REPORTING_GROUP_DESCRIPTION,THERAPY_AREA,THERAPY_AREA_DESCRIPTION,MANAGING_ORG,MANAGING_ORG_DESCRIPTION,ROOT,ROOT_DESCRIPTION FROM  PROJECT_HIERARCHY p, (SELECT p.PROJECT as REPORTING_GROUP,p.DESCRIPTION as REPORTING_GROUP_DESCRIPTION,THERAPY_AREA,THERAPY_AREA_DESCRIPTION,MANAGING_ORG,MANAGING_ORG_DESCRIPTION,ROOT,ROOT_DESCRIPTION FROM  PROJECT_HIERARCHY p, (SELECT p.PROJECT as THERAPY_AREA,p.DESCRIPTION as THERAPY_AREA_DESCRIPTION,MANAGING_ORG,MANAGING_ORG_DESCRIPTION,ROOT,ROOT_DESCRIPTION FROM  PROJECT_HIERARCHY p, (SELECT p.PROJECT as MANAGING_ORG,p.DESCRIPTION as MANAGING_ORG_DESCRIPTION,ROOT,ROOT_DESCRIPTION from PROJECT_HIERARCHY p, (Select distinct PROJECT as ROOT,DESCRIPTION as ROOT_DESCRIPTION from PROJECT_HIERARCHY where project = 'PO.PROJECT') lvl0 WHERE p.parent=lvl0.ROOT)lvl1 WHERE p.parent=lvl1.MANAGING_ORG) lvl2 WHERE p.parent=lvl2.THERAPY_AREA)lvl3 WHERE p.parent=lvl3.REPORTING_GROUP)lvl4 WHERE p.parent=lvl4.Project"

project = sqlContext.sql(query)

project = project.withColumn('STUDY_CODE', F.regexp_replace('STUDY_CODE', 'PR.', '').cast(StringType()))
project = project.withColumn('PROJECT_CODE', F.regexp_replace('PROJECT_CODE', 'CP.', '').cast(StringType()))
project = project.withColumn('SOURCE_FLAG', F.regexp_replace('SOURCE_FLAG', 'SF.', '').cast(StringType()))


project = project.selectExpr(
  "STUDY_CODE",
  "STUDY_DESCRIPTION",
  "PROJECT_CODE",
  "PROJECT_DESCRIPTION",
  "REPORTING_GROUP",
  "REPORTING_GROUP_DESCRIPTION",
  "THERAPY_AREA",
  "THERAPY_AREA_DESCRIPTION",
  "MANAGING_ORGANISATION",
  "MANAGING_ORGANISATION_DESCRIPTION",
  "ROOT",
  "ROOT_DESCRIPTION",
  "FUNDING_ORGANISATION",
  "PCUDA",
  "CEFLEXCOMM",
  "SOURCE_FLAG"
)

# COMMAND ----------

# write to curated
unique_run_id = runid + '-FlattenDRMProjectHierarchy/'
csv_temp_curated = rawPath + unique_run_id + 'curated/'

project.coalesce(1).write\
          .option("sep", "|")\
          .option("header", "true")\
          .option("quote",  '"')\
          .option("escape", '"')\
          .option("nullValue", "null")\
          .option("quoteAll", "true")\
          .mode('overwrite')\
        .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + '/' + "project_hierarchy.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)