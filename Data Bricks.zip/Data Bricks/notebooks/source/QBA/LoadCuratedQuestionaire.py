# Databricks notebook source
#File Name: LoadCuratedQuestionaire
#ADF Pipeline Name: QBA_ADL
#SQLDW Table: NA
#Description:
  # Load QBA Questionaire data from foundation to curated layer

# COMMAND ----------

# MAGIC %run "/library/configFile"

# COMMAND ----------

dbutils.widgets.text("runid", "dslse2-cwik21-cwl111-o032kdmmm")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
process_time = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

# COMMAND ----------

# Load QBA Data
df = spark.read.format("csv")\
        .option("inferSchema","true")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
  .load("dbfs:/mnt/foundation/qba/questionaire.txt")

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '[\\r\\n\\s+]', ''))
df=df.withColumn('source',F.lit('QBA').cast(StringType()))

# COMMAND ----------

# write to curated
rawPath = 'dbfs:/mnt/raw/qba/'
unique_run_id = runid + '-LoadCuratedQBAQuestionaire/'
csv_temp_curated = rawPath + unique_run_id + '/' + 'curated/'
curatedPath = 'dbfs:/mnt/curated/qba/'

df.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + "questionaire.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)