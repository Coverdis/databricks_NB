# Databricks notebook source
#File Name:FlattenMedicalConditionHierarchy
#ADF Pipeline Name: 
#SQLDW: irm_stg.MedicalConditionHierarchy
#Description:
  #Flatten Medical Condition hierarchy file comming from Hyperion DRM
  #Writes flatten Medical Condition Hierarchy file in curated layer

# COMMAND ----------

# MAGIC %run "/library/configFile"

# COMMAND ----------

dbutils.widgets.text("runid", "ssad2-we23d-sd782-uhbg2-dfj34")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *

rawPath = 'dbfs:/mnt/raw/pdm/'
foundationPath = 'dbfs:/mnt/foundation/pdm/'
curatedPath = 'dbfs:/mnt/curated/pdm/'

# COMMAND ----------

df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(foundationPath + "drm_medi_cond_code.txt")

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

# COMMAND ----------

df.createOrReplaceTempView("MCH")

query = "select LVL3PN, LVL3N, LVL3DEX, LEVEL3_DESCRIPTION, DISPLAY_ORDER, LVL2PN, LVL2N, LEVEL2_DESCRIPTION, LVL1PN, LVL1N, LEVEL1_DESCRIPTION \
		from (SELECT PARENT_NODE_ID as LVL3PN, NODE_ID as LVL3N, DEX_ID as LVL3DEX, DESCRIPTION as LEVEL3_DESCRIPTION,DISPLAY_ORDER FROM MCH) lvl3, \
			 (SELECT PARENT_NODE_ID as LVL2PN, NODE_ID as LVL2N, DESCRIPTION as LEVEL2_DESCRIPTION FROM MCH) lvl2, \
			 (SELECT PARENT_NODE_ID as LVL1PN, NODE_ID as LVL1N, DESCRIPTION as LEVEL1_DESCRIPTION FROM MCH WHERE DESCRIPTION = 'Medical Condition') lvl1 \
		WHERE lvl2.LVL2PN=lvl1.LVL1N AND lvl3.LVL3PN=lvl2.LVL2N \
        UNION \
        select null as LVL3PN, null as LVL3N, LVL2DEX as LVL3DEX, null as LEVEL3_DESCRIPTION, null as DISPLAY_ORDER, LVL2PN, LVL2N, LEVEL2_DESCRIPTION, LVL1PN, LVL1N, LEVEL1_DESCRIPTION \
        from (SELECT PARENT_NODE_ID as LVL2PN, NODE_ID as LVL2N, DEX_ID as LVL2DEX, DESCRIPTION as LEVEL2_DESCRIPTION FROM MCH) lvl2, \
             (SELECT PARENT_NODE_ID as LVL1PN, NODE_ID as LVL1N, DESCRIPTION as LEVEL1_DESCRIPTION FROM MCH WHERE DESCRIPTION = 'Medical Condition') lvl1 \
        WHERE lvl2.LVL2PN=lvl1.LVL1N"

medicalcondition = sqlContext.sql(query)

# COMMAND ----------

unique_run_id = runid + '-FlattenDRMMedicalConditionHierarchy/'
csv_temp_curated = rawPath + unique_run_id + 'curated/'

medicalcondition.coalesce(1).write\
          .option("sep", "|")\
          .option("header", "true")\
          .option("quote",  '"')\
          .option("escape", '"')\
          .option("nullValue", "null")\
          .option("quoteAll", "true")\
          .mode('overwrite')\
        .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + "medical_condition_hierarchy.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)