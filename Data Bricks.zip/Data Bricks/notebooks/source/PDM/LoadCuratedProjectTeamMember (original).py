# Databricks notebook source
# Load project_team_member.txt from foundation to curated 

# COMMAND ----------

dbutils.widgets.text('runid', 'plmna-dv83q-cdn82-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

dbutils.fs.cp('dbfs:/mnt/foundation/pdm/project_team_member.txt', 'dbfs:/mnt/curated/pdm/project_team_member.txt', recurse = True)