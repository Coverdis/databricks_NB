# Databricks notebook source
#File Name: LoadCuratedVxProject
#ADF Pipeline Name:  VxPLM_ADL
#SQLDW Table: irm_stg.PROJECT
#Description:
  #Load PLM project data in unified project management folder

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window

dbutils.widgets.text('runid', 'st822-mm118-cdn82-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

plm_edw_spec_header = spark.read.format("csv")\
        .option("inferSchema","false")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("escape",  '"')\
        .option("delimiter","|")\
        .option("quote",  '"')\
        .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/vaccines/plm/plm_edw_spec_header.txt')

plm_edw_spec_header = plm_edw_spec_header.toDF(*(col.replace('\r', '') for col in plm_edw_spec_header.columns))
plm_edw_spec_header = plm_edw_spec_header.toDF(*(col.replace('.', '') for col in plm_edw_spec_header.columns))


for col_name in plm_edw_spec_header.columns:
  plm_edw_spec_header = plm_edw_spec_header.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

# COMMAND ----------

plm_edw_spec_network = spark.read.format("csv")\
        .option("inferSchema","false")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("escape",  '"')\
        .option("delimiter","|")\
        .option("quote",  '"')\
        .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/vaccines/plm/plm_edw_spec_network.txt')

plm_edw_spec_network = plm_edw_spec_network.toDF(*(col.replace('\r', '') for col in plm_edw_spec_network.columns))
plm_edw_spec_network = plm_edw_spec_network.toDF(*(col.replace('.', '') for col in plm_edw_spec_network.columns))


for col_name in plm_edw_spec_network.columns:
  plm_edw_spec_network = plm_edw_spec_network.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

# COMMAND ----------

plm_edw_spec_data = spark.read.format("csv")\
        .option("inferSchema","false")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("escape",  '"')\
        .option("delimiter","|")\
        .option("quote",  '"')\
        .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/vaccines/plm/plm_edw_spec_data.txt')

plm_edw_spec_data = plm_edw_spec_data.toDF(*(col.replace('\r', '') for col in plm_edw_spec_data.columns))
plm_edw_spec_data = plm_edw_spec_data.toDF(*(col.replace('.', '') for col in plm_edw_spec_data.columns))

for col_name in plm_edw_spec_data.columns:
  plm_edw_spec_data = plm_edw_spec_data.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

# COMMAND ----------

plm_edw_spec_ident = spark.read.format("csv")\
        .option("inferSchema","false")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("escape",  '"')\
        .option("delimiter","|")\
        .option("quote",  '"')\
        .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/vaccines/plm/plm_edw_spec_ident.txt')

plm_edw_spec_ident = plm_edw_spec_ident.toDF(*(col.replace('\r', '') for col in plm_edw_spec_ident.columns))
plm_edw_spec_ident = plm_edw_spec_ident.toDF(*(col.replace('.', '') for col in plm_edw_spec_ident.columns))

for col_name in plm_edw_spec_ident.columns:
  plm_edw_spec_ident = plm_edw_spec_ident.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

# COMMAND ----------

spec_data_pivoted = plm_edw_spec_data.groupby('SUBID', 'substat_descr').pivot('c_id').agg(F.first('value'))

spec_ident_pivoted = plm_edw_spec_ident.groupby('SUBID').pivot('idcnam').agg(F.first('ident'))

# COMMAND ----------

print(spec_data_pivoted.count())

# COMMAND ----------

spec_ident_pivoted = spec_ident_pivoted.withColumnRenamed('SUBID', 'SUBID0')

# COMMAND ----------

spark.conf.set("spark.sql.crossJoin.enabled", 'true')

# COMMAND ----------

temp = plm_edw_spec_network.join(spec_data_pivoted, plm_edw_spec_network.SAP_STREAM_ID == spec_data_pivoted.SUBID, 'leftouter')

temp = temp.drop('SUBID0')
temp = temp.drop('SUBID')

# COMMAND ----------

stream = temp.join(spec_ident_pivoted.select('SUBID0', 'Stream Code', 'Stream Name'), temp.SAP_STREAM_ID == spec_ident_pivoted.SUBID0, 'leftouter')

stream = stream.drop('SUBID0')

# COMMAND ----------

project_stream = stream.join(spec_ident_pivoted.select('SUBID0', 'Project Code', 'Project Name'), stream.SAP_PROJECT_ID == spec_ident_pivoted.SUBID0, 'leftouter') # assuming all stream have a project

project_stream = project_stream.drop('SUBID0')

# COMMAND ----------

program_project_stream = project_stream.join(spec_ident_pivoted.select('SUBID0', 'Program Code', 'Program Name'), project_stream.SAP_PROGRAM_ID == spec_ident_pivoted.SUBID0, 'leftouter')

program_project_stream = program_project_stream.drop('SUBID0')

# COMMAND ----------

# No projects are associated with Programs
program_project_stream = program_project_stream.withColumn('Project Code', F.when(program_project_stream['Stream Code'].like('LCM%'), F.lit(None)).otherwise(program_project_stream['Project Code']))

program_project_stream = program_project_stream.withColumn('Project Name', F.when(program_project_stream['Stream Code'].like('LCM%'), F.lit(None)).otherwise(program_project_stream['Project Name']))

# COMMAND ----------

program_project_stream = program_project_stream.withColumnRenamed('Stream Code', 'PROJECT_CODE')
program_project_stream = program_project_stream.withColumnRenamed('Stream Name', 'DESCRIPTION_SHORT')
program_project_stream = program_project_stream.withColumnRenamed('SOURCE', 'SOURCING')
program_project_stream = program_project_stream.withColumnRenamed('RD Center', 'RD_CENTER')
program_project_stream = program_project_stream.withColumnRenamed('R&D Strategic Pillar', 'RD_STRATEGIC_PILLAR')
program_project_stream = program_project_stream.withColumnRenamed('Third Party', 'THIRD_PARTY')
program_project_stream = program_project_stream.withColumnRenamed('Marketed Product Group', 'MARKETED_PRODUCT_GROUP')
program_project_stream = program_project_stream.withColumnRenamed('Category', 'CATEGORY')
program_project_stream = program_project_stream.withColumnRenamed('Commercial Portfolio Group', 'COMERCIAL_PROTFOLIO_GROUP')
program_project_stream = program_project_stream.withColumnRenamed('Program Code', 'PROGRAM_CODE')
program_project_stream = program_project_stream.withColumnRenamed('Program Name', 'PROGRAM_NAME')

program_project_stream = program_project_stream.withColumn('PROGRAM_CODE', F.when(~program_project_stream['PROJECT_CODE'].like('LCM%'), program_project_stream['Project Code']).otherwise(program_project_stream['PROGRAM_CODE']))
program_project_stream = program_project_stream.withColumn('PROGRAM_NAME', F.when(~program_project_stream['PROJECT_CODE'].like('LCM%'), program_project_stream['Project Name']).otherwise(program_project_stream['PROGRAM_NAME']))
program_project_stream = program_project_stream.withColumn('PROJECT_DESCRIPTION', F.lit(program_project_stream.DESCRIPTION_SHORT))
program_project_stream = program_project_stream.withColumnRenamed('Stream Type', 'PROJECT_FORM_NAME')
program_project_stream = program_project_stream.withColumnRenamed('PORTFOLIO GROUP LEVEL 1', 'FUNDER_L1')
program_project_stream = program_project_stream.withColumn('VESTED_UNIT_LEVEL_1', F.lit(program_project_stream.FUNDER_L1))
program_project_stream = program_project_stream.withColumnRenamed('PORTFOLIO GROUP LEVEL 2', 'FUNDER_L2')
program_project_stream = program_project_stream.withColumn('VESTED_UNIT_LEVEL_2', F.lit(program_project_stream.FUNDER_L2))
program_project_stream = program_project_stream.withColumnRenamed('PORTFOLIO GROUP LEVEL 3', 'FUNDER_L3')
program_project_stream = program_project_stream.withColumn('VESTED_UNIT_LEVEL_3', F.lit(program_project_stream.FUNDER_L3))
program_project_stream = program_project_stream.withColumnRenamed('DISEASE AREA LEVEL 1', 'DISEASE_AREA')
program_project_stream = program_project_stream.withColumnRenamed('DISEASE AREA LEVEL 2', 'INDICATION')
# program_project_stream = program_project_stream.withColumn('THERAPEUTIC_AREA_SHORT_NAME', F.lit(program_project_stream.DISEASE_AREA).cast(StringType()))
# program_project_stream = program_project_stream.withColumn('THERAPEUTIC_AREA_LONG_NAME', F.lit(program_project_stream.DISEASE_AREA).cast(StringType()))

# program_project_stream = program_project_stream.withColumn('ACTIVE_SUBSTANCE_SUB_TYPE_DESCRIPTION', F.when(program_project_stream.PROJECT_CODE.like('%NVNT%'), 'P-NVNT')\
#                                                         .when(program_project_stream.PROJECT_CODE.like('%PI%'), 'P-NVNT')\
#                                                         .when(program_project_stream.PROJECT_CODE.like('%NOGS%'), 'P-NVNT')\
#                                                         .when(program_project_stream.PROJECT_CODE.like('%XPJ%'), 'P-xProject')\
#                                                         .when(program_project_stream.PROJECT_CODE.like('%BULK%'), 'P-BULK')\
#                                                         .when(program_project_stream.PROJECT_CODE.like('%TEC%'), 'P-TEC')\
#                                                         .when(program_project_stream.PROJECT_CODE.like('%CI%'), 'P-NVNT')\
#                                                         .when(program_project_stream.PROJECT_CODE.like('%LCM%'), 'P-LCM')\
#                                                         .when(program_project_stream.PROJECT_CODE.like('%INC%'), 'P-INC')\
#                                                        .otherwise('P-VAC'))

# program_project_stream = program_project_stream.withColumn('ASSET_NUMBER', F.when(program_project_stream['Program Code'].isNull(), program_project_stream['Project Code']).otherwise(program_project_stream['Program Code']))
# program_project_stream = program_project_stream.withColumn('PREFERRED_NAME', F.when(program_project_stream['Program Name'].isNull(), program_project_stream['Project Name']).otherwise(program_project_stream['Program Name']))
# program_project_stream = program_project_stream.withColumn('ACTIVE_SUBSTANCE_ID', F.lit(program_project_stream.ASSET_NUMBER))

program_project_stream = program_project_stream.withColumn('PROJECT_STATUS', F.substring_index(program_project_stream.substat_descr, '--', -1))

# program_project_stream = program_project_stream.withColumnRenamed('PROJECT/PROGRAM_TYPE', 'ACTIVE_SUBSTANCE_TYPE_DESCRIPTION')

# COMMAND ----------

staging_project = spark.read.format("com.databricks.spark.sqldw")\
  .option("url", sqlDwUrl)\
  .option( "forward_spark_azure_storage_credentials", "True")\
  .option("tempdir", tempDir)\
  .option("maxStrLength", 4000)\
  .option("dbtable", "irm_stg.project") \
  .load()

# COMMAND ----------

def addNullReference(df , staging):
  staging_set = set(staging.columns)
  plan_df_set = set(df.columns)
  staging_set_diff= staging_set - plan_df_set

  for x in staging_set_diff :
    df = df.withColumn(x, F.lit(None).cast(StringType()))
  return df 

# COMMAND ----------

program_project_stream = addNullReference(program_project_stream, staging_project)

# COMMAND ----------

# program_project_stream = program_project_stream.select('PROJECT_CODE', 'PROJECT_DESCRIPTION', 'DESCRIPTION_SHORT', 'PROJECT_STATUS_CODE', 'PROJECT_STATUS', 'PROJECT_SUB_STATUS', 'PROJECT_STATUS_LONG_NAME', 'PROJECT_CREATION_DATE', 'PROJECT_CREATION_USER_ID', 'PROJECT_MODIFICATION_DATE', 'PROJECT_MODIFICATION_USER_ID', 'PROJECT_FORM_NAME', 'PROJECT_OWNER_USER_ID', 'PROJECT_STATUS_CHANGE_DATE', 'PROJECT_STATUS_CHANGE_COMMENT', 'TEAM_ID', 'PROJECT_STATUS_TERMINATION_REASON_CODE','PROJECT_STATUS_TERMINATION_REASON','PROJECT_STATUS_TERMINATION_CATEGORY', 'MEDICAL_CONDITION_CODE', 'INDICATION','DISEASE_AREA', 'THERAPEUTIC_AREA_SHORT_NAME', 'THERAPEUTIC_AREA_LONG_NAME', 'PROJECT_CURRENT_PHASE', 'DELIVERABLE_TYPE', 'ACTIVE_SUBSTANCE_ID', 'ACTIVE_SUBSTANCE_TYPE_CODE', 'ACTIVE_SUBSTANCE_SUB_TYPE_DESCRIPTION', 'ACTIVE_SUBSTANCE_TYPE_DESCRIPTION', 'CANDIDATE_SELECTION_TYPE_NAME', 'ROUTE_OF_ADMINISTRATION', 'THERAPY_TYPE', 'THERAPY_TYPE_COMMENT', 'LEAD_BU_CODE', 'DEFAULT_FUNDING_PARTY', 'FUNDER_L1', 'FUNDER_L2', 'FUNDER_L3', 'VESTED_UNIT_LEVEL_1', 'VESTED_UNIT_LEVEL_2', 'VESTED_UNIT_LEVEL_3', 'IMMUNOMODULATORY_FLAG', 'GENESYMBOL', 'START_PHASE', 'START_PHASE_DISPLAY_ORDER', 'CURRENT_PHASE_DISPLAY_ORDER', 'COMPOUND_REPORTED_NAME', 'COMPOUND_STATUS', 'COMPOUND_MARKET_STATUS', 'FL_COMBINATION', 'LEAD_INDICATION_FLAG', 'PROJECT_CATEGORY', 'PROJECT_CATEGORY_DETAILED', 'PROJECT_ASSET_FAMILY', 'PROJECT_WORK_TYPE')

# COMMAND ----------

# write to curated

raw_path = 'dbfs:/mnt/raw/vaccines/plm/'
unique_run_id = runid + '-LoadCuratedVxProject/'
csv_temp_curated = raw_path + unique_run_id + 'curated/'

curated_path = 'dbfs:/mnt/curated/vaccines/plm/'

program_project_stream.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curated_path + "vx_project.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)