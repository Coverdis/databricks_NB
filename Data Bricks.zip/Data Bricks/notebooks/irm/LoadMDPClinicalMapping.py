# Databricks notebook source
#File Name: LoadMDPClinicalMapping
#ADF Pipeline Name: IRM_ADL_DW-PLWPlan-PLWActivity
#SQLDW: irm_stg.MDP_MAPPING
#Description:
  # Load MDP clinical mapping to staging

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
import pytz
from datetime import datetime, timedelta

process_time = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

dbutils.widgets.text("runid", "xvckl2-segb2-vfk23-cdkl2")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

df = spark.read.format('csv')\
      .option("inferSchema", "false")\
      .option("header", "true")\
      .option("multiLine", "true")\
      .option("delimiter", "|")\
      .option("quote", '"')\
      .option("escape", '"')\
      .option("nullValue", "null")\
    .load('dbfs:/mnt/curated/irm/irm_mdp_clinical.txt')

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

df = df.withColumnRenamed('ID', 'CLINICAL_MAPPING_CODE')
df = df.withColumnRenamed('PLW_STUDY_ID', 'CLINICAL_STUDY_ID')
df = df.withColumnRenamed('FDR_LEGACY_BUD_ID', 'BUDID_CODE')
# df = df.withColumnRenamed('ET_STUDY_ID', 'STUDY_CODE')

df = df.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
df = df.withColumn('CREATION_DATE', F.lit(process_time).cast(TimestampType()))
df = df.withColumn('CREATED_BY', F.lit('Databricks - LoadMDPClinicalMapping').cast(StringType()))
df = df.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
df = df.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))

# display(df)

# COMMAND ----------

df.write\
  .format("com.databricks.spark.sqldw")\
  .option("url", sqlDwUrl)\
  .option( "forward_spark_azure_storage_credentials", "True")\
  .option("tempdir", tempDir)\
  .option("dbtable", "irm_stg.MDP_CLINICAL_MAPPING") \
  .mode("append")\
  .save()

# COMMAND ----------

sql = "delete from irm_stg.MDP_CLINICAL_MAPPING where CREATION_DATE != '"+ process_time +"'"
dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})