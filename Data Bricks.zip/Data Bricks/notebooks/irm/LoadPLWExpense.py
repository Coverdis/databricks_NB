# Databricks notebook source
#File Name: LoadPLWExpense
#ADF Pipeline Name: IRM_ADL_DW-PLWPlan-PLWActivity
#SQLDW: irm_stg.PLW_Expense
#Description:
  # Write expense data to SQL DW from unified layer 

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
import pytz
from datetime import datetime, timedelta
import os
from glob import glob
import re

process_time = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

# COMMAND ----------

dbutils.widgets.text("runid", "")
runid = dbutils.widgets.get("runid")


dbutils.widgets.text("baselineflag", "")
dbutils.widgets.text("referenceobjectnumber", "")


baselineflag=dbutils.widgets.get("baselineflag")
referenceobjectnumber=dbutils.widgets.get("referenceobjectnumber")

# COMMAND ----------

if baselineflag=='true':
  unified_path='dbfs:/mnt/unified/project_management/reference_epe_forecast/'+referenceobjectnumber+'.txt'
elif baselineflag!='true':
  unified_path='dbfs:/mnt/unified/project_management/epe_forecast.txt' 

# COMMAND ----------

# read modified files
df = spark.read.format('csv')\
      .option("inferSchema", "false")\
      .option("header", "true")\
      .option("multiLine", "true")\
      .option("delimiter", "|")\
      .option("quote", '"')\
      .option("escape", '"')\
      .option("nullValue", "null")\
    .load(unified_path)
if df.count()==0:
  dbutils.notebook.exit("")
df = df.toDF(*(col.replace('\r', '') for col in df.columns))
for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ''))

# COMMAND ----------

df = df.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
df = df.withColumn('CREATION_DATE', F.lit(process_time).cast(TimestampType()))
df = df.withColumn('CREATED_BY', F.lit('Databricks - LoadPLWWExpense').cast(StringType()))
df = df.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
df = df.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))

# PROJECT_PHASE is only coming from unified/project_management/epe_forecast.txt, so if source is baseline, we need to add the column with empty values 
if baselineflag=='true':
  df = df.withColumn('PROJECT_PHASE', F.lit(None).cast(StringType()))

df = df.select(
  'GL_PERIOD',
  'COST_BREAKDOWN_STRUCTURE',
  'ACTIVITY_OBJECT_NUMBER',
  'PLAN_OBJECT_NUMBER',
  'REFERENCE_OBJECT_NUMBER',
  'ACTIVITY_RESOURCE_ID',
  'LEDGER_CODE', 
  'COST_CENTER_CODE',
  'ACCOUNT_CODE',
  'AMOUNT_LOC',
  'AMOUNT_GBP',
  'CURRENCY_CODE',
  'FISCMONTH',
  'FISCYEAR',
  'ACTUAL_OR_ESTIMATE_CODE',
  'COST_TYPE',
  'PURCHASE_DOCUMENT_NUMBER',
  'PURCHASE_DOCUMENT_NUMBER_COMMENTS',
  'SCALE_FACTOR',
  'SOURCE',
  'PROJECT_PHASE',
  'RUN_ID',
  'CREATION_DATE',
  'CREATED_BY',
  'UPDATION_DATE',
  'UPDATED_BY'
)

# COMMAND ----------

# write to sql dw

df.write\
  .format("com.databricks.spark.sqldw")\
  .option("url", sqlDwUrl)\
  .option( "forward_spark_azure_storage_credentials", "True")\
  .option("tempdir", tempDir)\
  .option("dbtable", "irm_stg.PLW_EXPENSE") \
  .option("maxStrLength","4000")\
  .mode("append")\
  .save()

# COMMAND ----------

# delete old data once new data has been inserted successfully
if baselineflag!='true':
  sql = "delete from irm_stg.PLW_EXPENSE where SOURCE = 'PLW-New' and REFERENCE_OBJECT_NUMBER is null AND ACTUAL_OR_ESTIMATE_CODE='Forecast' and CREATION_DATE != '"+ process_time +"'"
else: 
  sql = "delete from irm_stg.PLW_EXPENSE where SOURCE = 'PLW-New' and REFERENCE_OBJECT_NUMBER= "+referenceobjectnumber +" and CREATION_DATE != '"+ process_time +"'"
dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})