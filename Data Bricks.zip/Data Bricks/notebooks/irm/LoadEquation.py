# Databricks notebook source
#File Name: LoadEquation
#ADF Pipeline Name: PLANISWARE_DEFAULT_REPORT_DRIVER_ADL
#SQLDW: irm_stg.EQUATIONS
#Description:
  # Write EQUATIONS data to SQL DW from unified layer 

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
import pytz
from datetime import datetime, timedelta
import os
from glob import glob
import re

# process_time = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

# COMMAND ----------


dbutils.widgets.text("runid", "111")


runid = dbutils.widgets.get("runid")

unified_path = 'dbfs:/mnt/unified/project_management/equations.txt'


# COMMAND ----------

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

# COMMAND ----------

file_exists(unified_path)

# COMMAND ----------

# read modified files

if file_exists(unified_path):
  process_flag=True
  df = spark.read.format('csv')\
      .option("inferSchema", "false")\
      .option("header", "true")\
      .option("multiLine", "true")\
      .option("delimiter", "|")\
      .option("quote", '"')\
      .option("escape", '"')\
      .option("nullValue", "null")\
    .load(unified_path)

  df = df.toDF(*(col.replace('\r', '') for col in df.columns))
  for col_name in df.columns:
    df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ''))
    
#   df = df.filter('RANK = 1')

# COMMAND ----------

# display(df)

# COMMAND ----------

# display(df.withColumn('size',F.length('EQUATION')).select(F.max(F.col('size'))))

# COMMAND ----------

if process_flag:
  
  # Create additional columns
  df = df.withColumn('SOURCE', F.lit('PLW-NEW').cast(StringType()))
  df = df.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
  df = df.withColumn('CREATION_DATE', F.lit(processTime).cast(TimestampType()))
  df = df.withColumn('CREATED_BY', F.lit('Databricks - LoadDriver').cast(StringType()))
  df = df.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
  df = df.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))

  df = df.select(
    'EQUATION_OBJECT_NUMBER',
 'EQUATION_NAME',
 'EQUATION',
 'EQUATION_TEMPLATE',
 'PLAN_TYPE_NAME',
 'WBS_TYPE',
 'DRIVER_NAME',
 'ID',
 'SOURCE',
 'RUN_ID',
 'CREATION_DATE',
 'CREATED_BY',
 'UPDATION_DATE',
 'UPDATED_BY'
  )

# COMMAND ----------

# write to sql dw
if process_flag:
  df.write\
    .format("com.databricks.spark.sqldw")\
    .option("url", sqlDwUrl)\
    .option( "forward_spark_azure_storage_credentials", "True")\
    .option("tempdir", tempDir)\
    .option("maxStrLength", "4000" ) \
    .option("dbtable", "irm_stg.EQUATIONS") \
    .mode("append")\
    .save()

# COMMAND ----------

# # delete old data once new data has been inserted successfully
if process_flag:
  sql="delete from irm_stg.EQUATIONS where CREATION_DATE != '"+ processTime+"'"
  dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})
#   sql
  