# Databricks notebook source
#File Name: LoadPLWRBSHierarchy
#ADF Pipeline Name: IRM_ADL_DW-PLWPlan-PLWActivity
#SQLDW Table: irm_stg.RBS_HIERARCHY
#Description:
  #Read Planisware RBS_Hierarchy data from unified layer in ADL and load to staging table in SQL DW

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "sdijo32-bvdfo-vdfpiu-bvdkl3")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

# read new planisware data
df = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load('dbfs:/mnt/unified/project_management/rbs_hierarchy.txt')

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ' '))


# COMMAND ----------

df = df.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
df = df.withColumn('CREATION_DATE', F.lit(processTime).cast(TimestampType()))
df = df.withColumn('CREATED_BY', F.lit('Databricks - LoadPLWRBSHierarchy').cast(StringType()))
df = df.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
df = df.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))

# COMMAND ----------

df = df.select(
'id','rbs_id','inactive','lvl6_RBS_DESC','lvl6_order_number','lvl5_RBS_DESC','lvl5_order_number','lvl4_RBS_DESC','lvl4_order_number','lvl3_RBS_DESC','lvl3_order_number','lvl2_RBS_DESC','lvl2_order_number','lvl1_RBS_DESC','lvl1_order_number','RATE_TYPE','RATE_UNIT','RATE','resource_manager','SOURCE', 'RUN_ID', 'CREATION_DATE', 'CREATED_BY', 'UPDATION_DATE', 'UPDATED_BY'
)

# COMMAND ----------

# write to sql dw
df.write\
  .format("com.databricks.spark.sqldw")\
  .option("url", sqlDwUrl)\
  .option( "forward_spark_azure_storage_credentials", "True")\
  .option("tempdir", tempDir)\
  .option("dbtable", "irm_stg.RBS_HIERARCHY")\
  .option("maxStrLength","4000")\
  .mode("append")\
  .save()

# COMMAND ----------

#delete old data once new data has been inserted successfully
sql="delete from irm_stg.RBS_HIERARCHY where CREATION_DATE != '"+ processTime +"'"
dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})