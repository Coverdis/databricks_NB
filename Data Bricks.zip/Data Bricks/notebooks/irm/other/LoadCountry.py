# Databricks notebook source
#File Name: LoadActivityResource
#ADF Pipeline Name: Composite_ADL
#SQLDW Table: irm_stg.Country
#Description:
  # Load MDM Country data from unified to staging table

# COMMAND ----------

# MAGIC   %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *

process_time = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "fwe9023-veui23-wqe922-cv9nsa")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

# read activity resource data
df = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load('dbfs:/mnt/unified/other/country.txt')
	
df = df.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
df = df.withColumn('CREATION_DATE', F.lit(process_time).cast(TimestampType()))
df = df.withColumn('CREATED_BY', F.lit('Databricks - LoadCountry').cast(StringType()))
df = df.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
df = df.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))

# COMMAND ----------

# write activity resource data to sql dw
df.write\
  .format("com.databricks.spark.sqldw")\
  .option("url", sqlDwUrl)\
  .option( "forward_spark_azure_storage_credentials", "True")\
  .option("tempdir", tempDir)\
  .option("dbtable", "irm_stg.COUNTRY")\
  .option("maxStrLength","4000")\
  .mode("append")\
  .save()
  



# COMMAND ----------

#delete old data once new data has been inserted successfully
sql="delete from irm_stg.COUNTRY where CREATION_DATE != '"+ process_time +"'"
dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})