# Databricks notebook source
#File Name: LoadResourceForecast
#ADF Pipeline Name: ADL_DW-IRM-PLWPlan-PLWActivity
#SQLDW Table: irm_stg.Resource_Forecast
#Description:
  #Read legacy Planisware, New Planisware and Vaccines resource forecast data from ADL and load to staging table in SQL DW

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')


dbutils.widgets.text("referenceobjectnumber", "")
dbutils.widgets.text("runid", "")
dbutils.widgets.dropdown("baselineflag", "false", ['true', 'false'])
dbutils.widgets.dropdown("source", "plw-new", ['plw-new', 'vx-plw'])

runid = dbutils.widgets.get("runid")
source = dbutils.widgets.get("source")
baselineflag=dbutils.widgets.get("baselineflag")
referenceobjectnumber=dbutils.widgets.get("referenceobjectnumber")

# COMMAND ----------

if source == 'plw-new':
  if baselineflag=='true':
    unified_path='dbfs:/mnt/unified/project_management/reference_resource_forecast/'+referenceobjectnumber+'.txt'
  elif baselineflag!='true':
    unified_path='dbfs:/mnt/unified/project_management/resource_forecast.txt' 
elif source != 'plw-new':
  unified_path='dbfs:/mnt/unified/project_management/vx_resource_forecast.txt'

# COMMAND ----------

# read legacy planisware data and add source
df = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(unified_path)

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

# COMMAND ----------

df=df.withColumn('STD_FTES_FORECAST',F.col('STD_FTES_FORECAST').cast(FloatType()))

if baselineflag=='true': 
  df = df.withColumn('ACTIVITY_VERSION_TYPE', F.lit('Baseline').cast(StringType()))
  df = df.withColumn('PROJECT_PHASE', F.lit(None).cast(StringType()))
else: df = df.withColumn('ACTIVITY_VERSION_TYPE', F.lit(None).cast(StringType()))
if source=='vx-plw':
  df = df.withColumn('PROJECT_PHASE', F.lit(None).cast(StringType()))

df = df.withColumn('ACTIVITY_BASELINE_NAME', F.lit(None).cast(StringType()))  
df = df.withColumn('ACTIVITY_BASELINE_TYPE', F.lit(None).cast(StringType()))
df = df.withColumn('ORIGINAL_RATE', F.lit(None).cast(DecimalType()))
df = df.withColumn('WBS_TYPE', F.lit(None).cast(StringType()))
df = df.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
df = df.withColumn('CREATION_DATE', F.lit(processTime).cast(TimestampType()))
df = df.withColumn('CREATED_BY', F.lit('Databricks - LoadPLWResourceForecast').cast(StringType()))
df = df.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
df = df.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))

# COMMAND ----------

df = df.select(
'ACTIVITY_OBJECT_NUMBER', 'RBS', 'STD_FTES_FORECAST', 'YEAR', 'MONTH', 'RESOURCE_TYPE', 'ACTIVITY_VERSION_TYPE', 'ACTIVITY_BASELINE_NAME', 'ACTIVITY_BASELINE_TYPE', 'ORIGINAL_RATE','PLAN_OBJECT_NUMBER','WBS_TYPE','AMOUNT_GBP','COST_TYPE','COUNTRY','PLANNED_SITES', 'FORECASTED_IN_CSAP','REFERENCE_OBJECT_NUMBER', 'SOURCE', 'PROJECT_PHASE', 'RUN_ID', 'CREATION_DATE', 'CREATED_BY', 'UPDATION_DATE', 'UPDATED_BY'
)

# COMMAND ----------

#df=df.filter('ACTIVITY_OBJECT_NUMBER=117935737754' and 'RBS="GSK_RD_RES_IVIVT_BIB_GENO"')
df = df.withColumn("AMOUNT_GBP", df.AMOUNT_GBP.cast("Decimal(31,9)"))
#display(df)

# COMMAND ----------

# write to sql dw
df.write\
  .format("com.databricks.spark.sqldw")\
  .option("url", sqlDwUrl)\
  .option( "forward_spark_azure_storage_credentials", "True")\
  .option("tempdir", tempDir)\
  .option("dbtable", "irm_stg.Resource_Forecast")\
  .option("maxStrLength","4000")\
  .mode("append")\
  .save()

# COMMAND ----------

#delete old data once new data has been inserted successfully
if baselineflag=='true':
  sql="delete from irm_stg.RESOURCE_FORECAST where SOURCE='PLW-NEW' and REFERENCE_OBJECT_NUMBER = "+referenceobjectnumber +" and CREATION_DATE != '"+ processTime +"'"
else:
  sql="delete from irm_stg.RESOURCE_FORECAST where SOURCE='"+ source +"' and REFERENCE_OBJECT_NUMBER is null and CREATION_DATE != '"+ processTime +"'"
dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})