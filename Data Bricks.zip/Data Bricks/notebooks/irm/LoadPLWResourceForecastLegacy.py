# Databricks notebook source
#File Name: LoadPLWResourceForecastLegacy
#ADF Pipeline Name: ADL_DW-IRM-PLWPlan-PLWActivity
#SQLDW Table: irm_stg.PLW_Resource_Forecast
#Description:
  #Read legacy Planisware legacy resource forecast data from ADL and load to staging table in SQL DW

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "111")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

# read legacy planisware data and add source
df = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load('dbfs:/mnt/unified/project_management/resource_forecast_legacy.txt')

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ' '))

#df = df.withColumn('SOURCE', F.lit('PLW-LEGACY').cast(StringType()))

# COMMAND ----------

df = df.withColumn('COUNTRY', F.lit(None).cast(IntegerType()))  
df = df.withColumn('PLANNED_SITES', F.lit(None).cast(IntegerType()))
df = df.withColumn('PLAN_OBJECT_NUMBER', F.lit(None).cast(IntegerType()))  
df = df.withColumn('WBS_TYPE', F.lit(None).cast(StringType()))
df = df.withColumn('FORECASTED_IN_CSAP', F.lit(None).cast(StringType()))
df=df.withColumn('REFERENCE_OBJECT_NUMBER',F.lit(None).cast(LongType()))
df = df.withColumn('PROJECT_PHASE', F.lit(None).cast(StringType()))
df = df.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
df = df.withColumn('CREATION_DATE', F.lit(processTime).cast(StringType()))
df = df.withColumn('CREATED_BY', F.lit('Databricks - LoadPLWResourceForecastLegacy').cast(StringType()))
df = df.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
df = df.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))

# COMMAND ----------

df = df.select(
'ACTIVITY_OBJECT_NUMBER', 'RBS', 'STD_FTES_FORECAST', 'YEAR', 'MONTH', 'RESOURCE_TYPE', 'ACTIVITY_VERSION_TYPE', 'ACTIVITY_BASELINE_NAME', 'ACTIVITY_BASELINE_TYPE', 'ORIGINAL_RATE','PLAN_OBJECT_NUMBER','WBS_TYPE','AMOUNT_GBP','COST_TYPE','COUNTRY','PLANNED_SITES', 'FORECASTED_IN_CSAP','REFERENCE_OBJECT_NUMBER', 'SOURCE', 'PROJECT_PHASE', 'RUN_ID', 'CREATION_DATE', 'CREATED_BY', 'UPDATION_DATE', 'UPDATED_BY'
)

# COMMAND ----------

# write to sql dw
df.write\
  .format("com.databricks.spark.sqldw")\
  .option("url", sqlDwUrl)\
  .option( "forward_spark_azure_storage_credentials", "True")\
  .option("tempdir", tempDir)\
  .option("dbtable", "irm_stg.resource_forecast")\
  .option("maxStrLength","4000")\
  .mode("append")\
  .save()

# COMMAND ----------

#delete old data once new data has been inserted successfully
sql="delete from irm_stg.RESOURCE_FORECAST where SOURCE='PLW-LEGACY' and CREATION_DATE != '"+ processTime +"'"
dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})