# Databricks notebook source
#File Name: LoadPLWPlan
#ADF Pipeline Name: 
#SQLDW Table: irm_stg.Project_Team_Member
#Description:
  #Read Planisware Project Team Member data from ADL and load to staging table in SQL DW

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "111")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

# read new planisware data 
ptm = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load('dbfs:/mnt/unified/project_management/project_team_member.txt')

ptm = ptm.toDF(*(col.replace('\r', '') for col in ptm.columns))

for col_name in ptm.columns:
  ptm = ptm.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ' '))

# COMMAND ----------

ptm = ptm.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
ptm = ptm.withColumn('CREATION_DATE', F.lit(processTime).cast(TimestampType()))
ptm = ptm.withColumn('CREATED_BY', F.lit('Databricks - LoadProjectTeamMember').cast(StringType()))
ptm = ptm.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
ptm = ptm.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))

# COMMAND ----------

ptm = ptm.select(
'TEAM_MEMBER_ID', 'TEAM_ID', 'PERSON_MUD_ID', 'ROLE_CODE', 'ROLE_DESCRIPTION', 'SORT_ORDER', 'IN_DISTRIBUTION_LIST', 'RUN_ID', 'CREATION_DATE', 'CREATED_BY', 'UPDATION_DATE', 'UPDATED_BY'
)

# COMMAND ----------

# write to sql dw
ptm.write\
  .format("com.databricks.spark.sqldw")\
  .option("url", sqlDwUrl)\
  .option( "forward_spark_azure_storage_credentials", "True")\
  .option("tempdir", tempDir)\
  .option("dbtable", "irm_stg.PROJECT_TEAM_MEMBER")\
  .option("maxStrLength","4000")\
  .mode("append")\
  .save()

# COMMAND ----------

#delete old data once new data has been inserted successfully
sql="delete from irm_stg.PROJECT_TEAM_MEMBER where CREATION_DATE != '"+ processTime +"'"
dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})