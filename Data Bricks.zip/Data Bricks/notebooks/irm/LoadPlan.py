# Databricks notebook source
#File Name: LoadPLWPlan
#ADF Pipeline Name: ADL_DW-IRM-PLWPlan-PLWActivity
#SQLDW Table: irm_stg.PLW_PLAN
#Description:
  #Read Planisware PLAN (vaccines, legacy & new) and migrated plans from pdm  from ADL and load to staging table in SQL DW

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "")
dbutils.widgets.text("baselineflag", "")
dbutils.widgets.text("referenceobjectnumber", "")
dbutils.widgets.dropdown("source", "plw-new", ['plw-new', 'plw-legacy', 'pdm-migrated', 'vx-plw'])
runid = dbutils.widgets.get("runid")
source = dbutils.widgets.get("source")
baselineflag=dbutils.widgets.get("baselineflag")
referenceobjectnumber=dbutils.widgets.get("referenceobjectnumber")

# COMMAND ----------

if source=='plw-new' and baselineflag=='true':
  unified_path='dbfs:/mnt/unified/project_management/reference_plan/'+referenceobjectnumber+'.txt'
elif source=='plw-new' and baselineflag!='true':
  unified_path='dbfs:/mnt/unified/project_management/plan.txt'
elif source=='plw-legacy':
  unified_path='dbfs:/mnt/unified/project_management/plan_legacy.txt'
  dbutils.notebook.exit('Legacy Notebook Disabled')
elif source=='pdm-migrated':
  unified_path='dbfs:/mnt/unified/project_management/plan_migrated.txt'  
elif source == 'vx-plw':
  unified_path = 'dbfs:/mnt/unified/project_management/vx_plan.txt'

# COMMAND ----------

# read new planisware data 
df = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(unified_path)

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ' '))

# COMMAND ----------

df = df.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
df = df.withColumn('CREATION_DATE', F.lit(processTime).cast(TimestampType()))
df = df.withColumn('CREATED_BY', F.lit('Databricks - LoadPlan').cast(StringType()))
df = df.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
df = df.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))

# COMMAND ----------

cols = ['PLAN_OBJECT_NUMBER', 'PLAN_CURRENT_PHASE', 'PLAN_OWNER_NAME', 'PLAN_OWNER_ID', 'PLAN_NAME', 'PLAN_LAST_REVIEWED_DATE', 'PLAN_LAST_REVIEWED_BY', 'PLAN_CREATION_DATE', 'PLAN_DESCRIPTION', 'VESTED_UNIT_NAME', 'PROJECT_ID', 'PLAN_STATE', 'PLAN_TYPE_NAME', 'PLAN_MODIFIED_VERSION', 'PLAN_MODIFICATION_DATE', 'PLAN_USER_COMMENT', 'PLAN_VERSION_STATUS_TYPE_NAME', 'THERAPY_AREA_ABBREVIATION', 'COMPOUND_ASSET_GSK_ASSET_NUMBER', 'DISEASE_NAME', 'PRIMARY_INDICATION_FLAG', 'BUDGET_PLANNED_END_DATE', 'BUDGET_NAME', 'BUDGET_PLANNED_START_DATE', 'PLAN_CALENDAR_NAME', 'PLAN_CLASS_TYPE_NAME', 'PLAN_CLASS_TYPE_DESCRIPTION', 'PLAN_DELETED_FLAG', 'PROJECT_PLANNED_END_DATE', 'PLAN_TEMPLATE_FLAG', 'PLAN_SCHEDULE_REVIEW_FLAG', 'PLAN_TEMPLATE_SEQUENCE_NUMBER', 'PROJECT_LOAD_FLAG', 'CLINICAL_STUDY_LIST', 'PLAN_ID', 'PLAN_ACTIVE_FLAG', 'PLAN_LAST_MODIFICATION_DATE', 'PLAN_LAST_MODIFIED_BY', 'PLAN_COMMON_FILE_LIST', 'PLAN_LOAD_FLAG', 'PLAN_LOCKED_BY_', 'PLAN_LOCKED_DATE', 'PLAN_TIME_UNIT_NAME', 'NUMBER_OF_OBJECTS', 'PLAN_ORIGIN_ID', 'PLAN_PERMANENT_LOCK_FLAG', 'PROJECT_ACTUAL_END_DATE', 'PROJECT_ACTUAL_START_DATE', 'PLAN_ACCESS_RIGHT_TYPE_NAME', 'PLAN_STATE_TYPE_NAME', 'PLAN_TEMPLATE_NAME', 'CSAP_FLAG', 'MDP_FLAG', 'PLAN_VISIBLE_FLAG', 'PSAP_FLAG', 'PLAN_VERSION_FLAG', 'PLAN_FULL_NAME', 'PLAN_TYPE_DESCRIPTION', 'PROJECT_FULL_NAME', 'THERAPY_AREA_LONG_NAME', 'PLAN_VERSION_DESCRIPTION', 'PLAN_VERSION_NUMBER', 'PLAN_ACTIVITY_NUMBER', 'BUDGET_ID', 'PLAN_PLACEHOLDER_ATTRIBUTE_1', 'PLAN_PLACEHOLDER_ATTRIBUTE_2', 'PLAN_PLACEHOLDER_ATTRIBUTE_3', 'PLAN_CURRENT_DATE', 'PROJECT_READ_ONLY_USER_GROUP_NAME', 'PROJECT_READ_WRITE_USER_GROUP_NAME', 'PROJECT_PLANNED_START_DATE', 'PROJECT_PLAN_STATUS', 'STUDY_ID', 'PROJECT_STUDY_PHASE', 'PROJECT_PLAN_STATUS_DESCRIPTION', 'BASELINE_FLAG','PLAN_STRATEGIC_FRAMEWORK', 'ASSET_ORIGIN', 'WHAT_WILL_PROJECT_BE_DELIVERING', 'IMMUNOMODULATOR_FLAG', 'PROJECT_DELIVERABLE_TYPE','BIOSTATS_RESOURCE_STRATEGY','PLAN_PIPELINE_SPLIT','PARTNERSHIP_TYPE','SCENARIO_CODE','SCENARIO_GROUP','SCENARIO_TYPE','SCENARIO_VERSION','SCENARIO_STATUS','PLW_ACCESS','REPORT_ACCESS','SCENARIO_DOC','REFERENCE_OBJECT_NUMBER','REFERENCE_PROJECT','REFERENCE_BASELINE_TYPE','REFERENCE_ALTERNATE_NAME','REFERENCE_CREATED_BY','REFERENCE_ARCHIVE_DATE', 
        
'STUDY_DESIGNATION','ACTIVE_SUBSTANCE_TYPE_DESCRIPTION','PROJECT_STATUS','ROUTE_OF_ADMINISTRATION','STUDY_PHASE','PROJECT_CURRENT_PHASE','TEMPORARY_STUDY_ID','ORIGIN_DATE','NUMBER_OF_COUNTRIES','STUDY_DESIGN','NUMBER_OF_STAGE','TG_COMPLEXITY','PROJECT_STUDY_TYPE','MECHANISM_OF_ACTION_DESCRIPTION','NCR_COMPLEXITY','NUMBER_OF_ASSESSMENTS','ACTIVE_SUBSTANCE_ID','PROJECT_SERM_COMPLEXITY','STUDY_BLINDING','CMC_COMPLEXITY','GRPD_COMPLEXITY','COMPANION_DIAGNOSTICS','NUMBER_IMAGES','CANDIDATE_SELECTION_TYPE_NAME','CPMS_RESOURCE_STRATEGY','NUMBER_BIOMARKER_TYPES','PROJECT_ASSAY','PROJECT_RESOURCE_STRATEGY', 'PLAN_EPE_LAST_UPLOAD_DATE', 'PLAN_EPE_LAST_UPLOAD_BY', 'EPE_CHECK_STATUS_FLAG', 'PLANNED_NUMBER_OF_PATIENTS','NUMBER_OF_CENTER','NUMBER_STUDY_VISITS','COUNTRIES','PROJECT_INDICATION', 'BUDGET_REFERENCE_OBJECT_NUMBER',
        
'SOURCE', 'RUN_ID', 'CREATION_DATE', 'CREATED_BY', 'UPDATION_DATE', 'UPDATED_BY']
df = df.select(cols)

# COMMAND ----------

# write to sql dw
df.write\
  .format("com.databricks.spark.sqldw")\
  .option("url", sqlDwUrl)\
  .option( "forward_spark_azure_storage_credentials", "True")\
  .option("tempdir", tempDir)\
  .option("dbtable", "irm_stg.PLW_PLAN")\
  .option("maxStrLength","4000")\
  .mode("append")\
  .save()

# COMMAND ----------

#delete old data once new data has been inserted successfully
if baselineflag=='true':
  sql="delete from irm_stg.PLW_PLAN where SOURCE = '"+ source +"' and CREATION_DATE != '"+ processTime +"' AND REFERENCE_OBJECT_NUMBER = " +referenceobjectnumber
else:  
  sql="delete from irm_stg.PLW_PLAN where SOURCE = '"+ source +"' and CREATION_DATE != '"+ processTime +"' AND REFERENCE_OBJECT_NUMBER is null"
dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})