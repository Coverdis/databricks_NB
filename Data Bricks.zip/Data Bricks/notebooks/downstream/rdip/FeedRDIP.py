# Databricks notebook source
#File Name: rdip
#ADF Pipeline Name: ADL_RDIP
#SQLDW Table: NA
#Description:
  #Read Planisware PLAN (new)  and push to RDIP 
   

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "")
runid = dbutils.widgets.get("runid")
raw_path = 'dbfs:/mnt/raw/rdip/'
rdip_path = 'dbfs:/mnt/rdip/irm/'

# COMMAND ----------

unified_path='dbfs:/mnt/unified/project_management/plan.txt' 
# read new planisware data 
df = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(unified_path)

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ' '))
cols = ['PLAN_OBJECT_NUMBER','PLAN_NAME','PLAN_DESCRIPTION','PROJECT_ID','PLAN_STATE','PLAN_TYPE_NAME','CLINICAL_STUDY_LIST','PLAN_ID','PLAN_ACTIVE_FLAG','PROJECT_FULL_NAME','BASELINE_FLAG']
df = df.select(cols)
df = df.withColumn('CREATION_DATE-IRM', F.lit(processTime).cast(StringType()))

# COMMAND ----------

# write plan file to rdip folder

unique_run_id = runid + '-rdip/plan'
csv_temp_curated = raw_path + unique_run_id +'/'

df.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], rdip_path + "plan.txt", recurse = True)
# remove temp folder
#dbutils.fs.rm(raw_path + unique_run_id, recurse = True)

# COMMAND ----------

unified_path='dbfs:/mnt/unified/project_management/task.txt' 
# read new planisware activity data 
df = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(unified_path)

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ' '))
cols = ['PLAN_OBJECT_NUMBER','ACTIVITY_OBJECT_NUMBER','ACTIVITY_NAME','ACTIVITY_DESCRIPTION','PLAN_NAME','CLINICAL_STUDY_ID','VESTED_UNIT_NAME','PROJECT_ID','ACTIVITY_PLANNED_START_DATE','ACTIVITY_PLANNED_END_DATE','ACTIVITY_ACTUAL_START_DATE','ACTIVITY_ACTUAL_END_DATE','ACTIVITY_SCOPE_NAME','ACTIVITY_USER_COMMENT','BUDGET_START_DATE','BUDGET_END_DATE','MILESTONE_LONG_NAME','MILESTONE_SHORT_NAME','MILESTONE_ABBREVIATION','MILESTONE_SORT_ORDER','MILESTONE_PHASE_PROGRESSION','MILESTONE_SYNONYM','MILESTONE_CALC_GROUP','MILESTONE_CALC_MEMBER','PLANISWARE_ACTIVITY_TYPE','FIRST_SUBMISSION_MILESTONE','FIRST_APPROVAL_MILESTONE','FIRST_LAUNCH_MILESTONE','NEXT_PLANNED_MILESTONE','NEXT_PLANNED_DECISION_POINT_MILESTONE','LATEST_ACHIEVED_MILESTONE','LATEST_ACHIEVED_COMMIT_TO_MILESTONE','MILESTONE_STATUS']
df = df.select(cols)

df = df.withColumn('CREATION_DATE-IRM', F.lit(processTime).cast(StringType()))

# write activity file to rdip folder
unique_run_id = runid + '-rdip/activity'
csv_temp_curated = raw_path + unique_run_id
df.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
temp = dbutils.fs.ls(csv_temp_curated)[-1][0]

dbutils.fs.cp(temp, rdip_path + "activity.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)

# COMMAND ----------

unified_path='dbfs:/mnt/unified/project_management/project.txt' 
# read project data 
df = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(unified_path)

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ' '))
cols = ['ACTIVE_SUBSTANCE_ID','PROJECT_CURRENT_PHASE','START_PHASE','PROJECT_CODE','PROJECT_DESCRIPTION','DESCRIPTION_SHORT','PROJECT_STATUS_CODE','PROJECT_STATUS','PROJECT_STATUS_LONG_NAME','PROJECT_CREATION_DATE','PROJECT_CREATION_USER_ID','PROJECT_MODIFICATION_DATE','PROJECT_MODIFICATION_USER_ID','PROJECT_FORM_NAME','PROJECT_OWNER_USER_ID','PROJECT_STATUS_CHANGE_DATE','PROJECT_STATUS_CHANGE_COMMENT','TEAM_ID','PROJECT_STATUS_TERMINATION_REASON','ACTIVE_SUBSTANCE_TYPE_CODE','MEDICAL_CONDITION_CODE','INDICATION','THERAPEUTIC_AREA_SHORT_NAME','THERAPEUTIC_AREA_LONG_NAME','DELIVERABLE_TYPE','ACTIVE_SUBSTANCE_DESCRIPTION','FL_COMBINATION','COMPOUND_REPORTED_NAME','CANDIDATE_SELECTION_TYPE_NAME','ROUTE_OF_ADMINISTRATION','THERAPY_TYPE','THERAPY_TYPE_COMMENT','LEAD_BU_CODE','DEFAULT_FUNDING_PARTY','FUNDER_L1','FUNDER_L2','FUNDER_L3','IMMUNOMODULATORY_FLAG','GENESYMBOL','ACTIVE_SUBSTANCE_SUB_TYPE_DESCRIPTION','ACTIVE_SUBSTANCE_TYPE_DESCRIPTION','COMPOUND_STATUS','EARLIEST_MILESTONE_DISPLAY_ORDER','EARLIEST_MILESTONE_PHASE','EARLIEST_MILESTONE_REPORT_DATE','START_PHASE_DISPLAY_ORDER','CURRENT_PHASE_DISPLAY_ORDER','CURRENT_PHASE_INDUSTRY_ORDER','PROJECT_ORDER_FOR_ACTIVE_SUBSTANCE','LEAD_INDICATION_FLAG','COMPOUND_MARKET_STATUS','PROJECT_CATEGORY','PROJECT_CATEGORY_DETAILED']


df = df.select(cols)

df = df.withColumn('CREATION_DATE-IRM', F.lit(processTime).cast(StringType()))

unique_run_id = runid + '-rdip/plan'
csv_temp_curated = raw_path + unique_run_id +'/'

df.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
temp = dbutils.fs.ls(csv_temp_curated)[-1][0]

dbutils.fs.cp(temp, rdip_path + "project.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)

# COMMAND ----------

unified_path='dbfs:/mnt/unified/project_management/project_team.txt' 
# read project team data 
df = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(unified_path)

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ' '))
cols = ['TEAM_ID','TEAM_NAME','TEAM_DESCRIPTION','CREATE_DATE','CREATE_USER','MODIFY_DATE','MODIFY_USER','TEAM_TYPE_CODE','TEAM_TYPE_SHORT_NAME','TEAM_TYPE_LONG_NAME']

df = df.select(cols)

df = df.withColumn('CREATION_DATE-IRM', F.lit(processTime).cast(StringType()))

unique_run_id = runid + '-rdip/plan'
csv_temp_curated = raw_path + unique_run_id +'/'

df.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
temp = dbutils.fs.ls(csv_temp_curated)[-1][0]

dbutils.fs.cp(temp, rdip_path + "project_team.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)

# COMMAND ----------

unified_path='dbfs:/mnt/unified/project_management/project_team_member.txt' 
# read project team member data 
df = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(unified_path)

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ' '))
cols = ['TEAM_MEMBER_ID','TEAM_ID','PERSON_MUD_ID','ROLE_CODE','ROLE_DESCRIPTION','SORT_ORDER','IN_DISTRIBUTION_LIST']

df = df.select(cols)

df = df.withColumn('CREATION_DATE-IRM', F.lit(processTime).cast(StringType()))

unique_run_id = runid + '-rdip/plan'
csv_temp_curated = raw_path + unique_run_id +'/'

df.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
temp = dbutils.fs.ls(csv_temp_curated)[-1][0]

dbutils.fs.cp(temp, rdip_path + "project_team_member.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)