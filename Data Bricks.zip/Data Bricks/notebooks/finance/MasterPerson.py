# Databricks notebook source
#File Name:MasterPerson
#ADF Pipeline Name: FIN_ADL_DW-Project_Activity_GL_ROWExp_RURate
#SQLDW Table:fin_stg.PERSON
#Description:
  #Writes final file in curated layer
  #Identify delta between source person file and existing DW records
  #Delta is being inserted in SQL DW to maintain history in person staging table.

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

dbutils.widgets.text("runid", "ashg1-s28s2-dwjw2-2ewhd")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
import pytz
from datetime import datetime

curated_path = 'dbfs:/mnt/curated/amars/'
process_time = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')
file_name = 'amars_person.txt'

# COMMAND ----------

# read person data
person = spark.read.format("csv")\
      .option("inferSchema","true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load(curated_path + file_name)

person = person.toDF(*(col.replace('\r', '') for col in person.columns))

person = person.select(
  'PERSON_KEY',
  'PERSON_MUD_ID',
  'FIRST_NAME', 
  'LAST_NAME',
  'EMAIL'
)

person = person.withColumnRenamed("EMAIL", "EMAIL_ID")

for col_name in person.columns:
  person = person.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

# COMMAND ----------

delta_flag = False
delta_df = None
try:
  pushdown_query = "(select PERSON_KEY, PERSON_MUD_ID, FIRST_NAME, LAST_NAME, EMAIL_ID from fin_stg.PERSON) person"
  dw_person = spark.read.jdbc(url = sqlDwUrl, table = pushdown_query)

  delta_df = person.subtract(dw_person)
  
  if delta_df.count() > 0:
    delta_flag = True
  
  delta_df.createOrReplaceTempView("PERSON")
except Exception as e:
  print(e)

# COMMAND ----------

if delta_flag:
  query = "SELECT PERSON_KEY, PERSON_MUD_ID, FIRST_NAME, LAST_NAME, EMAIL_ID, '{0}' as RUN_ID, to_timestamp('{1}') as CREATION_DATE, 'Databricks - MasterPerson' as CREATED_BY, CAST(null as timestamp) as UPDATION_DATE, CAST(null as string) as UPDATED_BY FROM PERSON".format(runid, process_time)

  person_df = sqlContext.sql(query)

  # write dataframe to DW using polybase
  person_df.write\
      .format("com.databricks.spark.sqldw")\
      .option("url", sqlDwUrl)\
      .option( "forward_spark_azure_storage_credentials", "True")\
      .option("tempdir", tempDir)\
      .option("dbtable", "fin_stg.PERSON") \
      .mode("append")\
      .save()