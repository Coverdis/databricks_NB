# Databricks notebook source
#File Name:LoadDRMProjectHierarchy
#ADF Pipeline Name: HypDRM_ADL
#Description:
  #Writes flatten project hierarchy file to SQL DW

# COMMAND ----------

# MAGIC %run "/library/configFile"

# COMMAND ----------

dbutils.widgets.text('runid', 'asdj22-scj22-7878sh-sxuj2d')
runid = dbutils.widgets.get("runid")

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *

process_time = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

curated_path = 'dbfs:/mnt/curated/hyperion_drm/'

# COMMAND ----------

delta_flag = False
delta_df = None
try:
  curated_df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(curated_path + "project_hierarchy.txt")
  
  curated_df = curated_df.toDF(*(c.replace('\r', '') for c in curated_df.columns))
  
  pushdown_query = "(SELECT p.STUDY_ID, STUDY_NAME, PROJECT_CODE, PROJECT_NAME, REPORTING_GROUP, \
                  REPORTING_GROUP_DESCRIPTION, THERAPY_AREA, THERAPY_AREA_DESCRIPTION, MANAGING_ORG, \
                  MANAGING_ORG_DESCRIPTION, ROOT, ROOT_DESCRIPTION, FUNDINGORG, PCUDA \
                  FROM fin_stg.PROJECT_HIERARCHY p, \
                  (SELECT STUDY_ID, CREATION_DATE, RANK() over \
                  (partition by STUDY_ID order by CREATION_DATE desc) as RANK_ID FROM fin_stg.PROJECT_HIERARCHY) r \
                  where p.STUDY_ID=r.STUDY_ID and p.CREATION_DATE=r.CREATION_DATE and r.RANK_ID=1) ph"

  dw_project_hierarchy = spark.read.jdbc(url = sqlDwUrl, table = pushdown_query)

  delta_df = curated_df.subtract(dw_project_hierarchy)
  
  if delta_df.count() > 0:
    delta_flag = True
  
  delta_df.createOrReplaceTempView("PROJECT_HIERARCHY")  
except Exception as e:
  print(e)

# COMMAND ----------

if delta_flag:
  query = "SELECT STUDY_ID, STUDY_NAME, PROJECT_CODE, PROJECT_NAME, REPORTING_GROUP, REPORTING_GROUP_DESCRIPTION, THERAPY_AREA, THERAPY_AREA_DESCRIPTION, MANAGING_ORG, MANAGING_ORG_DESCRIPTION, ROOT, ROOT_DESCRIPTION,FUNDINGORG,PCUDA, 'DRM' as SOURCE, '{0}' as RUN_ID, to_timestamp('{1}') as CREATION_DATE, 'Databricks - LoadDRMProjectHierarchy' as CREATED_BY, CAST(null as timestamp) as UPDATION_DATE, CAST(null as string) as UPDATED_BY FROM PROJECT_HIERARCHY".format(runid, process_time)

  df = sqlContext.sql(query)

  # write dataframe to DW using polybase
  df.write\
      .format("com.databricks.spark.sqldw")\
      .option("url", sqlDwUrl)\
      .option( "forward_spark_azure_storage_credentials", "True")\
      .option("tempdir", tempDir)\
      .option("dbtable", "fin_stg.PROJECT_HIERARCHY") \
      .mode("append")\
      .save()