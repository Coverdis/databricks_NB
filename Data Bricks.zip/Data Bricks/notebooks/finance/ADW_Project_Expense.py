# Databricks notebook source
# MAGIC %run "./configFile"

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *
import pytz
import re
from datetime import datetime
processTime = datetime.now(pytz.timezone("US/Eastern")).strftime('%Y-%m-%dT%H:%M:%S')


et_df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load("dbfs:/mnt/foundation/et/effort_Fact_History")

# COMMAND ----------

fact_base = et_df['START_DATE','CC_ORIG_CODE','PROJECT_ID','ORIG_PROJ_CODE','TotalHours','TotalFTEs']

# COMMAND ----------

fact_base_month = fact_base.withColumn('month',month(et_df.START_DATE)).withColumn('year',year(et_df.START_DATE))

# COMMAND ----------

fact_base_rollup = fact_base_month.groupBy(['year','month','START_DATE','CC_ORIG_CODE','PROJECT_ID','ORIG_PROJ_CODE']).sum('TotalHours','TotalFTEs').withColumnRenamed('sum(TotalHours)','TotalHours').withColumnRenamed('sum(TotalFTEs)','TotalFTEs')

# COMMAND ----------

rates_pivot = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load("dbfs:/mnt/foundation/effort_poc/rates_pivot.txt")

# COMMAND ----------

#bring in hierarchy
hier_df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load("dbfs:/mnt/curated/hyperion_drm/cost_center_hierarchy.txt")

# COMMAND ----------

hier_df_subset = hier_df['COST_CENTER_CODE','Div_id',].withColumnRenamed('Div_id','div_id').withColumnRenamed('COST_CENTER_CODE','CC_ORIG_CODE')

# COMMAND ----------

fact_base_enriched = fact_base_rollup.join(hier_df_subset,'CC_ORIG_CODE').withColumnRenamed('TotalHours','Fact_Hours').withColumnRenamed('TotalFTEs','Fact_FTEs')

# COMMAND ----------

fact_base_rates = fact_base_enriched.join(rates_pivot,['year','month','div_id'])

# COMMAND ----------

fact_final = fact_base_rates['START_DATE','CC_ORIG_CODE','PROJECT_ID','ORIG_PROJ_CODE','Fact_Hours','Fact_FTEs','RateTotalHours','RateTotalFTEs']

# COMMAND ----------


fact_final = fact_final.withColumn('IPE_Expense_Hours',fact_final.Fact_Hours*fact_final.RateTotalHours).withColumn('IPE_Expense_FTEs',fact_final.Fact_FTEs*fact_final.RateTotalFTEs)


# fact_final = fact_final.withColumn('IPE_Expense_Hours',fact_final.Fact_Hours*fact_final.RateTotalHours).withColumn('IPE_Expense_FTEs',fact_final.Fact_FTEs*fact_final.RateTotalFTEs).withColumn('EPE',fact_final.Fact_Hours*0).withColumn('Total_Expense_Hours',fact_final.Fact_Hours*0).withColumn('Total_Expense_FTEs',fact_final.Fact_Hours*0)

# COMMAND ----------

# DBTITLE 1,F_PROJECT_EXPENSE is below


# COMMAND ----------

F_Project_Expense = fact_final['START_DATE','CC_ORIG_CODE','PROJECT_ID','ORIG_PROJ_CODE','Fact_Hours','Fact_FTEs','IPE_Expense_Hours','IPE_Expense_FTEs']


#F_Project_Expense = fact_final['START_DATE','CC_ORIG_CODE','PROJECT_ID','ORIG_PROJ_CODE','Fact_Hours','Fact_FTEs','IPE_Expense_Hours','IPE_Expense_FTEs','EPE','Total_Expense_Hours','Total_Expense_FTEs']

# COMMAND ----------

# DBTITLE 1,Code below is intended to get EPE into the fact table. It is designed to pull from COAST and CERPS.


# COMMAND ----------

coast_row_expense_df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load("dbfs:/mnt/raw/coast/coast_mtd_actuals_epe_from_fdr.txt")

#no longer need line to filter out WBS Code Unknown
#coast_row_epe = coast_row_expense_df.filter(coast_row_expense_df.WBS_CODE != 'UNK')

#Coast EPE: Join month, year, project id = wbs_code, cost center code = cost center code

# COMMAND ----------

coast_row_expense_df = coast_row_expense_df.withColumnRenamed('SUM(A.AMT_MTD_GBP)\r','AMT_GBP').withColumnRenamed('OBS_CODE','COST_CENTER_CODE')

# COMMAND ----------

coast_row_expense_trimmed = coast_row_expense_df['COST_CENTER_CODE','BUD_ID','GL_DATE','AMT_GBP']

# COMMAND ----------

exp_project_dim = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load("dbfs:/mnt/foundation/fdr/fdr_exp_project_dim.txt")


# COMMAND ----------

project_dim_trimmed = exp_project_dim['CHILD_CODE','PARENT_CODE']

# COMMAND ----------

coast_row_expense_enriched = coast_row_expense_trimmed.join(project_dim_trimmed, coast_row_expense_trimmed.BUD_ID == project_dim_trimmed.CHILD_CODE)
#display(coast_row_expense_enriched)

# COMMAND ----------

#pull US/UK expense from CERPS
cerps_us_uk_expense_df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load("dbfs:/mnt/curated/cerps/gllineitem/*/GLLineitem-*-*.txt")

#cerps -- wbs elemnt is project idea


# COMMAND ----------

cerps_us_uk_epe = cerps_us_uk_expense_df.filter((cerps_us_uk_expense_df.RANK == 1) &
                                                ((cerps_us_uk_expense_df.WBS_ELEMT.like('%-RD-%')) |
                                                 (cerps_us_uk_expense_df.WBS_ELEMT.like('%-CT-%'))))

# COMMAND ----------

cerps_expenses = cerps_us_uk_expense_df['FISCPER3','FISCYEAR','COSTCENTER','DEB_CRE_LC','LOC_CURRCY','WBS_ELEMT'].filter(cerps_us_uk_expense_df.COSTCENTER.isNotNull()).withColumnRenamed('FISCPER3','MONTH').withColumnRenamed('FISCYEAR','YEAR').withColumn('COST_CENTER', substring(cerps_us_uk_expense_df.COSTCENTER,3,10))

# COMMAND ----------

cerps_expenses = cerps_expenses.drop('COSTCENTER')

# COMMAND ----------

cerps_rollup = cerps_expenses.groupBy('MONTH','YEAR','LOC_CURRCY','WBS_ELEMT','COST_CENTER').sum('DEB_CRE_LC').withColumnRenamed('sum(DEB_CRE_LC)','DEB_CRE_LC')

# COMMAND ----------

display(cerps_rollup)

# COMMAND ----------


exchange_rates_df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine",'true')\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load("dbfs:/mnt/foundation/fdr/exchange_rates_r.txt")

exchange_rates_df = exchange_rates_df.toDF(*(c.replace('\r', '') for c in exchange_rates_df.columns)) 

cerps_expenses_currency = cerps_rollup.join(exchange_rates_df,
                                               (cerps_rollup.YEAR == exchange_rates_df.EXCHANGE_YEAR) & 
                                              (cerps_rollup.LOC_CURRCY == exchange_rates_df.CURRENCY_CODE))
cerps_expenses_converted = cerps_expenses_currency.withColumn('GBP_EXPENSE',cerps_expenses_currency.DEB_CRE_LC/cerps_expenses_currency.BUDGET_RATE)

# COMMAND ----------

#CERPS WBS mapping
wbs_bud_map = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine",'true')\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load("dbfs:/mnt/foundation/fdr/wbselemt_budid_map.txt")

wbs_bud_map = wbs_bud_map.toDF(*(c.replace('\r', '') for c in wbs_bud_map.columns)) 

# COMMAND ----------

#display(wbs_bud_map[wbs_bud_map.RD_BUDID == '7RAD200934\r'])
wbs_bud_map = wbs_bud_map.withColumn('BUDID_CLEAN',regexp_replace('RD_BUDID','\r',''))

# COMMAND ----------

cerps_epe_enriched = cerps_expenses_converted.join(wbs_bud_map,cerps_us_uk_epe.WBS_ELEMT == wbs_bud_map.CERPS_WBS_ELEMT)

# COMMAND ----------


cerps_epe_enriched_proj = cerps_epe_enriched.join(project_dim_trimmed, cerps_epe_enriched.BUDID_CLEAN == project_dim_trimmed.CHILD_CODE)

# COMMAND ----------

cerps_epe_enriched_proj_trimmed = cerps_epe_enriched_proj['YEAR','MONTH','COST_CENTER','PARENT_CODE','GBP_EXPENSE']
cerps_epe_enriched_proj_trimmed = cerps_epe_enriched_proj_trimmed.groupBy('YEAR','MONTH','COST_CENTER','PARENT_CODE').sum('GBP_EXPENSE').withColumnRenamed('sum(GBP_EXPENSE)','GBP_EXPENSE')

# COMMAND ----------

coast_row_expense_enriched =  coast_row_expense_enriched.withColumn('month',month(coast_row_expense_enriched.GL_DATE)).withColumn('year',year(coast_row_expense_enriched.GL_DATE))
coast_row_expense_trimmed = coast_row_expense_enriched['year','month','COST_CENTER_CODE','PARENT_CODE','AMT_GBP']
coast_row_expense_trimmed = coast_row_expense_trimmed.groupBy('year','month','COST_CENTER_CODE','PARENT_CODE').sum('AMT_GBP').withColumnRenamed('sum(AMT_GBP)','AMT_GBP')
#display(coast_row_expense_trimmed)

# COMMAND ----------

cerps_coast_combined = coast_row_expense_trimmed.union(cerps_epe_enriched_proj_trimmed)

# COMMAND ----------

cerps_coast_combined = cerps_coast_combined.withColumnRenamed('COST_CENTER_CODE','CC_ORIG_CODE').withColumnRenamed('PARENT_CODE','ORIG_PROJ_CODE')

# COMMAND ----------

display(cerps_coast_combined)

# COMMAND ----------

# coast  = coast_row_expense_trimmed
# cerps = cerps_epe_enriched_proj_trimmed
#fact = F_Project_Expense

# COMMAND ----------

F_Project_Expense = F_Project_Expense.withColumn('month',month(F_Project_Expense.START_DATE)).withColumn('year',year(F_Project_Expense.START_DATE))

# COMMAND ----------

F_Project_Expense_joined = F_Project_Expense.join(cerps_coast_combined,['CC_ORIG_CODE','ORIG_PROJ_CODE','year','month'])

# COMMAND ----------

F_Project_Expense_Final = F_Project_Expense_joined['START_DATE','CC_ORIG_CODE','ORIG_PROJ_CODE','Fact_Hours','Fact_FTEs','IPE_Expense_Hours','IPE_Expense_FTEs','AMT_GBP'].withColumnRenamed('AMT_GBP','EPE')
display(F_Project_Expense_Final)

# COMMAND ----------

F_Project_Expense_Final_Deploy = F_Project_Expense_Final.withColumn('Total_Expense_Hours',(F_Project_Expense_Final.IPE_Expense_Hours+F_Project_Expense_Final.EPE)).withColumn('Total_Expense_FTEs',(F_Project_Expense_Final.IPE_Expense_FTEs+F_Project_Expense_Final.EPE))

# COMMAND ----------

# write dataframe to DW using polybase
F_Project_Expense_Final_Deploy.write\
    .format("com.databricks.spark.sqldw")\
    .option("url", sqlDwUrl)\
    .option( "forward_spark_azure_storage_credentials", "True")\
    .option("tempdir", tempDir)\
    .option("dbtable", "fin.Project_Expense") \
    .mode("overwrite")\
    .save()