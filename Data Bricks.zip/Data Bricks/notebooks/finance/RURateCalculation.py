# Databricks notebook source
#File Name:RURateCalculation
#ADF Pipeline Name: FIN_ADL_DW-Project_Activity_GL_ROWExp_RURate_Person
#SQLDW Table:fin_stg.RU_RATE
#Description:
  #Calculates FTE rates for resource utilization use case
  #Saves ru_rate file in foundation layer
  #Save data in SQL DW.

# COMMAND ----------

# MAGIC %run "/library/configFile"

# COMMAND ----------

dbutils.widgets.text("runid", "1qs23-3hd62-1hshw-348dh-2jhsd")
runid = dbutils.widgets.get('runid')

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *
import pytz
import re
from datetime import datetime
processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')


# et_df = spark.read.format("csv")\
#           .option("inferSchema","true")\
#           .option("header","true")\
#           .option("multiLine","true")\
#           .option("delimiter","|")\
#           .option("quote", '"')\
#           .option("escape",'"')\
#           .option("nullValue","null")\
#     .load("dbfs:/mnt/foundation/et/efforts_month-*.txt")

et_df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load("dbfs:/mnt/foundation/et/timesheet/*/*.txt")

et_df_month = et_df.withColumn('month',month(et_df.START_DATE)).withColumn('year',year(et_df.START_DATE))
et_df_subset = et_df_month['year','month','COSTCENTRE', 'TotalHours', 'TotalFTEs']
et_df_rollup = et_df_subset.groupBy(['year','month','COSTCENTRE']).sum()
et_df_rollup_final = et_df_rollup.withColumnRenamed('sum(TotalHours)','TotalHours').withColumnRenamed('sum(TotalFTEs)','TotalFTEs')
et_df_rollup_final = et_df_rollup_final['year','month','COSTCENTRE','TotalHours','TotalFTEs']

et_df_rollup_final.createOrReplaceTempView("et")
et_df_month.createOrReplaceTempView("et_Month_v")

# COMMAND ----------

#bring in hierarchy
cchier_df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load("dbfs:/mnt/curated/hyperion_drm/cost_center_hierarchy.txt")

cchier_df.createOrReplaceTempView("ccHierarchy")

# COMMAND ----------

#Get headcount data from COAST for all countries (US, UK and RoW)
#add permanent and CW together.
 
coast_row_hc_df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load("dbfs:/mnt/foundation/coast/*/fdw_row_hc-*-*.txt")

coast_rcl_hc_df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load("dbfs:/mnt/foundation/coast/*/fdw_rcl_hc-*-*.txt")

coast_row_hc_df=coast_row_hc_df.drop('LOC_ID')
#it has PERM and CW workers
coast_hc_df=coast_row_hc_df.union(coast_rcl_hc_df) 
coast_hc_df = coast_hc_df.withColumn('month',month(coast_hc_df.GL_PERIOD)).withColumn('year',year(coast_hc_df.GL_PERIOD))
coast_hc_df=coast_hc_df.select('GL_PERIOD','COST_CENTER_CODE','month','year','HC_PEOPLE_COUNT','FTE_PEOPLE_COUNT')
coast_hc_df=coast_hc_df.groupBy(['GL_PERIOD','COST_CENTER_CODE','month','year']).sum('HC_PEOPLE_COUNT','FTE_PEOPLE_COUNT').withColumnRenamed('sum(HC_PEOPLE_COUNT)','HC_PEOPLE_COUNT').withColumnRenamed('sum(FTE_PEOPLE_COUNT)','FTE_PEOPLE_COUNT')

#coast_hc_df=coast_hc_df.sum()

hc_df= coast_hc_df.join(cchier_df,coast_hc_df.COST_CENTER_CODE == cchier_df.COST_CENTER_CODE).select(coast_hc_df.GL_PERIOD,coast_hc_df.HC_PEOPLE_COUNT,coast_hc_df.month,coast_hc_df.year,cchier_df.COST_CENTER_CODE,cchier_df.Div_id,cchier_df.Div_Description,cchier_df.Dir_id,cchier_df.Dir_Description,cchier_df.Org_id,cchier_df.Org_Description,cchier_df.COST_TYPE)

hc_df.createOrReplaceTempView("hc")


# COMMAND ----------

#get the IPE expense from COAST
coast_expense_df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load("dbfs:/mnt/curated/coast/fdw_opex_epe_ipe_*.txt")

#coast_expense_df=coast_expense_df.filter(coast_expense_df.COST_TYPE == 'IPE')
coast_expense_df= coast_expense_df.select('COST_CENTER_CODE','AMOUNT_GBP','FISCMONTH','FISCYEAR')
#coast_expense_df=coast_expense_df.withColumnRenamed('MTDAMOUNT','MTD')

#get US and UK expesne
#pull US/UK expense from CERPS
cerps_expense_df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load("dbfs:/mnt/curated/cerps/gllineitem/*/GLLineitem-*-*.txt")
cerps_expense_df = cerps_expense_df.toDF(*(col.replace('\r', '') for col in cerps_expense_df.columns))
cerps_expense_df = cerps_expense_df.filter(cerps_expense_df.RANK == 1)
cerps_expense_df= cerps_expense_df.select('COST_CENTER_CODE','AMOUNT_GBP','FISCMONTH','FISCYEAR')

#Below filter not required as it is already being put in curated layer
#.filter((cerps_expense_df.GL_ACCOUNT >= 5000000) & (cerps_expense_df.GL_ACCOUNT <= 8999999))

#cerps_expenses = #cerps_expense_df['COSTCENTER','LOC_CURRCY','DEB_CRE_LC','FISCPER3','FISCYEAR'].filter(cerps_expense_df.COSTCENTER.isNotNull()).filter(cerps_expense_df.WBS_ELEMT.isNull()).withColumnRenamed('FISCPER3','MONTH').withColumnRenamed('FISCYEAR','YEAR').withColumnRenamed('COSTCENTER','COST_CENTER_CODE').withColumnRenamed('LOC_CURRCY','CURRENCY_CODE').withColumnRenamed('DEB_CRE_LC','MTD')

expense_df=cerps_expense_df.union(coast_expense_df)


# COMMAND ----------

#get the exchange rates to convert expenses in GBP
#exchange_rates_df = spark.read.format("csv")\
 #         .option("inferSchema","true")\
 #         .option("header","true")\
 #         .option("multiLine","true")\
 #         .option("delimiter","|")\
 #         .option("quote", '"')\
 #         .option("escape",'"')\
 #         .option("nullValue","null")\
 #   .load("dbfs:/mnt/foundation/fdr/exchange_rates_r.txt")

#exchange_rates_df = exchange_rates_df.toDF(*(c.replace('\r', '') for c in exchange_rates_df.columns)) 

# COMMAND ----------

#Conversion of expense to GBP
#expenses_gbp_df = expesne_df.join(exchange_rates_df,
#                                               (expesne_df.YEAR == exchange_rates_df.EXCHANGE_YEAR) & 
#                                              (expesne_df.CURRENCY_CODE == #exchange_rates_df.CURRENCY_CODE)).select(expesne_df.COST_CENTER_CODE,expesne_df.CURRENCY_CODE,expesne_df.MTD,expesne_df.MONTH,expesne_df.YEAR,exchange_rates_df.BUDGET_RATE)

#expenses_gbp_df = expenses_gbp_df.withColumn('GBP_EXPENSE',(expenses_gbp_df.MTD/expenses_gbp_df.BUDGET_RATE))

#roll up expense at cc, month, year level
#expenses_gbp_df=expenses_gbp_df.select('COST_CENTER_CODE','MONTH','YEAR','GBP_EXPENSE') 
#expenses_gbp_rollup_df=expenses_gbp_df.groupBy(['COST_CENTER_CODE','MONTH','YEAR']).sum('GBP_EXPENSE').withColumnRenamed('sum(GBP_EXPENSE)','GBP_EXPENSE')

expenses_gbp_rollup_df=expense_df.groupBy(['COST_CENTER_CODE','FISCMONTH','FISCYEAR']).sum('AMOUNT_GBP').withColumnRenamed('sum(AMOUNT_GBP)','GBP_EXPENSE')

expenses_gbp_rollup_df.createOrReplaceTempView("expenseGBP")

# COMMAND ----------

query = "select hc.*,expenseGBP.GBP_EXPENSE,et.TotalHours,et.TotalFTEs  from hc inner join expenseGBP on (hc.month=expenseGBP.FISCMONTH and hc.year=expenseGBP.FISCYEAR and hc.COST_CENTER_CODE=expenseGBP.COST_CENTER_CODE) inner join et on (hc.month=et.month and hc.year=et.year and hc.COST_CENTER_CODE=et.COSTCENTRE)" 

hc_et_expense_df=sqlContext.sql(query)
hc_et_expense_df.createOrReplaceTempView("hc_et_expense_view")

# COMMAND ----------

query = "select hc_et_expense_view.*,d.hc_div,dir.hc_dir,org.hc_org,expdiv.exp_div,expdir.exp_dir,exporg.exp_org  from hc_et_expense_view inner join (select month,year,div_id,sum(HC_PEOPLE_COUNT) as hc_div from hc_et_expense_view group by month,year,Div_id) d on (d.month=hc_et_expense_view.month and d.year=hc_et_expense_view.year and hc_et_expense_view.Div_id=d.Div_id) inner join (select month,year,Dir_id,sum(HC_PEOPLE_COUNT) as hc_dir from hc_et_expense_view group by month,year,Dir_id) dir on (dir.month=hc_et_expense_view.month and dir.year=hc_et_expense_view.year and hc_et_expense_view.Dir_id=dir.Dir_id) inner join (select month,year,Org_id,sum(HC_PEOPLE_COUNT) as hc_org from hc_et_expense_view group by month,year,Org_id) org on (org.month=hc_et_expense_view.month and org.year=hc_et_expense_view.year and hc_et_expense_view.Org_id=org.Org_id) inner join (select month,year,Div_id,sum(GBP_EXPENSE) as exp_div from hc_et_expense_view where cost_type='SV'  group by month,year,Div_id) expdiv on (expdiv.month=hc_et_expense_view.month and expdiv.year=hc_et_expense_view.year and hc_et_expense_view.Div_id=expdiv.Div_id) inner join (select month,year,Dir_id,sum(GBP_EXPENSE) as exp_dir from hc_et_expense_view  where cost_type='SA'  group by month,year,Dir_id) expdir on (expdir.month=hc_et_expense_view.month and expdir.year=hc_et_expense_view.year and hc_et_expense_view.Dir_id=expdir.Dir_id) inner join (select month,year,Org_id,sum(GBP_EXPENSE) as exp_org from hc_et_expense_view  where cost_type='NS' group by month,year,Org_id) exporg on (exporg.month=hc_et_expense_view.month and exporg.year=hc_et_expense_view.year and hc_et_expense_view.Org_id=exporg.Org_id)"

rate_df=sqlContext.sql(query)

#calculate HC percent
rate_df=rate_df.withColumn('pctHCDiv',(rate_df.HC_PEOPLE_COUNT/rate_df.hc_div))
rate_df=rate_df.withColumn('pctHCDir',(rate_df.HC_PEOPLE_COUNT/rate_df.hc_dir))
rate_df=rate_df.withColumn('pctHCOrg',(rate_df.HC_PEOPLE_COUNT/rate_df.hc_org))
rate_df=rate_df.withColumn('pctExpDiv',(rate_df.pctHCDiv*rate_df.exp_div))
rate_df=rate_df.withColumn('pctExpDir',(rate_df.pctHCDir*rate_df.exp_dir))
rate_df=rate_df.withColumn('pctExpOrg',(rate_df.pctHCOrg*rate_df.exp_org))
rate_df=rate_df.withColumn('pctExpTotal',(rate_df.pctExpDiv + rate_df.pctExpDir + rate_df.pctExpOrg))


rate_df.createOrReplaceTempView("rate_view")

# COMMAND ----------

query="SELECT rv.*,r.pctExpTotalDiv,r.hoursDiv,r.fteDiv,r.hourlyRateDiv,r.fteRateDiv, '{0}' as RUN_ID, to_timestamp('{1}') as CREATION_DATE, 'Databricks - RURateCalculation' as CREATED_BY, CAST(null as timestamp) as UPDATION_DATE, CAST(null as string) as UPDATED_BY from rate_view rv inner join (select month,year,div_id,sum(pctExpTotal) as pctExpTotalDiv,sum(TotalHours) as hoursDiv,sum(TotalFTEs) as fteDiv, sum(pctExpTotal)/sum(TotalHours) as hourlyRateDiv, sum(pctExpTotal)/sum(TotalFTEs) as fteRateDiv from rate_view group by month,year,div_id) r on(rv.month=r.month and rv.year=r.year and rv.div_id=r.div_id)".format(runid, processTime) 

ru_rate_df=sqlContext.sql(query)
# rename columns as per standards
ru_rate_df = ru_rate_df.withColumnRenamed('GL_PERIOD', 'GL_PERIOD')
ru_rate_df = ru_rate_df.withColumnRenamed('HC_PEOPLE_COUNT', 'HC_PEOPLE_COUNT')
ru_rate_df = ru_rate_df.withColumnRenamed('month', 'MONTH')
ru_rate_df = ru_rate_df.withColumnRenamed('year', 'YEAR')
ru_rate_df = ru_rate_df.withColumnRenamed('COST_CENTER_CODE', 'COST_CENTER_CODE')
ru_rate_df = ru_rate_df.withColumnRenamed('Div_id', 'DIV_ID')
ru_rate_df = ru_rate_df.withColumnRenamed('Div_Description', 'DIV_DESCRIPTION')
ru_rate_df = ru_rate_df.withColumnRenamed('Dir_id', 'DIR_ID')
ru_rate_df = ru_rate_df.withColumnRenamed('Dir_Description', 'DIR_DESCRIPTION')
ru_rate_df = ru_rate_df.withColumnRenamed('Org_id', 'ORG_ID')
ru_rate_df = ru_rate_df.withColumnRenamed('Org_Description', 'ORG_DESCRIPTION')
ru_rate_df = ru_rate_df.withColumnRenamed('COST_TYPE', 'COST_TYPE')
ru_rate_df = ru_rate_df.withColumnRenamed('GBP_EXPENSE', 'EXPENSE_GBP')
ru_rate_df = ru_rate_df.withColumnRenamed('TotalHours', 'STD_HOURS')
ru_rate_df = ru_rate_df.withColumnRenamed('TotalFTEs', 'STD_FTES')
ru_rate_df = ru_rate_df.withColumnRenamed('hc_div', 'HC_DIV')
ru_rate_df = ru_rate_df.withColumnRenamed('hc_dir', 'HC_DIR')
ru_rate_df = ru_rate_df.withColumnRenamed('hc_org', 'HC_ORG')
ru_rate_df = ru_rate_df.withColumnRenamed('exp_div', 'EXP_DIV')
ru_rate_df = ru_rate_df.withColumnRenamed('exp_dir', 'EXP_DIR')
ru_rate_df = ru_rate_df.withColumnRenamed('exp_org', 'EXP_ORG')
ru_rate_df = ru_rate_df.withColumnRenamed('pctHCDiv', 'PCTHCDIV')
ru_rate_df = ru_rate_df.withColumnRenamed('pctHCDir', 'PCTHCDIR')
ru_rate_df = ru_rate_df.withColumnRenamed('pctHCOrg', 'PCTHCORG')
ru_rate_df = ru_rate_df.withColumnRenamed('pctExpDiv', 'PCTEXPDIV')
ru_rate_df = ru_rate_df.withColumnRenamed('pctExpDir', 'PCTEXPDIR')
ru_rate_df = ru_rate_df.withColumnRenamed('pctExpOrg', 'PCTEXPORG')
ru_rate_df = ru_rate_df.withColumnRenamed('pctExpTotal', 'PCTEXPTOTAL')
ru_rate_df = ru_rate_df.withColumnRenamed('pctExpTotalDiv', 'PCTEXPTOTALDIV')
ru_rate_df = ru_rate_df.withColumnRenamed('hoursDiv', 'STD_HOURS_DIV')
ru_rate_df = ru_rate_df.withColumnRenamed('fteDiv', 'STD_FTES_DIV')
ru_rate_df = ru_rate_df.withColumnRenamed('hourlyRateDiv', 'HOURLY_RATE_DIV')
ru_rate_df = ru_rate_df.withColumnRenamed('fteRateDiv', 'FTE_RATE_DIV')

#create view
ru_rate_df.createOrReplaceTempView("ru_rate_view")



# COMMAND ----------

query="SELECT et.*,r.FTE_RATE_DIV, et.TOTALFTES*r.FTE_RATE_DIV as ipeExpense from et_Month_v et inner join ccHierarchy cc on (et.COSTCENTRE=cc.COST_CENTER_CODE) left outer join ru_rate_view r on \
(r.DIV_ID = cc.Div_id and r.MONTH=et.month and r.YEAR=et.year)"

ru_ipe_df=sqlContext.sql(query)

# COMMAND ----------

#delete existing records
sql="delete from fin_stg.ru_rate"
dbutils.notebook.run("/library/DataLayer",0,{"query": sql})
#save rate file in SQL DW stage table

ru_rate_df.write\
    .format("com.databricks.spark.sqldw")\
    .option("url", sqlDwUrl)\
    .option( "forward_spark_azure_storage_credentials", "True")\
    .option("tempdir", tempDir)\
    .option("dbtable", "fin_stg.ru_rate") \
    .mode("append")\
    .save()

# COMMAND ----------

#save rate file to curated layer
tmp_file_path = 'dbfs:/mnt/raw/rurate' + runid
curatedPath = 'dbfs:/mnt/curated/resource_utilization/'

ru_rate_df=ru_rate_df.drop('RUN_ID')
ru_rate_df=ru_rate_df.drop('CREATION_DATE')
ru_rate_df=ru_rate_df.drop('CREATED_BY')
ru_rate_df=ru_rate_df.drop('UPDATION_DATE')
ru_rate_df=ru_rate_df.drop('UPDATED_BY')


ru_rate_df.coalesce(1).write\
            .option("sep", "|")\
            .option("header", "true")\
            .option("quote",  '"')\
            .option("escape", '"')\
            .option("nullValue", "null")\
        .csv(tmp_file_path)
# copy part-* csv file to curated and rename
dbutils.fs.cp(dbutils.fs.ls(tmp_file_path)[-1][0], curatedPath + 'ru_rate.txt', recurse = True)

# remove temp folders
dbutils.fs.rm(tmp_file_path, recurse = True)