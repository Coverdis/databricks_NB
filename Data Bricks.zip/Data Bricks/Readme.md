# Databricks Notebooks

This folder contains the python notebooks to be imported into Databricks.

# Databricks Libraries

Libraries can be installed using the *libraries.json* file. This file contains an array of libraries to install based on the Databricks install library API. See the following link for a full example of the JSON format used in this file:
https://docs.databricks.com/api/latest/libraries.html#install

# Configurations

Please, always retrieve configurations such as connection strings, passwords, secrets and any resource names/identifiers that may change between environments from secrets configured to read from Azure KeyVault. This way, we only change the target KeyVault for the secrets and the code in the notebooks will remain the same.

**Example:**
````
clientSecret = dbutils.secrets.get(scope = "azurekeyvault-databricks", key = "pw-irm-client-pwd")
````

# Databricks Tests

After deploying changes, DevOps will run the main tests notebook located at **/Data Bricks/notebooks/tests/testsmain.py** to execute the unit tests.
If you need to include more tests, create new notebooks and include them in the **testsmain.py** notebook by using the _%run_ syntax and add the new tests clases to the TestLoader so they are included in the execution.