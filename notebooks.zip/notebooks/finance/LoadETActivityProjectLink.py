# Databricks notebook source
#File Name:LoadETActivityProjectLink
#ADF Pipeline Name: FIN_ADL_DW-Project_Activity_GL_ROWExp_RURate_Person
#SQLDW Table:fin_stg.PROJECT_ACTIVITY_LINK
#Description:
  # Loads ET project activity link data to SQl DW

# COMMAND ----------

# MAGIC %run "/library/configFile"

# COMMAND ----------

dbutils.widgets.text("runid", "36dgf-2gs92-19jsw-shdfq-snxg3")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

# COMMAND ----------

# Load ET Data
et_activity = spark.read.format("csv")\
        .option("inferSchema","true")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
  .load("dbfs:/mnt/curated/et/project_activity_link.txt")

et_activity = et_activity.toDF(*(col.replace('\r', '') for col in et_activity.columns))

for col_name in et_activity.columns:
  et_activity = et_activity.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))
  

et_activity = et_activity.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
et_activity = et_activity.withColumn('CREATION_DATE', F.lit(processTime).cast(TimestampType()))
et_activity = et_activity.withColumn('CREATED_BY', F.lit('DataBricks - LoadETActivityProjectLink').cast(StringType()))
et_activity = et_activity.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
et_activity = et_activity.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))

# display(et_activity)

#et_activity = et_activity.select(
#  'ACTIVITY_ID',
#  'PROJECT_ID',
#  'SOURCE',
#  'RUN_ID',
#  'CREATION_DATE',
#  'CREATED_BY',
#  'UPDATION_DATE',
#  'UPDATED_BY'
#)

# display(et_activity)

# COMMAND ----------

# write to sql dw
et_activity.write\
    .format("com.databricks.spark.sqldw")\
    .option("url", sqlDwUrl)\
    .option( "forward_spark_azure_storage_credentials", "True")\
    .option("tempdir", tempDir)\
    .option("dbtable", "fin_stg.PROJECT_ACTIVITY_LINK") \
    .mode("append")\
    .save()

# COMMAND ----------

#delete old data once new data has been inserted successfully
sql="delete from fin_stg.PROJECT_ACTIVITY_LINK where SOURCE = 'ET' and CREATION_DATE!='"+ processTime +"'"
dbutils.notebook.run("/library/DataLayer", 0, {"query": sql})