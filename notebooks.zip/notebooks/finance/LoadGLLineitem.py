# Databricks notebook source
#File Name:Load_GLLineitem
#ADF Pipeline Name: FIN_ADL_DW-Project_Activity_GL_ROWExp_RURate
#SQLDW - fin_stg.Expense
#Description:
  #Write data in SQL DW for CERPS for a month and year 

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

dbutils.widgets.text("DeltaHours", "48")
runid = dbutils.widgets.text("runid", "d238s-segb2-vfk23-cdkl2")

deltaHours = dbutils.widgets.get("DeltaHours")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
import pytz
from datetime import datetime, timedelta
import os
from glob import glob
import re

process_time = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

curated_path = 'dbfs:/mnt/curated/cerps/gllineitem/'

# COMMAND ----------

process_flag = True

min_last_modified_time = datetime.now(pytz.timezone("UTC")) - timedelta(hours = float(deltaHours))

# list of files in curated
curated_files = [x.split('/')[-2:] for x in glob('/dbfs/mnt/curated/cerps/gllineitem/**/GLLineitem-*.txt', recursive=True)]

# get last modified time and convert that to Eastern time for each curated file
last_modified= [datetime.fromtimestamp(os.path.getctime(('/dbfs/mnt/curated/cerps/gllineitem/{0}/{1}').format(curated_files[item][0], curated_files[item][1]))).replace(tzinfo=pytz.utc) for item in range(0, len(curated_files))]


# list of updated files after max creation date
updated_files = [curated_files[idx] for idx, modified_time in enumerate(last_modified) if (modified_time >= min_last_modified_time)]


if len(updated_files) == 0:
  process_flag = False

# COMMAND ----------

if process_flag:
  # updated files year-month
  year_month = tuple([''.join(re.findall(r'\d+', i[1])) for i in updated_files])
  year_month = str(year_month)
  
  #updated files path from ADL
  updated_files_path = [curated_path + '/'.join(updated_files[idx]) for idx, n in enumerate(updated_files)]

# COMMAND ----------

if process_flag:
  cerps = spark.read.format('csv')\
      .option("inferSchema", "false")\
      .option("header", "true")\
      .option("multiLine", "true")\
      .option("delimiter", "|")\
      .option("quote", '"')\
      .option("escape", '"')\
      .option("nullValue", "null")\
    .load(updated_files_path)

  cerps = cerps.toDF(*(col.replace('\r', '') for col in cerps.columns))
  for col_name in cerps.columns:
    cerps = cerps.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))
    
  cerps = cerps.filter('RANK = 1')

# COMMAND ----------

if process_flag:
  # change types
  cerps = cerps.withColumn('AMOUNT_LOC', cerps.AMOUNT_LOC.cast(DecimalType(31,5)))
  cerps = cerps.withColumn('AMOUNT_GBP', cerps.AMOUNT_GBP.cast(DecimalType(31,5)))
  cerps = cerps.withColumn('FISCMONTH', cerps.FISCMONTH.cast(IntegerType()))
  cerps = cerps.withColumn('FISCYEAR', cerps.FISCYEAR.cast(IntegerType()))
  
  # Create additional columns
  cerps = cerps.withColumn('GL_PERIOD', F.concat_ws('-', cerps.FISCYEAR, cerps.FISCMONTH, F.lit(1)).cast(TimestampType()))
  cerps = cerps.withColumn('SOURCE', F.lit('CERPS').cast(StringType()))
  cerps = cerps.withColumn('ACTUAL_OR_ESTIMATE_CODE', F.lit('Actual').cast(StringType()))
  cerps = cerps.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
  cerps = cerps.withColumn('CREATION_DATE', F.lit(process_time).cast(TimestampType()))
  cerps = cerps.withColumn('CREATED_BY', F.lit('Databricks - LoadGLLineitem').cast(StringType()))
  cerps = cerps.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
  cerps = cerps.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))

  cerps = cerps.select(
    'GL_PERIOD',
    'COMP_CODE',
    'COST_CENTER_CODE',
    'ACCOUNT_CODE',
    'WBS_CODE',
    'BUDID_CODE',
    'DOCUMENT_NO',
    'AMOUNT_LOC',
    'AMOUNT_GBP',
    'CURRENCY_CODE',
    'FISCMONTH',
    'FISCYEAR',
    'SOURCE',
    'ACTUAL_OR_ESTIMATE_CODE',
    'COST_TYPE',
    'RUN_ID',
    'CREATION_DATE',
    'CREATED_BY',
    'UPDATION_DATE',
    'UPDATED_BY'
  )

# COMMAND ----------

if process_flag:
  # write to sql dw
  cerps.write\
    .format("com.databricks.spark.sqldw")\
    .option("url", sqlDwUrl)\
    .option( "forward_spark_azure_storage_credentials", "True")\
    .option("tempdir", tempDir)\
    .option("dbtable", "fin_stg.EXPENSE") \
    .mode("append")\
    .save()

# COMMAND ----------

if process_flag:
  # delete old data once new data has been inserted successfully
  sql="delete from fin_stg.EXPENSE where SOURCE='CERPS' and CREATION_DATE!='"+ process_time +"' and cast(FISCYEAR as varchar(10)) + cast(FISCMONTH as varchar(10)) in " +  ''.join(year_month)
  dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})