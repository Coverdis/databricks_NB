# Databricks notebook source
#File Name:MasterProject
#ADF Pipeline Name: FIN_ADL_DW-Project_Activity_GL_ROWExp_RURate
#SQLDW Table:fin_stg.PROJECT
#Description:
  #Merges PDM, DRM, ET and manual projects
  #Business keep input file in foundation layer for manual projects
  #Writes final file in curated layer
  #Identify delta between source project files and existing projectMaster file in curated layer
  #Delta is being inserted in SQL DW to maintain history in project staging table.

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

dbutils.widgets.text("runid", "1111")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

rawPath = 'dbfs:/mnt/raw/resource_utilization'
foundationPath = 'dbfs:/mnt/foundation/resource_utilization/'
curatedPath = 'dbfs:/mnt/curated/resource_utilization/'

# COMMAND ----------

pdmDF = spark.read.format("csv")\
        .option("inferSchema","true")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
  .load("dbfs:/mnt/foundation/pdm/project_deliverable.txt")

pdmDF = pdmDF.toDF(*(col.replace('\r', '') for col in pdmDF.columns))

for col_name in pdmDF.columns:
  pdmDF = pdmDF.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

# pdmDF = pdmDF.dropDuplicates(['PROJECT_ID', 'DESCRIPTION_SHORT', 'TA_LONG_NAME', 'DELIVERABLE_STATUS_SHORT_NAME'])

pdmDF =  pdmDF.withColumn('ROWNUM', F.row_number().over(Window.partitionBy('PROJECT_ID').orderBy('PROJECT_ID', 'DESCRIPTION_SHORT', 'TA_LONG_NAME', 'DELIVERABLE_STATUS_SHORT_NAME')))

pdmDF = pdmDF.filter('ROWNUM = 1')

pdmDF = pdmDF.select(
  'PROJECT_ID',
  'DESCRIPTION_SHORT',
  'TA_LONG_NAME',
  'DELIVERABLE_STATUS_SHORT_NAME',
  'FUNDER_L1',
  'FUNDER_L2',
  'FUNDER_L3',
  'CURRENT_PHASE'
)

pdmDF = pdmDF.withColumnRenamed('DESCRIPTION_SHORT', 'PROJECT_NAME')
pdmDF = pdmDF.withColumnRenamed('TA_LONG_NAME', 'THERAPY_AREA')
pdmDF = pdmDF.withColumnRenamed('DELIVERABLE_STATUS_SHORT_NAME', 'PROJECT_STATUS_DESC')
pdmDF = pdmDF.withColumnRenamed('CURRENT_PHASE', 'PROJECT_PHASE')

pdmDF = pdmDF.withColumn('PROJECT_CATEGORY', F.lit(None).cast(StringType()))
pdmDF = pdmDF.withColumn('ASSET_NAME', F.lit(None).cast(StringType()))
# pdmDF = pdmDF.withColumn('STAGE', F.lit(None).cast(StringType()))
pdmDF = pdmDF.withColumn('SOURCE', F.lit('PDM').cast(StringType()))

# COMMAND ----------

drmDF = spark.read.format("csv")\
        .option("inferSchema","true")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
  .load("dbfs:/mnt/curated/hyperion_drm/project_hierarchy.txt")

drmDF = drmDF.toDF(*(col.replace('\r', '') for col in drmDF.columns))

# read attribute hierarchy
attributeHierarchy = spark.read.format("csv")\
        .option("inferSchema","true")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
  .load("dbfs:/mnt/curated/hyperion_drm/attribute_hierarchy.txt")

attributeHierarchy = attributeHierarchy.toDF(*(col.replace('\r', '') for col in attributeHierarchy.columns))

drmDF = drmDF.join(attributeHierarchy, drmDF.FUNDINGORG == attributeHierarchy.lvl5Code, 'left')

# randomly selecting one project_code, this code needs to be revised later
drmDF =  drmDF.withColumn('ROWNUM', F.row_number().over(Window.partitionBy('PROJECT_CODE').orderBy('STUDY_ID', 'STUDY_NAME', 'FUNDINGORG', 'PROJECT_CODE', 'PROJECT_NAME', 'THERAPY_AREA_DESCRIPTION')))
drmDF = drmDF.filter('ROWNUM = 1')

for col_name in drmDF.columns:
  drmDF = drmDF.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

# drmDF = drmDF.dropDuplicates(['PROJECT_CODE', 'PROJECT_NAME', 'THERAPY_AREA_DESCRIPTION'])

# drmDF =  drmDF.withColumn('ROWNUM', F.row_number().over(Window.partitionBy('PROJECT_CODE').orderBy('PROJECT_CODE', 'PROJECT_NAME', 'THERAPY_AREA_DESCRIPTION')))

# drmDF = drmDF.filter('ROWNUM = 1')

drmDF = drmDF.select(
  'PROJECT_CODE',
  'PROJECT_NAME',
  'THERAPY_AREA_DESCRIPTION',
  'lvl5Desc',
  'lvl4Desc',
  'lvl3Desc'
)

drmDF = drmDF.withColumn('PROJECT_CODE', F.regexp_replace(drmDF.PROJECT_CODE,'^\s+|\s+$|\r//g', ''))
drmDF = drmDF.withColumn('PROJECT_NAME', F.regexp_replace(drmDF.PROJECT_NAME,'^\s+|\s+$|\r//g', ''))
drmDF = drmDF.withColumn('THERAPY_AREA_DESCRIPTION', F.regexp_replace(drmDF.THERAPY_AREA_DESCRIPTION,'^\s+|\s+$|\r//g', ''))

drmDF = drmDF.withColumnRenamed('PROJECT_CODE', 'PROJECT_ID')
drmDF = drmDF.withColumnRenamed('PROJECT_DESCRIPTION', 'PROJECT_NAME')
drmDF = drmDF.withColumnRenamed('THERAPY_AREA_DESCRIPTION', 'THERAPY_AREA')

drmDF = drmDF.withColumn('PROJECT_CATEGORY', F.lit(None).cast(StringType()))
drmDF = drmDF.withColumn('PROJECT_PHASE', F.lit('Not Applicable').cast(StringType()))
drmDF = drmDF.withColumn('ASSET_NAME', F.lit(None).cast(StringType()))
drmDF = drmDF.withColumn('PROJECT_STATUS_DESC', F.lit(None).cast(StringType()))
# drmDF = drmDF.withColumn('STAGE', F.lit(None).cast(StringType()))
drmDF = drmDF.withColumn('SOURCE', F.lit('DRM').cast(StringType()))

drmDF = drmDF.withColumnRenamed('lvl5Desc', 'FUNDER_L1')
drmDF = drmDF.withColumnRenamed('lvl4Desc', 'FUNDER_L2')
drmDF = drmDF.withColumnRenamed('lvl3Desc', 'FUNDER_L3')

# COMMAND ----------

etDF = spark.read.format("csv")\
        .option("inferSchema","true")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
  .load("dbfs:/mnt/foundation/et/projects.txt")

etDF = etDF.toDF(*(col.replace('\r', '') for col in etDF.columns))

for col_name in etDF.columns:
  etDF = etDF.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

# etDF = etDF.dropDuplicates(['ORIG_PROJ_CODE', 'NAME', 'PROJECT_PHASE', 'THERAPY_AREA', 'PROJECT_STATUS'])

etDF =  etDF.withColumn('ROWNUM', F.row_number().over(Window.partitionBy('ORIG_PROJ_CODE').orderBy('ORIG_PROJ_CODE', 'NAME', 'PROJECT_PHASE', 'THERAPY_AREA', 'PROJECT_STATUS')))
etDF = etDF.filter('ROWNUM = 1')

etDF = etDF.select(
  'ORIG_PROJ_CODE',
  'NAME',
  'PROJECT_PHASE',
  'THERAPY_AREA',
  'PROJECT_STATUS'
)

etDF = etDF.withColumnRenamed('ORIG_PROJ_CODE', 'PROJECT_ID')
etDF = etDF.withColumnRenamed('NAME', 'PROJECT_NAME')
etDF = etDF.withColumnRenamed('THERAPY_AREA', 'THERAPY_AREA')
etDF = etDF.withColumnRenamed('PROJECT_STATUS', 'PROJECT_STATUS_DESC')

etDF = etDF.withColumn('PROJECT_CATEGORY', F.lit(None).cast(StringType()))
etDF = etDF.withColumn('PROJECT_PHASE', F.lit('Life Cycle Management').cast(StringType()))
etDF = etDF.withColumn('ASSET_NAME', F.lit(None).cast(StringType()))
# etDF = etDF.withColumn('STAGE', F.lit(None).cast(StringType()))
etDF = etDF.withColumn('SOURCE', F.lit('ET').cast(StringType()))
etDF = etDF.withColumn('FUNDER_L1', F.lit(None).cast(StringType()))
etDF = etDF.withColumn('FUNDER_L2', F.lit(None).cast(StringType()))
etDF = etDF.withColumn('FUNDER_L3', F.lit(None).cast(StringType()))

# COMMAND ----------

ruDF = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter",",")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
        .load("dbfs:/mnt/foundation/resource_utilization/ru_project.csv")

ruDF = ruDF.toDF(*(col.replace('\r', '') for col in ruDF.columns))

ruDF = ruDF.withColumn('PROJECT_ID', F.regexp_replace(ruDF.PROJECT_ID,'^\s+|\s+$|\r//g', ''))
ruDF = ruDF.withColumn('PROJECT_NAME', F.regexp_replace(ruDF.PROJECT_NAME,'^\s+|\s+$|\r//g', ''))
ruDF = ruDF.withColumn('THERAPY_AREA_L1', F.regexp_replace(ruDF.THERAPY_AREA_L1,'^\s+|\s+$|\r//g', ''))
ruDF = ruDF.withColumn('ASSET_NAME', F.regexp_replace(ruDF.ASSET_NAME,'^\s+|\s+$|\r//g', ''))

# ruDF = ruDF.dropDuplicates(['PROJECT_ID', 'PROJECT_NAME', 'THERAPY_AREA_L1'])
# ruDF = ruDF.coalesce(1).dropDuplicates(['PROJECT_ID'])

ruDF =  ruDF.withColumn('ROWNUM', F.row_number().over(Window.partitionBy('PROJECT_ID').orderBy('PROJECT_ID', 'PROJECT_NAME', 'THERAPY_AREA_L1')))
ruDF = ruDF.filter('ROWNUM = 1')

ruDF = ruDF.select(
  'PROJECT_ID',
  'PROJECT_NAME',
  'THERAPY_AREA_L1',
  'ASSET_NAME'
)

ruDF = ruDF.withColumnRenamed('THERAPY_AREA_L1', 'THERAPY_AREA')

ruDF = ruDF.withColumn('PROJECT_CATEGORY', F.lit(None).cast(StringType()))
ruDF = ruDF.withColumn('PROJECT_PHASE', F.lit('Not Applicable').cast(StringType()))
ruDF = ruDF.withColumn('PROJECT_STATUS_DESC', F.lit(None).cast(StringType()))
# ruDF = ruDF.withColumn('STAGE', F.lit(None).cast(StringType()))
ruDF = ruDF.withColumn('SOURCE', F.lit('BUSINESS_FILE').cast(StringType()))
ruDF = ruDF.withColumn('FUNDER_L1', F.lit(None).cast(StringType()))
ruDF = ruDF.withColumn('FUNDER_L2', F.lit(None).cast(StringType()))
ruDF = ruDF.withColumn('FUNDER_L3', F.lit(None).cast(StringType()))

ruDF.count()
# display(ruDF)

# COMMAND ----------

# get project id in drm that are not in pdm and union them with pdm project id
dif1 = drmDF.select('PROJECT_ID').subtract(pdmDF.select('PROJECT_ID'))
# project = pdmDF.select('PROJECT_ID').union(dif1.select('PROJECT'))
project = pdmDF.select('PROJECT_ID', 'PROJECT_NAME', 'PROJECT_CATEGORY', 'PROJECT_PHASE', 'THERAPY_AREA', 'ASSET_NAME', 'PROJECT_STATUS_DESC', 'SOURCE', 'FUNDER_L1', 'FUNDER_L2', 'FUNDER_L3').unionByName(drmDF.where(drmDF.PROJECT_ID.isin([row.PROJECT_ID for row in dif1.collect()])).select('PROJECT_ID', 'PROJECT_NAME', 'PROJECT_CATEGORY', 'PROJECT_PHASE', 'THERAPY_AREA', 'ASSET_NAME', 'PROJECT_STATUS_DESC', 'SOURCE', 'FUNDER_L1', 'FUNDER_L2', 'FUNDER_L3'))

# get project id in et that are not in pdm+drm and union them with pdm+drm project id
dif2 = etDF.select('PROJECT_ID').subtract(project.select('PROJECT_ID'))
project = project.select('PROJECT_ID', 'PROJECT_NAME', 'PROJECT_CATEGORY', 'PROJECT_PHASE', 'THERAPY_AREA', 'ASSET_NAME', 'PROJECT_STATUS_DESC', 'SOURCE', 'FUNDER_L1', 'FUNDER_L2', 'FUNDER_L3').unionByName(etDF.where(etDF.PROJECT_ID.isin([row.PROJECT_ID for row in dif2.collect()])).select('PROJECT_ID', 'PROJECT_NAME', 'PROJECT_CATEGORY', 'PROJECT_PHASE', 'THERAPY_AREA', 'ASSET_NAME', 'PROJECT_STATUS_DESC', 'SOURCE', 'FUNDER_L1', 'FUNDER_L2', 'FUNDER_L3'))

# get project id in ru that are not in pdm+drm+et and union them with pdm+drm+et project id
dif3 = ruDF.select('PROJECT_ID').subtract(project.select('PROJECT_ID'))
project = project.select('PROJECT_ID', 'PROJECT_NAME', 'PROJECT_CATEGORY', 'PROJECT_PHASE', 'THERAPY_AREA', 'ASSET_NAME', 'PROJECT_STATUS_DESC', 'SOURCE', 'FUNDER_L1', 'FUNDER_L2', 'FUNDER_L3').unionByName(ruDF.where(ruDF.PROJECT_ID.isin([row.PROJECT_ID for row in dif3.collect()])).select('PROJECT_ID', 'PROJECT_NAME', 'PROJECT_CATEGORY', 'PROJECT_PHASE', 'THERAPY_AREA', 'ASSET_NAME', 'PROJECT_STATUS_DESC', 'SOURCE', 'FUNDER_L1', 'FUNDER_L2', 'FUNDER_L3'))

project = project.withColumn('RU_COST_SUB_TYPE', F.lit('EPE'))

project = project.withColumn('STAGE',
                             F.when((F.lower(project.PROJECT_PHASE) == 'target validation') | (F.lower(project.PROJECT_PHASE) == 'lead discovery') | (F.lower(project.PROJECT_PHASE) == 'lead optimisation') | (F.lower(project.PROJECT_PHASE) == 'pre-candidate profiling') | (F.lower(project.PROJECT_PHASE) == 'pre-clinical evaluation') | (F.lower(project.PROJECT_PHASE) == 'phase i'), 'Early').otherwise(
                               F.when((F.lower(project.PROJECT_PHASE) == 'phase iia') | (F.lower(project.PROJECT_PHASE) == 'phase iib') |(F.lower(project.PROJECT_PHASE) == 'phase ii') | (F.lower(project.PROJECT_PHASE) == 'phase iii') | (F.lower(project.PROJECT_PHASE) == 'registration & launch') | (F.lower(project.PROJECT_PHASE) == 'phase iv') | (F.lower(project.PROJECT_PHASE) == 'lcm') | (F.lower(project.PROJECT_PHASE) == 'life cycle management'), 'Late').otherwise(
                                 F.when(F.lower(project.PROJECT_PHASE) == 'not applicable', 'Not Applicable')
                               )
                             )
                            )

# COMMAND ----------

# read ru_pr_cost_sub_type.csv to get cost sub type at project level
try:
  costSubtype = spark.read.format("csv")\
            .option("inferSchema","true")\
            .option("header","true")\
            .option("multiLine","true")\
            .option("delimiter",",")\
            .option("quote", '"')\
            .option("escape",'"')\
            .option("nullValue","null")\
          .load("dbfs:/mnt/foundation/resource_utilization/ru_pr_cost_sub_type.csv")
  
  costSubtype = costSubtype.withColumnRenamed('RU_COST_SUB_TYPE', 'RU_COST_SUB_TYPE_FILE')
  project = project.join(costSubtype, project.PROJECT_ID == costSubtype.PROJECT_ID, 'left').drop(costSubtype.PROJECT_ID)
  project = project.withColumn('RU_COST_SUB_TYPE', 
                               F.when(project.RU_COST_SUB_TYPE_FILE.isNull(), project.RU_COST_SUB_TYPE).otherwise(
                                 project.RU_COST_SUB_TYPE_FILE
                               )
                              )
  project = project.drop('RU_COST_SUB_TYPE_FILE')
  
#   print(project.count())
except Exception as e:
  print(e)

# COMMAND ----------

# read flatten project hierarchy

projectHierarchy = spark.read.format("csv")\
        .option("inferSchema","true")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
  .load("dbfs:/mnt/curated/hyperion_drm/project_hierarchy.txt")

projectHierarchy = projectHierarchy.toDF(*(col.replace('\r', '') for col in projectHierarchy.columns))

# drop study fields and drop duplicates
projectHierarchy = projectHierarchy.drop('STUDY_ID', 'STUDY_NAME', 'FUNDINGORG', 'PCUDA')
projectHierarchy = projectHierarchy.drop_duplicates()

project = project.join(projectHierarchy, project.PROJECT_ID == projectHierarchy.PROJECT_CODE, 'left').drop(projectHierarchy.PROJECT_CODE).drop(projectHierarchy.PROJECT_NAME).drop(projectHierarchy.THERAPY_AREA).drop(projectHierarchy.ROOT).drop(projectHierarchy.ROOT_DESCRIPTION)

project = project.withColumnRenamed('THERAPY_AREA_DESCRIPTION', 'THERAPY_AREA_DRM')

# COMMAND ----------

project = project.select(
  'PROJECT_ID',
  'PROJECT_NAME',
  'PROJECT_CATEGORY',
  'PROJECT_PHASE',
  'THERAPY_AREA',
  'THERAPY_AREA_DRM',
  'ASSET_NAME',
  'PROJECT_STATUS_DESC',
  'RU_COST_SUB_TYPE',
  'REPORTING_GROUP',
  'REPORTING_GROUP_DESCRIPTION',
  'MANAGING_ORG',
  'MANAGING_ORG_DESCRIPTION',
  'STAGE',
  'SOURCE',
  'FUNDER_L1',
  'FUNDER_L2',
  'FUNDER_L3'
)

# COMMAND ----------

deltaFlag = False
deltaDF = ''
try:
  pushdown_query = "(SELECT  p.PROJECT_ID, PROJECT_NAME, PROJECT_CATEGORY, PROJECT_PHASE, THERAPY_AREA, THERAPY_AREA_DRM, ASSET_NAME, PROJECT_STATUS_DESC, RU_COST_SUB_TYPE, REPORTING_GROUP, REPORTING_GROUP_DESCRIPTION, MANAGING_ORG, MANAGING_ORG_DESCRIPTION, STAGE, SOURCE, FUNDER_L1, FUNDER_L2, FUNDER_L3 from fin_stg.Project p, (SELECT PROJECT_ID, CREATION_DATE, rank() over  (partition by PROJECT_ID order by CREATION_DATE desc) as RANK_ID FROM fin_stg.PROJECT) r where p.PROJECT_ID=r.PROJECT_ID and p.CREATION_DATE=r.CREATION_DATE and r.RANK_ID=1) project"

  dw_project = spark.read.jdbc(url = sqlDwUrl, table = pushdown_query)
  
  deltaDF = project.subtract(dw_project)
  
  if deltaDF.count() > 0:
    deltaFlag = True
    
  deltaDF.createOrReplaceTempView("PROJECT_VIEW")
except:
  deltaFlag = True
  project.createOrReplaceTempView("PROJECT_VIEW")

# COMMAND ----------

if deltaFlag:
  query = "SELECT PROJECT_ID, PROJECT_NAME, PROJECT_CATEGORY, PROJECT_PHASE, THERAPY_AREA, THERAPY_AREA_DRM, ASSET_NAME, PROJECT_STATUS_DESC, RU_COST_SUB_TYPE, REPORTING_GROUP, REPORTING_GROUP_DESCRIPTION, MANAGING_ORG, MANAGING_ORG_DESCRIPTION, STAGE, SOURCE, FUNDER_L1, FUNDER_L2, FUNDER_L3, '{0}' as RUN_ID, to_timestamp('{1}') as CREATION_DATE, 'DataBricks - MasterProject' as CREATED_BY, CAST(null as timestamp) as UPDATION_DATE, CAST(null as string) as UPDATED_BY FROM PROJECT_VIEW".format(runid, processTime)

  df2 = sqlContext.sql(query)
  
  # write dataframe to DW using polybase
  df2.write\
    .format("com.databricks.spark.sqldw")\
    .option("url", sqlDwUrl)\
    .option( "forward_spark_azure_storage_credentials", "True")\
    .option("tempdir", tempDir)\
    .option("dbtable", "fin_stg.PROJECT") \
    .mode("append")\
    .save()

# COMMAND ----------

if deltaFlag:
  # Write to curated
  csv_temp_curated = rawPath + runid + '/' + 'curated'

  project.coalesce(1).write\
          .option("sep", "|")\
          .option("header", "true")\
          .option("quote",  '"')\
          .option("escape", '"')\
          .option("nullValue", "null")\
        .csv(csv_temp_curated)

  # copy part-* csv file to foundation and rename
  dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + "project_master.txt", recurse = True)

  # remove temp folder
  dbutils.fs.rm(rawPath + runid, recurse = True)

# COMMAND ----------

# dbutils.fs.rm(curatedPath + 'project_master.txt', True)