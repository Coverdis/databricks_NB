# Databricks notebook source
# MAGIC %run "./configFile"

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *
import pytz
import re
from datetime import datetime
processTime = datetime.now(pytz.timezone("US/Eastern")).strftime('%Y-%m-%dT%H:%M:%S')


project_dim = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load("dbfs:/mnt/foundation/effort_poc/project_dim.txt")
project_dim = project_dim.toDF(*(c.replace('\r', '') for c in project_dim.columns))

# COMMAND ----------

project_dim = project_dim['PROJECT_ID','ORIG_PROJ_CODE','PROJECT_NAME','PROJECT_CATEGORY','PROJECTSOURCE','PROJECT_PHASE','THERAPY_AREA','PROJECT_STATUS_DESC']

# COMMAND ----------

exp = """CASE WHEN PROJECT_PHASE = 'Phase I' THEN 'Early' 
          ELSE CASE WHEN PROJECT_PHASE = 'Phase II' THEN 'Early'
          ELSE CASE WHEN PROJECT_PHASE = 'Phase III' THEN 'Late'
          ELSE CASE WHEN PROJECT_PHASE = 'Phase IV' THEN 'Late'
          ELSE 'Other'
          END
          END
          END
          END
          END"""

project_dim = project_dim.withColumn('Stage', expr(exp))

# COMMAND ----------

display(project_dim)

# COMMAND ----------

project_dim.write\
    .format("com.databricks.spark.sqldw")\
    .option("url", sqlDwUrl)\
    .option( "forward_spark_azure_storage_credentials", "True")\
    .option("tempdir", tempDir)\
    .option("dbtable", "fin.PROJECT") \
    .mode("overwrite") \
    .save()
