# Databricks notebook source
#File Name:LoadDRMCCHierarchy
#ADF Pipeline Name: FIN_ADL_DW-Project_Activity_GL_ROWExp_RURate_Person
#ADW Table name: fin_stg.COST_CENTER_HIERARCHY
#Description:
  #Identify delta between current file in curated and SQL DW
  #Delta is being inserted in SQL DW to maintain history in staging table.

# COMMAND ----------

# MAGIC %run "/library/configFile"

# COMMAND ----------

dbutils.widgets.text('runid', 'abc111000')
runid = dbutils.widgets.get("runid")

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.window import Window

import pytz
from datetime import datetime
from pyspark.sql import functions as F
process_time = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

curated_path = 'dbfs:/mnt/curated/hyperion_drm/'

# COMMAND ----------

ccDF = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(curated_path + "cost_center_hierarchy.txt")

ccDF = ccDF.toDF(*(col.replace('\r', '') for col in ccDF.columns))
#by default all cost_sub_type are IPE
ccDF = ccDF.withColumn('RU_COST_SUB_TYPE',F.lit('IPE'))
ccDF = ccDF.drop('Type')

# COMMAND ----------

# read ru_cc_cost_sub_type.csv to get cost sub type at CC level
try:
  costSubtype = spark.read.format("csv")\
            .option("inferSchema","true")\
            .option("header","true")\
            .option("multiLine","true")\
            .option("delimiter",",")\
            .option("quote", '"')\
            .option("escape",'"')\
            .option("nullValue","null")\
          .load("dbfs:/mnt/foundation/resource_utilization/ru_cc_cost_sub_type.csv")
  costSubtype = costSubtype.withColumnRenamed('RU_COST_SUB_TYPE', 'RU_COST_SUB_TYPE_FILE')

  ccDF = ccDF.join(costSubtype, (ccDF.Div_id == costSubtype.DIV_ID) & (ccDF.Dir_id == costSubtype.DIR_ID), 'left').drop(costSubtype.DIV_ID).drop(costSubtype.DIV_DESCRIPTION).drop(costSubtype.DIR_ID).drop(costSubtype.DIR_DESCRIPTION)
  

  ccDF = ccDF.withColumn('RU_COST_SUB_TYPE', 
                               F.when(ccDF.RU_COST_SUB_TYPE_FILE.isNull(), ccDF.RU_COST_SUB_TYPE).otherwise(
                                 ccDF.RU_COST_SUB_TYPE_FILE
                               )
                              )
  ccDF = ccDF.drop('RU_COST_SUB_TYPE_FILE')
except Exception as e:
  print(e)

# COMMAND ----------

delta_flag = False
delta_df = None
try:
  pushdown_query = "(SELECT c.COST_CENTER_CODE,COST_CENTER_DESCRIPTION,Dept_id,Dept_Description,SubDiv_id,SubDiv_Description,Div_id,  Div_Description,Dir_id,Dir_Description,Org_id,Org_Description,COST_CENTER_STATUS,CURRENCY_CODE,  COUNTRY_CODE,COUNTRY_DESC,COST_TYPE,COST_TYPE_DESC,RU_COST_SUB_TYPE FROM  FIN_STG.COST_CENTER_HIERARCHY c, (SELECT COST_CENTER_CODE,Creation_date, rank() over  (partition by COST_CENTER_CODE order by creation_date desc) as rank_id FROM  FIN_stg.COST_CENTER_HIERARCHY) r where c.COST_CENTER_CODE=r.COST_CENTER_CODE and c.creation_date=r.Creation_date and r.rank_id=1) cc"

  dw_cc = spark.read.jdbc(url = sqlDwUrl, table = pushdown_query)

  delta_df = ccDF.subtract(dw_cc)
  
  if delta_df.count() > 0:
    delta_flag = True
  
  delta_df.createOrReplaceTempView("COST_CENTER_HIERARCHY")
  
except Exception as e:
  print(e)

# COMMAND ----------

if delta_flag:
  query = "SELECT COST_CENTER_CODE, COST_CENTER_DESCRIPTION, DEPT_ID, DEPT_DESCRIPTION, SUBDIV_ID, SUBDIV_DESCRIPTION, DIV_ID, DIV_DESCRIPTION, DIR_ID, DIR_DESCRIPTION, ORG_ID, ORG_DESCRIPTION, COST_CENTER_STATUS, CURRENCY_CODE, COUNTRY_CODE, COUNTRY_DESC, COST_TYPE, COST_TYPE_DESC, RU_COST_SUB_TYPE, '{0}' as RUN_ID, to_timestamp('{1}') as CREATION_DATE, 'Databricks - FlattenDRMCCHierarchy' as CREATED_BY, CAST(null as timestamp) as UPDATION_DATE, CAST(null as string) as UPDATED_BY FROM COST_CENTER_HIERARCHY".format(runid, process_time)

  df = sqlContext.sql(query)

  # write dataframe to DW using polybase
  df.write\
      .format("com.databricks.spark.sqldw")\
      .option("url", sqlDwUrl)\
      .option( "forward_spark_azure_storage_credentials", "True")\
      .option("tempdir", tempDir)\
      .option("dbtable", "fin_stg.COST_CENTER_HIERARCHY") \
      .mode("append")\
      .save()