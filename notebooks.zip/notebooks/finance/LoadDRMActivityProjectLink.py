# Databricks notebook source
#File Name:LoadDRMActivityProjectLink
#ADF Pipeline Name: FIN_ADL_DW-Project_Activity_GL_ROWExp_RURate_Person
#SQLDW Table:fin_stg.PROJECT_ACTIVITY_LINK
#Description:
  # Loads DRM project activity link data to SQl DW
  # Writes DRM project activity link data to curated folder in ADL

# COMMAND ----------

# MAGIC %run "/library/configFile"

# COMMAND ----------

dbutils.widgets.text("runid", "36dgf-2gs92-19jsw-shdfq-snxg3")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

# COMMAND ----------

# Load DRM Data
drm_activity = spark.read.format("csv")\
        .option("inferSchema","true")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
  .load("dbfs:/mnt/curated/hyperion_drm/project_hierarchy.txt")

drm_activity = drm_activity.toDF(*(col.replace('\r', '') for col in drm_activity.columns))

for col_name in drm_activity.columns:
  drm_activity = drm_activity.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))
  
drm_activity = drm_activity.withColumnRenamed('STUDY_ID', 'ACTIVITY_ID')
drm_activity = drm_activity.withColumnRenamed('PROJECT_CODE', 'PROJECT_ID')
drm_activity = drm_activity.withColumn('SOURCE', F.lit("DRM").cast(StringType()))

drm_activity = drm_activity.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
drm_activity = drm_activity.withColumn('CREATION_DATE', F.lit(processTime).cast(TimestampType()))
drm_activity = drm_activity.withColumn('CREATED_BY', F.lit('Databricks - LoadDRMActivityProjectLink').cast(StringType()))
drm_activity = drm_activity.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
drm_activity = drm_activity.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))

drm_activity = drm_activity.select(
  'ACTIVITY_ID',
  'PROJECT_ID',
  'SOURCE',
  'RUN_ID',
  'CREATION_DATE',
  'CREATED_BY',
  'UPDATION_DATE',
  'UPDATED_BY'
)

# display(drm_activity)

# COMMAND ----------

# write to sql dw
drm_activity.write\
    .format("com.databricks.spark.sqldw")\
    .option("url", sqlDwUrl)\
    .option( "forward_spark_azure_storage_credentials", "True")\
    .option("tempdir", tempDir)\
    .option("dbtable", "fin_stg.PROJECT_ACTIVITY_LINK") \
    .mode("append")\
    .save()

# COMMAND ----------

#delete old data once new data has been inserted successfully
sql="delete from fin_stg.PROJECT_ACTIVITY_LINK where SOURCE = 'DRM' and CREATION_DATE!='"+ processTime +"'"
dbutils.notebook.run("/library/DataLayer", 0, {"query": sql})

# COMMAND ----------

# write to curated

tmp_file_path = 'dbfs:/mnt/raw/' + runid
curatedPath = 'dbfs:/mnt/curated/resource_utilization/'

drm_activity.coalesce(1).write\
            .option("sep", "|")\
            .option("header", "true")\
            .option("quote",  '"')\
            .option("escape", '"')\
            .option("nullValue", "null")\
        .csv(tmp_file_path)
# copy part-* csv file to curated and rename
dbutils.fs.cp(dbutils.fs.ls(tmp_file_path)[-1][0], curatedPath + 'drm_project_activity_link.txt', recurse = True)

# remove temp folders
dbutils.fs.rm(tmp_file_path, recurse = True)