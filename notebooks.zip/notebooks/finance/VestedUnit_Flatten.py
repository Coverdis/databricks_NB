# Databricks notebook source
# MAGIC %run "./configFile"

# COMMAND ----------

df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load("dbfs:/mnt/foundation/hyperion_drm/vested_unit_to_fdr.txt")

df = df.toDF(*(c.replace('\r', '') for c in df.columns))



# COMMAND ----------

df.createOrReplaceTempView("VUH")



# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT VUH.NodeActive FRom VUH

# COMMAND ----------


query="SELECT VUH.NodeID,Description as Level4Desc,Name as Level4Name,Level3Desc,Level3Name,Level2Desc,Level2Name,Level1Desc,Level1Name,NodeActive FROM VUH,(SELECT VUH.NodeID,Description as Level3Desc,Name as Level3Name,Level2Desc,Level2Name,Level1Desc,Level1Name FROM VUH,(SELECT VUH.NodeID,Description as Level2Desc,Name as Level2Name,Level1Desc,Level1Name FROM VUH,(SELECT NodeID,Description as Level1Desc,Name as Level1Name  FROM VUH where ParentID=0) Level1 WHERE ParentID=Level1.NodeId) Level2 WHERE ParentID=Level2.NodeId) Level3                     WHERE ParentID=Level3.NodeId"


vuhDF= sqlContext.sql(query)

# COMMAND ----------

# write flatten hierarchy to Azure foundation data lake gen 2
vuhDF.coalesce(1).write\
    .option("sep", "|")\
    .option("header", "true")\
    .option("quote",  '"')\
    .option("escape", '"')\
    .option("nullValue", "null")\
  .csv('dbfs:/mnt/raw/hyperion_drm/VESTED_UNIT_HIERARCHY_TEMP')

# COMMAND ----------

# copy part-* csv file to curated and rename
dbutils.fs.cp(dbutils.fs.ls('dbfs:/mnt/raw/hyperion_drm/VESTED_UNIT_HIERARCHY_TEMP')[-1][0],'dbfs:/mnt/curated/hyperion_drm/vested_unit_hierarchy.txt', recurse = True) 
  
 

# COMMAND ----------

 # remove temp folder
 dbutils.fs.rm('dbfs:/mnt/raw/hyperion_drm/VESTED_UNIT_HIERARCHY_TEMP', recurse = True)