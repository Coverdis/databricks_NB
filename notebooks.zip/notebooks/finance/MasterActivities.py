# Databricks notebook source
#File Name:MasterActivities
#ADF Pipeline Name:FIN_ADL_DW-Project_Activity_GL_ROWExp_RURate 
#SQLDW Table:fin_stg.ACTIVITY 
#Description:
  #Loads DRM and ET activities data from foundation layer in ADL to SQL DW
  #Writes DRM and ET activities data to curated folder in ADL

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

dbutils.widgets.text("runid", "1sdw2-we23d-qkgn9-uhbg2-hdj22")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

# COMMAND ----------

# Load DRM Activities
drm_activities = spark.read.format("csv")\
        .option("inferSchema","true")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
  .load("dbfs:/mnt/curated/hyperion_drm/project_hierarchy.txt")

drm_activities = drm_activities.toDF(*(col.replace('\r', '') for col in drm_activities.columns))


for col_name in drm_activities.columns:
  drm_activities = drm_activities.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))
  
drm_activities = drm_activities.withColumnRenamed('STUDY_ID', 'ACTIVITY_ID')
drm_activities = drm_activities.withColumnRenamed('STUDY_NAME', 'ACTIVITY_NAME')
drm_activities = drm_activities.withColumnRenamed('PROJECT', 'PROJECT_ID')

# drm_activities = drm_activities.withColumn('ACTIVITY_NAME', drm_activities.ACTIVITY_NAME.substr(1, 256))
drm_activities = drm_activities.withColumn('ACTIVITY_NAME', F.regexp_replace(drm_activities.ACTIVITY_NAME, '^\s+|\s+$|\r//g', ''))

drm_activities = drm_activities.withColumn('STATUS', F.lit(None).cast(StringType()))
drm_activities = drm_activities.withColumn('ACTIVITY_TYPE', F.lit(None).cast(StringType()))
drm_activities = drm_activities.withColumn('ACTIVITY_SOURCE', F.lit("DRM").cast(StringType()))

#filter distinct activity id- There are duplicate activity id in DRM
drm_activities =  drm_activities.withColumn('ROWNUM', F.row_number().over(Window.partitionBy('ACTIVITY_ID').orderBy('ACTIVITY_ID','ACTIVITY_NAME', 'STATUS', 'ACTIVITY_SOURCE','ACTIVITY_TYPE')))

drm_activities = drm_activities.filter('ROWNUM = 1')
drm_activities = drm_activities.select(
  'ACTIVITY_ID',
  'ACTIVITY_NAME',
  'STATUS',
  'ACTIVITY_SOURCE',
  'ACTIVITY_TYPE'
)


# display(drm_activities)

# COMMAND ----------

# Load ET Activities
et_activities = spark.read.format("csv")\
        .option("inferSchema","true")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
  .load("dbfs:/mnt/foundation/et/activities.txt")

et_activities = et_activities.toDF(*(col.replace('\r', '') for col in et_activities.columns))

for col_name in et_activities.columns:
  et_activities = et_activities.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))
  
et_activities = et_activities.withColumnRenamed('ORIG_ACT_CODE', 'ACTIVITY_ID')
et_activities = et_activities.withColumnRenamed('NAME', 'ACTIVITY_NAME')
et_activities = et_activities.withColumnRenamed('RECORD_STATUS', 'STATUS')

# et_activities = et_activities.withColumn('ACTIVITY_NAME', et_activities.ACTIVITY_NAME.substr(1, 256))
et_activities = et_activities.withColumn('ACTIVITY_NAME', F.regexp_replace(et_activities.ACTIVITY_NAME, '^\s+|\s+$|\r//g', ''))

et_activities = et_activities.withColumn('ACTIVITY_TYPE', F.lit(None).cast(StringType()))
et_activities = et_activities.withColumn('ACTIVITY_SOURCE', F.lit("ET").cast(StringType()))

et_activities = et_activities.select(
  'ACTIVITY_ID',
  'ACTIVITY_NAME',
  'STATUS',
  'ACTIVITY_SOURCE',
  'ACTIVITY_TYPE'
)

# display(et_activities)

# COMMAND ----------

# get activity id in ET that are not in DRM and union them with DRM activity id
dif1 = et_activities.select('ACTIVITY_ID').subtract(drm_activities.select('ACTIVITY_ID'))
activities = drm_activities.unionByName(et_activities.where(et_activities.ACTIVITY_ID.isin([row.ACTIVITY_ID for row in dif1.collect()])))

# COMMAND ----------

deltaFlag = False
deltaDF = ''
try:
#   curatedDF = spark.read.format("csv")\
#         .option("inferSchema","true")\
#         .option("header","true")\
#         .option("multiLine","true")\
#         .option("delimiter","|")\
#         .option("quote", '"')\
#         .option("escape",'"')\
#         .option("nullValue","null")\
#   .load("dbfs:/mnt/curated/resource_utilization/activities_master.txt")
  
  pushdown_query = "(SELECT  a.ACTIVITY_ID, ACTIVITY_NAME, STATUS, ACTIVITY_SOURCE, ACTIVITY_TYPE from fin_stg.ACTIVITY a, (SELECT ACTIVITY_ID, CREATION_DATE, rank() over  (partition by ACTIVITY_ID order by CREATION_DATE desc) as RANK_ID FROM fin_stg.ACTIVITY) r where a.ACTIVITY_ID=r.ACTIVITY_ID and a.CREATION_DATE=r.CREATION_DATE and r.RANK_ID=1) activity"
  
  dw_activity = spark.read.jdbc(url = sqlDwUrl, table = pushdown_query)
  
  deltaDF = activities.subtract(dw_activity)
  
  if deltaDF.count() > 0:
    deltaFlag = True
    
  deltaDF.createOrReplaceTempView("ACTIVITY_VIEW")
except:
  deltaFlag = True
  activities.createOrReplaceTempView("ACTIVITY_VIEW")
  
# display(activities)

# COMMAND ----------

if deltaFlag:
  query = "SELECT ACTIVITY_ID, ACTIVITY_NAME, STATUS, ACTIVITY_SOURCE, ACTIVITY_TYPE, '{0}' as RUN_ID, to_timestamp('{1}') as CREATION_DATE, 'DataBricks - MasterActivities' as CREATED_BY, CAST(null as timestamp) as UPDATION_DATE, CAST(null as string) as UPDATED_BY FROM ACTIVITY_VIEW".format(runid, processTime)

  df2 = sqlContext.sql(query)
  
  # write dataframe to DW using polybase
  df2.write\
    .format("com.databricks.spark.sqldw")\
    .option("url", sqlDwUrl)\
    .option( "forward_spark_azure_storage_credentials", "True")\
    .option("tempdir", tempDir)\
    .option("dbtable", "fin_stg.ACTIVITY")\
    .option("maxStrLength","4000")\
    .mode("append")\
    .save()

# COMMAND ----------

# write to curated
if deltaFlag:
  tmp_file_path = 'dbfs:/mnt/raw/' + runid
  curatedPath = 'dbfs:/mnt/curated/resource_utilization/'

  activities.coalesce(1).write\
              .option("sep", "|")\
              .option("header", "true")\
              .option("quote",  '"')\
              .option("escape", '"')\
              .option("nullValue", "null")\
          .csv(tmp_file_path)
  # copy part-* csv file to curated and rename
  dbutils.fs.cp(dbutils.fs.ls(tmp_file_path)[-1][0], curatedPath + 'activities_master.txt', recurse = True)

  # remove temp folders
  dbutils.fs.rm(tmp_file_path, recurse = True)