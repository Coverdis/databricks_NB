# Databricks notebook source
#File Name:FlattenDRMVestedUnitHierarchy
#ADF Pipeline Name: HypDRM_ADL_DW
#Description:
  #Flatten vested unit hierarchy comming from DRM
  #Writes final file in curated layer  

# COMMAND ----------

# MAGIC %run "./configFile"

# COMMAND ----------

dbutils.widgets.text('runid', 'abc111000')
runid = dbutils.widgets.get("runid")

# COMMAND ----------

import pytz
from datetime import datetime
processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

rawPath = 'dbfs:/mnt/raw/hyperion_drm/vu/'
foundationPath = 'dbfs:/mnt/foundation/hyperion_drm/'
curatedPath = 'dbfs:/mnt/curated/hyperion_drm/'

# COMMAND ----------

from pyspark.sql import functions as F

df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(foundationPath + "vested_unit_to_fdr.txt")

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

df.createOrReplaceTempView("VU")

# COMMAND ----------


query="select vu.nodeid as TAU3Id,vu.description as TAU3Desc,TAU2Id,TAU2Desc,TAU1Id,TAU1Desc,rootId,root,NodeActive as active from vu,(select vu.Nodeid as TAU2Id,vu.description as TAU2Desc,TAU1Id,TAU1Desc,rootId,root from vu, \
(select vu.Nodeid as TAU1Id,vu.description as TAU1Desc,rootId,root from vu,(select NodeId as rootId,Description as root from vu where ParentId=0) lvl0 where vu.parentId=rootId) lvl1 where vu.parentId=TAU1Id)lvl2 where vu.parentId=TAU2Id"

vuDF = sqlContext.sql(query)

# COMMAND ----------

csv_temp_curated = rawPath + runid + '/' + 'curated'

# write flatten hierarchy to Azure foundation data lake gen 2
vuDF.coalesce(1).write\
    .option("sep", "|")\
    .option("header", "true")\
    .option("quote",  '"')\
    .option("escape", '"')\
    .option("nullValue", "null")\
  .csv(csv_temp_curated)

# copy part-* csv file to curated and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + 'vested_unit.txt', recurse = True) 

# remove temp folder
dbutils.fs.rm(rawPath + runid, recurse = True)