# Databricks notebook source
#File Name: LoadUnifiedClinical
#ADF Pipeline Name: OneCDP_ADL, GRIPStaging_ADL, Composite_ADL
#SQLDW Table: NA
#Description:
  #Load OneCDP, eTrack (via GRIPStgaing), MDM (via Composite) clinical data to unified layer

# COMMAND ----------

dbutils.widgets.text('runid', 'pweqi-dwj122-sdjk2e-scj2as')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

# Load clinical data from OneCDP
dbutils.fs.cp('dbfs:/mnt/curated/one_cdp/clinical.txt', 'dbfs:/mnt/unified/clinical/clinical.txt', recurse = True)

# Load clinical data from eTrack
dbutils.fs.cp('dbfs:/mnt/curated/etrack/clinicalstudy.txt', 'dbfs:/mnt/unified/clinical/clinicalstudy.txt', recurse = True)
dbutils.fs.cp('dbfs:/mnt/curated/etrack/clinicalstudycountryandsite.txt', 'dbfs:/mnt/unified/clinical/clinicalstudycountryandsite.txt', recurse = True)
dbutils.fs.cp('dbfs:/mnt/curated/etrack/clinicalmilestone.txt', 'dbfs:/mnt/unified/clinical/clinicalmilestone.txt', recurse = True)
dbutils.fs.cp('dbfs:/mnt/curated/etrack/clinicalstudyasset.txt', 'dbfs:/mnt/unified/clinical/clinicalstudyasset.txt', recurse = True)