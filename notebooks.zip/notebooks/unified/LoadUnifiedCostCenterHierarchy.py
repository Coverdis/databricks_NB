# Databricks notebook source
#File Name: LoadUnifiedCostCenterHierarchy
#ADF Pipeline Name: Planisware_ADL
#SQLDW Table: NA
#Description:
  #Load Cost Center Hierarchy and IRM RBS data to unified layer in ADL

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "ffdad2-uhbny1-uytvc3-lmnsrt8")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

# read cost_center_hierarchy
cc_df = spark.read.format("csv")\
          .option("inferSchema", "false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load('dbfs:/mnt/curated/hyperion_drm/cost_center_hierarchy.txt')

cc_df = cc_df.toDF(*(col.upper().replace('\r', '') for col in cc_df.columns))
for col_name in cc_df.columns:
  cc_df = cc_df.withColumn(col_name, F.regexp_replace(F.col(col_name), '[\\r\\n\\s+]', ' '))

# COMMAND ----------

org_units_et = spark.read.format("csv")\
        .option("inferSchema","true")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
  .load("dbfs:/mnt/foundation/et/organisation_units.txt")

org_units_et = org_units_et.toDF(*(col.replace('\r', '') for col in org_units_et.columns))

for col_name in org_units_et.columns:
  org_units_et = org_units_et.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

# COMMAND ----------


new_cc_df = cc_df.join(org_units_et, cc_df.COST_CENTER_CODE == org_units_et.ORIG_CODE, 'left').drop('ID', 'NAME', 'OUT_ID', 'ORIG_CODE', 'EMS_ID', 'CC_TIME_UNIT', 'CC_TYPE', 'LOC_ID', 'SRL_ID', 'FTES_COVERED', 'STANDARD_HOURS', 'CONTRACTED_HOURS', 'PARENT_ID', 'SS_ID', 'RECORD_STATUS', 'CREATED_BY', 'CREATED_DATE', 'LAST_MODIFIED_DATE', 'LAST_MODIFIED_BY', 'LOCK_USER_YN')

new_cc_df = new_cc_df.withColumnRenamed('OPT_IN_YN', 'OPT_IN_ET')

# COMMAND ----------

# read irm_rbs
rbs_df = spark.read.format("csv")\
          .option("inferSchema", "false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/irm/rbs.txt')

rbs_df = rbs_df.toDF(*(col.upper().replace('\r', '') for col in rbs_df.columns))

for col_name in rbs_df.columns:
  rbs_df = rbs_df.withColumn(col_name, F.regexp_replace(F.col(col_name), '[\\r\\n\\s+]', ' '))
  
rbs_df = rbs_df.withColumnRenamed('NODE_NAME', 'RBS_CODE')
rbs_df = rbs_df.withColumnRenamed('DESCRIPTION', 'RBS_DESCRIPTION')

# COMMAND ----------

df = new_cc_df.join(rbs_df.select('RBS_CODE', 'RBS_DESCRIPTION'), ['RBS_CODE'], 'left')

# COMMAND ----------

# write to unified
raw_path = 'dbfs:/mnt/raw/hyp_drm/'
unique_run_id = runid + '-LoadUnifiedCostCenterHierarchy/'
csv_temp_curated = raw_path + unique_run_id + '/' + 'unified/'
unified_path = 'dbfs:/mnt/unified/finance/'

df.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], unified_path + "cost_center_hierarchy.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)