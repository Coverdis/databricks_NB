# Databricks notebook source
#File Name: LoadUnifiedOther
#ADF Pipeline Name: Composite_ADL
#SQLDW Table: NA
#Description:
  #Load Composite(MDM) Activity Resource, Ledger Code, Country List data to unified layer

# COMMAND ----------

dbutils.widgets.text('runid', 'pweqi-dwj122-sdjk2e-scj2as')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

# Load other data
dbutils.fs.cp('dbfs:/mnt/curated/composite/activityresource.txt', 'dbfs:/mnt/unified/other/activityresource.txt', recurse = True)
dbutils.fs.cp('dbfs:/mnt/curated/composite/activityresourceledgercode.txt', 'dbfs:/mnt/unified/other/activityresourceledgercode.txt', recurse = True)
dbutils.fs.cp('dbfs:/mnt/curated/composite/country.txt', 'dbfs:/mnt/unified/other/country.txt', recurse = True)