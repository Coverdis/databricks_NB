# Databricks notebook source
#File Name: LoadUnifiedProject
#ADF Pipeline Name:  PDM_ADL, HypDRM_ADL, VxPLM_ADL
#SQLDW Table: irm_stg.PROJECT
#Description:
  #Load PDM, Vx PLM and DRM project data in unified project management folder

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
import random

dbutils.widgets.text('runid', 'csdj238-dfo233d-ovrfpr3-pveuiec')
dbutils.widgets.dropdown("source", "rx-pdm", ['rx-pdm', 'vx-plm'])

runid = dbutils.widgets.get("runid")
source = dbutils.widgets.get("source")


# COMMAND ----------

def read(path):
  read_df = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load(path)
  df = read_df.toDF(*(col.replace('\r', '') for col in read_df.columns))
  return df

# COMMAND ----------

if source == 'vx-plm':
  project = read('dbfs:/mnt/curated/vaccines/plm/vx_project.txt')
  project = project.withColumn('SOURCE', F.lit('Vx-PLM').cast(StringType()))
  project = project.withColumn('ACTIVE_SUBSTANCE_DESCRIPTION', F.lit(None).cast(StringType()))
  project = project.withColumn('EARLIEST_MILESTONE_DISPLAY_ORDER', F.lit(None).cast(StringType()))
  project = project.withColumn('EARLIEST_MILESTONE_PHASE', F.lit(None).cast(StringType()))
  project = project.withColumn('EARLIEST_MILESTONE_REPORT_DATE', F.lit(None).cast(StringType()))
  project = project.withColumn('CURRENT_PHASE_INDUSTRY_ORDER', F.lit(None).cast(StringType()))
  project = project.withColumn('PROJECT_ORDER_FOR_ACTIVE_SUBSTANCE', F.lit(None).cast(StringType()))
  
#   vx_plan = read('dbfs:/mnt/curated/vaccines/planisware/vx_plw_plan.txt').filter('PLAN_TYPE_NAME = "PT"').select('PROJECT_ID', 'PLAN_OWNER_ID', 'PLAN_CURRENT_PHASE')
  
#   project = project.join(vx_plan, project.PROJECT_CODE == vx_plan.PROJECT_ID, 'leftouter')
#   project = project.withColumn('PROJECT_OWNER_USER_ID', F.lit(project.PLAN_OWNER_ID).cast(StringType()))
#   project = project.withColumn('PROJECT_CURRENT_PHASE', F.lit(project.PLAN_CURRENT_PHASE).cast(StringType()))
  
  
  vx_plan = read('dbfs:/mnt/foundation/vaccines/planisware/plw_project.txt').filter('VACC_RA_PRJ_PLT = "PT" and _pv_aa_s_status = ""').select('VACC_NF_S_MDM_STREAM_CODE', 'ID', 'OWNER', 'USER_ATTRIBUTE_PME_UA_S_CURRENT_PRJ_PHASE')
  
#   vx_plan = vx_plan.withColumn('ID', F.substring(vx_plan.ID, 1, 11))
  vx_plan = vx_plan.withColumn('ID', F.when(F.length(vx_plan.ID) == '11', vx_plan.ID).otherwise(F.lit(None)))
  
  project = project.join(vx_plan, project.PROJECT_CODE == vx_plan.ID, 'leftouter')
  project = project.withColumn('PROJECT_OWNER_USER_ID', F.lit(project.OWNER).cast(StringType()))
  project = project.withColumn('PROJECT_CURRENT_PHASE', F.lit(project.USER_ATTRIBUTE_PME_UA_S_CURRENT_PRJ_PHASE).cast(StringType()))

# COMMAND ----------

if source == 'rx-pdm':
  # read PDM project data from curated layer
  project = spark.read.format("csv")\
        .option("inferSchema", "false")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
    .load('dbfs:/mnt/curated/pdm/project.txt')

  project = project.toDF(*(col.replace('\r', '') for col in project.columns))

  project = project.select('PROJECT_CODE', 'PROJECT_DESCRIPTION', 'DESCRIPTION_SHORT', 'PROJECT_STATUS_CODE', 'PROJECT_CREATION_DATE', 'PROJECT_CREATION_USER_ID', 'PROJECT_MODIFICATION_DATE', 'PROJECT_MODIFICATION_USER_ID', 'PROJECT_FORM_NAME', 'PROJECT_OWNER_USER_ID', 'PROJECT_STATUS_CHANGE_DATE', 'PROJECT_STATUS_CHANGE_COMMENT', 'TEAM_ID', 'PROJECT_STATUS_TERMINATION_REASON')

# COMMAND ----------

if source == 'rx-pdm':
  # read PDM Project Deliverable data from curated layer
  project_deliverable = read('dbfs:/mnt/curated/pdm/project_deliverable.txt')

  project_deliverable = project_deliverable.select('PROJECT_CODE', 'MEDICAL_CONDITION_CODE', 'INDICATION_CODE', 'THERAPEUTIC_AREA_SHORT_NAME', 'THERAPEUTIC_AREA_LONG_NAME',  'DELIVERABLE_TYPE','ACTIVE_SUBSTANCE_ID', 'ACTIVE_SUBSTANCE_DESCRIPTION', 'ACTIVE_SUBSTANCE_TYPE_CODE', 'FL_COMBINATION', 'COMPOUND_REPORTED_NAME', 'CANDIDATE_SELECTION_TYPE_NAME', 'ROUTE_OF_ADMINISTRATION', 'THERAPY_TYPE', 'THERAPY_TYPE_COMMENT', 'LEAD_BU_CODE', 'DEFAULT_FUNDING_PARTY', 'FUNDER_L1', 'FUNDER_L2', 'FUNDER_L3', 'START_PHASE', 'START_PHASE_DISPLAY_ORDER', 'IMMUNOMODULATORY_FLAG', 'GENESYMBOL','CREATE_DATE', 'MODIFY_DATE')

# COMMAND ----------

if source == 'rx-pdm':
  # read PDM Active Substance data from curated layer
  act_sub_df = read('dbfs:/mnt/curated/pdm/active_substance.txt').select(['ACTIVE_SUBSTANCE_ID', 'MECHANISM_OF_ACTION_DESCRIPTION'])

  #add MECHANISM_OF_ACTION_DESCRIPTION field to project_deliverable table
  project_deliverable = project_deliverable.join(act_sub_df, ["ACTIVE_SUBSTANCE_ID"], 'left')

# COMMAND ----------

if source == 'rx-pdm':
  # read PDM Active Substance Hierarchy data from curated layer
  active_substance_hierarchy = read('dbfs:/mnt/curated/pdm/active_substance_hierarchy.txt').select(['LEVEL2_DESCRIPTION','LEVEL3_DESCRIPTION','LVL3DEX'])
  active_substance_hierarchy = active_substance_hierarchy.withColumnRenamed('LVL3DEX','ACTIVE_SUBSTANCE_TYPE_CODE')
  active_substance_hierarchy = active_substance_hierarchy.withColumnRenamed('LEVEL3_DESCRIPTION','ACTIVE_SUBSTANCE_SUB_TYPE_DESCRIPTION')
  active_substance_hierarchy = active_substance_hierarchy.withColumnRenamed('LEVEL2_DESCRIPTION','ACTIVE_SUBSTANCE_TYPE_DESCRIPTION')

  #add ACTIVE_SUBSTANCE_SUB_TYPE_DESCRIPTION and ACTIVE_SUBSTANCE_TYPE_DESCRIPTION fields to project_deliverable table
  project_deliverable = project_deliverable.join(active_substance_hierarchy, ["ACTIVE_SUBSTANCE_TYPE_CODE"], 'left')

# COMMAND ----------

if source == 'rx-pdm':
  # read PDM Medical Condition Hierarchy data from curated layer
  
  medi_con_h = read('dbfs:/mnt/curated/pdm/medical_condition_hierarchy.txt').select(['LEVEL2_DESCRIPTION','LEVEL3_DESCRIPTION','LVL3DEX'])
  medi_con_h = medi_con_h.withColumnRenamed('LVL3DEX','MEDICAL_CONDITION_CODE')
  medi_con_h = medi_con_h.withColumnRenamed('LEVEL3_DESCRIPTION','INDICATION')
  medi_con_h = medi_con_h.withColumnRenamed('LEVEL2_DESCRIPTION','DISEASE_AREA')

  #add INDICATION and DISEASE_AREA fields to project_deliverable table
  project_deliverable = project_deliverable.join(medi_con_h, ["MEDICAL_CONDITION_CODE"], 'left')
  
  

# COMMAND ----------

if source == 'rx-pdm':
  from pyspark.sql.functions import *
  from pyspark.sql.types import *

  project_deliverable = project_deliverable.withColumn('INDICATION',when(project_deliverable.INDICATION_CODE.startswith('URN') &  project_deliverable.INDICATION.isNotNull(),project_deliverable.INDICATION).when(project_deliverable.INDICATION_CODE.startswith('URN') &  project_deliverable.INDICATION.isNull(),project_deliverable.DISEASE_AREA).when(project_deliverable.INDICATION_CODE=='TBD',lit('TBD')).when(project_deliverable.INDICATION.isNull(),project_deliverable.DISEASE_AREA).otherwise(col("INDICATION")))
  


# COMMAND ----------

if source == 'rx-pdm':
  # read PDM Vested Unit Hierarchy data from curated layer
  vested_unit_hierarchy = read('dbfs:/mnt/curated/pdm/vested_unit_hierarchy.txt').select(['LEVEL1_DESCRIPTION','LEVEL2_DESCRIPTION','LEVEL3_DESCRIPTION','DEXCODE'])
  vested_unit_hierarchy = vested_unit_hierarchy.withColumnRenamed('DEXCODE','LEAD_BU_CODE')
#   vested_unit_hierarchy = vested_unit_hierarchy.withColumnRenamed('LEVEL3_DESCRIPTION','VESTED_UNIT_LEVEL_3')
#   vested_unit_hierarchy = vested_unit_hierarchy.withColumnRenamed('LEVEL2_DESCRIPTION','VESTED_UNIT_LEVEL_2')
#   vested_unit_hierarchy = vested_unit_hierarchy.withColumnRenamed('LEVEL1_DESCRIPTION','VESTED_UNIT_LEVEL_1')

  #add VESTED_UNIT fields to project_deliverable table
  project_deliverable = project_deliverable.join(vested_unit_hierarchy, ["LEAD_BU_CODE"], 'left')

# COMMAND ----------

if source == 'rx-pdm':
  #calculate project delivarable fields
  project_deliverable = project_deliverable.withColumn('COMPOUND_STATUS', F.lit(None).cast(StringType()))

# COMMAND ----------

if source == 'rx-pdm':
  #join project with project deliverable file
  project = project.join(project_deliverable, ["PROJECT_CODE"], 'left')

# COMMAND ----------

if source == 'rx-pdm':
  # read PDM Termination Reason Hierarchy data from curated layer
  term_reason_hierarchy = read('dbfs:/mnt/curated/pdm/term_reason_hierarchy.txt').select(['LEVEL2_DESCRIPTION','LEVEL3_DESCRIPTION','LVL3DEX'])
  term_reason_hierarchy = term_reason_hierarchy.withColumnRenamed('LVL3DEX','PROJECT_STATUS_TERMINATION_REASON_CODE')
  term_reason_hierarchy = term_reason_hierarchy.withColumnRenamed('LEVEL3_DESCRIPTION','PROJECT_STATUS_TERMINATION_REASON')
  term_reason_hierarchy = term_reason_hierarchy.withColumnRenamed('LEVEL2_DESCRIPTION','PROJECT_STATUS_TERMINATION_CATEGORY')

  #add STATUS_TERMINATION_REASON and STATUS_TERMINATION_CATEGORY fields to project_deliverable table
  project = project.withColumnRenamed('PROJECT_STATUS_TERMINATION_REASON','PROJECT_STATUS_TERMINATION_REASON_CODE')
  project = project.join(term_reason_hierarchy, ["PROJECT_STATUS_TERMINATION_REASON_CODE"], 'left')

# COMMAND ----------

if source == 'rx-pdm':
  # read PDM Project Status Hierarchy data from curated layer
  project_status_hierarchy = read('dbfs:/mnt/curated/pdm/project_status_hierarchy.txt').select(['LEVEL2_DESCRIPTION','LEVEL3_DESCRIPTION','LVL3DEX'])
  project_status_hierarchy = project_status_hierarchy.withColumnRenamed('LVL3DEX','PROJECT_STATUS_CODE')
  project_status_hierarchy = project_status_hierarchy.withColumnRenamed('LEVEL3_DESCRIPTION','PROJECT_SUB_STATUS')
  project_status_hierarchy = project_status_hierarchy.withColumnRenamed('LEVEL2_DESCRIPTION','PROJECT_STATUS')
  project_status_hierarchy = project_status_hierarchy.withColumn('PROJECT_STATUS_LONG_NAME', F.concat(F.when(project_status_hierarchy.PROJECT_STATUS != "null", project_status_hierarchy['PROJECT_STATUS']).otherwise(F.lit('')), F.when(project_status_hierarchy.PROJECT_SUB_STATUS != "null", F.concat(F.lit('-'), project_status_hierarchy['PROJECT_SUB_STATUS'])).otherwise(F.lit(''))))

  #add Project Status fields to project_deliverable table
  project = project.join(project_status_hierarchy, ["PROJECT_STATUS_CODE"], 'left')

# COMMAND ----------

if source == 'rx-pdm':
  # keep only one row for each project_code based on descending CREATION_DATE and MODIFICATION_DATE
  project = project.withColumn('ROWNUM', F.row_number().over(Window.partitionBy('PROJECT_CODE').orderBy(F.desc('CREATE_DATE'), F.desc('MODIFY_DATE'))))
  project = project.filter('ROWNUM = 1')
  project = project.drop('CREATE_DATE', 'MODIFY_DATE', 'ROWNUM')

# COMMAND ----------

if source == 'rx-pdm':
  for col_name in project.columns:
    project = project.withColumn(col_name, F.regexp_replace(F.col(col_name), '[\\r\\n\\s]', ' '))

# COMMAND ----------

if source == 'rx-pdm':
  #calculate compound status field
  project = project.withColumn('COMPOUND_STATUS', F.when((project.PROJECT_STATUS == "Proposed") & (project.PROJECT_FORM_NAME != "Pre-Candidate (Never Progress beyond Lead Opt"), 'Active').when((project.PROJECT_STATUS == "Active") & (project.PROJECT_FORM_NAME != "Pre-Candidate (Never Progress beyond Lead Opt"), 'Active').when((project.PROJECT_STATUS_LONG_NAME == "Under Review-Progressing") & (project.PROJECT_FORM_NAME != "Pre-Candidate (Never Progress beyond Lead Opt"), 'Active').when((project.PROJECT_STATUS == "Under Review") & (project.PROJECT_FORM_NAME != "Pre-Candidate (Never Progress beyond Lead Opt"), 'Active').when((project.PROJECT_STATUS_LONG_NAME == "Under Review-On Hold") & (project.PROJECT_FORM_NAME != "Pre-Candidate (Never Progress beyond Lead Opt"), 'Active').when((project.PROJECT_STATUS_LONG_NAME == "Under Review-Termination Proposed") & (project.PROJECT_FORM_NAME != "Pre-Candidate (Never Progress beyond Lead Opt"), 'Active').otherwise('Inactive')) 


# COMMAND ----------

if source == 'rx-pdm':
  #add planisware data
  #check if new and legacy plw file exists or not
  plw_new=False
  plw_legacy=False
  pdm_migrated=False
  act_new = False
  if file_exists('dbfs:/mnt/unified/project_management/plan.txt')==True:   
    plw_new=True
    plan_new = spark.read.format("csv")\
          .option("inferSchema", "false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null").load("dbfs:/mnt/unified/project_management/plan.txt")
    plan_new=plan_new.select('plan_object_number','plan_type_name','project_id','source').filter("plan_type_name in ('MDP','PCMP') and project_id is not null and project_id<>'' and plan_state in ('Active','Closed') and reference_object_number is null")

  if file_exists('dbfs:/mnt/unified/project_management/task.txt')==True:
    act_new = True
    activity_new = spark.read.format("csv")\
        .option("inferSchema", "false")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
    .load("dbfs:/mnt/unified/project_management/task.txt")
    activity_new=activity_new.select('plan_object_number','MILESTONE_SORT_ORDER','INDUSTRY_PHASE','MILESTONE_STATUS','SOURCE','MILESTONE_PHASE_PROGRESSION','FIRST_SUBMISSION_MILESTONE','FIRST_APPROVAL_MILESTONE','FIRST_LAUNCH_MILESTONE','ACTIVITY_ACTUAL_START_DATE','ACTIVITY_ACTUAL_END_DATE','ACTIVITY_PLANNED_START_DATE','ACTIVITY_PLANNED_END_DATE','ACTIVITY_OBJECT_NUMBER','WBS_TYPE').filter("reference_object_number is null")


  if file_exists('dbfs:/mnt/unified/project_management/plan_legacy.txt')==True:   
    plw_legacy=True
    plan_legacy = spark.read.format("csv")\
          .option("inferSchema", "false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null").load("dbfs:/mnt/unified/project_management/plan_legacy.txt")
    plan_legacy=plan_legacy.select('plan_object_number','plan_type_name','project_id','source').filter("plan_type_name='MDP' and project_id is not null and project_id<>'' and plan_state in ('Active','Closed')")
    activity_legacy = spark.read.format("csv")\
        .option("inferSchema", "false")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
    .load("dbfs:/mnt/unified/project_management/task_legacy.txt")
    activity_legacy=activity_legacy.select('plan_object_number','MILESTONE_SORT_ORDER','INDUSTRY_PHASE','MILESTONE_STATUS','SOURCE','MILESTONE_PHASE_PROGRESSION','FIRST_SUBMISSION_MILESTONE','FIRST_APPROVAL_MILESTONE','FIRST_LAUNCH_MILESTONE','ACTIVITY_ACTUAL_START_DATE','ACTIVITY_ACTUAL_END_DATE','ACTIVITY_PLANNED_START_DATE','ACTIVITY_PLANNED_END_DATE','ACTIVITY_OBJECT_NUMBER','WBS_TYPE')  

  if file_exists('dbfs:/mnt/unified/project_management/plan_migrated.txt')==True:   
    pdm_migrated=True
    plan_migrated = spark.read.format("csv")\
          .option("inferSchema", "false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null").load("dbfs:/mnt/unified/project_management/plan_migrated.txt")
    plan_migrated=plan_migrated.select('plan_object_number','plan_type_name','project_id','source').filter("plan_type_name='MDP' and project_id is not null and project_id<>'' and plan_state in ('Migrated')") 

    activity_migrated = spark.read.format("csv")\
        .option("inferSchema", "false")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
    .load("dbfs:/mnt/unified/project_management/task_migrated.txt")
    activity_migrated=activity_migrated.select('plan_object_number','MILESTONE_SORT_ORDER','INDUSTRY_PHASE','MILESTONE_STATUS','SOURCE','MILESTONE_PHASE_PROGRESSION','FIRST_SUBMISSION_MILESTONE','FIRST_APPROVAL_MILESTONE','FIRST_LAUNCH_MILESTONE','ACTIVITY_ACTUAL_START_DATE','ACTIVITY_ACTUAL_END_DATE','ACTIVITY_PLANNED_START_DATE','ACTIVITY_PLANNED_END_DATE','ACTIVITY_OBJECT_NUMBER','WBS_TYPE')  

  if plw_new==True and plw_legacy==True and pdm_migrated==True and act_new == True:
    plan=plan_new.union(plan_legacy).union(plan_migrated)  
    activity=activity_new.union(activity_legacy).union(activity_migrated)  
  elif plw_new==True and plw_legacy==True and act_new == True: 
    plan=plan_new.union(plan_legacy)
    activity=activity_new.union(activity_legacy)
  elif plw_new==True and pdm_migrated==True and act_new == True: 
    plan=plan_new.union(plan_migrated)
    activity=activity_new.union(activity_migrated)
  elif plw_new==True and act_new == True: 
    plan=plan_new
    activity=activity_new
  elif plw_legacy==True: 
    plan=plan_legacy
    activity=activity_legacy
  elif pdm_migrated==True: 
    plan=plan_migrated
    activity=activity_migrated  
  else: 
    project=project.withColumn('PROJECT_CURRENT_PHASE',F.lit(None).cast(StringType()))
    project=project.withColumn('CURRENT_PHASE_DISPLAY_ORDER',F.lit(None).cast(IntegerType()))

  print(plw_new)
  print(act_new)
  print(plw_legacy)
  print(pdm_migrated)

# COMMAND ----------

if source == 'rx-pdm':
  plan_priority = plan.filter('source="PLW-NEW"')
  activity_priority =  activity.join(plan_priority,['plan_object_number','SOURCE'],'inner')
  # calculate PCMP and MDP Priority Flag
  activity_priority = activity_priority.withColumn('MDP_PRIORITY',F.row_number().over(Window.partitionBy('project_id','SOURCE','WBS_TYPE').orderBy(F.asc('plan_type_name'))))

  activity_priority = activity_priority.withColumn('PCMP_PRIORITY',F.row_number().over(Window.partitionBy('project_id','SOURCE','WBS_TYPE').orderBy(F.desc('plan_type_name'))))

  activity_priority = activity_priority.withColumn('Flag',F.when((activity_priority.PCMP_PRIORITY == 1) & ((activity_priority.WBS_TYPE == "C2TID") | (activity_priority.WBS_TYPE == "C2TV") | (activity_priority.WBS_TYPE == "C2T") | (activity_priority.WBS_TYPE == "C2LO") | (activity_priority.WBS_TYPE == "C2PC") | (activity_priority.WBS_TYPE == "C2CS") ) ,1).when( (activity_priority.MDP_PRIORITY == 1) & (activity_priority.WBS_TYPE == "C2FTIH"), 1 ).when( (activity_priority.WBS_TYPE != "C2TID") | (activity_priority.WBS_TYPE != "C2TV") | (activity_priority.WBS_TYPE != "C2T") | (activity_priority.WBS_TYPE != "C2LO") | (activity_priority.WBS_TYPE != "C2PC") | (activity_priority.WBS_TYPE != "C2CS") | (activity_priority.WBS_TYPE != "C2FTIH"), 1 ).otherwise(0))

  activity_pcmp = activity_priority.filter('plan_type_name="PCMP" and Flag=1')
  activity_pcmp = activity_pcmp.drop('plan_type_name').drop('project_id').drop('PCMP_PRIORITY').drop('MDP_PRIORITY').drop('Flag')

  activity_mdp = activity_priority.filter('plan_type_name="MDP" and Flag=1')
  activity_mdp = activity_mdp.drop('plan_type_name').drop('project_id').drop('PCMP_PRIORITY').drop('MDP_PRIORITY').drop('Flag')

  plan_leg = plan.filter('source="PLW-LEGACY"')
  activity_leg =  activity.join(plan_leg,['plan_object_number','SOURCE'],'inner')
  activity_leg = activity_leg.filter('plan_type_name="MDP"')
  activity_leg = activity_leg.drop('plan_type_name').drop('project_id')

  plan_mig = plan.filter('source="PDM-MIGRATED"')
  activity_mig =  activity.join(plan_mig,['plan_object_number','SOURCE'],'inner')
  activity_mig = activity_mig.filter('plan_type_name="MDP"')
  activity_mig = activity_mig.drop('plan_type_name').drop('project_id')

  # merge the dataFrames
  un1 = activity_pcmp.union(activity_mdp)
  un2 = un1.union(activity_leg)
  activity_merged = un2.union(activity_mig)



# COMMAND ----------

if source == 'rx-pdm':
  #calculate industry phase and display order based on the last achieved milestone in planisware
  if plw_new==True or plw_legacy==True or pdm_migrated==True:
    last_milestone = activity_merged.filter('MILESTONE_STATUS="Achieved" and MILESTONE_PHASE_PROGRESSION is not NULL').select('plan_object_number','MILESTONE_SORT_ORDER','INDUSTRY_PHASE','SOURCE')

    last_milestone = last_milestone.join(plan,['plan_object_number','SOURCE'],'inner')  
    last_milestone = last_milestone.drop('project_id').drop('plan_type_name')
    last_milestone = last_milestone.withColumn("MILESTONE_SORT_ORDER", last_milestone['MILESTONE_SORT_ORDER'].cast(IntegerType()))
    last_milestone = last_milestone.withColumn('ROWNUM',F.row_number().over(Window.partitionBy('SOURCE','plan_object_number').orderBy(F.desc('MILESTONE_SORT_ORDER'))))

    last_milestone = last_milestone.filter('ROWNUM=1')
    last_milestone = last_milestone.drop('ROWNUM')

    last_milestone_plan = plan.join(last_milestone,['plan_object_number','SOURCE'],'left')

    last_milestone_plan = last_milestone_plan.withColumn('Priority',F.row_number().over(Window.partitionBy('Project_id').orderBy(F.desc('SOURCE')))) 
    last_milestone_plan = last_milestone_plan.filter('priority=1').drop('plan_object_number').drop('source').drop('plan_type_name').drop('MILESTONE_STATUS').drop('Priority')
    last_milestone_plan = last_milestone_plan.withColumnRenamed('project_id','PROJECT_CODE')
    last_milestone_plan = last_milestone_plan.withColumnRenamed('INDUSTRY_PHASE','PROJECT_CURRENT_PHASE')
    last_milestone_plan = last_milestone_plan.withColumnRenamed('MILESTONE_SORT_ORDER','CURRENT_PHASE_DISPLAY_ORDER')
    project = project.join(last_milestone_plan,['PROJECT_CODE'],'left')

# COMMAND ----------

if source == 'rx-pdm':
  # checkpointing the project df to raw, for notebook optimization and debugging
  raw_path = 'dbfs:/mnt/raw/resource_utilization/'
  unique_run_id = runid + '-LoadUnifiedProject/'
  csv_temp_unified = raw_path + unique_run_id + '/' + 'unified'

  checkpoint_raw_path = 'dbfs:/mnt/raw/pdm/LoadUnifiedProject_checkpoints/'

  project.coalesce(1).write\
          .option("sep", "|")\
          .option("header", "true")\
          .option("quote",  '"')\
          .option("quoteAll", "true")\
          .option("escape", '"')\
          .option("nullValue", "null")\
          .mode('overwrite')\
        .csv(csv_temp_unified)

  # copy part-* csv file to foundation and rename
  dbutils.fs.cp(dbutils.fs.ls(csv_temp_unified)[-1][0], checkpoint_raw_path + "project_checkpoint1.txt", recurse = True)

  # remove temp folder
  dbutils.fs.rm(raw_path + unique_run_id, recurse = True)

# COMMAND ----------

if source == 'rx-pdm':
  # reading first project checkpoint from raw
  project = spark.read.format("csv")\
        .option("inferSchema", "false")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
    .load('dbfs:/mnt/raw/pdm/LoadUnifiedProject_checkpoints/project_checkpoint1.txt')

  project = project.toDF(*(col.replace('\r', '') for col in project.columns))

# COMMAND ----------

if source == 'rx-pdm':
  #calculate industry phase, display order and report date based on the last of the earliest milestones (first sumbmission/first approval/first launch) in planisware
  if plw_new==True or plw_legacy==True or pdm_migrated==True:
    earliest_milestone = activity_merged.filter('FIRST_SUBMISSION_MILESTONE="True" or FIRST_APPROVAL_MILESTONE="True" or FIRST_LAUNCH_MILESTONE="True"').select('plan_object_number','MILESTONE_SORT_ORDER','INDUSTRY_PHASE','SOURCE','ACTIVITY_ACTUAL_START_DATE','ACTIVITY_ACTUAL_END_DATE','ACTIVITY_PLANNED_START_DATE','ACTIVITY_PLANNED_END_DATE')
    earliest_milestone = earliest_milestone.withColumn('REPORT_DATE', F.when(earliest_milestone.ACTIVITY_ACTUAL_END_DATE!="null", earliest_milestone.ACTIVITY_ACTUAL_END_DATE).when(earliest_milestone.ACTIVITY_ACTUAL_START_DATE!="null", earliest_milestone.ACTIVITY_ACTUAL_START_DATE).when(earliest_milestone.ACTIVITY_PLANNED_END_DATE!="null", earliest_milestone.ACTIVITY_PLANNED_END_DATE).when(earliest_milestone.ACTIVITY_PLANNED_START_DATE!="null", earliest_milestone.ACTIVITY_PLANNED_START_DATE))
    earliest_milestone = earliest_milestone.drop('ACTIVITY_ACTUAL_END_DATE').drop('ACTIVITY_ACTUAL_START_DATE').drop('ACTIVITY_PLANNED_END_DATE').drop('ACTIVITY_PLANNED_START_DATE')
    earliest_milestone = earliest_milestone.join(plan,['plan_object_number','SOURCE'],'inner')
    earliest_milestone = earliest_milestone.drop('project_id').drop('plan_type_name')
    earliest_milestone = earliest_milestone.withColumn("MILESTONE_SORT_ORDER", earliest_milestone['MILESTONE_SORT_ORDER'].cast(IntegerType()))
    earliest_milestone = earliest_milestone.withColumn('ROWNUM',F.row_number().over(Window.partitionBy('SOURCE','plan_object_number').orderBy(F.desc('MILESTONE_SORT_ORDER'))))
    earliest_milestone = earliest_milestone.filter('ROWNUM=1')
    earliest_milestone = earliest_milestone.drop('ROWNUM')
    earliest_milestone_plan = plan.join(earliest_milestone,['plan_object_number','SOURCE'],'left')
    earliest_milestone_plan = earliest_milestone_plan.withColumn('Priority',F.row_number().over(Window.partitionBy('Project_id').orderBy(F.desc('SOURCE')))) 
    earliest_milestone_plan = earliest_milestone_plan.filter('priority=1').drop('plan_object_number').drop('source').drop('plan_type_name').drop('MILESTONE_STATUS').drop('Priority')
    earliest_milestone_plan = earliest_milestone_plan.withColumnRenamed('project_id','PROJECT_CODE')
    earliest_milestone_plan = earliest_milestone_plan.withColumnRenamed('INDUSTRY_PHASE','EARLIEST_MILESTONE_PHASE')
    earliest_milestone_plan = earliest_milestone_plan.withColumnRenamed('MILESTONE_SORT_ORDER','EARLIEST_MILESTONE_DISPLAY_ORDER')
    earliest_milestone_plan = earliest_milestone_plan.withColumnRenamed('REPORT_DATE','EARLIEST_MILESTONE_REPORT_DATE')
    project = project.join(earliest_milestone_plan,['PROJECT_CODE'],'left')

# COMMAND ----------

if source == 'rx-pdm':
  mapping = spark.read.format("csv")\
        .option("inferSchema", "false")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
    .load("dbfs:/mnt/curated//erdm/project_milestone_list.txt")
  mapping=mapping.select('MILESTONE_SORT_ORDER','INDUSTRY_PHASE')
  mapping = mapping.withColumn("MILESTONE_SORT_ORDER", mapping['MILESTONE_SORT_ORDER'].cast(IntegerType()))
  mapping=mapping.withColumn('Priority',F.row_number().over(Window.partitionBy('INDUSTRY_PHASE').orderBy('MILESTONE_SORT_ORDER'))) 
  mapping=mapping.filter('priority=1 and INDUSTRY_PHASE!="null"').drop('Priority')
  mapping=mapping.withColumnRenamed('INDUSTRY_PHASE','PROJECT_CURRENT_PHASE')
  mapping=mapping.withColumnRenamed('MILESTONE_SORT_ORDER','CURRENT_PHASE_DISPLAY_ORDER')


# COMMAND ----------

if source == 'rx-pdm':
  #set the START_PHASE_DISPLAY_ORDER same as current phase for comparison
  df=mapping
  df=df.withColumnRenamed('PROJECT_CURRENT_PHASE','START_PHASE')
  df=df.withColumnRenamed('CURRENT_PHASE_DISPLAY_ORDER','START_PHASE_DISPLAY_ORDER')
  project=project.drop('START_PHASE_DISPLAY_ORDER')
  project=project.join(df,['START_PHASE'],'left')

# COMMAND ----------

if source == 'rx-pdm':
  #for technology projects current phase will be same as start phase
  project=project.withColumn('PROJECT_CURRENT_PHASE', F.when(project.PROJECT_FORM_NAME=='Technology',project.START_PHASE).otherwise(project.PROJECT_CURRENT_PHASE))

# COMMAND ----------

if source == 'rx-pdm':
  #set current phase as start phase if current phase is null
  project=project.withColumn('PROJECT_CURRENT_PHASE', F.coalesce('PROJECT_CURRENT_PHASE', 'START_PHASE'))
  #set current phase as start phase if start phase is later than current phase-- this should not happen, where start phase is Pre-Candidate Profiling
  project = project.withColumn('PROJECT_CURRENT_PHASE', F.when((project.START_PHASE_DISPLAY_ORDER > project.CURRENT_PHASE_DISPLAY_ORDER) & (project.START_PHASE!='Pre-Candidate Profiling') , project.START_PHASE).otherwise(project.PROJECT_CURRENT_PHASE))

  #set current phase as not applicable where current phase is null
  project = project.na.fill("Not Applicable", 'PROJECT_CURRENT_PHASE')
  #recalulate current phase display order
  project=project.drop('CURRENT_PHASE_DISPLAY_ORDER')
  project=project.join(mapping,['PROJECT_CURRENT_PHASE'],'left')
  #project=project.withColumn('CURRENT_PHASE_DISPLAY_ORDER', F.coalesce('CURRENT_PHASE_DISPLAY_ORDER', #'MILESTONE_SORT_ORDER','START_PHASE_DISPLAY_ORDER'))
  #project=project.drop('MILESTONE_SORT_ORDER')

# COMMAND ----------

if source == 'rx-pdm':
  #Current phase will be set to lead optimization if start phase is Pre-Candidate Profiling and current phase is Pre-Candidate Profiling)
  project = project.withColumn('PROJECT_CURRENT_PHASE', F.when((project.PROJECT_CURRENT_PHASE=='Pre-Candidate Profiling') & (project.START_PHASE=='Pre-Candidate Profiling') , F.lit('Lead Optimisation')).otherwise(project.PROJECT_CURRENT_PHASE))
  #display(project.filter((project.PROJECT_CURRENT_PHASE=='Pre-Candidate Profiling') & (project.START_PHASE=='Pre-Candidate Profiling')))

# COMMAND ----------

if source == 'rx-pdm':
  #Add current phase order. The field CURRENT_PHASE_DISPLAY_ORDER actually contains the display order of the last achieved milestone
  project = project.withColumn('CURRENT_PHASE_INDUSTRY_ORDER', F.when(project.PROJECT_CURRENT_PHASE == "Not Applicable", 0).when(project.PROJECT_CURRENT_PHASE == "Target Validation", 1).when(project.PROJECT_CURRENT_PHASE == "Lead Discovery", 2).when(project.PROJECT_CURRENT_PHASE == "Lead Optimisation", 3).when(project.PROJECT_CURRENT_PHASE == "Pre-Candidate Profiling", 4).when(project.PROJECT_CURRENT_PHASE == "Pre-Clinical Evaluation", 5).when(project.PROJECT_CURRENT_PHASE == "Phase I", 6).when(project.PROJECT_CURRENT_PHASE == "Phase II", 7).when(project.PROJECT_CURRENT_PHASE == "Phase III", 9).when(project.PROJECT_CURRENT_PHASE == "Registration & Launch", 10).when(project.PROJECT_CURRENT_PHASE == "Phase IV", 11).otherwise(F.lit(None).cast(IntegerType())))

# COMMAND ----------

if source == 'rx-pdm':
  #calculate the order of the project in the active substance project list
  project = project.withColumn('PROJECT_ORDER_FOR_ACTIVE_SUBSTANCE', F.row_number().over(Window.partitionBy('ACTIVE_SUBSTANCE_ID').orderBy(F.desc('CURRENT_PHASE_INDUSTRY_ORDER'),F.desc('EARLIEST_MILESTONE_DISPLAY_ORDER'),'EARLIEST_MILESTONE_REPORT_DATE','PROJECT_CREATION_DATE','PROJECT_CODE')))

# COMMAND ----------

if source == 'rx-pdm':
  #Add LEAD_INDICATION_FLAG
  project = project.withColumn('NA_DELIVERABLE_TYPE', F.when((project.DELIVERABLE_TYPE == "Candidate Selection") | (project.DELIVERABLE_TYPE == "Legacy") | (project.DELIVERABLE_TYPE == "Regulatory Commitment"), 'N/A').otherwise('A'))

  active_substance_count = project.select('ACTIVE_SUBSTANCE_ID','PROJECT_CODE').filter('NA_DELIVERABLE_TYPE = "A"').groupBy("ACTIVE_SUBSTANCE_ID").agg(F.count('PROJECT_CODE').alias('ACTIVE_SUBSTANCE_PROJECT_COUNT'))
  project = project.join(active_substance_count, ["ACTIVE_SUBSTANCE_ID"], 'left')

  project = project.withColumn('ACTIVE_SUBSTANCE_PROJECT_RANK', F.dense_rank().over(Window.partitionBy('ACTIVE_SUBSTANCE_ID','NA_DELIVERABLE_TYPE','PROJECT_STATUS').orderBy('PROJECT_ORDER_FOR_ACTIVE_SUBSTANCE')))

  project = project.withColumn('LEAD_INDICATION_FLAG', F.when(project.NA_DELIVERABLE_TYPE == "N/A", 'N/A').when((((project.PROJECT_STATUS_LONG_NAME == "Active") | (project.PROJECT_STATUS_LONG_NAME == "Under Review-Progressing")) & (project.ACTIVE_SUBSTANCE_PROJECT_RANK == 1)) | (project.ACTIVE_SUBSTANCE_PROJECT_COUNT == 1), 'Y').otherwise('N'))

  project = project.drop('NA_DELIVERABLE_TYPE')
  project = project.drop('ACTIVE_SUBSTANCE_PROJECT_COUNT')
  project = project.drop('ACTIVE_SUBSTANCE_PROJECT_RANK')

# COMMAND ----------

if source == 'rx-pdm':
  # checkpointing the project df to raw, for notebook optimization and debugging
  raw_path = 'dbfs:/mnt/raw/resource_utilization/'
  unique_run_id = runid + '-LoadUnifiedProject/'
  csv_temp_unified = raw_path + unique_run_id + '/' + 'unified'

  checkpoint_raw_path = 'dbfs:/mnt/raw/pdm/LoadUnifiedProject_checkpoints/'

  project.coalesce(1).write\
          .option("sep", "|")\
          .option("header", "true")\
          .option("quote",  '"')\
          .option("quoteAll", "true")\
          .option("escape", '"')\
          .option("nullValue", "null")\
          .mode('overwrite')\
        .csv(csv_temp_unified)

  # copy part-* csv file to foundation and rename
  dbutils.fs.cp(dbutils.fs.ls(csv_temp_unified)[-1][0], checkpoint_raw_path + "project_checkpoint2.txt", recurse = True)

  # remove temp folder
  dbutils.fs.rm(raw_path + unique_run_id, recurse = True)

# COMMAND ----------

if source == 'rx-pdm':
  # reading second project checkpoint from raw
  project = spark.read.format("csv")\
        .option("inferSchema", "false")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
    .load('dbfs:/mnt/raw/pdm/LoadUnifiedProject_checkpoints/project_checkpoint2.txt')

  project = project.toDF(*(col.replace('\r', '') for col in project.columns))

# COMMAND ----------

#tableName = 'project' + str(random.randint(0, 999999))
#tableName

# COMMAND ----------

# bucketing project dataframe for join optimization
# project.createOrReplaceTempView('project')
# sqlContext.table("project").write.bucketBy(500, "ACTIVE_SUBSTANCE_ID").mode('Overwrite').saveAsTable(tableName)

# COMMAND ----------

#project = spark.table(tableName)

# COMMAND ----------

if source == 'rx-pdm':
  #Add COMPOUND_MARKET_STATUS field
  compound_status = project.select('ACTIVE_SUBSTANCE_ID','PROJECT_CURRENT_PHASE','LEAD_INDICATION_FLAG')
  compound_status = compound_status.filter('EARLIEST_MILESTONE_PHASE="Phase IV" and LEAD_INDICATION_FLAG!="null"')
  compound_status = compound_status.withColumn('MARKETED_FLAG', F.lit('1'))
  compound_status = compound_status.select('ACTIVE_SUBSTANCE_ID','MARKETED_FLAG').distinct()

  if compound_status.count()>1: 
    project = project.join(compound_status, ["ACTIVE_SUBSTANCE_ID"], 'left')
    project = project.withColumn('COMPOUND_MARKET_STATUS', F.when(project.MARKETED_FLAG != "null", F.lit('Marketed')).when(project.ACTIVE_SUBSTANCE_ID != "null", F.lit('R&D')).otherwise(F.lit('None')))                                                          
    project = project.drop('MARKETED_FLAG')
  else: 
    project = project.withColumn('COMPOUND_MARKET_STATUS', F.lit('None'))

# COMMAND ----------

if source == 'rx-pdm':
  #calculate project category and project category detailed fields
  project = project.withColumn('PROJECT_CATEGORY', F.when(project.LEAD_INDICATION_FLAG == "N/A", 'Not Applicable').when((project.ACTIVE_SUBSTANCE_TYPE_DESCRIPTION == 'Chemical') & (project.COMPOUND_MARKET_STATUS == "Marketed") & (project.PROJECT_ORDER_FOR_ACTIVE_SUBSTANCE == 1), 'New Chemical Entity').when((project.ACTIVE_SUBSTANCE_TYPE_DESCRIPTION == 'Chemical') & (project.COMPOUND_MARKET_STATUS == "Marketed") & (project.PROJECT_ORDER_FOR_ACTIVE_SUBSTANCE > 1), 'Product Line Extension').when((project.ACTIVE_SUBSTANCE_TYPE_DESCRIPTION == 'Chemical') & (project.COMPOUND_MARKET_STATUS == "R&D"), 'New Chemical Entity').when(((project.ACTIVE_SUBSTANCE_TYPE_DESCRIPTION == 'Biological') | (project.ACTIVE_SUBSTANCE_TYPE_DESCRIPTION == 'Cell and Gene Therapy')) & (project.COMPOUND_MARKET_STATUS == "Marketed") & (project.PROJECT_ORDER_FOR_ACTIVE_SUBSTANCE == 1), 'New Biological Entity').when(((project.ACTIVE_SUBSTANCE_TYPE_DESCRIPTION == 'Biological') | (project.ACTIVE_SUBSTANCE_TYPE_DESCRIPTION == 'Cell and Gene Therapy')) & (project.COMPOUND_MARKET_STATUS == "Marketed") & (project.PROJECT_ORDER_FOR_ACTIVE_SUBSTANCE > 1), 'Biological Line Extension').when(((project.ACTIVE_SUBSTANCE_TYPE_DESCRIPTION == 'Biological') | (project.ACTIVE_SUBSTANCE_TYPE_DESCRIPTION == 'Cell and Gene Therapy')) & (project.COMPOUND_MARKET_STATUS == "R&D"), 'New Biological Entity').otherwise('Not Applicable'))

  project = project.withColumn('PROJECT_CATEGORY_DETAILED', F.when(project.PROJECT_CATEGORY == "Not Applicable", 'N/A').when((project.PROJECT_CATEGORY == "New Chemical Entity") & (project.LEAD_INDICATION_FLAG == "Y"), 'pNCE').when((project.PROJECT_CATEGORY == "New Chemical Entity") & (project.LEAD_INDICATION_FLAG == "N"), 'sNCE').when((project.PROJECT_CATEGORY == "New Biological Entity") & (project.LEAD_INDICATION_FLAG == "Y"), 'pNBE').when((project.PROJECT_CATEGORY == "New Biological Entity") & (project.LEAD_INDICATION_FLAG == "N"), 'sNBE').when((project.PROJECT_CATEGORY == "Product Line Extension") & ((project.LEAD_INDICATION_FLAG == "Y") | (project.LEAD_INDICATION_FLAG == "N")), 'PLE').when((project.PROJECT_CATEGORY == "Biological Line Extension") & ((project.LEAD_INDICATION_FLAG == "Y") | (project.LEAD_INDICATION_FLAG == "N")), 'BLE').otherwise('N/A'))

# COMMAND ----------

if source == 'rx-pdm':
  #calculate asset family field
  project = project.withColumn("PROJECT_ASSET_FAMILY", F.concat(F.when(project.MECHANISM_OF_ACTION_DESCRIPTION != "null", project['MECHANISM_OF_ACTION_DESCRIPTION']).otherwise(F.lit('')),
                                                                F.when(project.DISEASE_AREA != "null", F.concat(F.lit(' - '), project['DISEASE_AREA'])).otherwise(F.lit('')),
                                                                F.when(project.ROUTE_OF_ADMINISTRATION != "null", F.concat(F.lit(' - '), project['ROUTE_OF_ADMINISTRATION'])).otherwise(F.lit('')),
                                                                F.when(project.ACTIVE_SUBSTANCE_SUB_TYPE_DESCRIPTION != "null", F.concat(F.lit(' - '), project['ACTIVE_SUBSTANCE_SUB_TYPE_DESCRIPTION'])).otherwise(F.lit('')),
                                                                F.when(project.ACTIVE_SUBSTANCE_TYPE_DESCRIPTION != "null", F.concat(F.lit(' - '), project['ACTIVE_SUBSTANCE_TYPE_DESCRIPTION'])).otherwise(F.lit(''))
                                                               )
                              )

# COMMAND ----------

if source == 'rx-pdm':
  #calculate the order of the project in the asset family project list
  asset_family_order = project.select('PROJECT_CODE','ACTIVE_SUBSTANCE_ID','PROJECT_ASSET_FAMILY','CURRENT_PHASE_INDUSTRY_ORDER','EARLIEST_MILESTONE_DISPLAY_ORDER','EARLIEST_MILESTONE_REPORT_DATE','PROJECT_CREATION_DATE').filter('DELIVERABLE_TYPE not in ("Candidate Selection") and PROJECT_STATUS_LONG_NAME in ("Active","Under Review-Progressing")')
  asset_family_order = asset_family_order.withColumn('ORDER_FOR_ASSET_FAMILY', F.row_number().over(Window.partitionBy('PROJECT_ASSET_FAMILY').orderBy(F.desc('CURRENT_PHASE_INDUSTRY_ORDER'),F.desc('EARLIEST_MILESTONE_DISPLAY_ORDER'),'EARLIEST_MILESTONE_REPORT_DATE','PROJECT_CREATION_DATE','PROJECT_CODE')))

  asset_family = asset_family_order.select('ACTIVE_SUBSTANCE_ID','ORDER_FOR_ASSET_FAMILY').groupBy("ACTIVE_SUBSTANCE_ID").agg(F.min('ORDER_FOR_ASSET_FAMILY').alias('PROJECT_ORDER_FOR_ASSET_FAMILY'))
  project = project.join(asset_family, ["ACTIVE_SUBSTANCE_ID"], 'left')

# COMMAND ----------

if source == 'rx-pdm':
  #calculate work type field
  project = project.withColumn('PROJECT_WORK_TYPE', F.when((project.DELIVERABLE_TYPE != "Candidate Selection") & ((project.PROJECT_STATUS_LONG_NAME == "Active") | (project.PROJECT_STATUS_LONG_NAME == "Under Review-Progressing")) & (project.PROJECT_ORDER_FOR_ASSET_FAMILY == 1), 'Lead').when((project.DELIVERABLE_TYPE != "Candidate Selection") & ((project.PROJECT_STATUS_LONG_NAME == "Active") | (project.PROJECT_STATUS_LONG_NAME == "Under Review-Progressing")) & (project.PROJECT_ORDER_FOR_ASSET_FAMILY > 1), 'Back-up').otherwise('Unknown'))
  
  project = project.withColumn('VESTED_UNIT_LEVEL_1', F.lit(project.FUNDER_L1))
  project = project.withColumn('VESTED_UNIT_LEVEL_2', F.lit(project.FUNDER_L2))
  project = project.withColumn('VESTED_UNIT_LEVEL_3', F.lit(project.FUNDER_L3))

# COMMAND ----------

if source == 'rx-pdm':
  project = project.withColumn('SOURCE', F.lit('Rx-PDM').cast(StringType()))
  project = project.withColumn('SOURCING', F.lit(None).cast(StringType()))
  project = project.withColumn('RD_CENTER', F.lit(None).cast(StringType()))
  project = project.withColumn('RD_STRATEGIC_PILLAR', F.lit(None).cast(StringType()))
  project = project.withColumn('THIRD_PARTY', F.lit(None).cast(StringType()))
  project = project.withColumn('MARKETED_PRODUCT_GROUP', F.lit(None).cast(StringType()))
  project = project.withColumn('CATEGORY', F.lit(None).cast(StringType()))
  project = project.withColumn('COMERCIAL_PROTFOLIO_GROUP', F.lit(None).cast(StringType()))
  project = project.withColumn('PROGRAM_CODE', F.lit(None).cast(StringType()))
  project = project.withColumn('PROGRAM_NAME', F.lit(None).cast(StringType()))
  project = project.withColumn('PRIORITY', F.lit(None).cast(StringType()))

# COMMAND ----------

project = project.select('PROJECT_CODE', 'PROJECT_DESCRIPTION', 'DESCRIPTION_SHORT', 'PROJECT_STATUS_CODE', 'PROJECT_STATUS', 'PROJECT_SUB_STATUS', 'PROJECT_STATUS_LONG_NAME', 'PROJECT_CREATION_DATE', 'PROJECT_CREATION_USER_ID', 'PROJECT_MODIFICATION_DATE', 'PROJECT_MODIFICATION_USER_ID', 'PROJECT_FORM_NAME', 'PROJECT_OWNER_USER_ID', 'PROJECT_STATUS_CHANGE_DATE', 'PROJECT_STATUS_CHANGE_COMMENT', 'TEAM_ID', 'PROJECT_STATUS_TERMINATION_REASON_CODE','PROJECT_STATUS_TERMINATION_REASON','PROJECT_STATUS_TERMINATION_CATEGORY', 'MEDICAL_CONDITION_CODE', 'INDICATION','DISEASE_AREA', 'THERAPEUTIC_AREA_SHORT_NAME', 'THERAPEUTIC_AREA_LONG_NAME', 'PROJECT_CURRENT_PHASE', 'DELIVERABLE_TYPE', 'ACTIVE_SUBSTANCE_ID', 'ACTIVE_SUBSTANCE_DESCRIPTION', 'ACTIVE_SUBSTANCE_TYPE_CODE', 'ACTIVE_SUBSTANCE_SUB_TYPE_DESCRIPTION', 'ACTIVE_SUBSTANCE_TYPE_DESCRIPTION', 'CANDIDATE_SELECTION_TYPE_NAME', 'ROUTE_OF_ADMINISTRATION', 'THERAPY_TYPE', 'THERAPY_TYPE_COMMENT', 'LEAD_BU_CODE', 'DEFAULT_FUNDING_PARTY', 'FUNDER_L1', 'FUNDER_L2', 'FUNDER_L3', 'VESTED_UNIT_LEVEL_1', 'VESTED_UNIT_LEVEL_2', 'VESTED_UNIT_LEVEL_3', 'IMMUNOMODULATORY_FLAG', 'GENESYMBOL', 'START_PHASE', 'START_PHASE_DISPLAY_ORDER', 'CURRENT_PHASE_DISPLAY_ORDER', 'COMPOUND_REPORTED_NAME', 'COMPOUND_STATUS', 'EARLIEST_MILESTONE_DISPLAY_ORDER', 'EARLIEST_MILESTONE_PHASE', 'EARLIEST_MILESTONE_REPORT_DATE', 'CURRENT_PHASE_INDUSTRY_ORDER', 'PROJECT_ORDER_FOR_ACTIVE_SUBSTANCE', 'COMPOUND_MARKET_STATUS', 'FL_COMBINATION', 'LEAD_INDICATION_FLAG', 'PROJECT_CATEGORY', 'PROJECT_CATEGORY_DETAILED', 'PROJECT_ASSET_FAMILY', 'PROJECT_WORK_TYPE', 'PROGRAM_CODE', 'PROGRAM_NAME', 'SOURCING', 'RD_CENTER', 'RD_STRATEGIC_PILLAR', 'THIRD_PARTY', 'MARKETED_PRODUCT_GROUP', 'CATEGORY', 'COMERCIAL_PROTFOLIO_GROUP', 'PRIORITY','SOURCE')

# COMMAND ----------

if source == 'vx-plm':
  project = project.dropDuplicates()

# COMMAND ----------

if source == 'rx-pdm':
  unified_path = 'dbfs:/mnt/unified/project_management/project.txt'

if source == 'vx-plm':
  unified_path = 'dbfs:/mnt/unified/project_management/vx_project.txt'

# write to unified layer
raw_path = 'dbfs:/mnt/raw/resource_utilization/'
unique_run_id = runid + '-LoadUnifiedProject/'
csv_temp_unified = raw_path + unique_run_id + '/' + 'unified'

# unified_path = 'dbfs:/mnt/unified/project_management/'

project.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("quoteAll", "true")\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .mode('overwrite')\
      .csv(csv_temp_unified)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_unified)[-1][0], unified_path, recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)

# COMMAND ----------

#dbutils.fs.rm('dbfs:/user/hive/warehouse/' + tableName, recurse = True)
#sqlContext.sql('drop table ' + tableName)