# Databricks notebook source
#File Name:LoadUnifiedResourceForecast
#ADF Pipeline Name: PLW_ADL_Resource_forecast
#SQLDW Table:NA
#Description:
  #Notebook to load Planisware and Vaccines resource forecast  data from ADL curated to unified layer along with IPE data in resource management folder

# COMMAND ----------

# MAGIC %run "/library/configFile"

# COMMAND ----------

dbutils.widgets.text("runid", "")
dbutils.widgets.text("referenceobjectnumber", "")
dbutils.widgets.dropdown("baselineflag", "false", ['true', 'false'])
dbutils.widgets.dropdown("source", "plw-new", ['plw-new', 'vx-plw'])

runid = dbutils.widgets.get("runid")
source = dbutils.widgets.get("source")
baselineflag=dbutils.widgets.get("baselineflag")
referenceobjectnumber=dbutils.widgets.get("referenceobjectnumber")

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')


fteRate_curatedPath = 'dbfs:/mnt/curated/planisware/new/plw_rbs_hierarchy.txt'
clinical_unifiedPath ='dbfs:/mnt/unified/clinical/clinicalstudycountryandsite.txt'
plan_unifiedPath = 'dbfs:/mnt/unified/project_management/plan.txt'

# RIDs for splitting GMASE roles FTE by country
rid = ("RID00139", "RID00135", "RID00227", "RID00228", "RID00140", "RID00141")

if source == 'plw-new':
  if  baselineflag=='true':
    fteRate_baselinePath = 'dbfs:/mnt/unified/project_management/reference_fterate/' + referenceobjectnumber + '.txt'
    sourcefilepath='curated/planisware/new/reference_resource_forecast/'+referenceobjectnumber+'.txt'
    targetfilepath='unified/project_management/reference_resource_forecast/'+referenceobjectnumber+'.txt'
  if  baselineflag!='true': 
    sourcefilepath='curated/planisware/new/plw_resource_forecast.txt'
    targetfilepath='unified/project_management/resource_forecast.txt'

elif source != 'plw-new':
  sourcefilepath='curated/vaccines/planisware/vx_plw_planned_hour.txt'
  targetfilepath='unified/project_management/vx_resource_forecast.txt'

# COMMAND ----------

sourcefilepath

# COMMAND ----------

df = spark.read.format("csv")\
        .option("inferSchema","true")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
.load('dbfs:/mnt/'+sourcefilepath)

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

df.createOrReplaceTempView('resourceForecast')

# COMMAND ----------

if source == 'plw-new':
  
  #load fte rates from resource hierarchy
  fteRate = spark.read.format("csv")\
            .option("inferSchema","true")\
            .option("header","true")\
            .option("multiLine","true")\
            .option("delimiter","|")\
            .option("quote", '"')\
            .option("escape",'"')\
            .option("nullValue","null")\
  .load(fteRate_curatedPath) 
  fteRate=fteRate.select('id','rate', 'rbs_id')

  # load rbs hierarchy
  rbs = spark.read.format("csv")\
            .option("inferSchema","true")\
            .option("header","true")\
            .option("multiLine","true")\
            .option("delimiter","|")\
            .option("quote", '"')\
            .option("escape",'"')\
            .option("nullValue","null")\
  .load('dbfs:/mnt/unified/project_management/plw_rbs_hierarchy.txt')
  
if source == 'vx-plw':
  rbs = spark.read.format("csv")\
            .option("inferSchema","true")\
            .option("header","true")\
            .option("multiLine","true")\
            .option("delimiter","|")\
            .option("quote", '"')\
            .option("escape",'"')\
            .option("nullValue","null")\
  .load('dbfs:/mnt/unified/project_management/rbs_hierarchy.txt').filter('source = "Vx-PLW"').select('ID', 'LVL5_RBS_DESC', 'RATE')
#   rbs = rbs.toDF(*(col.replace('\r', '') for col in rbs.columns))
  
  for col_name in rbs.columns:
    rbs = rbs.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))
  
  df = df.join(rbs, ((df.RBS == rbs.ID) & (df.USER_ATTRIBUTE_PME_UA_PH_VET2 == rbs.LVL5_RBS_DESC)), 'leftouter')
#   df = df.join(rbs, ((df.RBS == rbs.ID)), 'leftouter')

# COMMAND ----------

# display(rbs.select('ID').distinct())

# COMMAND ----------

# display(df.select('rbs').distinct())

# display(df.select('RATE').distinct())

# COMMAND ----------

# if source == 'plw-new':
#   # filtering RIDs for GICCO
#   rid = '(' + ', '.join(map(str, ['"' + str(row['rbs_id']) + '"' for row in rbs[rbs['lvl5_RBS_DESC'] == role].select('rbs_id').collect()])) + ')'
#   print(str(rid))

# COMMAND ----------

if source == 'plw-new':
  #check if baseline file for fte rate already exists
  if baselineflag == 'true':
    if file_exists(fteRate_baselinePath) == True: 
      #if yes, use historical rates to calculate IPE baselines
      fteRate = spark.read.format("csv")\
            .option("inferSchema","true")\
            .option("header","true")\
            .option("multiLine","true")\
            .option("delimiter","|")\
            .option("quote", '"')\
            .option("escape",'"')\
            .option("nullValue","null")\
      .load(fteRate_baselinePath)    
    else:
      # write baseline rates to unified
      tmp_file_path='dbfs:/mnt/raw/plw/unified/LoadUnifiedResourceForecast' + referenceobjectnumber +runid
      fteRate.coalesce(1).write\
              .option("sep", "|")\
              .option("header", "true")\
              .option("quote",  '"')\
              .option("escape", '"')\
              .option("nullValue", "null")\
          .csv(tmp_file_path)
    # copy part-* csv file to curated and rename
      dbutils.fs.cp(dbutils.fs.ls(tmp_file_path)[-1][0], fteRate_baselinePath, recurse = True)
      dbutils.fs.rm(tmp_file_path, recurse = True)



  fteRate.createOrReplaceTempView('fteRate')

# COMMAND ----------

if source == 'plw-new':
  plan_file = spark.read.format("csv")\
            .option("inferSchema","false")\
            .option("header","true")\
            .option("multiLine","true")\
            .option("delimiter","|")\
            .option("quote", '"')\
            .option("escape",'"')\
            .option("nullValue","null")\
      .load(plan_unifiedPath)
  plan_file = plan_file.toDF(*(col.replace('\r', '') for col in plan_file.columns))
  plan_file=plan_file.select('PLAN_OBJECT_NUMBER','project_id','plan_type_name','plan_state')

  #empty plan file if baselines are being loaded. Only retain schema so that subsequent code doe not break
  if baselineflag=='true': plan_file=plan_file.filter('PLAN_OBJECT_NUMBER=1')
  plan_file.createOrReplaceTempView('plan')

# COMMAND ----------

if source == 'plw-new':
  clinical_file = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(clinical_unifiedPath)

  clinical_file = clinical_file.toDF(*(col.replace('\r', '') for col in clinical_file.columns))

  clinical_file.createOrReplaceTempView('clinicalcountry')

# COMMAND ----------

if source == 'plw-new':
  query = '''select rc.ETRACK__STUDY_ID as clinical_study_id,
  rc.ACTIVITY_NAME,
  rc.ACTIVITY_OBJECT_NUMBER,
  rc.ACT_PER_ONB,
  rc.END_DATE,
  rc.STD_FTES_FORECAST,
  rc.PROJECT_ID,
  rc.PLAN_OBJECT_NUMBER,
  rc.RBS,
  rc.START_DATE,
  rc.RESOURCE_TYPE,
  rc.YEAR,
  rc.MONTH,
  rc.SOURCE, 
  rc.resource_id,
  rc.REFERENCE_OBJECT_NUMBER,
  case when rc.study_id is null then rc.STD_FTES_FORECAST else rc.COUNTRY_FTES_FORECAST end as COUNTRY_FTES_FORECAST, 
  case when rc.study_country is null then 'Not-Defined' else rc.study_country end as study_country,
  rc.planned_sites,
  plan.project_id as plan_project_id,
  plan.plan_type_name,
  plan.plan_state
  from (
          select rf.*, si.study_id, si.study_country, si.planned_sites, si.total_planned_sites, rf.STD_FTES_FORECAST*(si.planned_sites/si.total_planned_sites) as COUNTRY_FTES_FORECAST
          from resourceForecast as rf
          left outer join (
              select s.study_id, s.study_country, s.planned_sites, t.total_planned_sites
              from clinicalcountry s
              inner join (
                  select cc.study_id, sum(cc.planned_sites) total_planned_sites
                  from clinicalcountry cc
                  where cc.planned_sites is not null
                  group by study_id
                  having sum(cc.planned_sites)>0
              ) t on s.study_id = t.study_id
              where s.planned_sites is not null
          ) si on ( rf.ETRACK__STUDY_ID = si.study_id) and rf.resource_id in''' + str(rid) +'''
      ) rc
  left outer join plan on rc.PLAN_OBJECT_NUMBER = plan.PLAN_OBJECT_NUMBER
  '''
 
  resource_country=sqlContext.sql(query)

# COMMAND ----------

# DBTITLE 1,Calculate Project Phase
if source == 'plw-new':
  tasks_file = 'dbfs:/mnt/unified/project_management/task.txt'
  clinicalstudy_file ='dbfs:/mnt/unified/clinical/clinicalstudy.txt'
  onecdpclinical_file='dbfs:/mnt/unified/clinical/clinical.txt'
  milestones_file = 'dbfs:/mnt/unified/project_management/project_milestones.txt'
  project_file = 'dbfs:/mnt/unified/project_management/project.txt'
  plans_file = 'dbfs:/mnt/unified/project_management/plan.txt'

  tasks = spark.read.format("csv")\
            .option("inferSchema","true")\
            .option("header","true")\
            .option("multiLine","true")\
            .option("delimiter","|")\
            .option("quote", '"')\
            .option("escape",'"')\
            .option("nullValue","null")\
            .load(tasks_file)

  studies = spark.read.format("csv")\
            .option("inferSchema","true")\
            .option("header","true")\
            .option("multiLine","true")\
            .option("delimiter","|")\
            .option("quote", '"')\
            .option("escape",'"')\
            .option("nullValue","null")\
            .load(clinicalstudy_file)

  milestones = spark.read.format("csv")\
            .option("inferSchema","true")\
            .option("header","true")\
            .option("multiLine","true")\
            .option("delimiter","|")\
            .option("quote", '"')\
            .option("escape",'"')\
            .option("nullValue","null")\
            .load(milestones_file) 

  projects = spark.read.format("csv")\
            .option("inferSchema","true")\
            .option("header","true")\
            .option("multiLine","true")\
            .option("delimiter","|")\
            .option("quote", '"')\
            .option("escape",'"')\
            .option("nullValue","null")\
            .load(project_file)
  
  plans = spark.read.format("csv")\
          .option("inferSchema", "false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
          .load(plans_file)
  
  onecdpstudies = spark.read.format("csv")\
        .option("inferSchema","true")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
        .load(onecdpclinical_file)


  #select tasks field and format baseline code
  tasks_to_join = tasks.select('ACTIVITY_OBJECT_NUMBER','PROJECT_ID','REFERENCE_OBJECT_NUMBER','SOURCE','PLAN_PHASE_NAME','CLINICAL_STUDY_ID','ACTIVITY_PLANNED_START_DATE')\
                       .withColumn('REFERENCE_OBJECT_NUMBER_AUX', F.when(tasks.REFERENCE_OBJECT_NUMBER.isNull(), 0).otherwise(tasks.REFERENCE_OBJECT_NUMBER))\
                       .withColumn('PROJECT_ID_TASK', tasks.PROJECT_ID)

  #format forecast fields and created date field
  resource_country = resource_country.withColumn('REFERENCE_OBJECT_NUMBER_AUX', F.when((resource_country.REFERENCE_OBJECT_NUMBER.isNull()) | (resource_country.REFERENCE_OBJECT_NUMBER == 'null'), 0)\
                                     .otherwise(resource_country.REFERENCE_OBJECT_NUMBER))\
                                     .withColumn('DATE',F.concat_ws('-',resource_country.YEAR,resource_country.MONTH).cast('timestamp'))\
                                     .withColumn('plan_project_id', resource_country.PROJECT_ID)

  projects = projects.selectExpr('PROJECT_CODE as PROJECT_ID','PROJECT_CURRENT_PHASE')  

  tasks_studies = tasks.join(plans, ['PLAN_OBJECT_NUMBER']) \
                       .where(((plans.PLAN_STATE=='Active') & (plans.PLAN_TYPE_NAME=='MDP')) | (plans.PLAN_STATE.isin('Active','Closed') & (plans.PLAN_TYPE_NAME=='PCMP')))\
                       .where((tasks.CLINICAL_STUDY_ID.isNotNull()) & (tasks.WBS_TYPE=='CLIN_STUDY') & (tasks.ACTIVITY_SCOPE_NAME=='Work Package'))\
                       .where((tasks.REFERENCE_OBJECT_NUMBER.isNull()) | (tasks.REFERENCE_OBJECT_NUMBER == 'null'))\
                       .select('PLAN_OBJECT_NUMBER','CLINICAL_STUDY_ID','ACTIVITY_PLANNED_START_DATE')
  
  tasks_studies = tasks_studies.orderBy('ACTIVITY_PLANNED_START_DATE').coalesce(1).dropDuplicates(subset = ['PLAN_OBJECT_NUMBER','CLINICAL_STUDY_ID']).selectExpr("PLAN_OBJECT_NUMBER","CLINICAL_STUDY_ID", "ACTIVITY_PLANNED_START_DATE as STUDY_START_DATE")
    
  onecdpstudies = onecdpstudies.selectExpr("CLINICAL_STUDY_ID", "STUDY_PHASE as study_phase_type_name")
  studies = studies.selectExpr("clinical_study_master_id as CLINICAL_STUDY_ID", "study_phase_type_name")
  studies = studies.union(onecdpstudies).dropDuplicates(['CLINICAL_STUDY_ID'])
  
  plans = plans.selectExpr("PLAN_OBJECT_NUMBER", "PROJECT_ID as PROJECT_ID_PLAN")
  
  joined_df = resource_country.join(tasks_to_join, ['ACTIVITY_OBJECT_NUMBER','REFERENCE_OBJECT_NUMBER_AUX','SOURCE'], 'left')\
                              .join(studies, ['CLINICAL_STUDY_ID'], 'left')\
                              .join(plans,['PLAN_OBJECT_NUMBER'], 'left')\
                              .join(milestones, milestones.PROJECT_ID == F.when(tasks_to_join.PROJECT_ID_TASK.isNull(),plans.PROJECT_ID_PLAN).otherwise(tasks_to_join.PROJECT_ID_TASK), 'left')\
                              .join(projects, projects.PROJECT_ID == F.when(tasks_to_join.PROJECT_ID_TASK.isNull(),plans.PROJECT_ID_PLAN).otherwise(tasks_to_join.PROJECT_ID_TASK), 'left' )\
                              .join(tasks_studies, ['PLAN_OBJECT_NUMBER','CLINICAL_STUDY_ID'], 'left')\
                              .drop(tasks.CLINICAL_STUDY_ID)\
                              .drop(milestones.PROJECT_ID)\
                              .drop(projects.PROJECT_ID)\
                              .drop(tasks_to_join.PROJECT_ID)
    

  joined_df = joined_df.withColumn('study_phase_type_name',F.when(joined_df.study_phase_type_name == 'PHASE I', 'Phase 1')\
                                                             .when(joined_df.study_phase_type_name == 'PHASE IIA', 'Phase 2a')\
                                                             .when(joined_df.study_phase_type_name == 'PHASE IIB', 'Phase 2b')\
                                                             .when((joined_df.study_phase_type_name == 'PHASE IIIA') | (joined_df.study_phase_type_name == 'PHASE IIIB'), 'Phase 3'))

  joined_df = joined_df.withColumn('STUDY_NEXT_PHASE_START', F.when(joined_df.study_phase_type_name == 'Target Identification', joined_df.C2TV)\
                                                              .when(joined_df.study_phase_type_name == 'Target Validation', joined_df.C2T)\
                                                              .when(joined_df.study_phase_type_name == 'Lead Discovery', joined_df.C2LO)\
                                                              .when(joined_df.study_phase_type_name == 'Lead Optimisation', joined_df.C2CS)\
                                                              .when(joined_df.study_phase_type_name == 'Pre-Clinical', joined_df.FDIH)\
                                                              .when(joined_df.study_phase_type_name == 'Phase 1', joined_df.FIRST_PH2_DOSE)\
                                                              .when(joined_df.study_phase_type_name == 'Phase 2a', joined_df.C2PH2B)\
                                                              .when(joined_df.study_phase_type_name == 'Phase 2b', joined_df.PH3_START)\
                                                              .when(joined_df.study_phase_type_name == 'Phase 3', joined_df.SUBMISSION)\
                                                              .when(joined_df.study_phase_type_name == 'File & Launch', joined_df.LAUNCH))

  joined_df = joined_df.withColumn('PROJECT_PHASE', F.when((joined_df.PLAN_PHASE_NAME.isNotNull()) & (joined_df.PLAN_PHASE_NAME != ''), joined_df.PLAN_PHASE_NAME)\
                                                     .when((joined_df.study_phase_type_name.isNotNull()) & (joined_df.study_phase_type_name != '') & (joined_df.STUDY_START_DATE < joined_df.STUDY_NEXT_PHASE_START),\
                                                           joined_df.study_phase_type_name)\
                                                     .when((joined_df.LAUNCH.isNotNull()) & (joined_df.DATE >= joined_df.LAUNCH), 'Commercialisation')\
                                                     .when((joined_df.SUBMISSION.isNotNull()) & (joined_df.DATE >= joined_df.SUBMISSION), 'File & Launch')\
                                                     .when((joined_df.PH3_START.isNotNull()) & (joined_df.DATE >= joined_df.PH3_START), 'Phase 3')\
                                                     .when((joined_df.C2PH2B.isNotNull()) & (joined_df.DATE >= joined_df.C2PH2B), 'Phase 2b')\
                                                     .when((joined_df.C2PH2A.isNotNull()) & (joined_df.DATE >= joined_df.C2PH2A), 'Phase 2a')\
                                                     .when((joined_df.FIRST_PH2_DOSE.isNotNull()) & (joined_df.DATE >= joined_df.FIRST_PH2_DOSE), 'Phase 2a')\
                                                     .when((joined_df.FDIH.isNotNull()) & (joined_df.DATE >= joined_df.FDIH), 'Phase 1')\
                                                     .when((joined_df.C2CS.isNotNull()) & (joined_df.DATE >= joined_df.C2CS), 'Pre-Clinical')\
                                                     .when((joined_df.C2PC.isNotNull()) & (joined_df.DATE >= joined_df.C2PC), 'Pre-Candidate')\
                                                     .when((joined_df.C2LO.isNotNull()) & (joined_df.DATE >= joined_df.C2LO), 'Lead Optimisation')\
                                                     .when((joined_df.C2T.isNotNull()) & (joined_df.DATE >= joined_df.C2T), 'Lead Discovery')\
                                                     .when((joined_df.C2TV.isNotNull()) & (joined_df.DATE >= joined_df.C2TV), 'Target Validation')\
                                                     .when((joined_df.C2TID.isNotNull()) & (joined_df.DATE >= joined_df.C2TID), 'Target Identification')\
                                                     .when((joined_df.C2TV.isNotNull()) & (joined_df.DATE < joined_df.C2TV), 'Target Identification')\
                                                     .when((joined_df.C2T.isNotNull()) & (joined_df.DATE < joined_df.C2T), 'Target Validation')\
                                                     .when((joined_df.C2LO.isNotNull()) & (joined_df.DATE < joined_df.C2LO), 'Lead Discovery')\
                                                     .when((joined_df.C2PC.isNotNull()) & (joined_df.DATE < joined_df.C2PC), 'Lead Optimisation')\
                                                     .when((joined_df.C2CS.isNotNull()) & (joined_df.DATE < joined_df.C2CS), 'Pre-Candidate')\
                                                     .when((joined_df.FDIH.isNotNull()) & (joined_df.DATE < joined_df.FDIH), 'Pre-Clinical')\
                                                     .when((joined_df.FIRST_PH2_DOSE.isNotNull()) & (joined_df.DATE < joined_df.FIRST_PH2_DOSE), 'Phase 1')\
                                                     .when((joined_df.C2PH2A.isNotNull()) & (joined_df.DATE < joined_df.C2PH2A), 'Phase 1')\
                                                     .when((joined_df.C2PH2B.isNotNull()) & (joined_df.DATE < joined_df.C2PH2B), 'Phase 2a')\
                                                     .when((joined_df.PH3_START.isNotNull()) & (joined_df.DATE < joined_df.PH3_START), 'Phase 2b')\
                                                     .when((joined_df.SUBMISSION.isNotNull()) & (joined_df.DATE < joined_df.SUBMISSION), 'Phase 3')\
                                                     .when((joined_df.LAUNCH.isNotNull()) & (joined_df.DATE < joined_df.LAUNCH), 'File & Launch')\
                                                     .otherwise(joined_df.PROJECT_CURRENT_PHASE))
  
  joined_df.createOrReplaceTempView('resourcecountry')

# COMMAND ----------

if source == 'plw-new':
  query='''SELECT rf.PROJECT_ID,
  rf.RBS,
  rf.START_DATE,
  rf.END_DATE,
  round(rf.COUNTRY_FTES_FORECAST,9) as STD_FTES_FORECAST,
  rf.ACTIVITY_OBJECT_NUMBER,
  rf.PLAN_OBJECT_NUMBER,
  rf.RESOURCE_TYPE,
  rf.YEAR,
  rf.MONTH,
  rf.SOURCE,
  round(rf.COUNTRY_FTES_FORECAST*r.rate*8*21,9) as AMOUNT_GBP,
  rf.STUDY_COUNTRY as COUNTRY,
  rf.PLANNED_SITES,
  case when rf.plan_type_name = 'MDP' and rf.plan_state in ('Active','Closed') and rfcsap.exists_csap_forecast = 1 then 'Y' end as forecasted_in_csap,
  rf.PROJECT_PHASE
  FROM resourcecountry rf
  left outer join fteRate r on (rf.resource_id=r.rbs_id)
  left outer join (SELECT distinct plan_project_id, clinical_study_id, 1 as exists_csap_forecast FROM resourcecountry where plan_type_name = 'CSAP' and plan_state in ('Active','Closed')) rfcsap
  on (rf.plan_project_id = rfcsap.plan_project_id and rf.clinical_study_id = rfcsap.clinical_study_id)'''

# COMMAND ----------

if source == 'plw-new':
  df=sqlContext.sql(query)
  df=df.withColumn('COST_TYPE',F.lit('IPE').cast(StringType()))
  if baselineflag=='true': df=df.withColumn('REFERENCE_OBJECT_NUMBER',F.lit(referenceobjectnumber).cast(LongType()))
  else: df=df.withColumn('REFERENCE_OBJECT_NUMBER',F.lit(None).cast(LongType()))

if source == 'vx-plw':
  df = df.withColumn('AMOUNT_GBP', F.lit(df.STD_FTES_FORECAST * 21 * 8 * df.RATE).cast(FloatType()))
  df = df.withColumn('COST_TYPE',F.lit('IPE').cast(StringType()))
  df = df.withColumn('REFERENCE_OBJECT_NUMBER',F.lit(None).cast(LongType()))
  df = df.dropDuplicates()

# COMMAND ----------

# write to unified
tmp_file_path = 'dbfs:/mnt/raw/plw/unified/LoadUnifiedResourceForecast' + runid
if baselineflag=='true': tmp_file_path = 'dbfs:/mnt/raw/plw/unified/LoadUnifiedResourceForecast' + referenceobjectnumber +runid
df.coalesce(1).write\
            .option("sep", "|")\
            .option("header", "true")\
            .option("quote",  '"')\
            .option("escape", '"')\
            .option("nullValue", "null")\
        .csv(tmp_file_path)
# copy part-* csv file to curated and rename
dbutils.fs.cp(dbutils.fs.ls(tmp_file_path)[-1][0], 'dbfs:/mnt/' + targetfilepath, recurse = True)

# remove temp folders
dbutils.fs.rm(tmp_file_path, recurse = True)