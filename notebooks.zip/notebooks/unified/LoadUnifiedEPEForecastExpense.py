# Databricks notebook source
#File Name: LoadUnifiedForecast
#ADF Pipeline Name: Cerps_ADL,Coast_ADL 
#SQLDW Table: NA
#Description:
  #Load EPE forecast in unified finance folder

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
import os
from glob import glob
import re

runid = dbutils.widgets.text("runid", "kldf30-vdkd3-vdkd2-9vfjd3")
runid = dbutils.widgets.get("runid")

curated_path = 'dbfs:/mnt/curated/hyperion_essbase/epe_forecast/'

# COMMAND ----------

forecast_df = None
forecast_file_exist = False

try:
  forecast_files = [x.split('/')[-2:] for x in glob('/dbfs/mnt/curated/hyperion_essbase/epe_forecast/**/Forecast-*.txt', recursive=True)]
  # exclude files with month > 12 (causing issues)
  # excluding 2019 files since the balance for the year has already been accounted for
  forecast_files = [curated_path + '/'.join(forecast_files[idx]) for idx, n in enumerate(forecast_files) if int(re.findall(r'\d+', n[1])[-1]) <= 12 and int(re.findall(r'\d+', n[0])[-1]) != 2019]

  forecast_df = spark.read.format('csv') \
        .option('header', 'true') \
        .option("inferSchema","false")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
      .load(forecast_files)

  forecast_df = forecast_df.toDF(*(col.replace('\r', '') for col in forecast_df.columns))
  for col_name in forecast_df.columns:
    forecast_df = forecast_df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ''))
    
  forecast_df = forecast_df.select(
    'GL_PERIOD',
    'COMP_CODE',
    'COST_CENTER_CODE',
    'ACCOUNT_CODE',
    'WBS_CODE',
    'BUDID_CODE',
    'DOCUMENT_NO',
    'AMOUNT_LOC',
    'AMOUNT_GBP',
    'CURRENCY_CODE',
    'FISCMONTH',
    'FISCYEAR',
    'ACTUAL_OR_ESTIMATE_CODE',
    'COST_TYPE',
    'BEGINNING_BALANCE'
  )
  
  forecast_file_exist = True
except Exception as e:
  print(e)

# COMMAND ----------

# read cost_center_hierarchy
cc_df = spark.read.format("csv")\
          .option("inferSchema", "false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load('dbfs:/mnt/curated/hyperion_drm/cost_center_hierarchy.txt')

cc_df = cc_df.toDF(*(col.upper().replace('\r', '') for col in cc_df.columns))
for col_name in cc_df.columns:
  cc_df = cc_df.withColumn(col_name, F.regexp_replace(F.col(col_name), '[\\r\\n\\s+]', ' '))

# COMMAND ----------

# identify redundant attributes to drop
matched_columns=set(forecast_df.columns).intersection(set(cc_df.columns))

# COMMAND ----------

# dropping columns except COST_CENTER_CODE
for col in matched_columns:
  if col not in ('COST_CENTER_CODE'):
    cc_df=cc_df.drop(col)

# COMMAND ----------

# joining the cost center with expense to get cost center code data with market code
forecast_cc_df=forecast_df.join(cc_df,['COST_CENTER_CODE'],'left')

# COMMAND ----------

forecast_cc_df.createOrReplaceTempView('forecast_cc_df')

# COMMAND ----------

forecast_cc_df=spark.sql('''select *,case when MARKET_CODE in ('2379','2494','7360','7337','2548','2514','2519') and 
COST_CENTER_CODE not in ('23791208', '23790213', '23790214', '23790215', '23790216', '23790217') then 'Vx' else 'Rx' end as BUSINESS_UNIT from forecast_cc_df''')

# COMMAND ----------

forecast_cc_df = forecast_cc_df.withColumn('AMOUNT_HIST_GBP', F.lit(forecast_cc_df.AMOUNT_GBP).cast(DecimalType(31,5)))

# COMMAND ----------

milestones_file = 'dbfs:/mnt/unified/project_management/project_milestones.txt'
project_file = 'dbfs:/mnt/unified/project_management/project.txt'
project_hierarchy_file = 'dbfs:/mnt/unified/finance/project_hierarchy.txt'

projects = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
          .load(project_file)

milestones = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
          .load(milestones_file) 

project_hierarchy = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
          .load(project_hierarchy_file)

project_hierarchy.createOrReplaceTempView('project_hierarchy_view')

project_hierarchy_query = '''
        SELECT  
        STUDY_CODE as BUDID_CODE_HIERARCHY,
        PROJECT_CODE
        FROM
        (
            SELECT STUDY_CODE,
                    PROJECT_CODE,
                    ROW_NUMBER() OVER (PARTITION BY STUDY_CODE ORDER BY PROJECT_CODE desc) as ROWNUM
            FROM project_hierarchy_view
            WHERE STUDY_CODE is not null
        ) MAP_PROJECT_HIERARCHY
        WHERE ROWNUM=1'''

project_hierarchy_df = sqlContext.sql(project_hierarchy_query)

forecast_cc_df = forecast_cc_df.withColumn('DATE',F.concat_ws('-',forecast_cc_df.FISCYEAR,forecast_cc_df.FISCMONTH).cast('timestamp'))

forecast_cc_df = forecast_cc_df.join(project_hierarchy_df,F.upper(forecast_cc_df.BUDID_CODE) == F.upper(project_hierarchy_df.BUDID_CODE_HIERARCHY), 'left')

projects = projects.select('PROJECT_CODE','PROJECT_CURRENT_PHASE')


joined_df = forecast_cc_df.join(milestones,forecast_cc_df.PROJECT_CODE == milestones.PROJECT_ID, 'left')\
                           .join(projects,['PROJECT_CODE'], 'left' )


joined_df = joined_df.withColumn('PROJECT_PHASE', F.when((joined_df.LAUNCH.isNotNull()) & (joined_df.DATE >= joined_df.LAUNCH), 'Commercialisation')\
                                                   .when((joined_df.SUBMISSION.isNotNull()) & (joined_df.DATE >= joined_df.SUBMISSION), 'File & Launch')\
                                                   .when((joined_df.PH3_START.isNotNull()) & (joined_df.DATE >= joined_df.PH3_START), 'Phase 3')\
                                                   .when((joined_df.C2PH2B.isNotNull()) & (joined_df.DATE >= joined_df.C2PH2B), 'Phase 2b')\
                                                   .when((joined_df.C2PH2A.isNotNull()) & (joined_df.DATE >= joined_df.C2PH2A), 'Phase 2a')\
                                                   .when((joined_df.FIRST_PH2_DOSE.isNotNull()) & (joined_df.DATE >= joined_df.FIRST_PH2_DOSE), 'Phase 2a')\
                                                   .when((joined_df.FDIH.isNotNull()) & (joined_df.DATE >= joined_df.FDIH), 'Phase 1')\
                                                   .when((joined_df.C2CS.isNotNull()) & (joined_df.DATE >= joined_df.C2CS), 'Pre-Clinical')\
                                                   .when((joined_df.C2PC.isNotNull()) & (joined_df.DATE >= joined_df.C2PC), 'Pre-Candidate')\
                                                   .when((joined_df.C2LO.isNotNull()) & (joined_df.DATE >= joined_df.C2LO), 'Lead Optimisation')\
                                                   .when((joined_df.C2T.isNotNull()) & (joined_df.DATE >= joined_df.C2T), 'Lead Discovery')\
                                                   .when((joined_df.C2TV.isNotNull()) & (joined_df.DATE >= joined_df.C2TV), 'Target Validation')\
                                                   .when((joined_df.C2TID.isNotNull()) & (joined_df.DATE >= joined_df.C2TID), 'Target Identification')\
                                                   .when((joined_df.C2TV.isNotNull()) & (joined_df.DATE < joined_df.C2TV), 'Target Identification')\
                                                   .when((joined_df.C2T.isNotNull()) & (joined_df.DATE < joined_df.C2T), 'Target Validation')\
                                                   .when((joined_df.C2LO.isNotNull()) & (joined_df.DATE < joined_df.C2LO), 'Lead Discovery')\
                                                   .when((joined_df.C2PC.isNotNull()) & (joined_df.DATE < joined_df.C2PC), 'Lead Optimisation')\
                                                   .when((joined_df.C2CS.isNotNull()) & (joined_df.DATE < joined_df.C2CS), 'Pre-Candidate')\
                                                   .when((joined_df.FDIH.isNotNull()) & (joined_df.DATE < joined_df.FDIH), 'Pre-Clinical')\
                                                   .when((joined_df.FIRST_PH2_DOSE.isNotNull()) & (joined_df.DATE < joined_df.FIRST_PH2_DOSE), 'Phase 1')\
                                                   .when((joined_df.C2PH2A.isNotNull()) & (joined_df.DATE < joined_df.C2PH2A), 'Phase 1')\
                                                   .when((joined_df.C2PH2B.isNotNull()) & (joined_df.DATE < joined_df.C2PH2B), 'Phase 2a')\
                                                   .when((joined_df.PH3_START.isNotNull()) & (joined_df.DATE < joined_df.PH3_START), 'Phase 2b')\
                                                   .when((joined_df.SUBMISSION.isNotNull()) & (joined_df.DATE < joined_df.SUBMISSION), 'Phase 3')\
                                                   .when((joined_df.LAUNCH.isNotNull()) & (joined_df.DATE < joined_df.LAUNCH), 'File & Launch')\
                                                   .otherwise(joined_df.PROJECT_CURRENT_PHASE))

joined_df = joined_df.select('COST_CENTER_CODE', 'GL_PERIOD', 'COMP_CODE', 'ACCOUNT_CODE', 'WBS_CODE', 'BUDID_CODE', 'DOCUMENT_NO', 'AMOUNT_LOC', 'AMOUNT_GBP','AMOUNT_HIST_GBP', 'CURRENCY_CODE', 'FISCMONTH', 'FISCYEAR', 'ACTUAL_OR_ESTIMATE_CODE', 'COST_TYPE', 'BEGINNING_BALANCE', 'COST_CENTER_DESCRIPTION', 'DEPARTMENT_CODE', 'DEPARTMENT_DESCRIPTION', 'SUB_DIVISION_CODE', 'SUB_DIVISION_DESCRIPTION', 'DIVISION_CODE', 'DIVISION_DESCRIPTION', 'DIRECTORATE_CODE', 'DIRECTORATE_DESCRIPTION', 'ORGANISATION_CODE', 'ORGANISATION_DESCRIPTION', 'ORGANISATION_TYPE', 'COST_CENTER_STATUS', 'COUNTRY_CODE', 'COUNTRY_DESCRIPTION', 'COST_TYPE_DESCRIPTION', 'MARKET_CODE', 'RBS_CODE', 'BUSINESS_UNIT', 'PROJECT_PHASE')

forecast_cc_df = joined_df


                     

# COMMAND ----------

# MAGIC %run  /library/ParallelClass

# COMMAND ----------

if forecast_file_exist:
  # create global temp view of dataframe to be accessible from child notebooks
  dataset_temp_view = 'ForecastUnified'
  forecast_cc_df.createOrReplaceGlobalTempView(dataset_temp_view)

  # get list of year and month
  fiscper = forecast_cc_df.select('FISCYEAR').distinct().collect()
  year = [i[0] for i in fiscper]

  query = list(map(lambda x: 'FISCYEAR = {0}'.format(x), year))
  dataset = [dataset_temp_view] * len(query)
  path = list(map(lambda x: 'dbfs:/mnt/unified/estimated_expense/Forecast_EPE_{0}.txt'.format(x), year))

  # list of notebooks based on the month and year parameter: child notebook path, timeout, parameters, retry
  notebooks = list(map(lambda x, y, z: NotebookData(path = '/library/LoadFilesADL', timeout = 300, parameters = {'args': x, 'dataset': y, 'path': z}, retry = 2), query, dataset, path))

#   calling child notebooks with number of parallel notebook runs
  res = NotebookData.parallelNotebooks(notebooks, 4)
  # blocking call to wait for completion of child notebooks run
  result = [f.result(timeout = 100000) for f in res] # This is a blocking call.
  # print(result)
  
  # drop global temp view
  spark.catalog.dropGlobalTempView(dataset_temp_view)