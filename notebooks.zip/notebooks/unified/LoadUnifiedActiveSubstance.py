# Databricks notebook source
#File Name: LoadUnifiedActiveSubstance
#ADF Pipeline Name:  PDM_ADL
#SQLDW Table: irm_stg.ACTIVE_SUBSTANCE
#Description:
  #Load PDM and Active Substance data in unified project management folder

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
import random

dbutils.widgets.text('runid', 'csdj238-dfo233d-ovrfpr3-pveuiec')

runid = dbutils.widgets.get("runid")

# COMMAND ----------

def read(path):
  read_df = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load(path)
  df = read_df.toDF(*(col.replace('\r', '') for col in read_df.columns))
  return df

# COMMAND ----------

# read Rx active substance file
actsub = read('dbfs:/mnt/curated/pdm/active_substance.txt')

# add source rx-pdm
actsub = actsub.withColumn('SOURCE', F.lit('Rx-PDM').cast(StringType()))

actsub = actsub.select('ACTIVE_SUBSTANCE_ID', 'ACTIVE_SUBSTANCE_TYPE_CODE', 'ACTIVE_SUBSTANCE_TYPE_DESCRIPTION', 'ACTIVE_FLAG', 'CAMRD_REFERENCE_ID', 'CAMRD_REFERENCE_DESCRIPTION', 'ASSET_NUMBER', 'PREFERRED_NAME',	'GENERIC_NAME_USA', 'GENERIC_NAME_ENG', 'MECHANISM_OF_ACTION_CODE', 'MECHANISM_OF_ACTION_DESCRIPTION', 'ASSET_REPORTED_NAME', 'SOURCE')

# COMMAND ----------

# #read vaccine projects and add in Rx file
# if file_exists('dbfs:/mnt/curated/vaccines/plm/vx_project.txt') == True:  
#   vx_actsub = read('dbfs:/mnt/curated/vaccines/plm/vx_project.txt')
  
#   vx_actsub = vx_actsub.select('ACTIVE_SUBSTANCE_ID', 'ASSET_NUMBER', 'PREFERRED_NAME')
  
#   # adding null references
#   vx_actsub = vx_actsub.withColumn('ACTIVE_SUBSTANCE_TYPE_CODE', F.lit(None).cast(StringType()))
#   vx_actsub = vx_actsub.withColumn('ACTIVE_SUBSTANCE_TYPE_DESCRIPTION', F.lit(None).cast(StringType()))
#   vx_actsub = vx_actsub.withColumn('ACTIVE_FLAG', F.lit(None).cast(StringType()))
#   vx_actsub = vx_actsub.withColumn('CAMRD_REFERENCE_ID', F.lit(None).cast(StringType()))
#   vx_actsub = vx_actsub.withColumn('CAMRD_REFERENCE_DESCRIPTION', F.lit(None).cast(StringType()))
#   vx_actsub = vx_actsub.withColumn('GENERIC_NAME_USA', F.lit(None).cast(StringType()))
#   vx_actsub = vx_actsub.withColumn('GENERIC_NAME_ENG', F.lit(None).cast(StringType()))
#   vx_actsub = vx_actsub.withColumn('MECHANISM_OF_ACTION_CODE', F.lit(None).cast(StringType()))
#   vx_actsub = vx_actsub.withColumn('MECHANISM_OF_ACTION_DESCRIPTION', F.lit(None).cast(StringType()))
#   vx_actsub = vx_actsub.withColumn('ASSET_REPORTED_NAME', F.lit(None).cast(StringType()))  
  
#   #add source as vx-plm
#   vx_actsub = vx_actsub.withColumn('SOURCE', F.lit('Vx-PLM').cast(StringType()))
  
#   vx_actsub = vx_actsub.select('ACTIVE_SUBSTANCE_ID', 'ACTIVE_SUBSTANCE_TYPE_CODE', 'ACTIVE_SUBSTANCE_TYPE_DESCRIPTION', 'ACTIVE_FLAG', 'CAMRD_REFERENCE_ID', 'CAMRD_REFERENCE_DESCRIPTION', 'ASSET_NUMBER', 'PREFERRED_NAME',	'GENERIC_NAME_USA', 'GENERIC_NAME_ENG', 'MECHANISM_OF_ACTION_CODE', 'MECHANISM_OF_ACTION_DESCRIPTION', 'ASSET_REPORTED_NAME', 'SOURCE')
  
#   # dropping nulls from ACTIVE_SUBSTANCE_ID and removing duplicates
#   vx_actsub = vx_actsub.dropna(subset = ['ACTIVE_SUBSTANCE_ID'])
#   vx_actsub = vx_actsub.dropDuplicates()
  
#   # merge Rx + Vx data
#   actsub = rx_actsub.union(vx_actsub)
  
# else:
#   actsub = rx_actsub

# COMMAND ----------

# write to unified layer
raw_path = 'dbfs:/mnt/raw/resource_utilization/'
unique_run_id = runid + '-LoadUnifiedActiveSubstance/'
csv_temp_unified = raw_path + unique_run_id + '/' + 'unified'

unified_path = 'dbfs:/mnt/unified/project_management/'

actsub.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("quoteAll", "true")\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .mode('overwrite')\
      .csv(csv_temp_unified)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_unified)[-1][0], unified_path + 'active_substance.txt', recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)