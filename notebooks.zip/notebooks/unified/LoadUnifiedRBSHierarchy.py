# Databricks notebook source
#File Name: LoadUnifiedRBSHierarchy
#ADF Pipeline Name:  VxPLW_ADL
#SQLDW Table: irm_Stg.rbs_hierarchy
#Description:
  #Load rbs hierarchy data from Vx and Rx planisware in unified project management folder

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
import random

dbutils.widgets.text('runid', 'csdj238-dfo233d-ovrfpr3-pveuiec')
runid = dbutils.widgets.get("runid")

# COMMAND ----------

def read(path):
  read_df = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load(path)
  df = read_df.toDF(*(col.replace('\r', '') for col in read_df.columns))
  return df

# COMMAND ----------

#read Rx RBS hierarchy file
rbs = read('dbfs:/mnt/curated/planisware/new/plw_rbs_hierarchy.txt')
#project = project.withColumn('SOURCE', F.lit('Vx-PLM').cast(StringType()))
#add source as rx-pdm


# COMMAND ----------

#read vaccine rbs hierarchy  file
if file_exists('dbfs:/mnt/curated/vaccines/planisware/vx_plw_rbs_hierarchy.txt')==True:  
  rbsvx = read('dbfs:/mnt/curated/vaccines/planisware/vx_plw_rbs_hierarchy.txt')
  #load file and add dummy attribute
  #add source as vx-plm
  rbsvx = rbsvx.withColumn('SOURCE', F.lit('Vx-PLW').cast(StringType()))
  rbsvx = rbsvx.withColumn('lvl6_order_number', F.lit(None).cast(StringType()))
  rbsvx = rbsvx.withColumn('lvl5_order_number', F.lit(None).cast(StringType()))
  rbsvx = rbsvx.withColumn('lvl4_order_number', F.lit(None).cast(StringType()))
  rbsvx = rbsvx.withColumn('lvl3_order_number', F.lit(None).cast(StringType()))
  rbsvx = rbsvx.withColumn('lvl2_order_number', F.lit(None).cast(StringType()))
  rbsvx = rbsvx.withColumn('lvl1_order_number', F.lit(None).cast(StringType()))
  rbsvx = rbsvx.withColumn('rate_unit', F.lit(None).cast(StringType()))
  rbsvx = rbsvx.withColumn('rate_type', F.lit(None).cast(StringType()))
#   rbsvx = rbsvx.withColumn('rate', F.lit(None).cast(StringType())) 
  rbsvx = rbsvx.withColumn('resource_manager',F.lit(None).cast(StringType()))
  
  rbsvx=rbsvx.select('id','rbs_id','lvl6_RBS_DESC','lvl6_order_number','inactive','rate_unit','rate_type','rate','lvl5_RBS_DESC','lvl5_order_number','lvl4_RBS_DESC',\
                       'lvl4_order_number','lvl3_RBS_DESC','lvl3_order_number','lvl2_RBS_DESC','lvl2_order_number','lvl1_RBS_DESC','lvl1_order_number','resource_manager','SOURCE')  
  rbs=rbs.union(rbsvx)

# COMMAND ----------

# write to unified layer
raw_path = 'dbfs:/mnt/raw/planisware/rbshierarchy'
unique_run_id = runid + '-LoadUnifiedRBSHierarchy/'
csv_temp_unified = raw_path + unique_run_id + '/' + 'unified'

unified_path = 'dbfs:/mnt/unified/project_management/'

rbs.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("quoteAll", "true")\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .mode('overwrite')\
      .csv(csv_temp_unified)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_unified)[-1][0], unified_path + "rbs_hierarchy.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)