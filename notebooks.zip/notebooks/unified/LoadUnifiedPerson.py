# Databricks notebook source
#File Name: LoadUnifiedPerson
#ADF Pipeline Name: HRODS_ADL
#SQLDW Table: NA
#Description:
  #Load Person data in unified person folder
  #Load HRODS Worker data from curated to unified person folder
  #Load HRODS Position data from curated to unified person folder
  #Load HRODS Worker Managed Org data from curated to unified person folder

# COMMAND ----------

dbutils.widgets.text('runid', 'cjsd0-cvd93-bgkl4-awji2')
runid = dbutils.widgets.get('runid')

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

# COMMAND ----------

# Copy person position data
dbutils.fs.cp('dbfs:/mnt/curated/hrods/hrods.view_IRM_Position.txt', 'dbfs:/mnt/unified/person/person_position.txt', recurse = True)

# Copy person managed org data as one person can manage multiple organisations
dbutils.fs.cp('dbfs:/mnt/curated/hrods/hrods.view_IRM_Worker_Managed_Org.txt', 'dbfs:/mnt/unified/person/person_managed_org.txt', recurse = True)


# COMMAND ----------

#read HRODS Worker data from curated layer
workerdf = spark.read.format("csv")\
      .option("inferSchema", "false")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/curated/hrods/hrods.view_IRM_Worker.txt')

workerdf = workerdf.toDF(*(col.replace('\r', '') for col in workerdf.columns))

# COMMAND ----------

# Updating Fields for FIRST & LAST Name using PREFERRED NAME
workerdf = workerdf.withColumn('FIRST_NAME', F.when(workerdf.GSK_PREFERRED_NAME.isNotNull(),workerdf.GSK_PREFERRED_NAME).otherwise(workerdf.FIRST_NAME))
workerdf = workerdf.withColumn('LAST_NAME', F.when(workerdf.PREFERRED_LAST_NAME.isNotNull(),workerdf.PREFERRED_LAST_NAME).otherwise(workerdf.LAST_NAME))

# COMMAND ----------

#write HRODS Worker to unified layer
raw_path = 'dbfs:/mnt/raw/hrods/'
unique_run_id = runid + '-LoadUnifiedPerson/'
csv_temp_unified = raw_path + unique_run_id + '/' + 'unified'

unified_path = 'dbfs:/mnt/unified/person/'

workerdf.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("quoteAll", "true")\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .mode('overwrite')\
      .csv(csv_temp_unified)

#copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_unified)[-1][0], unified_path + "person.txt", recurse = True)

#remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)