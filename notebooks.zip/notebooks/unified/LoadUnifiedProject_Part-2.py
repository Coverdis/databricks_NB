# Databricks notebook source
#File Name: LoadUnifiedProject
#ADF Pipeline Name:  PDM_ADL, HypDRM_ADL
#SQLDW Table: irm_stg.PROJECT
#Description:
  #Load PDM and DRM project data in unified project management folder

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
import random

dbutils.widgets.text('runid', 'csdj238-dfo233d-ovrfpr3-pveuiec')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

def read(path):
  read_df = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load(path)
  df = read_df.toDF(*(col.replace('\r', '') for col in read_df.columns))
  return df

# COMMAND ----------

# read project data from foundation layer
project = spark.read.format("csv")\
      .option("inferSchema", "false")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/pdm/pdm_project_temp/project.txt')

project = project.toDF(*(col.replace('\r', '') for col in project.columns))

# COMMAND ----------

mapping = spark.read.format("csv")\
      .option("inferSchema", "false")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter",",")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load("dbfs:/mnt/curated/dish/PDR_DEX_Milestone_PLW-NEW.csv")
mapping=mapping.select('MILESTONE_SORT_ORDER','INDUSTRY_PHASE')
mapping=mapping.withColumn('Priority',F.row_number().over(Window.partitionBy('INDUSTRY_PHASE').orderBy('MILESTONE_SORT_ORDER'))) 
mapping=mapping.filter('priority=1 and INDUSTRY_PHASE!="null"').drop('Priority')
mapping=mapping.withColumnRenamed('INDUSTRY_PHASE','PROJECT_CURRENT_PHASE')
mapping=mapping.withColumnRenamed('MILESTONE_SORT_ORDER','CURRENT_PHASE_DISPLAY_ORDER')


# COMMAND ----------

#set the START_PHASE_DISPLAY_ORDER same as current phase for comparison
df=mapping
df=df.withColumnRenamed('PROJECT_CURRENT_PHASE','START_PHASE')
df=df.withColumnRenamed('CURRENT_PHASE_DISPLAY_ORDER','START_PHASE_DISPLAY_ORDER')
project=project.drop('START_PHASE_DISPLAY_ORDER')
project=project.drop('START_PHASE_DISPLAY_ORDER')
project=project.join(df,['START_PHASE'],'left')


# COMMAND ----------

#for technology projects current phase will be same as start phase
project=project.withColumn('PROJECT_CURRENT_PHASE', F.when(project.PROJECT_FORM_NAME=='Technology',project.START_PHASE).otherwise(project.PROJECT_CURRENT_PHASE))

# COMMAND ----------

#set current phase as start phase if current phase is null
project=project.withColumn('PROJECT_CURRENT_PHASE', F.coalesce('PROJECT_CURRENT_PHASE', 'START_PHASE'))
#set current phase as start phase if start phase is later than current phase-- this should not happen, where start phase is Pre-Candidate Profiling
project = project.withColumn('PROJECT_CURRENT_PHASE', F.when((project.START_PHASE_DISPLAY_ORDER > project.CURRENT_PHASE_DISPLAY_ORDER) & (project.START_PHASE!='Pre-Candidate Profiling') , project.START_PHASE).otherwise(project.PROJECT_CURRENT_PHASE))

#set current phase as not applicable where current phase is null
project = project.na.fill("Not Applicable", 'PROJECT_CURRENT_PHASE')
#recalulate current phase display order
project=project.drop('CURRENT_PHASE_DISPLAY_ORDER')
project=project.join(mapping,['PROJECT_CURRENT_PHASE'],'left')
#project=project.withColumn('CURRENT_PHASE_DISPLAY_ORDER', F.coalesce('CURRENT_PHASE_DISPLAY_ORDER', #'MILESTONE_SORT_ORDER','START_PHASE_DISPLAY_ORDER'))
#project=project.drop('MILESTONE_SORT_ORDER')

# COMMAND ----------

#Current phase will be set to lead optimization if start phase is Pre-Candidate Profiling and current phase is Pre-Candidate Profiling)
project = project.withColumn('PROJECT_CURRENT_PHASE', F.when((project.PROJECT_CURRENT_PHASE=='Pre-Candidate Profiling') & (project.START_PHASE=='Pre-Candidate Profiling') , F.lit('Lead Optimisation')).otherwise(project.PROJECT_CURRENT_PHASE))
#display(project.filter((project.PROJECT_CURRENT_PHASE=='Pre-Candidate Profiling') & (project.START_PHASE=='Pre-Candidate Profiling')))

# COMMAND ----------

#Add current phase order. The field CURRENT_PHASE_DISPLAY_ORDER actually contains the display order of the last achieved milestone
project = project.withColumn('CURRENT_PHASE_INDUSTRY_ORDER', F.when(project.PROJECT_CURRENT_PHASE == "Not Applicable", 0).when(project.PROJECT_CURRENT_PHASE == "Target Validation", 1).when(project.PROJECT_CURRENT_PHASE == "Lead Discovery", 2).when(project.PROJECT_CURRENT_PHASE == "Lead Optimisation", 3).when(project.PROJECT_CURRENT_PHASE == "Pre-Candidate Profiling", 4).when(project.PROJECT_CURRENT_PHASE == "Pre-Clinical Evaluation", 5).when(project.PROJECT_CURRENT_PHASE == "Phase I", 6).when(project.PROJECT_CURRENT_PHASE == "Phase II", 7).when(project.PROJECT_CURRENT_PHASE == "Phase III", 9).when(project.PROJECT_CURRENT_PHASE == "Registration & Launch", 10).when(project.PROJECT_CURRENT_PHASE == "Phase IV", 11).otherwise(F.lit(None).cast(IntegerType())))

# COMMAND ----------

#calculate the order of the project in the active substance project list
project = project.withColumn('PROJECT_ORDER_FOR_ACTIVE_SUBSTANCE', F.row_number().over(Window.partitionBy('ACTIVE_SUBSTANCE_ID').orderBy(F.desc('CURRENT_PHASE_INDUSTRY_ORDER'),F.desc('EARLIEST_MILESTONE_DISPLAY_ORDER'),'EARLIEST_MILESTONE_REPORT_DATE','PROJECT_CREATION_DATE','PROJECT_CODE')))

# COMMAND ----------

#Add LEAD_INDICATION_FLAG
project = project.withColumn('NA_DELIVERABLE_TYPE', F.when((project.DELIVERABLE_TYPE == "Candidate Selection") | (project.DELIVERABLE_TYPE == "Legacy") | (project.DELIVERABLE_TYPE == "Regulatory Commitment"), 'N/A').otherwise('A'))

active_substance_count = project.select('ACTIVE_SUBSTANCE_ID','PROJECT_CODE').filter('NA_DELIVERABLE_TYPE = "A"').groupBy("ACTIVE_SUBSTANCE_ID").agg(F.count('PROJECT_CODE').alias('ACTIVE_SUBSTANCE_PROJECT_COUNT'))
project = project.join(active_substance_count, ["ACTIVE_SUBSTANCE_ID"], 'left')

project = project.withColumn('ACTIVE_SUBSTANCE_PROJECT_RANK', F.dense_rank().over(Window.partitionBy('ACTIVE_SUBSTANCE_ID','NA_DELIVERABLE_TYPE','PROJECT_STATUS').orderBy('PROJECT_ORDER_FOR_ACTIVE_SUBSTANCE')))

project = project.withColumn('LEAD_INDICATION_FLAG', F.when(project.NA_DELIVERABLE_TYPE == "N/A", 'N/A').when((((project.PROJECT_STATUS_LONG_NAME == "Active") | (project.PROJECT_STATUS_LONG_NAME == "Under Review-Progressing")) & (project.ACTIVE_SUBSTANCE_PROJECT_RANK == 1)) | (project.ACTIVE_SUBSTANCE_PROJECT_COUNT == 1), 'Y').otherwise('N'))

project = project.drop('NA_DELIVERABLE_TYPE')
project = project.drop('ACTIVE_SUBSTANCE_PROJECT_COUNT')
project = project.drop('ACTIVE_SUBSTANCE_PROJECT_RANK')

# COMMAND ----------

tableName = 'project' + str(random.randint(0, 999999))
tableName

# COMMAND ----------

# bucketing project dataframe for join optimization
project.createOrReplaceTempView('project')
sqlContext.table("project").write.bucketBy(500, "ACTIVE_SUBSTANCE_ID").mode('Overwrite').saveAsTable(tableName)

# COMMAND ----------

project = spark.table(tableName)

# COMMAND ----------

#Add COMPOUND_MARKET_STATUS field
compound_status = project.select('ACTIVE_SUBSTANCE_ID','PROJECT_CURRENT_PHASE','LEAD_INDICATION_FLAG')
compound_status = compound_status.filter('EARLIEST_MILESTONE_PHASE="Phase IV" and LEAD_INDICATION_FLAG!="null"')
compound_status = compound_status.withColumn('MARKETED_FLAG', F.lit('1'))
compound_status = compound_status.select('ACTIVE_SUBSTANCE_ID','MARKETED_FLAG').distinct()

if compound_status.count()>1: 
  project = project.join(compound_status, ["ACTIVE_SUBSTANCE_ID"], 'left')
  project = project.withColumn('COMPOUND_MARKET_STATUS', F.when(project.MARKETED_FLAG != "null", F.lit('Marketed')).when(project.ACTIVE_SUBSTANCE_ID != "null", F.lit('R&D')).otherwise(F.lit('None')))                                                          
  project = project.drop('MARKETED_FLAG')
else: 
  project = project.withColumn('COMPOUND_MARKET_STATUS', F.lit('None'))

# COMMAND ----------

#calculate project category and project category detailed fields
project = project.withColumn('PROJECT_CATEGORY', F.when(project.LEAD_INDICATION_FLAG == "N/A", 'Not Applicable').when((project.ACTIVE_SUBSTANCE_TYPE_DESCRIPTION == 'Chemical') & (project.COMPOUND_MARKET_STATUS == "Marketed") & (project.PROJECT_ORDER_FOR_ACTIVE_SUBSTANCE == 1), 'New Chemical Entity').when((project.ACTIVE_SUBSTANCE_TYPE_DESCRIPTION == 'Chemical') & (project.COMPOUND_MARKET_STATUS == "Marketed") & (project.PROJECT_ORDER_FOR_ACTIVE_SUBSTANCE > 1), 'Product Line Extension').when((project.ACTIVE_SUBSTANCE_TYPE_DESCRIPTION == 'Chemical') & (project.COMPOUND_MARKET_STATUS == "R&D"), 'New Chemical Entity').when(((project.ACTIVE_SUBSTANCE_TYPE_DESCRIPTION == 'Biological') | (project.ACTIVE_SUBSTANCE_TYPE_DESCRIPTION == 'Cell and Gene Therapy')) & (project.COMPOUND_MARKET_STATUS == "Marketed") & (project.PROJECT_ORDER_FOR_ACTIVE_SUBSTANCE == 1), 'New Biological Entity').when(((project.ACTIVE_SUBSTANCE_TYPE_DESCRIPTION == 'Biological') | (project.ACTIVE_SUBSTANCE_TYPE_DESCRIPTION == 'Cell and Gene Therapy')) & (project.COMPOUND_MARKET_STATUS == "Marketed") & (project.PROJECT_ORDER_FOR_ACTIVE_SUBSTANCE > 1), 'Biological Line Extension').when(((project.ACTIVE_SUBSTANCE_TYPE_DESCRIPTION == 'Biological') | (project.ACTIVE_SUBSTANCE_TYPE_DESCRIPTION == 'Cell and Gene Therapy')) & (project.COMPOUND_MARKET_STATUS == "R&D"), 'New Biological Entity').otherwise('Not Applicable'))

project = project.withColumn('PROJECT_CATEGORY_DETAILED', F.when(project.PROJECT_CATEGORY == "Not Applicable", 'N/A').when((project.PROJECT_CATEGORY == "New Chemical Entity") & (project.LEAD_INDICATION_FLAG == "Y"), 'pNCE').when((project.PROJECT_CATEGORY == "New Chemical Entity") & (project.LEAD_INDICATION_FLAG == "N"), 'sNCE').when((project.PROJECT_CATEGORY == "New Biological Entity") & (project.LEAD_INDICATION_FLAG == "Y"), 'pNBE').when((project.PROJECT_CATEGORY == "New Biological Entity") & (project.LEAD_INDICATION_FLAG == "N"), 'sNBE').when((project.PROJECT_CATEGORY == "Product Line Extension") & ((project.LEAD_INDICATION_FLAG == "Y") | (project.LEAD_INDICATION_FLAG == "N")), 'PLE').when((project.PROJECT_CATEGORY == "Biological Line Extension") & ((project.LEAD_INDICATION_FLAG == "Y") | (project.LEAD_INDICATION_FLAG == "N")), 'BLE').otherwise('N/A'))

# COMMAND ----------

#calculate asset family field
project = project.withColumn("PROJECT_ASSET_FAMILY", F.concat(F.when(project.MECHANISM_OF_ACTION_DESCRIPTION != "null", project['MECHANISM_OF_ACTION_DESCRIPTION']).otherwise(F.lit('')),
                                                              F.when(project.DISEASE_AREA != "null", F.concat(F.lit(' - '), project['DISEASE_AREA'])).otherwise(F.lit('')),
                                                              F.when(project.ROUTE_OF_ADMINISTRATION != "null", F.concat(F.lit(' - '), project['ROUTE_OF_ADMINISTRATION'])).otherwise(F.lit('')),
                                                              F.when(project.ACTIVE_SUBSTANCE_SUB_TYPE_DESCRIPTION != "null", F.concat(F.lit(' - '), project['ACTIVE_SUBSTANCE_SUB_TYPE_DESCRIPTION'])).otherwise(F.lit('')),
                                                              F.when(project.ACTIVE_SUBSTANCE_TYPE_DESCRIPTION != "null", F.concat(F.lit(' - '), project['ACTIVE_SUBSTANCE_TYPE_DESCRIPTION'])).otherwise(F.lit(''))
                                                             )
                            )

# COMMAND ----------

#calculate the order of the project in the asset family project list
asset_family_order = project.select('PROJECT_CODE','ACTIVE_SUBSTANCE_ID','PROJECT_ASSET_FAMILY','CURRENT_PHASE_INDUSTRY_ORDER','EARLIEST_MILESTONE_DISPLAY_ORDER','EARLIEST_MILESTONE_REPORT_DATE','PROJECT_CREATION_DATE').filter('DELIVERABLE_TYPE not in ("Candidate Selection") and PROJECT_STATUS_LONG_NAME in ("Active","Under Review-Progressing")')
asset_family_order = asset_family_order.withColumn('ORDER_FOR_ASSET_FAMILY', F.row_number().over(Window.partitionBy('PROJECT_ASSET_FAMILY').orderBy(F.desc('CURRENT_PHASE_INDUSTRY_ORDER'),F.desc('EARLIEST_MILESTONE_DISPLAY_ORDER'),'EARLIEST_MILESTONE_REPORT_DATE','PROJECT_CREATION_DATE','PROJECT_CODE')))

asset_family = asset_family_order.select('ACTIVE_SUBSTANCE_ID','ORDER_FOR_ASSET_FAMILY').groupBy("ACTIVE_SUBSTANCE_ID").agg(F.min('ORDER_FOR_ASSET_FAMILY').alias('PROJECT_ORDER_FOR_ASSET_FAMILY'))
project = project.join(asset_family, ["ACTIVE_SUBSTANCE_ID"], 'left')

# COMMAND ----------

#calculate work type field
project = project.withColumn('PROJECT_WORK_TYPE', F.when((project.DELIVERABLE_TYPE != "Candidate Selection") & ((project.PROJECT_STATUS_LONG_NAME == "Active") | (project.PROJECT_STATUS_LONG_NAME == "Under Review-Progressing")) & (project.PROJECT_ORDER_FOR_ASSET_FAMILY == 1), 'Lead').when((project.DELIVERABLE_TYPE != "Candidate Selection") & ((project.PROJECT_STATUS_LONG_NAME == "Active") | (project.PROJECT_STATUS_LONG_NAME == "Under Review-Progressing")) & (project.PROJECT_ORDER_FOR_ASSET_FAMILY > 1), 'Back-up').otherwise('Unknown'))

# COMMAND ----------

# write to unified layer
raw_path = 'dbfs:/mnt/raw/resource_utilization/'
unique_run_id = runid + '-LoadUnifiedProject/'
csv_temp_unified = raw_path + unique_run_id + '/' + 'unified'

unified_path = 'dbfs:/mnt/unified/project_management/'

project.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("quoteAll", "true")\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .mode('overwrite')\
      .csv(csv_temp_unified)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_unified)[-1][0], unified_path + "project.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)

# COMMAND ----------

dbutils.fs.rm('dbfs:/user/hive/warehouse/' + tableName, recurse = True)
sqlContext.sql('drop table ' + tableName)