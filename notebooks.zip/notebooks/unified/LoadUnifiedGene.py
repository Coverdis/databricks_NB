# Databricks notebook source
#File Name: LoadUnifiedGene
#ADF Pipeline Name: PDM_ADL
#SQLDW Table: NA
#Description:
  #Load PDM Gene data in unified Gene folder

# COMMAND ----------

# MAGIC %run /library/logs

# COMMAND ----------

dbutils.widgets.text('runid', 'vfj3s-dv83q-cdn82-cdnms')
runid = dbutils.widgets.get("runid")

# COMMAND ----------

dbutils.fs.cp('dbfs:/mnt/curated/pdm/project_gene.txt', 'dbfs:/mnt/unified/project_management/project_gene.txt', recurse = True)