# Databricks notebook source
#File Name:LoadUnifiedTimesheet
#ADF Pipeline Name: ET_ADL
#SQLDW Table:NA
#Description:
  #Notebook to load Timesheet data from ADL curated to unified layer along with IPE data in resource management folder

# COMMAND ----------

# MAGIC %run "/library/configFile"

# COMMAND ----------

dbutils.widgets.text("runid", "1sdw2-we23d-qkgn9-uhbg2-hdj22")
dbutils.widgets.text("year", "2017")
dbutils.widgets.text("month", "5")
runid = dbutils.widgets.get("runid")
year = dbutils.widgets.get("year")
month = dbutils.widgets.get("month")
print (year)
print(month)

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

curatedPath='dbfs:/mnt/curated/et/timesheet/'
unifiedPath='dbfs:/mnt/unified/resource_management/timesheet/'
file = 'timesheets-' + year + '-' + month + '.txt'

# COMMAND ----------

timesheet = spark.read.format("csv")\
        .option("inferSchema","true")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
  .load(curatedPath + year + '/' + file)

timesheet = timesheet.toDF(*(col.replace('\r', '') for col in timesheet.columns))

timesheet.createOrReplaceTempView('timesheet')

# COMMAND ----------

#load fte rates from resource hierarchy
fteRate = spark.read.format("csv")\
        .option("inferSchema","true")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
  .load('dbfs:/mnt/curated/planisware/new/plw_rbs_hierarchy.txt')
  
fteRate.createOrReplaceTempView('fteRate')

# COMMAND ----------

#load person data
person = spark.read.format("csv")\
        .option("inferSchema","true")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
  .load('dbfs:/mnt/unified/hrods/hrods.view_IRM_Worker.txt')
  
person.createOrReplaceTempView('person')

# COMMAND ----------

query="SELECT tm.*, tm.ACTUAL_FTES*fr.rate*8*21 as AMOUNT_GBP FROM timesheet TM left outer join fteRate fr on (tm.RBS_ID=fr.rbs_id)"

# COMMAND ----------

tm=sqlContext.sql(query)
tm=tm.withColumn('COST_TYPE',F.lit('IPE').cast(StringType()))

# COMMAND ----------

tm = tm.select('PROJECT_CODE',
              'PROJECT_NAME',
              'PROJECT_CATEGORY_DESC',
              'ACTIVITY_CODE',
              'ACTIVITY_NAME',
              'COST_CENTER_CODE',
              'UNIT',
              'START_DATE',
              'LVL6_RBS_DESC',
              'PROJECT_RECOMMENDED_FLAG',
              'ACTIVITY_RECOMMENDED_FLAG',
              'user_id',
              'USER_NAME',
              'FTES_COVERED',
              'STANDARD_FTES',
              'STANDARD_HOURS',
              'ACTUAL_FTES',
              'ACTUAL_HOURS',
              'ACTIVITY_RESOURCE_ID',
              'SOURCE',
              'RBS_ID',
              'AMOUNT_GBP',
              'COST_TYPE'
)

# COMMAND ----------

# write to unified
tmp_file_path = 'dbfs:/mnt/raw/timesheet/unified' +year + month + runid
tm.coalesce(1).write\
            .option("sep", "|")\
            .option("header", "true")\
            .option("quote",  '"')\
            .option("escape", '"')\
            .option("nullValue", "null")\
        .csv(tmp_file_path)
# copy part-* csv file to curated and rename
dbutils.fs.cp(dbutils.fs.ls(tmp_file_path)[-1][0], unifiedPath + year + '/' + file, recurse = True)

# remove temp folders
dbutils.fs.rm(tmp_file_path, recurse = True)