# Databricks notebook source
#File Name: LoadUnifiedResourceManagement
#ADF Pipeline Name:  
#SQLDW Table: NA
#Description:
  #Load Planisware and PDM data in unified resource management folder

# COMMAND ----------

dbutils.widgets.text('runid', 'vfj3s-dv83q-cdn82-cdnms')
dbutils.widgets.text('source', 'et')
runid = dbutils.widgets.get('runid')
source = dbutils.widgets.get('source')

# COMMAND ----------

# Load et data 
if source == 'et':
  dbutils.fs.cp('dbfs:/mnt/curated/et/activity.txt', 'dbfs:/mnt/unified/resource_management/activity.txt', recurse = True)
  dbutils.fs.cp('dbfs:/mnt/curated/et/project.txt', 'dbfs:/mnt/unified/resource_management/project.txt', recurse = True)
  dbutils.fs.cp('dbfs:/mnt/curated/et/project_activity_link.txt', 'dbfs:/mnt/unified/resource_management/project_activity_link.txt', recurse = True)
  dbutils.fs.cp('dbfs:/mnt/curated/et/person_role.txt', 'dbfs:/mnt/unified/resource_management/person_role.txt', recurse = True)
  dbutils.fs.cp('dbfs:/mnt/curated/et/et_expected_users.txt', 'dbfs:/mnt/unified/et/et_expected_users.txt', recurse = False)