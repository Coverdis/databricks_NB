# Databricks notebook source
#File Name: LoadUnifiedCompoundAsset
#ADF Pipeline Name: PDM_ADL
#SQLDW Table: NA
#Description:
  #Load PDM compound asset to unified layer

# COMMAND ----------

dbutils.widgets.text('runid', 'pweqi-dwj122-sdjk2e-scj2as')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

# Load compound asset data
dbutils.fs.cp('dbfs:/mnt/curated/pdm/compound_asset.txt', 'dbfs:/mnt/unified/research/compound_asset.txt', recurse = True)