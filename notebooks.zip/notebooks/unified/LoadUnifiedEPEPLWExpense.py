# Databricks notebook source
#File Name: LoadUnifiedEPEPLWExpense
#ADF Pipeline Name: Planisware_ADL 
#SQLDW Table: NA
#Description:
  #Load EPE forecast in unified project_management folder

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
import os
from glob import glob
import re

runid = dbutils.widgets.text("runid", "kldf30-vdkd3-vdkd2-9vfjd3")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

#target file
target_file = 'dbfs:/mnt/unified/project_management/epe_forecast.txt'
# read planisware epe forecast
plw_epe_df = spark.read.format("csv")\
          .option("inferSchema", "false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load('dbfs:/mnt/curated/planisware/new/epe_forecast.txt')

print(plw_epe_df.count())

# COMMAND ----------

tasks_file = 'dbfs:/mnt/unified/project_management/task.txt'
clinicalstudy_file ='dbfs:/mnt/unified/clinical/clinicalstudy.txt'
onecdpclinical_file='dbfs:/mnt/unified/clinical/clinical.txt'
milestones_file = 'dbfs:/mnt/unified/project_management/project_milestones.txt'
project_file = 'dbfs:/mnt/unified/project_management/project.txt'
plans_file = 'dbfs:/mnt/unified/project_management/plan.txt'

tasks = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
          .load(tasks_file)

studies = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
          .load(clinicalstudy_file)
         

milestones = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
          .load(milestones_file) 

projects = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
          .load(project_file)

plans = spark.read.format("csv")\
          .option("inferSchema", "false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
          .load(plans_file)

onecdpstudies = spark.read.format("csv")\
        .option("inferSchema","true")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
        .load(onecdpclinical_file)


#select tasks field
tasks_to_join = tasks.select('ACTIVITY_OBJECT_NUMBER','PROJECT_ID','REFERENCE_OBJECT_NUMBER','SOURCE','PLAN_PHASE_NAME','CLINICAL_STUDY_ID','ACTIVITY_PLANNED_START_DATE','WBS_TYPE','PLAN_OBJECT_NUMBER','ACTIVITY_SCOPE_NAME')\
                     .withColumn('REFERENCE_OBJECT_NUMBER_AUX', F.when(tasks.REFERENCE_OBJECT_NUMBER.isNull(), 0).otherwise(tasks.REFERENCE_OBJECT_NUMBER))\
                     .withColumn('PROJECT_ID_TASK', tasks.PROJECT_ID)

#format forecast fields for baseline and created date field
plw_epe_df = plw_epe_df.withColumn('REFERENCE_OBJECT_NUMBER_AUX', F.when((plw_epe_df.REFERENCE_OBJECT_NUMBER.isNull()) | (plw_epe_df.REFERENCE_OBJECT_NUMBER == 'null'), 0)\
                                   .otherwise(plw_epe_df.REFERENCE_OBJECT_NUMBER))\
                                   .withColumn('DATE',F.concat_ws('-',plw_epe_df.FISCYEAR,plw_epe_df.FISCMONTH).cast('timestamp'))                            
#select projects fields
projects = projects.selectExpr('PROJECT_CODE as PROJECT_ID','PROJECT_CURRENT_PHASE')

#select clinical studies from tasks to get the STUDY_START_DATE
tasks_studies = tasks.join(plans, ['PLAN_OBJECT_NUMBER'])\
                       .where(((plans.PLAN_STATE=='Active') & (plans.PLAN_TYPE_NAME=='MDP')) | (plans.PLAN_STATE.isin('Active','Closed') & (plans.PLAN_TYPE_NAME=='PCMP')))\
                       .where((tasks.CLINICAL_STUDY_ID.isNotNull()) & (tasks.WBS_TYPE=='CLIN_STUDY') & (tasks.ACTIVITY_SCOPE_NAME=='Work Package'))\
                       .where((tasks.REFERENCE_OBJECT_NUMBER.isNull()) | (tasks.REFERENCE_OBJECT_NUMBER == 'null'))\
                       .select('PLAN_OBJECT_NUMBER','CLINICAL_STUDY_ID','ACTIVITY_PLANNED_START_DATE')

tasks_studies = tasks_studies.orderBy('ACTIVITY_PLANNED_START_DATE').coalesce(1).dropDuplicates(subset = ['PLAN_OBJECT_NUMBER','CLINICAL_STUDY_ID']).selectExpr("PLAN_OBJECT_NUMBER","CLINICAL_STUDY_ID", "ACTIVITY_PLANNED_START_DATE as STUDY_START_DATE")

#select studies to get phase
onecdpstudies = onecdpstudies.selectExpr("CLINICAL_STUDY_ID", "STUDY_PHASE as study_phase_type_name")
studies = studies.selectExpr("clinical_study_master_id as CLINICAL_STUDY_ID", "study_phase_type_name")
studies = studies.union(onecdpstudies).dropDuplicates(['CLINICAL_STUDY_ID'])

plans = plans.selectExpr("PLAN_OBJECT_NUMBER", "PROJECT_ID as PROJECT_ID_PLAN")
#main join
joined_df = plw_epe_df.join(tasks_to_join, ['ACTIVITY_OBJECT_NUMBER','REFERENCE_OBJECT_NUMBER_AUX','SOURCE'], 'left')\
                            .join(studies,['CLINICAL_STUDY_ID'], 'left')\
                            .join(plans,['PLAN_OBJECT_NUMBER'], 'left')\
                            .join(milestones, milestones.PROJECT_ID == F.when(tasks_to_join.PROJECT_ID_TASK.isNull(),plans.PROJECT_ID_PLAN).otherwise(tasks_to_join.PROJECT_ID_TASK), 'left')\
                            .join(projects, projects.PROJECT_ID == F.when(tasks_to_join.PROJECT_ID_TASK.isNull(),plans.PROJECT_ID_PLAN).otherwise(tasks_to_join.PROJECT_ID_TASK), 'left' )\
                            .join(tasks_studies, ['PLAN_OBJECT_NUMBER','CLINICAL_STUDY_ID'], 'left')\
                            .drop(tasks.CLINICAL_STUDY_ID)\
                            .drop(tasks.REFERENCE_OBJECT_NUMBER)\
                            .drop(milestones.PROJECT_ID)\
                            .drop(projects.PROJECT_ID)\
                            .drop(tasks_to_join.PROJECT_ID)\
                            .drop(tasks.PLAN_OBJECT_NUMBER)\


joined_df = joined_df.withColumn('study_phase_type_name',F.when(joined_df.study_phase_type_name == 'PHASE I', 'Phase 1')\
                                                           .when(joined_df.study_phase_type_name == 'PHASE IIA', 'Phase 2a')\
                                                           .when(joined_df.study_phase_type_name == 'PHASE IIB', 'Phase 2b')\
                                                           .when((joined_df.study_phase_type_name == 'PHASE IIIA') | (joined_df.study_phase_type_name == 'PHASE IIIB'), 'Phase 3'))

joined_df = joined_df.withColumn('STUDY_NEXT_PHASE_START', F.when(joined_df.study_phase_type_name == 'Target Identification', joined_df.C2TV)\
                                                            .when(joined_df.study_phase_type_name == 'Target Validation', joined_df.C2T)\
                                                            .when(joined_df.study_phase_type_name == 'Lead Discovery', joined_df.C2LO)\
                                                            .when(joined_df.study_phase_type_name == 'Lead Optimisation', joined_df.C2CS)\
                                                            .when(joined_df.study_phase_type_name == 'Pre-Clinical', joined_df.FDIH)\
                                                            .when(joined_df.study_phase_type_name == 'Phase 1', joined_df.FIRST_PH2_DOSE)\
                                                            .when(joined_df.study_phase_type_name == 'Phase 2a', joined_df.C2PH2B)\
                                                            .when(joined_df.study_phase_type_name == 'Phase 2b', joined_df.PH3_START)\
                                                            .when(joined_df.study_phase_type_name == 'Phase 3', joined_df.SUBMISSION)\
                                                            .when(joined_df.study_phase_type_name == 'File & Launch', joined_df.LAUNCH))

joined_df = joined_df.withColumn('PROJECT_PHASE', F.when((joined_df.PLAN_PHASE_NAME.isNotNull()) & (joined_df.PLAN_PHASE_NAME != ''), joined_df.PLAN_PHASE_NAME)\
                                                   .when((joined_df.study_phase_type_name.isNotNull()) & (joined_df.study_phase_type_name != '') & (joined_df.STUDY_START_DATE < joined_df.STUDY_NEXT_PHASE_START),\
                                                         joined_df.study_phase_type_name)\
                                                   .when((joined_df.LAUNCH.isNotNull()) & (joined_df.DATE >= joined_df.LAUNCH), 'Commercialisation')\
                                                   .when((joined_df.SUBMISSION.isNotNull()) & (joined_df.DATE >= joined_df.SUBMISSION), 'File & Launch')\
                                                   .when((joined_df.PH3_START.isNotNull()) & (joined_df.DATE >= joined_df.PH3_START), 'Phase 3')\
                                                   .when((joined_df.C2PH2B.isNotNull()) & (joined_df.DATE >= joined_df.C2PH2B), 'Phase 2b')\
                                                   .when((joined_df.C2PH2A.isNotNull()) & (joined_df.DATE >= joined_df.C2PH2A), 'Phase 2a')\
                                                   .when((joined_df.FIRST_PH2_DOSE.isNotNull()) & (joined_df.DATE >= joined_df.FIRST_PH2_DOSE), 'Phase 2a')\
                                                   .when((joined_df.FDIH.isNotNull()) & (joined_df.DATE >= joined_df.FDIH), 'Phase 1')\
                                                   .when((joined_df.C2CS.isNotNull()) & (joined_df.DATE >= joined_df.C2CS), 'Pre-Clinical')\
                                                   .when((joined_df.C2PC.isNotNull()) & (joined_df.DATE >= joined_df.C2PC), 'Pre-Candidate')\
                                                   .when((joined_df.C2LO.isNotNull()) & (joined_df.DATE >= joined_df.C2LO), 'Lead Optimisation')\
                                                   .when((joined_df.C2T.isNotNull()) & (joined_df.DATE >= joined_df.C2T), 'Lead Discovery')\
                                                   .when((joined_df.C2TV.isNotNull()) & (joined_df.DATE >= joined_df.C2TV), 'Target Validation')\
                                                   .when((joined_df.C2TID.isNotNull()) & (joined_df.DATE >= joined_df.C2TID), 'Target Identification')\
                                                   .when((joined_df.C2TV.isNotNull()) & (joined_df.DATE < joined_df.C2TV), 'Target Identification')\
                                                   .when((joined_df.C2T.isNotNull()) & (joined_df.DATE < joined_df.C2T), 'Target Validation')\
                                                   .when((joined_df.C2LO.isNotNull()) & (joined_df.DATE < joined_df.C2LO), 'Lead Discovery')\
                                                   .when((joined_df.C2PC.isNotNull()) & (joined_df.DATE < joined_df.C2PC), 'Lead Optimisation')\
                                                   .when((joined_df.C2CS.isNotNull()) & (joined_df.DATE < joined_df.C2CS), 'Pre-Candidate')\
                                                   .when((joined_df.FDIH.isNotNull()) & (joined_df.DATE < joined_df.FDIH), 'Pre-Clinical')\
                                                   .when((joined_df.FIRST_PH2_DOSE.isNotNull()) & (joined_df.DATE < joined_df.FIRST_PH2_DOSE), 'Phase 1')\
                                                   .when((joined_df.C2PH2A.isNotNull()) & (joined_df.DATE < joined_df.C2PH2A), 'Phase 1')\
                                                   .when((joined_df.C2PH2B.isNotNull()) & (joined_df.DATE < joined_df.C2PH2B), 'Phase 2a')\
                                                   .when((joined_df.PH3_START.isNotNull()) & (joined_df.DATE < joined_df.PH3_START), 'Phase 2b')\
                                                   .when((joined_df.SUBMISSION.isNotNull()) & (joined_df.DATE < joined_df.SUBMISSION), 'Phase 3')\
                                                   .when((joined_df.LAUNCH.isNotNull()) & (joined_df.DATE < joined_df.LAUNCH), 'File & Launch')\
                                                   .otherwise(joined_df.PROJECT_CURRENT_PHASE))

epe_df = joined_df.select('LEDGER_CODE', 'cost_center_desc', 'CLINICAL_STUDY_ID', 'COST_BREAKDOWN_STRUCTURE', 'ACTIVITY_OBJECT_NUMBER', 'act_per_onb', 'AMOUNT_LOC', 'END_MONTH', 'GL_PERIOD', 'ACTIVITY_RESOURCE_ID', 'COST_CENTER_CODE', 'PROJECT_ID', 'plan_state', 'PLAN_OBJECT_NUMBER', 'ACCOUNT_CODE', 'PLAN_TYPE', 'scale_factor', 'PURCHASE_DOCUMENT_NUMBER', 'PURCHASE_DOCUMENT_NUMBER_COMMENTS', 'REFERENCE_OBJECT_NUMBER', 'CURRENCY_CODE', 'AMOUNT_GBP', 'ACTUAL_OR_ESTIMATE_CODE', 'COST_TYPE', 'SOURCE', 'FISCMONTH', 'FISCYEAR', 'PROJECT_PHASE')

# COMMAND ----------

raw_path = 'dbfs:/mnt/raw/planisware/'
unique_run_id = runid + '-LoadUnifiedEPEPLWExpense/'
csv_temp_curated = raw_path + unique_run_id + '/unified/'

epe_df.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], target_file, recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)