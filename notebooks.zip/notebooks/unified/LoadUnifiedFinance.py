# Databricks notebook source
#File Name: LoadUnifiedFinance
#ADF Pipeline Name:  
#SQLDW Table: NA
#Description:
  #Load Planisware and PDM data in unified finance folder

# COMMAND ----------

dbutils.widgets.text('runid', 'vfj3s-dv83q-cdn82-cdnms')
dbutils.widgets.text('source', 'drm')
runid = dbutils.widgets.get('runid')
source = dbutils.widgets.get('source')

# COMMAND ----------

# Load et data 
if source == 'drm':
  dbutils.fs.cp('dbfs:/mnt/curated/hyperion_drm/account_hierarchy.txt', 'dbfs:/mnt/unified/finance/account_hierarchy.txt', recurse = True)
  dbutils.fs.cp('dbfs:/mnt/curated/hyperion_drm/attribute_hierarchy.txt', 'dbfs:/mnt/unified/finance/attribute_hierarchy.txt', recurse = True)
#   dbutils.fs.cp('dbfs:/mnt/curated/hyperion_drm/cost_center_hierarchy.txt', 'dbfs:/mnt/unified/finance/cost_center_hierarchy.txt', recurse = True)
  dbutils.fs.cp('dbfs:/mnt/curated/hyperion_drm/project_hierarchy.txt', 'dbfs:/mnt/unified/finance/project_hierarchy.txt', recurse = True)

# COMMAND ----------

if source == 'cerps':
  dbutils.fs.cp('dbfs:/mnt/curated/cerps/vendor.txt', 'dbfs:/mnt/unified/finance/vendor.txt', recurse = True)