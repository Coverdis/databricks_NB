# Databricks notebook source
#File Name: LoadUnifiedProjectManagement
#ADF Pipeline Name: Planisware_ADL, VxPlanisware_ADL
#SQLDW Table: NA
#Description:
  #Load Planisware, vaccines, legacy and PDM data in unified project management folder

# COMMAND ----------

# MAGIC %run /library/logs

# COMMAND ----------

dbutils.widgets.text('runid', 'vfj3s-dv83q-cdn82-cdnms')
dbutils.widgets.dropdown("source", "plw-new", ['plw-new', 'plw-legacy', 'pdm', 'qba', 'pdm-migrated', 'vx-plw'])

runid = dbutils.widgets.get("runid")
source = dbutils.widgets.get("source")

logDebug('LoadUnifiedProjectManagement: source: ' + source)

# COMMAND ----------

# Load planisware new data
if source == 'plw-new':
  dbutils.fs.cp('dbfs:/mnt/curated/planisware/new/plw_plan.txt', 'dbfs:/mnt/unified/project_management/plan.txt', recurse = True)
  dbutils.fs.cp('dbfs:/mnt/curated/planisware/new/plw_wbs_type.txt', 'dbfs:/mnt/unified/project_management/wbs_type.txt', recurse = True)
#   dbutils.fs.cp('dbfs:/mnt/curated/planisware/new/plw_rbs_hierarchy.txt', 'dbfs:/mnt/unified/project_management/plw_rbs_hierarchy.txt', recurse = True)  
#   dbutils.fs.cp('dbfs:/mnt/curated/planisware/new/epe_forecast.txt', 'dbfs:/mnt/unified/project_management/epe_forecast.txt', recurse = True)  
  
  dbutils.fs.cp('dbfs:/mnt/curated/planisware/new/equations.txt', 'dbfs:/mnt/unified/project_management/equations.txt', recurse = True)
  
  logDebug('LoadUnifiedProjectManagement: plw-new files copied')

# COMMAND ----------

# Load planisware legacy data
if source == 'plw-legacy':
  dbutils.fs.cp('dbfs:/mnt/curated/planisware/legacy/plw_plan_legacy.txt', 'dbfs:/mnt/unified/project_management/plan_legacy.txt', recurse = True)
  logDebug('LoadUnifiedProjectManagement: plw-legacy files copied')

# COMMAND ----------

# Load pdm data
if source == 'pdm':
  #dbutils.fs.cp('dbfs:/mnt/curated/pdm/active_substance.txt', 'dbfs:/mnt/unified/project_management/active_substance.txt', recurse = True)
  dbutils.fs.cp('dbfs:/mnt/curated/pdm/active_substance_hierarchy.txt', 'dbfs:/mnt/unified/project_management/active_substance_hierarchy.txt', recurse = True)
  dbutils.fs.cp('dbfs:/mnt/curated/pdm/medical_condition_hierarchy.txt', 'dbfs:/mnt/unified/project_management/medical_condition_hierarchy.txt', recurse = True)
  dbutils.fs.cp('dbfs:/mnt/curated/pdm/term_reason_hierarchy.txt', 'dbfs:/mnt/unified/project_management/term_reason_hierarchy.txt', recurse = True)
  dbutils.fs.cp('dbfs:/mnt/curated/pdm/project_status_hierarchy.txt', 'dbfs:/mnt/unified/project_management/project_status_hierarchy.txt', recurse = True)
  dbutils.fs.cp('dbfs:/mnt/curated/pdm/vested_unit_hierarchy.txt', 'dbfs:/mnt/unified/project_management/vested_unit_hierarchy.txt', recurse = True)
  dbutils.fs.cp('dbfs:/mnt/curated/pdm/agreement.txt', 'dbfs:/mnt/unified/project_management/agreement.txt', recurse = True)
  dbutils.fs.cp('dbfs:/mnt/curated/pdm/industry_phase_code.txt', 'dbfs:/mnt/unified/project_management/industry_phase_code.txt', recurse = True)
  dbutils.fs.cp('dbfs:/mnt/curated/pdm/portfolio.txt', 'dbfs:/mnt/unified/project_management/portfolio.txt', recurse = True)
  dbutils.fs.cp('dbfs:/mnt/curated/pdm/portfolio_member.txt', 'dbfs:/mnt/unified/project_management/portfolio_member.txt', recurse = True)
  #dbutils.fs.cp('dbfs:/mnt/curated/pdm/project.txt', 'dbfs:/mnt/unified/project_management/project.txt', recurse = True)
  dbutils.fs.cp('dbfs:/mnt/curated/pdm/project_deliverable.txt', 'dbfs:/mnt/unified/project_management/project_deliverable.txt', recurse = True)
  dbutils.fs.cp('dbfs:/mnt/curated/pdm/project_team.txt', 'dbfs:/mnt/unified/project_management/project_team.txt', recurse = True)
#   dbutils.fs.cp('dbfs:/mnt/curated/pdm/project_team_member.txt', 'dbfs:/mnt/unified/project_management/project_team_member.txt', recurse = True)
  dbutils.fs.cp('dbfs:/mnt/curated/pdm/therapeutic_area_code.txt', 'dbfs:/mnt/unified/project_management/therapeutic_area_code.txt', recurse = True)
  logDebug('LoadUnifiedProjectManagement: pdm files copied')

# COMMAND ----------

# Load qba data
if source == 'qba':
  dbutils.fs.cp('dbfs:/mnt/curated/qba/questionaire.txt', 'dbfs:/mnt/unified/project_management/questionaire.txt', recurse = True)

# COMMAND ----------

# Load pdm-migrated data
if source == 'pdm-migrated':
  dbutils.fs.cp('dbfs:/mnt/curated/pdm/pdm_migrated_plan.txt', 'dbfs:/mnt/unified/project_management/plan_migrated.txt', recurse = True)

# COMMAND ----------

# Load vaccines planisware data
if source == 'vx-plw':
  dbutils.fs.cp('dbfs:/mnt/curated/vaccines/planisware/vx_plw_plan.txt', 'dbfs:/mnt/unified/project_management/vx_plan.txt', recurse = True)