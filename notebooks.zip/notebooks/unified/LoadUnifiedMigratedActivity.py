# Databricks notebook source
  #File Name: LoadUnifiedMigratedActivity
#ADF Pipeline Name: PDM_ADL_OneTime
#SQLDW Table: NA
#Description:
  #Load migrated Activity from PDM and DISH data to unified layer in ADL

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "pwer2-wner3-cfedj-amxq1")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

# read migrated activity data
activity = spark.read.format("csv")\
          .option("inferSchema", "false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load('dbfs:/mnt/curated/pdm/pdm_migrated_activity.txt')

activity = activity.toDF(*(col.upper().replace('\r', '') for col in activity.columns))
for col_name in activity.columns:
  activity = activity.withColumn(col_name, F.regexp_replace(F.col(col_name), '[\\r\\n\\s+]', ' '))
  
# cast date fields for sorting
activity = activity.withColumn('ACTIVITY_ACTUAL_END_DATE', activity.ACTIVITY_ACTUAL_END_DATE.cast(TimestampType()))
activity = activity.withColumn('ACTIVITY_ACTUAL_START_DATE', activity.ACTIVITY_ACTUAL_START_DATE.cast(TimestampType()))
activity = activity.withColumn('ACTIVITY_PLANNED_END_DATE', activity.ACTIVITY_PLANNED_END_DATE.cast(TimestampType()))
activity = activity.withColumn('ACTIVITY_PLANNED_START_DATE', activity.ACTIVITY_PLANNED_START_DATE.cast(TimestampType()))

# COMMAND ----------

# read DISH list data
dish = spark.read.format("csv")\
          .option("inferSchema", "false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter",",")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load('dbfs:/mnt/curated/dish/PDR_DEX_Milestone_PLW-NEW.csv')

dish = dish.toDF(*(col.upper().replace('\r', '') for col in dish.columns))
for col_name in dish.columns:
  dish = dish.withColumn(col_name, F.regexp_replace(F.col(col_name), '[\\r\\n\\s+]', ' '))
  
dish = dish.select('MILESTONE_LONG_NAME', 'MILESTONE_SHORT_NAME', 'MILESTONE_ABBREVIATION', 'MILESTONE_SORT_ORDER', 'MILESTONE_PHASE_PROGRESSION', 'MILESTONE_SYNONYM', 'MILESTONE_CALC_GROUP', 'MILESTONE_CALC_MEMBER', 'PLANISWARE_ACTIVITY_TYPE')

# COMMAND ----------

# join activity and dish tables
df = activity.join(dish, activity.WBS_TYPE == dish.PLANISWARE_ACTIVITY_TYPE, 'left')

# COMMAND ----------

#create a date which is non null based on actual and planned dates
df=df.withColumn('MilestoneDate',(F.when(df.ACTIVITY_ACTUAL_END_DATE.isNotNull(),df.ACTIVITY_ACTUAL_END_DATE) .when(df.ACTIVITY_ACTUAL_START_DATE.isNotNull(),df.ACTIVITY_ACTUAL_START_DATE).when(df.ACTIVITY_PLANNED_END_DATE.isNotNull(),df.ACTIVITY_PLANNED_END_DATE).otherwise(df.ACTIVITY_PLANNED_START_DATE)))

#create date which is non null based on planned dates
df=df.withColumn('PlannedMilestoneDate',(F.when(df.ACTIVITY_PLANNED_END_DATE.isNotNull(),df.ACTIVITY_PLANNED_END_DATE).otherwise(df.ACTIVITY_PLANNED_START_DATE)))

#create date which is non null based on actual dates
df=df.withColumn('ActualMilestoneDate',(F.when(df.ACTIVITY_ACTUAL_END_DATE.isNotNull(),df.ACTIVITY_ACTUAL_END_DATE).otherwise(df.ACTIVITY_ACTUAL_START_DATE)))

# COMMAND ----------

# create FIRST_SUBMISSION_MILESTONE
df_temp = df.filter('upper(MILESTONE_CALC_MEMBER) like "%EARLIEST SUBMISSION DATE%"')
df_temp = df_temp.withColumn(
    'FIRST_SUBMISSION_MILESTONE', F.dense_rank().over(Window.partitionBy('PLAN_OBJECT_NUMBER').orderBy(df_temp.MilestoneDate)))
df_temp = df_temp.withColumn('FIRST_SUBMISSION_MILESTONE', F.when(df_temp.FIRST_SUBMISSION_MILESTONE == 1, 'True').otherwise('False'))
df = df.join(df_temp.select('ACTIVITY_OBJECT_NUMBER', 'FIRST_SUBMISSION_MILESTONE'), ['ACTIVITY_OBJECT_NUMBER'], 'left')

# create FIRST_APPROVAL_MILESTONE
df_temp = df.filter('upper(MILESTONE_CALC_MEMBER) like "%EARLIEST APPROVAL DATE%"')
df_temp = df_temp.withColumn(
    'FIRST_APPROVAL_MILESTONE', F.dense_rank().over(Window.partitionBy('PLAN_OBJECT_NUMBER').orderBy(df_temp.MilestoneDate)))
df_temp = df_temp.withColumn('FIRST_APPROVAL_MILESTONE', F.when(df_temp.FIRST_APPROVAL_MILESTONE == 1, 'True').otherwise('False'))
df = df.join(df_temp.select('ACTIVITY_OBJECT_NUMBER', 'FIRST_APPROVAL_MILESTONE'), ['ACTIVITY_OBJECT_NUMBER'], 'left')

# create FIRST_LAUNCH_MILESTONE
df_temp = df.filter('upper(MILESTONE_CALC_MEMBER) like "%EARLIEST LAUNCH DATE%"')
df_temp = df_temp.withColumn(
    'FIRST_LAUNCH_MILESTONE', F.dense_rank().over(Window.partitionBy('PLAN_OBJECT_NUMBER').orderBy(df_temp.MilestoneDate)))
df_temp = df_temp.withColumn('FIRST_LAUNCH_MILESTONE', F.when(df_temp.FIRST_LAUNCH_MILESTONE == 1, 'True').otherwise('False'))
df = df.join(df_temp.select('ACTIVITY_OBJECT_NUMBER', 'FIRST_LAUNCH_MILESTONE'), ['ACTIVITY_OBJECT_NUMBER'], 'left')

# COMMAND ----------

df = df.drop('MilestoneDate').drop('PlannedMilestoneDate').drop('ActualMilestoneDate')

# COMMAND ----------

#calculate milestone status
#need to pull project status as well
project = spark.read.format("csv")\
          .option("inferSchema", "false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load('dbfs:/mnt/unified/project_management/project.txt')
project=project.select('PROJECT_CODE','PROJECT_STATUS')

#calculate milestone status
df=df.join(project,df.PROJECT_ID==project.PROJECT_CODE,'left').drop('PROJECT_CODE')
df=df.withColumn('MILESTONE_STATUS',F.when(df.ACTIVITY_ACTUAL_END_DATE.isNotNull(),'Achieved').when(df.ACTIVITY_ACTUAL_START_DATE.isNotNull(),'Achieved').when(df.ACTIVITY_PLANNED_END_DATE.isNull() & df.ACTIVITY_PLANNED_START_DATE.isNull(),'N/A').when(df.PROJECT_STATUS=='On Hold','On Hold').when(df.PROJECT_STATUS=='Under Review','Under Review').when(df.PROJECT_STATUS=='Termination Proposed','Termination Proposed').otherwise('Planned'))
df=df.drop('PROJECT_STATUS')

# COMMAND ----------

# write to curated
raw_path = 'dbfs:/mnt/raw/planisware/'
unique_run_id = runid + '-LoadUnifiedPLWActivityLegacy/'
csv_temp_curated = raw_path + unique_run_id + '/' + 'curated/'
unified_path = 'dbfs:/mnt/unified/project_management/'

df.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], unified_path + "task_migrated.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)