# Databricks notebook source
#File Name: LoadUnifiedPO
#ADF Pipeline Name: Cerps_ADL 
#SQLDW Table: NA
#Description:
  #Load Purchase Order data from cerps in unified finance folder

# COMMAND ----------

# MAGIC %run /library/ParallelClass

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
import os
from glob import glob
import re

runid = dbutils.widgets.text("runid", "as2swq-csd3232-cscvr2-ssxsa2")
runid = dbutils.widgets.get("runid")

curated_path = 'dbfs:/mnt/curated/cerps/po/'

# COMMAND ----------

po_df = None
try:
  po_files = [x.split('/')[-2:] for x in glob('/dbfs/mnt/curated/cerps/po/**/PO-*.txt', recursive=True)]
  # exclude files with month > 12 (causing issues)
  po_files = [curated_path + '/'.join(po_files[idx]) for idx, n in enumerate(po_files) if int(re.findall(r'\d+', n[1])[-1]) <= 12]

  po_df = spark.read.format('csv') \
        .option('header', 'true') \
        .option("inferSchema","false")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
      .load(po_files)

  po_df = po_df.toDF(*(col.replace('\r', '') for col in po_df.columns))
  for col_name in po_df.columns:
    po_df = po_df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ''))

  po_df = po_df.withColumn('GL_PERIOD', F.concat_ws('-', po_df.FISCYEAR, po_df.FISCMONTH, F.lit(1)).cast(TimestampType()))
  po_df = po_df.withColumn('ACTUAL_OR_ESTIMATE_CODE', F.lit(None).cast(StringType()))
  po_df = po_df.withColumn('SOURCE', F.lit('CERPS').cast(StringType()))
  
    
  po_df = po_df.select(
    'GL_PERIOD',
    'COMP_CODE',
    'COST_CENTER_CODE',
    'ACCOUNT_CODE',
    'WBS_CODE',
    'BUDID_CODE',
    'AMOUNT_LOC',
    'AMOUNT_GBP',
    'CURRENCY_CODE',
    'FISCMONTH',
    'FISCYEAR',
    'ACTUAL_OR_ESTIMATE_CODE',
    'COST_TYPE',
    'PURCHASE_DOCUMENT_NUMBER',
    'PO_DESCRIPTION',
	'VENDOR_ID',
	'INVOICE_VALUE',
    'INVOICE_VALUE_GBP',
	'DOCUMENT_DATE',
	'POSTING_DATE',
    'REQUESTER',
    'RANK',
    'SOURCE'    
  )
  
  
  
except Exception as e:
  print(e)

# COMMAND ----------

po_df=po_df.where("FISCYEAR is not null or FISCYEAR !=''")

# COMMAND ----------

# display()
# po_df.where("PO_DESCRIPTION is not null or PO_DESCRIPTION !=''").select('PO_DESCRIPTION').count()

# COMMAND ----------

po_df = po_df.withColumn('PO_DESCRIPTION', F.regexp_replace(F.col('PO_DESCRIPTION'),'[^a-zA-Z0-9]',' '))
  
#   df = df.PO_DESCRIPTION.str.replace('[^a-zA-Z0-9]', '')
po_df=po_df.withColumn('PO_DESCRIPTION', F.regexp_replace(po_df.PO_DESCRIPTION,'\\s+', '_'))
# df2=po_df.select("po_description")
# df2 = df2.withColumn('length_col2', F.length(df2.po_description))
# display(df2.orderBy(F.col("length_col2"),ascending=False))

# COMMAND ----------

# po_df.where("PO_DESCRIPTION is not null or PO_DESCRIPTION !=''").select('PO_DESCRIPTION').count()

# COMMAND ----------

# create global temp view of dataframe to be accessible from child notebooks
dataset_temp_view = 'POExpense'
po_df.createOrReplaceGlobalTempView(dataset_temp_view)

# get list of year and month
fiscper = po_df.select('FISCYEAR').distinct().collect()
year = [i[0] for i in fiscper]

query = list(map(lambda x: 'FISCYEAR = {0}'.format(x), year))
dataset = [dataset_temp_view] * len(query)
path = list(map(lambda x: 'dbfs:/mnt/unified/finance/po/po-{0}.txt'.format(x), year))

# list of notebooks based on the month and year parameter: child notebook path, timeout, parameters, retry
# notebooks = list(map(lambda y: NotebookData(path = '/library/LoadFilesADL', timeout = 1500, parameters = {'year': y}, retry = 2), year))
notebooks = list(map(lambda x, y, z: NotebookData(path = '/library/LoadFilesADL', timeout = 300, parameters = {'args': x, 'dataset': y, 'path': z}, retry = 2), query, dataset, path))

# calling child notebooks with number of parallel notebook runs
res = NotebookData.parallelNotebooks(notebooks, 4)
# blocking call to wait for completion of child notebooks run
result = [f.result(timeout = 10000) for f in res] # This is a blocking call.
# print(result)

# COMMAND ----------

# drop global temp view
spark.catalog.dropGlobalTempView(dataset_temp_view)