# Databricks notebook source
#File Name:LoadUnifiedResourceForecastLegacy
#ADF Pipeline Name: PLW_ADL_Legacy
#SQLDW Table:NA
#Description:
  #Notebook to load resource forecast  data from ADL curated to unified layer along with IPE data in resource management folder

# COMMAND ----------

# MAGIC %run "/library/configFile"

# COMMAND ----------

dbutils.widgets.text("runid", "1sdw2-we23d-qkgn9-uhbg2-hdj22")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

curatedPath='dbfs:/mnt/curated/planisware/legacy/plw_export_all_fte.txt'
unifiedPath='dbfs:/mnt/unified/project_management/resource_forecast_legacy.txt'

# COMMAND ----------

df = spark.read.format("csv")\
        .option("inferSchema","true")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
  .load(curatedPath)

df = df.toDF(*(col.replace('\r', '') for col in df.columns))
df.createOrReplaceTempView('resourceForecast')

# COMMAND ----------

#load fte rates from resource hierarchy
fteRate = spark.read.format("csv")\
        .option("inferSchema","true")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
  .load('dbfs:/mnt/curated/irm/fterates/*.*')
#pick latest rate for each role
fteRate = fteRate.withColumn('Rank', F.dense_rank().over(Window.partitionBy('RBS_DESC').orderBy(fteRate.YEAR.desc())))
fteRate.createOrReplaceTempView('fteRate')

# COMMAND ----------

query='SELECT rf.ACTIVITY_OBJECT_NUMBER,rf.RBS,rf.STD_FTES_FORECAST,rf.YEAR,rf.MONTH,rf.RESOURCE_TYPE,rf.ACTIVITY_VERSION_TYPE,rf.ACTIVITY_BASELINE_NAME,rf.ACTIVITY_BASELINE_TYPE,round(rf.ORIGINAL_RATE,3) as ORIGINAL_RATE,rf.SOURCE, round(rf.STD_FTES_FORECAST*r.rate/12,9) as AMOUNT_GBP    FROM resourceForecast rf left outer join fteRate r  on (rf.rbs=r.RBS_DESC) where r.Rank=1'  

# COMMAND ----------

df=sqlContext.sql(query)
df=df.withColumn('COST_TYPE',F.lit('IPE').cast(StringType()))

# COMMAND ----------

# write to curated
tmp_file_path = 'dbfs:/mnt/raw/plw/unified' + runid
df.coalesce(1).write\
            .option("sep", "|")\
            .option("header", "true")\
            .option("quote",  '"')\
            .option("escape", '"')\
            .option("nullValue", "null")\
        .csv(tmp_file_path)
# copy part-* csv file to curated and rename
dbutils.fs.cp(dbutils.fs.ls(tmp_file_path)[-1][0], unifiedPath, recurse = True)

# remove temp folders
dbutils.fs.rm(tmp_file_path, recurse = True)