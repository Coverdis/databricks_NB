# Databricks notebook source
#File Name: LoadUnifiedActivity
#ADF Pipeline Name: Planisware_ADL, VxPlanisware_ADL, Planisware_Legacy_ADL,PDM_ADL_OneTime
#SQLDW Table: NA
#Description:
  #Load PLW New Activity, vaccines, Legacy activity and migrated activity from PDM  and erdm data to unified layer in ADL

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "")
dbutils.widgets.text("baselineflag", "")
dbutils.widgets.text("referenceobjectnumber", "")
dbutils.widgets.dropdown("source", "plw-new", ['plw-new', 'plw-legacy', 'pdm-migrated', 'vx-plw'])
runid = dbutils.widgets.get("runid")
source = dbutils.widgets.get("source")
baselineflag=dbutils.widgets.get("baselineflag")
referenceobjectnumber=dbutils.widgets.get("referenceobjectnumber")

# COMMAND ----------

if source=='plw-new' and baselineflag=='true':
  source_file='planisware/new/reference_activity/'+referenceobjectnumber+'.txt'
  target_file='reference_activity/'+referenceobjectnumber+'.txt'
if source=='plw-new'and baselineflag!='true': 
  source_file='planisware/new/plw_activity.txt'
  target_file='task.txt'
if source=='plw-legacy': 
  source_file='planisware/legacy/plw_activity_legacy.txt'
  target_file='task_legacy.txt'
if source=='pdm-migrated': 
  source_file='pdm/pdm_migrated_activity.txt'
  target_file='task_migrated.txt'
if source == 'vx-plw':
  source_file = 'vaccines/planisware/vx_plw_activity.txt'
  target_file = 'vx_task.txt'
print (source_file)  

# COMMAND ----------

# read activity data
df = spark.read.format("csv")\
          .option("inferSchema", "false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load('dbfs:/mnt/curated/'+source_file)

df = df.toDF(*(col.upper().replace('\r', '') for col in df.columns))
for col_name in df.columns:
  if col_name != 'ACTIVITY_SUCCESSOR_LINE_ID' and col_name != 'ACTIVITY_PREDECESSOR_LINE_ID' and col_name != 'ACTIVITY_DESCRIPTION' and col_name != 'ACTIVITY_USER_COMMENT':
    df = df.withColumn(col_name, F.regexp_replace(F.col(col_name), '[\\r\\n\\s+]', ' '))

# cast date fields for sorting
df = df.withColumn('ACTIVITY_ACTUAL_END_DATE', df.ACTIVITY_ACTUAL_END_DATE.cast(TimestampType()))
df = df.withColumn('ACTIVITY_ACTUAL_START_DATE', df.ACTIVITY_ACTUAL_START_DATE.cast(TimestampType()))
df = df.withColumn('ACTIVITY_PLANNED_END_DATE', df.ACTIVITY_PLANNED_END_DATE.cast(TimestampType()))
df = df.withColumn('ACTIVITY_PLANNED_START_DATE', df.ACTIVITY_PLANNED_START_DATE.cast(TimestampType()))
print(df.count())

# COMMAND ----------

if source != 'vx-plw':
  # read Dex modified data created manaully 
  erdm = spark.read.format("csv")\
            .option("inferSchema", "false")\
            .option("header","true")\
            .option("multiLine","true")\
            .option("delimiter","|")\
            .option("quote", '"')\
            .option("escape",'"')\
            .option("nullValue","null")\
      .load('dbfs:/mnt/curated/erdm/project_milestone_list.txt')

  erdm = erdm.toDF(*(col.upper().replace('\r', '') for col in erdm.columns))
  for col_name in erdm.columns:
    erdm = erdm.withColumn(col_name, F.regexp_replace(F.col(col_name), '[\\r\\n\\s+]', ' '))
  if source=='plw-new':  
    erdm=erdm.drop('PLANISWARE_ACTIVITY_TYPE')
    erdm=erdm.withColumnRenamed('NEW_PLW_ACTIVITY_TYPE','PLANISWARE_ACTIVITY_TYPE')
  erdm = erdm.select('MILESTONE_LONG_NAME', 'MILESTONE_SHORT_NAME', 'MILESTONE_ABBREVIATION', 'MILESTONE_SORT_ORDER', 'MILESTONE_PHASE_PROGRESSION', 'MILESTONE_SYNONYM', 'MILESTONE_CALC_GROUP', 'MILESTONE_CALC_MEMBER', 'PLANISWARE_ACTIVITY_TYPE','INDUSTRY_PHASE')

# COMMAND ----------

if source != 'vx-plw':  
  #create a date which is non null based on actual and planned dates
  df=df.withColumn('MilestoneDate',(F.when(df.ACTIVITY_ACTUAL_END_DATE.isNotNull(),df.ACTIVITY_ACTUAL_END_DATE) .when(df.ACTIVITY_ACTUAL_START_DATE.isNotNull(),df.ACTIVITY_ACTUAL_START_DATE).when(df.ACTIVITY_PLANNED_END_DATE.isNotNull(),df.ACTIVITY_PLANNED_END_DATE).otherwise(df.ACTIVITY_PLANNED_START_DATE)))

  #create date which is non null based on planned dates
  df=df.withColumn('PlannedMilestoneDate',(F.when(df.ACTIVITY_PLANNED_END_DATE.isNotNull(),df.ACTIVITY_PLANNED_END_DATE).otherwise(df.ACTIVITY_PLANNED_START_DATE)))

  #create date which is non null based on actual dates
  df=df.withColumn('ActualMilestoneDate',(F.when(df.ACTIVITY_ACTUAL_END_DATE.isNotNull(),df.ACTIVITY_ACTUAL_END_DATE).otherwise(df.ACTIVITY_ACTUAL_START_DATE)))
  print(df.count())

# COMMAND ----------

if source != 'vx-plw':
  # join activity and erdm tables
  df = df.join(erdm, df.WBS_TYPE == erdm.PLANISWARE_ACTIVITY_TYPE, 'left')

# COMMAND ----------

if source != 'vx-plw':  
  # create FIRST_SUBMISSION_MILESTONE
  df_temp = df.filter('upper(MILESTONE_CALC_MEMBER) like "%EARLIEST SUBMISSION DATE%"')
  df_temp = df_temp.withColumn(
      'FIRST_SUBMISSION_MILESTONE', F.dense_rank().over(Window.partitionBy('PLAN_OBJECT_NUMBER').orderBy(df_temp.MilestoneDate)))
  df_temp = df_temp.withColumn('FIRST_SUBMISSION_MILESTONE', F.when(df_temp.FIRST_SUBMISSION_MILESTONE == 1, 'True').otherwise('False'))
  df = df.join(df_temp.select('ACTIVITY_OBJECT_NUMBER', 'FIRST_SUBMISSION_MILESTONE','PLAN_OBJECT_NUMBER'), ['ACTIVITY_OBJECT_NUMBER','PLAN_OBJECT_NUMBER'], 'left')
  # create FIRST_APPROVAL_MILESTONE
  df_temp = df.filter('upper(MILESTONE_CALC_MEMBER) like "%EARLIEST APPROVAL DATE%"')
  df_temp = df_temp.withColumn(
      'FIRST_APPROVAL_MILESTONE', F.dense_rank().over(Window.partitionBy('PLAN_OBJECT_NUMBER').orderBy(df_temp.MilestoneDate)))
  df_temp = df_temp.withColumn('FIRST_APPROVAL_MILESTONE', F.when(df_temp.FIRST_APPROVAL_MILESTONE == 1, 'True').otherwise('False'))
  df = df.join(df_temp.select('ACTIVITY_OBJECT_NUMBER', 'FIRST_APPROVAL_MILESTONE','PLAN_OBJECT_NUMBER'), ['ACTIVITY_OBJECT_NUMBER','PLAN_OBJECT_NUMBER'], 'left')
  print(df.count())
  # create FIRST_LAUNCH_MILESTONE
  df_temp = df.filter('upper(MILESTONE_CALC_MEMBER) like "%EARLIEST LAUNCH DATE%"')
  df_temp = df_temp.withColumn(
      'FIRST_LAUNCH_MILESTONE', F.dense_rank().over(Window.partitionBy('PLAN_OBJECT_NUMBER').orderBy(df_temp.MilestoneDate)))
  df_temp = df_temp.withColumn('FIRST_LAUNCH_MILESTONE', F.when(df_temp.FIRST_LAUNCH_MILESTONE == 1, 'True').otherwise('False'))
  df = df.join(df_temp.select('ACTIVITY_OBJECT_NUMBER', 'FIRST_LAUNCH_MILESTONE','PLAN_OBJECT_NUMBER'), ['ACTIVITY_OBJECT_NUMBER','PLAN_OBJECT_NUMBER'], 'left')

# COMMAND ----------

if source != 'vx-plw':
  #calculate milestone status
  #need to pull project status as well
  if file_exists('dbfs:/mnt/unified/project_management/project.txt')==True:
    project = spark.read.format("csv")\
              .option("inferSchema", "false")\
              .option("header","true")\
              .option("multiLine","true")\
              .option("delimiter","|")\
              .option("quote", '"')\
              .option("escape",'"')\
              .option("nullValue","null")\
        .load('dbfs:/mnt/unified/project_management/project.txt')
    project=project.select('PROJECT_CODE','PROJECT_STATUS')

    #calculate milestone status
    df=df.join(project,df.PROJECT_ID==project.PROJECT_CODE,'left').drop('PROJECT_CODE')
    df=df.withColumn('MILESTONE_STATUS',F.when(df.ACTIVITY_ACTUAL_END_DATE.isNotNull(),'Achieved').when(df.ACTIVITY_ACTUAL_START_DATE.isNotNull(),'Achieved').when(df.ACTIVITY_PLANNED_END_DATE.isNull() & df.ACTIVITY_PLANNED_START_DATE.isNull(),'N/A').when(df.PROJECT_STATUS=='On Hold','On Hold').when(df.PROJECT_STATUS=='Under Review','Under Review').when(df.PROJECT_STATUS=='Termination Proposed','Termination Proposed').otherwise('Planned'))
    df=df.drop('PROJECT_STATUS')
    print(df.count())

  else:
    df = df.withColumn('MILESTONE_STATUS', F.lit(None).cast(StringType()))

# COMMAND ----------

if source != 'vx-plw':
  plans_file = 'dbfs:/mnt/unified/project_management/plan.txt'
  #calculate activity priority project milestone
  if file_exists(plans_file)==True:
    plans_df = spark.read.format("csv")\
              .option("inferSchema", "false")\
              .option("header","true")\
              .option("multiLine","true")\
              .option("delimiter","|")\
              .option("quote", '"')\
              .option("escape",'"')\
              .option("nullValue","null")\
        .load(plans_file)
    
    tasks_df = df.withColumn('REFERENCE_OBJECT_NUMBER', F.when(df.REFERENCE_OBJECT_NUMBER.isNull(), 0).otherwise(df.REFERENCE_OBJECT_NUMBER))
    plans_df = plans_df.withColumn('REFERENCE_OBJECT_NUMBER', F.when(plans_df.REFERENCE_OBJECT_NUMBER.isNull(), 0).otherwise(plans_df.REFERENCE_OBJECT_NUMBER))
    
    tasks_df.createOrReplaceTempView('tasks')
    plans_df.createOrReplaceTempView('plans')

    #calculate activity priority project milestone flag
    active_prj_milestones_query = '''
    select ACTIVITY_OBJECT_NUMBER,
           WBS_TYPE,
           ROW_NUMBER() OVER(PARTITION BY tasks.PROJECT_ID, tasks.WBS_TYPE ORDER BY plans.PLAN_TYPE_NAME ASC) AS MDP_PRIORITY,
           ROW_NUMBER() OVER(PARTITION BY tasks.PROJECT_ID, tasks.WBS_TYPE ORDER BY plans.PLAN_TYPE_NAME DESC) AS PCMP_PRIORITY
    FROM tasks
    INNER JOIN plans on tasks.PLAN_OBJECT_NUMBER = plans.PLAN_OBJECT_NUMBER and tasks.SOURCE = plans.SOURCE and tasks.REFERENCE_OBJECT_NUMBER = plans.REFERENCE_OBJECT_NUMBER
    WHERE tasks.SOURCE = 'PLW-NEW'
      AND tasks.REFERENCE_OBJECT_NUMBER = 0
      AND tasks.ACTIVITY_SCOPE_NAME = 'Project Milestone'
      AND plans.PLAN_TYPE_NAME in ('PCMP','MDP')
      AND plans.PLAN_STATE in ('Active','Closed')'''

    active_prj_milestones = sqlContext.sql(active_prj_milestones_query)
    active_prj_milestones = active_prj_milestones\
    .withColumn('ACTIVITY_PRIORITY_PROJECT_MILESTONE_FLAG', F.when(((active_prj_milestones.WBS_TYPE.isin('C2TID','C2TV','C2T','C2LO','C2PC','C2CS') & (active_prj_milestones.PCMP_PRIORITY == 1)) | \
                                                             (active_prj_milestones.WBS_TYPE.isin(['C2FTIH']) & (active_prj_milestones.MDP_PRIORITY == 1)) | \
                                                             ~active_prj_milestones.WBS_TYPE.isin('C2TID','C2TV','C2T','C2LO','C2PC','C2CS','C2FTIH')), 'Y'))
    
    active_prj_milestones = active_prj_milestones.drop(active_prj_milestones.MDP_PRIORITY).drop(active_prj_milestones.PCMP_PRIORITY).drop(active_prj_milestones.WBS_TYPE)
    
    df = df.join(active_prj_milestones,['ACTIVITY_OBJECT_NUMBER'],'left')

    #calculate activity scenario project milestone flag    
    scenario_prj_milestones_query = '''
    select tasks.ACTIVITY_OBJECT_NUMBER,
           tasks.WBS_TYPE,
           ROW_NUMBER() OVER(PARTITION BY plans.PROJECT_ID, plans.SCENARIO_CODE, plans.SOURCE, tasks.WBS_TYPE ORDER BY plans.PLAN_TYPE_NAME ASC) AS MDP_PRIORITY,
           ROW_NUMBER() OVER(PARTITION BY plans.PROJECT_ID, plans.SCENARIO_CODE, plans.SOURCE, tasks.WBS_TYPE ORDER BY plans.PLAN_TYPE_NAME DESC) AS PCMP_PRIORITY
    FROM tasks
    INNER JOIN plans on tasks.PLAN_OBJECT_NUMBER = plans.PLAN_OBJECT_NUMBER and tasks.SOURCE = plans.SOURCE and tasks.REFERENCE_OBJECT_NUMBER = plans.REFERENCE_OBJECT_NUMBER
    WHERE tasks.SOURCE = 'PLW-NEW'
      AND tasks.REFERENCE_OBJECT_NUMBER = 0
      AND tasks.ACTIVITY_SCOPE_NAME = 'Project Milestone'
      AND plans.PLAN_TYPE_NAME in ('PCMP','MDP')
      AND plans.PLAN_STATE = 'Version'
      AND plans.SCENARIO_CODE IS NOT NULL'''
    
    scenario_prj_milestones = sqlContext.sql(scenario_prj_milestones_query)
    scenario_prj_milestones = scenario_prj_milestones\
    .withColumn('SCENARIO_PRIORITY_PROJECT_MILESTONE_FLAG', F.when(((scenario_prj_milestones.WBS_TYPE.isin('C2TID','C2TV','C2T','C2LO','C2PC','C2CS') & (scenario_prj_milestones.PCMP_PRIORITY == 1)) | \
                                                             (scenario_prj_milestones.WBS_TYPE.isin(['C2FTIH']) & (scenario_prj_milestones.MDP_PRIORITY == 1)) | \
                                                             ~scenario_prj_milestones.WBS_TYPE.isin('C2TID','C2TV','C2T','C2LO','C2PC','C2CS','C2FTIH')), 'Y'))
    
    scenario_prj_milestones = scenario_prj_milestones.drop(scenario_prj_milestones.MDP_PRIORITY).drop(scenario_prj_milestones.PCMP_PRIORITY).drop(scenario_prj_milestones.WBS_TYPE)
    df = df.join(scenario_prj_milestones,['ACTIVITY_OBJECT_NUMBER'],'left')
    
  else:
    df = df.withColumn('ACTIVITY_PRIORITY_PROJECT_MILESTONE_FLAG', F.lit(None).cast(StringType()))
    df = df.withColumn('SCENARIO_PRIORITY_PROJECT_MILESTONE_FLAG', F.lit(None).cast(StringType()))

# COMMAND ----------

# adding null references of the fields created/calculated in this notebook for vx df
if source == 'vx-plw':
#   df = df.withColumn('MILESTONE_STATUS', F.lit(None).cast(StringType()))
  df = df.withColumn('FIRST_LAUNCH_MILESTONE', F.lit(None).cast(StringType()))
  df = df.withColumn('FIRST_APPROVAL_MILESTONE', F.lit(None).cast(StringType()))
  df = df.withColumn('FIRST_SUBMISSION_MILESTONE', F.lit(None).cast(StringType()))
  df = df.withColumn('MILESTONE_LONG_NAME', F.lit(None).cast(StringType()))
  df = df.withColumn('MILESTONE_SHORT_NAME', F.lit(None).cast(StringType()))
  df = df.withColumn('MILESTONE_ABBREVIATION', F.lit(None).cast(StringType()))
#   df = df.withColumn('MILESTONE_SORT_ORDER', F.lit(None).cast(StringType()))
  df = df.withColumn('MILESTONE_PHASE_PROGRESSION', F.lit(None).cast(StringType()))
  df = df.withColumn('MILESTONE_SYNONYM', F.lit(None).cast(StringType()))
  df = df.withColumn('MILESTONE_CALC_GROUP', F.lit(None).cast(StringType()))
  df = df.withColumn('MILESTONE_CALC_MEMBER', F.lit(None).cast(StringType()))
  df = df.withColumn('PLANISWARE_ACTIVITY_TYPE', F.lit(None).cast(StringType()))
  df = df.withColumn('INDUSTRY_PHASE', F.lit(None).cast(StringType()))
  df = df.withColumn('ACTIVITY_PRIORITY_PROJECT_MILESTONE_FLAG', F.lit(None).cast(StringType()))
  df = df.withColumn('SCENARIO_PRIORITY_PROJECT_MILESTONE_FLAG', F.lit(None).cast(StringType()))
  
  df = df.withColumn('MILESTONE_STATUS', F.when(df.ACTIVITY_ACTUAL_END_DATE.isNull(), 'Planned').otherwise('Achieved'))
  w = Window.partitionBy(df.PLAN_OBJECT_NUMBER).orderBy(df.ACTIVITY_PLANNED_START_DATE)
  df = df.withColumn("MILESTONE_SORT_ORDER", F.row_number().over(w))

# COMMAND ----------

# write to unified
raw_path = 'dbfs:/mnt/raw/planisware/'
unique_run_id = runid + source + '-LoadUnifiedActivity/'
if baselineflag=='true': unique_run_id=runid + source + referenceobjectnumber + '-LoadUnifiedActivity/'
csv_temp_curated = raw_path + unique_run_id + '/' + 'unified/'
unified_path = 'dbfs:/mnt/unified/project_management/'


df.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], unified_path + target_file, recurse = True)


# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)