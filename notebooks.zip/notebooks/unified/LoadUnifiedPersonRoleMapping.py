# Databricks notebook source
#File Name: LoadUnifiedPersonRoleMapping
#ADF Pipeline Name: ET_ADL
#SQLDW Table:NA
#Description:
  #Notebook to load person role mapping data from ADL curated to unified layer

# COMMAND ----------

import pytz
from datetime import datetime, timedelta

# COMMAND ----------

# MAGIC %run "/library/configFile"

# COMMAND ----------

dbutils.widgets.text("runid", "1sdw2-we23d-qkgn9-uhbg2-hdj22")
runid = dbutils.widgets.get("runid")
dbutils.widgets.text("filename", "")
staging_filename = dbutils.widgets.get("filename")

year = datetime.now(pytz.timezone("UTC")).strftime('%Y')
month = datetime.now(pytz.timezone("UTC")).strftime('%m')

if staging_filename:
  year=staging_filename[21:][:4]
  month=staging_filename[26:][:2]

print(year)
print(month)

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

curatedPath='dbfs:/mnt/curated/et/user_role/'
unifiedPath='dbfs:/mnt/unified/resource_management/person_role_mapping/'
filename = 'person_role_mapping-' + year + '-' + month + '.txt'

# COMMAND ----------

# Functiond defined to find the latest file in the Target folder from a given ADL folder
def latest_file_target(file_folder):
  if len(dbutils.fs.ls(file_folder))>0:
    recent_files_year=max([int(x.path.split('/')[-1][-11:-7]) for x in dbutils.fs.ls(file_folder)])
    recent_files_month=max([int(x.path.split('/')[-1][-6:-4].replace('_','')) for x in dbutils.fs.ls(file_folder) if int(x.path.split('/')[-1][-11:-7])==recent_files_year])
    if recent_files_month<10: recent_files_month='0'+str(recent_files_month)
    source=file_folder+'et_user_role_mapping_'+str(recent_files_year)+'_'+str(recent_files_month)+'.txt'
    return source

# COMMAND ----------

role_file = curatedPath+'et_user_role_mapping_'+year+'_'+month+'.txt'
target_file = unifiedPath + filename

# Copy user role mapping mmonthly file to the unified layer
if file_exists(role_file):
  dbutils.fs.cp(role_file, target_file, recurse = True)
else:
  #Copy latest file the first day of the month
  if not file_exists(target_file):
    latest_file=latest_file_target(curatedPath)
    if latest_file and file_exists(latest_file):
      # copy latest file and rename
      dbutils.fs.cp(latest_file, target_file, recurse = True)