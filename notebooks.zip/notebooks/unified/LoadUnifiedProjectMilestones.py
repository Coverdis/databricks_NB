# Databricks notebook source
#File Name: LoadUnifiedProjectMilestones
#ADF Pipeline Name: Planisware_ADL
#SQLDW Table: NA
#Description:
  #Load PLW New milestones to unified layer in ADL. NOTE: Run this notebook after LoadUnifiedActivity

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from pyspark.sql import functions as F
from pyspark.sql.types import *

dbutils.widgets.text("runid", "")
dbutils.widgets.dropdown("baselineflag", "false", ['true', 'false'])

runid = dbutils.widgets.get("runid")
baselineflag=dbutils.widgets.get("baselineflag")

# COMMAND ----------

tasks_file = 'dbfs:/mnt/unified/project_management/task.txt'
plans_file = 'dbfs:/mnt/unified/project_management/plan.txt'
target_file = 'dbfs:/mnt/unified/project_management/project_milestones.txt'

# COMMAND ----------

tasks_df = spark.read.format("csv")\
          .option("inferSchema", "false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(tasks_file)

plans_df = spark.read.format("csv")\
          .option("inferSchema", "false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(plans_file)

tasks_df = tasks_df.withColumn('REFERENCE_OBJECT_NUMBER', F.when(tasks_df.REFERENCE_OBJECT_NUMBER.isNull(), 0).otherwise(tasks_df.REFERENCE_OBJECT_NUMBER))
plans_df = plans_df.withColumn('REFERENCE_OBJECT_NUMBER', F.when(plans_df.REFERENCE_OBJECT_NUMBER.isNull(), 0).otherwise(plans_df.REFERENCE_OBJECT_NUMBER))

tasks_df.createOrReplaceTempView('tasks')
plans_df.createOrReplaceTempView('plans')

# COMMAND ----------

milestone_tasks = tasks_df.select('ACTIVITY_OBJECT_NUMBER', 'ACTIVITY_NAME', 'PLAN_OBJECT_NUMBER', 'WBS_TYPE', 'ACTIVITY_SCOPE_NAME', 'FIRST_LAUNCH_MILESTONE', 'FIRST_SUBMISSION_MILESTONE', 'ACTIVITY_PLANNED_START_DATE', 'ACTIVITY_PLANNED_END_DATE') \
  .where(tasks_df.ACTIVITY_SCOPE_NAME=='Project Milestone') \
  .where(tasks_df.ACTIVITY_PRIORITY_PROJECT_MILESTONE_FLAG=='Y')

plans_to_join = plans_df.select('PLAN_OBJECT_NUMBER', 'PLAN_STATE', 'PLAN_TYPE_NAME', 'PROJECT_ID')

df = milestone_tasks.join(plans_to_join, ['PLAN_OBJECT_NUMBER']) \
    .where(((plans_to_join.PLAN_STATE=='Active') & (plans_to_join.PLAN_TYPE_NAME=='MDP')) | (plans_to_join.PLAN_STATE.isin('Active','Closed') & (plans_to_join.PLAN_TYPE_NAME=='PCMP')))

# calculate PROJECT_MILESTONE_TYPE column
df = df.withColumn('PROJECT_MILESTONE_TYPE', F.when(df.FIRST_LAUNCH_MILESTONE=="True", "LAUNCH").when(df.FIRST_SUBMISSION_MILESTONE=="True", "SUBMISSION").when(df.WBS_TYPE.isin(["C2TID", "C2TV", "C2T", "C2LO", "C2PC", "C2CS", "FDIH", "C2PH2A", "C2PH2B", "FIRST_PH2_DOSE", "PH3_START"]), df.WBS_TYPE))

df = df.where(df.PROJECT_MILESTONE_TYPE.isNotNull())
df = df.withColumn('TASK_PLANNED_DATE',F.when(df.ACTIVITY_PLANNED_END_DATE.isNotNull(),df.ACTIVITY_PLANNED_END_DATE).otherwise(df.ACTIVITY_PLANNED_START_DATE))
df = df.withColumn('TASK_PLANNED_DATE',F.date_trunc('day',df.TASK_PLANNED_DATE))

df = df.select('PROJECT_ID', 'PROJECT_MILESTONE_TYPE', 'TASK_PLANNED_DATE') \
  .groupby('PROJECT_ID') \
  .pivot('PROJECT_MILESTONE_TYPE') \
  .agg(F.first('TASK_PLANNED_DATE'))

if not 'LAUNCH' in df.columns: df = df.withColumn('LAUNCH', F.lit(None).cast(StringType()))
if not 'SUBMISSION' in df.columns: df = df.withColumn('SUBMISSION', F.lit(None).cast(StringType()))
if not 'PH3_START' in df.columns: df = df.withColumn('PH3_START', F.lit(None).cast(StringType()))
if not 'C2PH2B' in df.columns: df = df.withColumn('C2PH2B', F.lit(None).cast(StringType()))
if not 'C2PH2A' in df.columns: df = df.withColumn('C2PH2A', F.lit(None).cast(StringType()))
if not 'FIRST_PH2_DOSE' in df.columns: df = df.withColumn('FIRST_PH2_DOSE', F.lit(None).cast(StringType()))
if not 'FDIH' in df.columns: df = df.withColumn('FDIH', F.lit(None).cast(StringType()))
if not 'C2CS' in df.columns: df = df.withColumn('C2CS', F.lit(None).cast(StringType()))
if not 'C2PC' in df.columns: df = df.withColumn('C2PC', F.lit(None).cast(StringType()))
if not 'C2LO' in df.columns: df = df.withColumn('C2LO', F.lit(None).cast(StringType()))
if not 'C2T' in df.columns: df = df.withColumn('C2T', F.lit(None).cast(StringType()))
if not 'C2TV' in df.columns: df = df.withColumn('C2TV', F.lit(None).cast(StringType()))
if not 'C2TID' in df.columns: df = df.withColumn('C2TID', F.lit(None).cast(StringType()))

# COMMAND ----------

raw_path = 'dbfs:/mnt/raw/planisware/'
unique_run_id = runid + '-LoadUnifiedProjectMilestones/'
csv_temp_curated = raw_path + unique_run_id + '/unified/'

df.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", None)\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], target_file, recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)