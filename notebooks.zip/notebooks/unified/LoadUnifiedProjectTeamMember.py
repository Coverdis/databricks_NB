# Databricks notebook source
#File Name: LoadUnifiedProjectTeamMember
#ADF Pipeline Name:  PDM_ADL
#SQLDW Table: 
#Description:
  #Load project team meber data in unified project management folder

# COMMAND ----------

from pyspark.sql import functions as F
# from pyspark.sql.types import *

dbutils.widgets.text('runid', 'sdye23-dsfr33-vsdf322-fwdge22')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

# read Project Team Member data from curated layer

project_team_member_df = spark.read.format("csv")\
      .option("inferSchema","true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/curated/pdm/project_team_member.txt')

project_team_member_df = project_team_member_df.toDF(*(col.replace('\r', '') for col in project_team_member_df.columns))


project_team_member_df = project_team_member_df.select(
  'TEAM_MEMBER_ID', 
  'TEAM_ID', 
  'PERSON_MUD_ID', 
  'ROLE_CODE', 
  'ROLE_DESCRIPTION',
  'SORT_ORDER',
  'IN_DISTRIBUTION_LIST'
)

for col_name in project_team_member_df.columns:
  project_team_member_df = project_team_member_df.withColumn(col_name, F.regexp_replace(col_name, '[\\r\\n]', ' '))

# COMMAND ----------

# write to unified layer
raw_path = 'dbfs:/mnt/raw/resource_utilization'
unique_run_id = runid + '-LoadUnifiedProjectTeamMember/'
csv_temp_unified = raw_path + unique_run_id + '/' + 'unified'

unified_path = 'dbfs:/mnt/unified/project_management/'

project_team_member_df.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("quoteAll", "true")\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .mode('overwrite')\
      .csv(csv_temp_unified)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_unified)[-1][0], unified_path + "project_team_member.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)