# Databricks notebook source
# Data lake gen 2 account access settings (mount foundation, raw, log, curated)
clientID = dbutils.secrets.get(scope = "azurekeyvault-databricks", key = "cfg-irm-client-id")
clientSecret = dbutils.secrets.get(scope = "azurekeyvault-databricks", key = "pw-irm-client-pwd")
datalake_account_name = dbutils.secrets.get(scope = "azurekeyvault-databricks", key = "cfg-irm-datalake-account-name")

configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": clientID,
           "fs.azure.account.oauth2.client.secret": clientSecret,
           "fs.azure.account.oauth2.client.endpoint": "https://login.microsoftonline.com/63982aff-fb6c-4c22-973b-70e4acfb63e6/oauth2/token"}

# COMMAND ----------

import datetime
daynumber = str(datetime.datetime.today().weekday() + 1)

# COMMAND ----------

# remount using test containers
mounts = [str(i) for i in dbutils.fs.ls('/mnt/')]
folders = [mounts[idx].lower().split(',')[1].split('=')[1].replace("/", "").replace("'", "") for idx, rows in enumerate(mounts)] 

def remount(mountName):
  if mountName in folders:
    print('/mnt/'+mountName+' already mounted')
  else:
    print('mounting /mnt/'+mountName+' in Data Lake container '+mountName)
    dbutils.fs.mount(
	  source = 'abfss://'+ mountName +'@' + datalake_account_name + '.dfs.core.windows.net',
	  mount_point= "/mnt/" + mountName,
	  extra_configs = configs)

remount('foundation')
remount('foundation-backup-'+daynumber)

# COMMAND ----------

dbutils.fs.rm('dbfs:/mnt/foundation-backup-' + daynumber, True)

# COMMAND ----------

dbutils.fs.cp('dbfs:/mnt/foundation', 'dbfs:/mnt/foundation-backup-' + daynumber, True)