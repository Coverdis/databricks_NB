-- Databricks notebook source
select distinct(Org_Description) org from cc order by org

-- COMMAND ----------

select COUNTRY_CODE ccode, COUNTRY_DESC cdesc from cc group by COUNTRY_CODE, COUNTRY_DESC order by cdesc