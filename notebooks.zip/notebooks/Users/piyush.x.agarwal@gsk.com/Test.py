# Databricks notebook source
#//SQL Data Warehouse access settings

jdbcHostname = "gsk-us6-rd-irm-sqlsrv-devtest.database.windows.net"
jdbcPort = '1433'
jdbcDatabase = "rd-irm-sqldb"
jdbcUsername = "irm_devtest@gsk-us6-rd-irm-sqlsrv-devtest"
jdbcPassword = "Project1!"
# jdbcUrl = "jdbc:sqlserver://{0}:{1};database={2};user={3};password={4}".format(jdbcHostname, jdbcPort, jdbcDatabase, jdbcUsername, jdbcPassword)

jdbcUrl = "jdbc:sqlserver://{0}:{1};database={2};encrypt=true;trustServerCertificate=true;hostNameInCertificate=*.database.windows.net;loginTimeout=30;user={3};password={4}".format(jdbcHostname, jdbcPort, jdbcDatabase, jdbcUsername, jdbcPassword)

# COMMAND ----------

print (jdbcUrl)

# COMMAND ----------


df = spark.read \
  .format("jdbc") \
  .option("url", jdbcUrl) \
  .option("query", "delete from  project_plan") \
  .load()


# COMMAND ----------

display (df)

# COMMAND ----------

# Load data from a SQL DW query.
df = spark.read \
  .format("com.databricks.spark.sqldw") \
  .option("url", "jdbc:sqlserver://<the-rest-of-the-connection-string>") \
  .option("tempDir", "wasbs://<your-container-name>@<your-storage-account-name>.blob.core.windows.net/<your-directory-name>") \
  .option("forwardSparkAzureStorageCredentials", "true") \
  .option("query", "select x, count(*) as cnt from my_table_in_dw group by x") \
  .load()