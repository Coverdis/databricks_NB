# Databricks notebook source
# Databricks notebook source
#//SQL Data DB access settings
clientSecret = dbutils.secrets.get(scope = "azurekeyvault-databricks", key = "pw-irm-client-pwd")
dbDatabase = "testdw"#"rd-finance-sqldb"
dbServer = "gsk-us6-rd-irm-sqlsrv-devtest"
dbUser =  "irm_devtest"
dbPass = "Project1!"
dbJdbcPort =  "1433"
dbJdbcExtraOptions = "encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30"
sqlDbUrl = "jdbc:sqlserver://" + dbServer + ".database.windows.net:" + dbJdbcPort + ";database=" + dbDatabase + ";"+dbJdbcExtraOptions + ";user=" + dbUser+";password=" + dbPass
sqlDbUrlSmall = "jdbc:sqlserver://" + dbServer + ".database.windows.net:" + dbJdbcPort + ";database=rd-finance-sqldb;user=" + dbUser+";password=" +dbPass

# COMMAND ----------

# Storage blob account access settings for polybase

storage_account_name = "irmstoragedevtest"
storage_account_access_key =  "9wU0hltdp5vX1OB5aB9QQyhLjG1e9wIdjqJ+P4PD4ahHOVQ1HAIcH17UpPg9/LdDG9+ReqE9j8JhACDkgYezKA=="

file_type = "csv"
spark.conf.set(
  "fs.azure.account.key."+storage_account_name+".blob.core.windows.net",
  storage_account_access_key)
 
tempDir = "wasbs://irm@irmstoragedevtest.blob.core.windows.net/TempDir"

# COMMAND ----------

df = spark.read.format("csv")\
          .option("inferschema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load("dbfs:/mnt/foundation/HyperionEssbase/EPEForecast/*.csv")

# COMMAND ----------

df.write\
    .format("com.databricks.spark.sqldw")\
    .option("url", sqlDbUrl)\
    .option( "forward_spark_azure_storage_credentials", "True")\
    .option("tempdir", tempDir)\
    .option("dbtable", "test")\
    .mode("overwrite")\
    .save() 

# COMMAND ----------

df.write \
    .option('user', dbUser) \
    .option('password', dbPass) \
    .jdbc(sqlDbUrlSmall, 'test', mode = 'overwrite')