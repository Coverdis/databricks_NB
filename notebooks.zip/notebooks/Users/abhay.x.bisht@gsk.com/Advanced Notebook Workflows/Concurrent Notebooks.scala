// Databricks notebook source
// MAGIC %run "./parallel-notebooks"

// COMMAND ----------

val df = spark.read.format("csv")
          .option("inferSchema","false")
          .option("header","true")
          .option("multiLine","true")
          .option("delimiter","|")
          .option("quote", "\"")
          .option("escape","\"")
          .option("nullValue","null")
    .load("dbfs:/mnt/raw/Cerps/GLLineitem/*.txt")

val data = df.repartition($"FISCPER")

data.rdd.getNumPartitions

// COMMAND ----------

// find distinct fiscal period
val fp = data.select(data("fiscper")).distinct.collect

// COMMAND ----------

// convert to array
val newArray = for (e <- fp) yield e(0)

var l = Seq[String]()

for(e <- newArray) {
  if(e != null) {
//     l = l :+ s"NotebookData(datalayer, 0, Map(fiscper -> $e))"
    l = l :+ s"$e"
  }
}

// var n = l.map(x => NotebookData("datalayer", 0, Map("", x)))
var n = l.map(x => NotebookData("datalayer", 0, Map(("fiscper", x), ("runid" -> "111"))))

// COMMAND ----------

import scala.concurrent.Await
import scala.concurrent.duration._
import scala.language.postfixOps

// val notebooks = Seq(
//   NotebookData("datalayer", 0, Map("fiscper" -> "2014007", "runid" -> "111")),
//   NotebookData("datalayer", 0, Map("fiscper" -> "2014008", "runid" -> "112")),
//   NotebookData("datalayer", 0, Map("fiscper" -> "2014009", "runid" -> "113")),
//   NotebookData("datalayer", 0, Map("fiscper" -> "2014010", "runid" -> "114"))
// )


val res = parallelNotebooks(n)
// val res = parallelNotebooks(notebooks)

Await.result(res, 75 minutes) // this is a blocking call.
res.value

// COMMAND ----------

// val notebooks = Seq(
//   NotebookData("datalayer", 0, Map("fiscper" -> "2014007")),
//   NotebookData("datalayer", 0, Map("fiscper" -> "2014008")),
//   NotebookData("datalayer", 0, Map("fiscper" -> "2014009")),
//   NotebookData("datalayer", 0, Map("fiscper" -> "2014010"))
// )

val notebook = Seq(NotebookData("datalayer", 0, Map("fiscper" -> "2017002")))