# Databricks notebook source
# dbutils.widgets.text('fiscper', '')
# dbutils.widgets.text('runid', '')
# # dbutils.widgets.remove('filename')

# COMMAND ----------

df = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load("dbfs:/mnt/raw/Cerps/GLLineitem/*.txt")

data = df.repartition('fiscper')

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.window import Window

rawFilePath = 'dbfs:/mnt/raw/Cerps/GLLineitem/'
foundationFilePath = 'dbfs:/mnt/foundation/Cerps/GLLineitem/'
runid = dbutils.widgets.get("runid")

# allPeriod = data.select('fiscper').distinct().collect()
# fiscalPeriod = sorted(list(filter(lambda x: x != None, [item[0] for item in allPeriod])))
period = dbutils.widgets.get("fiscper")

# for period in fiscalPeriod:
year = period[:4]
month = period[5:].lstrip('0')
newdf = df.filter('fiscper = ' + period)
try:
  dbutils.fs.ls(foundationFilePath + year)
  try:
    dbutils.fs.ls(foundationFilePath + year + '/' + 'GLLineitem-'+ year + '-' + month + '.txt')
    baseFile = spark.read.format('csv')\
                .option("inferSchema","false")\
                .option("header","true")\
                .option("multiLine","true")\
                .option("delimiter","|")\
                .option("quote", '"')\
                .option("escape",'"')\
                .option("nullValue","null")\
              .load(foundationFilePath + year + '/' + 'GLLineitem-'+ year + '-' + month + '.txt')
    baseFile = baseFile.drop('RANK')    
    # find rows that are not in base but are in delta, this is to avoid loading duplicates in base file
    changeddf = newdf.subtract(baseFile)
    # merge with base data
    merged = baseFile.union(changeddf)
    # rank dataframe
    ranked =  merged.withColumn(
  'RANK', rank().over(Window.partitionBy('ac_doc_no', 'item_num', 'comp_code', 'fiscper', 'fiscvarnt', 'rectype', 'ac_ledger').orderBy(desc('BW_REQUEST_ID'), desc('BW_RECORD_NUMBER'))))
    # temp csv folder - run id is being added to make sure files do not mess up while running code in parallel
    csv_location = rawFilePath + runid + '/' + year + '/' + month
    # write ranked to temp folder
    ranked.coalesce(1).write\
              .option("sep","|")\
              .option("header","true")\
              .option("quote", '"')\
              .option("escape",'"')\
              .option("nullValue","null")\
            .csv(csv_location)
    # copy part-* csv file and rename
    dbutils.fs.cp(dbutils.fs.ls(csv_location)[-1][0], foundationFilePath + year + '/' + 'GLLineitem-'+ year + '-' + month + '.txt', True)
    # remove temp folder
    dbutils.fs.rm(rawFilePath + runid, recurse = True)
  # else create month file
  except:
    ranked =  newdf.withColumn('RANK', rank().over(Window.partitionBy('ac_doc_no', 'item_num', 'comp_code', 'fiscper', 'fiscvarnt', 'rectype', 'ac_ledger').orderBy(desc('BW_REQUEST_ID'), desc('BW_RECORD_NUMBER'))))
    # temp csv folder - run id is being added to make sure files do not mess up while running code in parallel
    csv_location = rawFilePath + runid + '/' + year + '/' + month
    ranked.coalesce(1).write\
          .option("sep","|")\
          .option("header","true")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
        .csv(csv_location)
    # copy part-* csv file and rename; move to foundation
    dbutils.fs.cp(dbutils.fs.ls(csv_location)[-1][0], foundationFilePath + year + '/' + 'GLLineitem-'+ year + '-' + month + '.txt', True)
    # remove temp folder
    dbutils.fs.rm(rawFilePath + runid, recurse = True)
except:
  # year folder does not exist; create year folder
  dbutils.fs.mkdirs(foundationFilePath + year)
  ranked =  newdf.withColumn('RANK', rank().over(Window.partitionBy('ac_doc_no', 'item_num', 'comp_code', 'fiscper', 'fiscvarnt', 'rectype', 'ac_ledger').orderBy(desc('BW_REQUEST_ID'), desc('BW_RECORD_NUMBER'))))
  # temp csv folder - run id is being added to make sure files do not mess up while running code in parallel
  csv_location = rawFilePath + runid + '/' + year + '/' + month
  ranked.coalesce(1).write\
        .option("sep","|")\
        .option("header","true")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
      .csv(csv_location)
  # copy part-* csv file and rename; move to foundation
  dbutils.fs.cp(dbutils.fs.ls(csv_location)[-1][0], foundationFilePath + year + '/' + 'GLLineitem-'+ year + '-' + month + '.txt', True)
  # remove temp folder
  dbutils.fs.rm(rawFilePath + runid, recurse = True)

# COMMAND ----------

dbutils.notebook.exit(period)