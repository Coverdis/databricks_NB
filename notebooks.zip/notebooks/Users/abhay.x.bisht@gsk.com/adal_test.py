# Databricks notebook source
# MAGIC %scala
# MAGIC // This code block only needs to be run once to create the init script for the cluster (file remains on restart)
# MAGIC 
# MAGIC // Create dbfs:/databricks/init/ if it doesnt exist.
# MAGIC dbutils.fs.mkdirs("dbfs:/databricks/init/")
# MAGIC 
# MAGIC // Display the list of existing global init scripts.
# MAGIC display(dbutils.fs.ls("dbfs:/databricks/init/"))
# MAGIC 
# MAGIC // Create a directory named (irmCluster) using Databricks File System - DBFS.
# MAGIC dbutils.fs.mkdirs("dbfs:/databricks/init/irmCluster/")
# MAGIC 
# MAGIC // Create the adal4j script.
# MAGIC dbutils.fs.put("/databricks/init/irmCluster/adal4j-install.sh","""
# MAGIC #!/bin/bash
# MAGIC wget --quiet -O /mnt/driver-daemon/jars/adal4j-1.6.0.jar http://central.maven.org/maven2/com/microsoft/azure/adal4j/1.6.0/adal4j-1.6.0.jar
# MAGIC wget --quiet -O /mnt/jars/driver-daemon/adal4j-1.6.0.jar http://central.maven.org/maven2/com/microsoft/azure/adal4j/1.6.0/adal4j-1.6.0.jar
# MAGIC wget --quiet -O /mnt/driver-daemon/jars/oauth2-oidc-sdk-3.0.jar http://central.maven.org/maven2/com/nimbusds/oauth2-oidc-sdk/3.0/oauth2-oidc-sdk-3.0.jar
# MAGIC wget --quiet -O /mnt/jars/driver-daemon/oauth2-oidc-sdk-3.0.jar http://central.maven.org/maven2/com/nimbusds/oauth2-oidc-sdk/3.0/oauth2-oidc-sdk-3.0.jar
# MAGIC """, true)
# MAGIC 
# MAGIC 
# MAGIC 
# MAGIC // Check that the cluster-specific init script exists.
# MAGIC display(dbutils.fs.ls("dbfs:/databricks/init/irmCluster/"))

# COMMAND ----------

# MAGIC %scala
# MAGIC // import java.sql.Connection;
# MAGIC // import java.sql.ResultSet;
# MAGIC // import java.sql.Statement;
# MAGIC // import com.microsoft.azure.sqldb.spark.config.Config
# MAGIC // import com.microsoft.azure.sqldb.spark.connect._
# MAGIC // import com.microsoft.sqlserver.jdbc.SQLServerDataSource
# MAGIC // // import com.microsoft.aad.adal4j.AuthenticationException
# MAGIC // import com.microsoft.aad.adal4j.AuthenticationContext
# MAGIC // import com.microsoft.aad.adal4j.AuthenticationResult
# MAGIC // import com.microsoft.aad.adal4j.ClientCredential
# MAGIC // # import java.util.concurrent.ExecutionException
# MAGIC // # import java.util.concurrent.ExecutorService
# MAGIC // # import java.util.concurrent.Executors
# MAGIC // # import java.util.concurrent.Future
# MAGIC 
# MAGIC import com.microsoft.azure.sqldb.spark.config.Config
# MAGIC import com.microsoft.azure.sqldb.spark.connect._
# MAGIC import com.microsoft.sqlserver.jdbc.SQLServerDataSource
# MAGIC import com.microsoft.aad.adal4j.AuthenticationContext
# MAGIC import com.microsoft.aad.adal4j.AuthenticationResult
# MAGIC import com.nimbusds.oauth2._
# MAGIC 
# MAGIC val config = Config(Map(
# MAGIC   "url"            -> "gsk-us6-rd-irm-sqlsrv-devtest.database.windows.net",
# MAGIC   "databaseName"   -> "rd-irm-sqldb",
# MAGIC   "dbTable"        -> "project_plan",
# MAGIC   "user"           -> "sudeep.x.mishra@gsk.com",
# MAGIC   "password"       -> "Feb2019@new",
# MAGIC   "authentication" -> "ActiveDirectoryPassword",
# MAGIC   "connectTimeout" -> "30", //seconds
# MAGIC   "queryTimeout"   -> "30",  //seconds
# MAGIC   "encrypt"        -> "true",
# MAGIC   "trustServerCertificate" -> "false",
# MAGIC   "hostNameInCertificate" -> "*.database.windows.net"
# MAGIC ))
# MAGIC 
# MAGIC val collection = spark.read.sqlDB(config)
# MAGIC collection.show()