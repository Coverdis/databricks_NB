# Databricks notebook source
# 1. Config parameters 
dwDatabase = "irmdb"
dwServer = "irmdwserver" 
dwUser =  "irm_sandbox@irmdwserver"
dwPass = "Experiments1!"
dwJdbcPort =  "1433"

# COMMAND ----------

# 1. Read from SQLDW table: cerps_glineitem_dup_all into Dataframe : cerps_gllineitem_sqldw_df
cerps_gllineitem_sqldw_df = spark.read \
  .option('user', dwUser) \
  .option('password', dwPass) \
  .jdbc('jdbc:sqlserver://' + dwServer + ".database.windows.net" + ':' + dwJdbcPort + ';database=' + dwDatabase, 'cerps_glineitem_dup_all')

# COMMAND ----------

# importing neccessary functions/libraries
from pyspark.sql.functions import *
import pyspark.sql.functions as fn

# COMMAND ----------

# 1. Calculating the length of the COSTCENTER column and making a corresponding length column i.e LENCOSTCENTER.
# 2. Making a new column TRFM_COSTCENTER, which consist of the valid values, i.e max 8 characters after removing leading 2 zeroes.

cerps_gllineitem_sqldw_df = cerps_gllineitem_sqldw_df.withColumn("LENCOSTCENTER",fn.length(cerps_gllineitem_sqldw_df["COSTCENTER"])) 

cerps_gllineitem_sqldw_df = cerps_gllineitem_sqldw_df.withColumn("TRFM_COSTCENTER", when(cerps_gllineitem_sqldw_df['LENCOSTCENTER'] == 8,fn.substring(cerps_gllineitem_sqldw_df["COSTCENTER"], 1, 8)).when(((cerps_gllineitem_sqldw_df['LENCOSTCENTER'] == 10) & (fn.substring(cerps_gllineitem_sqldw_df["COSTCENTER"], 1, 2) =='00')),fn.substring(cerps_gllineitem_sqldw_df["COSTCENTER"], 3, 10)).when( (cerps_gllineitem_sqldw_df['LENCOSTCENTER'] == 9) & (fn.substring(cerps_gllineitem_sqldw_df["COSTCENTER"], 1, 1) =='0'),fn.substring(cerps_gllineitem_sqldw_df["COSTCENTER"], 2, 9)) )

# COMMAND ----------

# 1. Calculating the length of the GL_Account column and making a corresponding length column i.e LENGL_Account.
# 2. Making a new column TRFM_GL_Account, which consist of the valid values, i.e max 7 characters after removing leading 3 zeroes.

cerps_gllineitem_sqldw_df = cerps_gllineitem_sqldw_df.withColumn("LENGL_Account",fn.length(cerps_gllineitem_sqldw_df["GL_Account"])) 

cerps_gllineitem_sqldw_df = cerps_gllineitem_sqldw_df.withColumn("TRFM_GL_Account", when(cerps_gllineitem_sqldw_df['LENGL_Account'] == 7,fn.substring(cerps_gllineitem_sqldw_df["GL_Account"], 1, 7)).when(((cerps_gllineitem_sqldw_df['LENGL_Account'] == 8) & (fn.substring(cerps_gllineitem_sqldw_df["GL_Account"], 1, 1) =='0')),fn.substring(cerps_gllineitem_sqldw_df["GL_Account"], 2, 8)).when( (cerps_gllineitem_sqldw_df['LENGL_Account'] == 9) & (fn.substring(cerps_gllineitem_sqldw_df["GL_Account"], 1, 2) =='00'),fn.substring(cerps_gllineitem_sqldw_df["GL_Account"], 3, 9)).when( (cerps_gllineitem_sqldw_df['LENGL_Account'] == 10) & (fn.substring(cerps_gllineitem_sqldw_df["GL_Account"], 1, 3) =='000'),fn.substring(cerps_gllineitem_sqldw_df["GL_Account"], 4, 10)) )

# COMMAND ----------

# 1. Calculating the length of the PROFIT_CTR column and making a corresponding length column i.e LENPROFIT_CTR.
# 2. Making a new column TRFM_PROFIT_CTR, which consist of the valid values, i.e max 4 characters after removing leading 6 zeroes.

cerps_gllineitem_sqldw_df = cerps_gllineitem_sqldw_df.withColumn("LENPROFIT_CTR",fn.length(cerps_gllineitem_sqldw_df["PROFIT_CTR"])) 


cerps_gllineitem_sqldw_df = cerps_gllineitem_sqldw_df.withColumn("TRFM_PROFIT_CTR", when(cerps_gllineitem_sqldw_df['LENPROFIT_CTR'] == 4,fn.substring(cerps_gllineitem_sqldw_df["PROFIT_CTR"], 1, 4)).when(((cerps_gllineitem_sqldw_df['LENPROFIT_CTR'] == 5) & (fn.substring(cerps_gllineitem_sqldw_df["PROFIT_CTR"], 1, 1) =='0')),fn.substring(cerps_gllineitem_sqldw_df["PROFIT_CTR"], 2, 5)).when( (cerps_gllineitem_sqldw_df['LENPROFIT_CTR'] == 6) & (fn.substring(cerps_gllineitem_sqldw_df["PROFIT_CTR"], 1, 2) =='00'),fn.substring(cerps_gllineitem_sqldw_df["PROFIT_CTR"], 3, 6)).when( (cerps_gllineitem_sqldw_df['LENPROFIT_CTR'] == 7) & (fn.substring(cerps_gllineitem_sqldw_df["PROFIT_CTR"], 1, 3) =='000'),fn.substring(cerps_gllineitem_sqldw_df["PROFIT_CTR"], 4, 7)) .when( (cerps_gllineitem_sqldw_df['LENPROFIT_CTR'] == 8) & (fn.substring(cerps_gllineitem_sqldw_df["PROFIT_CTR"], 1, 4) =='0000'),fn.substring(cerps_gllineitem_sqldw_df["PROFIT_CTR"], 5, 8)).when( (cerps_gllineitem_sqldw_df['LENPROFIT_CTR'] == 9) & (fn.substring(cerps_gllineitem_sqldw_df["PROFIT_CTR"], 1, 5) =='00000'),fn.substring(cerps_gllineitem_sqldw_df["PROFIT_CTR"], 6, 9)).when( (cerps_gllineitem_sqldw_df['LENPROFIT_CTR'] == 10) & (fn.substring(cerps_gllineitem_sqldw_df["PROFIT_CTR"], 1, 6) =='000000'),fn.substring(cerps_gllineitem_sqldw_df["PROFIT_CTR"], 7, 10))   )

# COMMAND ----------

# 1. Inserting a new column as CreationTimestamp, which consists of the current timestamp while the file is being written.

import time
import datetime
from pyspark.sql.functions import lit,unix_timestamp
timestamp = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
type(timestamp)
timestamp
cerps_gllineitem_sqldw_df = cerps_gllineitem_sqldw_df.withColumn('CreationTimestamp',unix_timestamp(lit(timestamp),'yyyy-MM-dd HH:mm:ss').cast("timestamp"))

# COMMAND ----------

# 1. Inserting a new column as CreatedBy, which consists of the corresponding value while the file is being written.

cerps_gllineitem_sqldw_df = cerps_gllineitem_sqldw_df.withColumn("CreatedBy", lit('Initial_Load'))

# COMMAND ----------

# 1. Writing the final dataframe into the DBFS in parquet format, so that we can use this file as a processing storage for incremental load as well.

cerps_gllineitem_sqldw_df.write.parquet("/irm/prod/incremental_cerps_gllineitem_sqldw_df.parquet")

# COMMAND ----------

#last step to write this data back into sql dw table.

cerps_gllineitem_sqldw_df.write\
    .format("com.databricks.spark.sqldw")\
    .option("url", sqlDwUrl)\
    .option("dbtable", "Cerps_GlLineItem_Processed_parquet")\
    .option( "forward_spark_azure_storage_credentials","True")\
    .option("tempdir", tempDir)\
    .mode("Overwrite")\
    .save()

# COMMAND ----------

# cerps_gllineitem_parquet_df = sqlContext.read.parquet("/irm/prod/incremental_cerps_gllineitem_sqldw_df.parquet")

# COMMAND ----------

# put_your_df_here.write.mode('append').parquet('name_of_existing_parquet_file.parquet')