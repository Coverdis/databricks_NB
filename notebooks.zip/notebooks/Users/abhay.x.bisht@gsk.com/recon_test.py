# Databricks notebook source
dbutils.fs.ls('dbfs:/mnt/foundation/cerps/gllineitem/2019')

# COMMAND ----------

df = spark.read.format('csv')\
  .option("inferSchema","false")\
  .option("header","true")\
  .option("multiLine","true")\
  .option("delimiter","|")\
  .option("quote", '"')\
  .option("escape",'"')\
  .option("nullValue","null")\
.load('dbfs:/mnt/foundation/cerps/gllineitem/2019/GLLineitem-2019-3.txt')

# COMMAND ----------

df.count()

# COMMAND ----------

df.select('fiscper', 'fiscper3', 'fiscyear').distinct().show()

# COMMAND ----------

df2 = df.filter('RANK == 1')

# COMMAND ----------

df2.count()

# COMMAND ----------

from pyspark.sql.types import *
df2 = df2.withColumn('deb_cre_lc', df2["deb_cre_lc"].cast(DecimalType(15,2)))

# COMMAND ----------

df2.agg({"deb_cre_lc":"sum"}).collect()[0]