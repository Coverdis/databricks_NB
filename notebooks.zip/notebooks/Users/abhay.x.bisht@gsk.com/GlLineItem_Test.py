# Databricks notebook source
# Data lake gen 2 account access settings
clientSecret = dbutils.secrets.get(scope = "azurekeyvault-databricks", key = "pw-irm-client-pwd")

configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": "781debca-07aa-4570-99f1-a6d988890115",
           "fs.azure.account.oauth2.client.secret": clientSecret,
           "fs.azure.account.oauth2.client.endpoint": "https://login.microsoftonline.com/63982aff-fb6c-4c22-973b-70e4acfb63e6/oauth2/token"}

mountName = 'raw'
mounts = [str(i) for i in dbutils.fs.ls('/mnt/')] 
if "FileInfo(path='dbfs:/mnt/" +mountName + "/', name='" +mountName + "/', size=0)" in mounts:
  print(mountName + " is already mounted") 
else:
  dbutils.fs.mount(
  source = "abfss://raw@irmdatalakegen2.dfs.core.windows.net",
  mount_point= "/mnt/" + mountName,
  extra_configs = configs)
  print(mountName + " is mounted")

# COMMAND ----------

dbutils.fs.ls('/mnt/foundation/Cerps/GLLineitem/2019')

# COMMAND ----------

dbutils.fs.ls('/mnt/raw/Cerps/GLLineitem/')

# COMMAND ----------

df = sc.textFile("dbfs:/mnt/raw/Cerps/GLLineitem/GLLineitem.txt")
df = df.map(lambda k: k.replace("\r", ''))
df = df.map(lambda k: k.replace("\n", ''))
df = df.map(lambda k: k.replace("\"", ''))

header = df.first()

df = df.filter(lambda line: line != header)

temp_var = df.map(lambda k: k.split("|"))
log_df = temp_var.toDF(header.split("|"))


# display(log_df)

# COMMAND ----------

display(log_df)

# COMMAND ----------

log_df.printSchema()

# COMMAND ----------

df2 = spark.read.format('csv') \
#           .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
.load("dbfs:/mnt/raw/Cerps/GLLineitem/GLLineitem.txt")

# COMMAND ----------

display(df2)

# COMMAND ----------

# dbutils.fs.unmount("/mnt/raw")