# Databricks notebook source
# sample data with \r

col1 = ['this is a sentence', 'this is a sentence with\rCR', 'this is another sentence', 'this is another\r sentence with CR', 'this is the end']
col2 = [1, 2, 3, 4, 5]
col3 = [
  'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut iaculis ac justo ut\r egestas. Sed ac volutpat dolor. Maecenas sem arcu, laoreet sit amet enim nec, feugiat suscipit dui. Sed sollicitudin vitae lorem vel imperdiet. Sed eleifend blandit velit eget blandit. Sed laoreet maximus leo, quis vestibulum libero scelerisque nec. Vivamus dictum felis tortor\r, id aliquam orci placerat ut. Integer massa eros, auctor sed porttitor eu, suscipit et enim. Quisque tincidunt risus leo, at iaculis enim vehicula non. Aliquam vestibulum tortor sapien, non dictum sapien\r convallis eget. Aliquam ullamcorper aliquet sodales. Nullam porttitor metus sem, ac placerat elit laoreet sed.',
  'Maecenas posuere turpis vel velit vestibulum maximus. Vestibulum condimentum, lacus non scelerisque venenatis, dui elit fringilla odio, eget scelerisque nunc eros sed justo. Fusce non quam\r consequat, hendrerit nulla quis, posuere arcu. Nullam efficitur posuere metus\r, tincidunt iaculis arcu varius\r eu. Aliquam convallis ante quis porta malesuada. Orci varius natoque penatibus et magnis\r dis parturient montes, nascetur ridiculus mus. Integer sodales mattis risus eu aliquet. Pellentesque pulvinar sit amet felis et ullamcorper. Fusce viverra enim at urna eleifend fringilla. \rAliquam ultricies iaculis nulla, a gravida sem rhoncus vel. Aenean aliquam,\r sem eu varius semper, tortor nulla\r faucibus ex, vel aliquet urna felis fringilla ligula. Maecenas justo tortor, tincidunt sed mi nec, convallis eleifend leo.',
  'Suspendisse feugiat\r non libero aliquam condimentum. Quisque in purus at orci molestie auctor. Sed aliquam, mi vel vehicula congue, dui tortor luctus quam, at dapibus magna nisl sed metus. Suspendisse lobortis pretium libero, nec eleifend odio gravida ac. Suspendisse porttitor\r leo orci. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus fringilla mi, ac sollicitudin sem maximus et \r. Cras mi leo, consectetur non maximus vel, ultrices sit amet leo. Duis accumsan finibus erat at finibus. Nam sit amet suscipit erat.',
  'Phasellus sollicitudin sem in sem mollis, sed pretium turpis vehicula. Sed feugiat sed justo elementum pharetra. Nulla facilisi. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent porta imperdiet orci, eget tristique sem posuere ut. Suspendisse auctor\r vel urna at convallis. In in quam vel nunc aliquet scelerisque ut eu magna.',
'Curabitur molestie lorem eu cursus blandit. Nam quis laoreet sapien, in hendrerit mi. Sed quis dictum lectus, ac condimentum lorem. Sed nec ultrices nisi. Suspendisse dolor risus, molestie sollicitudin velit ac, rutrum laoreet eros.\r Praesent eu enim tincidunt, dignissim enim cursus, auctor nibh. Aenean sollicitudin porta luctus. Nulla vitae sapien eu leo tempor consequat ac nec ipsum. Fusce rutrum malesuada justo,\r sit amet rutrum tortor dapibus lacinia. In velit nulla, accumsan a interdum nec, rutrum quis leo.'
]

print(col3[1])

# COMMAND ----------

# create dataframe
df = sqlContext.createDataFrame(zip(col1, col2, col3), schema=['col1', 'col2', 'col3'])

# COMMAND ----------

display(df)

# COMMAND ----------

df.collect()

# COMMAND ----------

# remove \r from values

from pyspark.sql.functions import regexp_replace
df = df.withColumn('col1', regexp_replace('col1', '\r', ''))
df = df.withColumn('col3', regexp_replace('col3', '\r', ''))

# COMMAND ----------

df.collect()

# COMMAND ----------

display(df)