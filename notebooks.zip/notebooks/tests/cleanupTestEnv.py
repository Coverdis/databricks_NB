# Databricks notebook source
mounts = [str(i) for i in dbutils.fs.ls('/mnt/')]
folders = [mounts[idx].lower().split(',')[1].split('=')[1].replace("/", "").replace("'", "") for idx, rows in enumerate(mounts)] 

def revert_mount(mountName):
  if mountName in folders:
    if file_exists('/mnt/'+mountName+'/tests_container.txt'):
      print('/mnt/'+mountName+' is mounted in filesystem '+mountName+'-test. Cleaning it up...')
      dbutils.fs.rm('/mnt/'+mountName, True)
      dbutils.fs.unmount('/mnt/'+mountName)
    else:
      print('Skipping /mnt/'+mountName+' since it is already mounted in '+mountName+' filesystem')

# COMMAND ----------

revert_mount('raw')
revert_mount('log')
revert_mount('foundation')
revert_mount('curated')
revert_mount('unified')
revert_mount('downstream')