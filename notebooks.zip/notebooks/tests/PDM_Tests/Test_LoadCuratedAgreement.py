# Databricks notebook source
# MAGIC %run /tests/initTestEnv

# COMMAND ----------

# 1. ARRANGE: prepare input data for testing
# create mock file
dbutils.fs.put('dbfs:/mnt/foundation/pdm/agreement.txt','''AGREEMENT_ID|AGREEMENT_NAME_CODE|AGREEMENT_NAME_DESC|AGREEMENT_PARTY_CODE|AGREEMENT_PARTY_DESC|AGREEMENT_TYPE_CODE|AGREEMENT_TYPE_DESC|AGREEMENT_CATEGORY_CODE|AGREEMENT_CATEGORY_DESC|AGREEMENT_DATE
190|"URN:LSID:gsk.com/rd:item.DEX:1269369636"|"FivePrime NOPE"|"URN:LSID:gsk.com/rd:item.DEX:134268"|"Five Prime Therapeutics, Inc."|"URN:LSID:gsk.com/rd:item.DEX:59910"|"Option-based deal"|"URN:LSID:gsk.com/rd:item.DEX:116368"|"UNKNOWN"|2015-11-24 00:00:00.0000000
166|"URN:LSID:gsk.com/rd:item.DEX:127588"|"Yale University PROTACS"|"URN:LSID:gsk.com/rd:item.DEX:127568"|"Yale University"|"URN:LSID:gsk.com/rd:item.DEX:59930"|"Collaboration"|"URN:LSID:gsk.com/rd:item.DEX:116368"|"UNKNOWN"|2012-04-24 00:00:00.0000000''', overwrite = True)

# COMMAND ----------

# 2. ACT: execute notebook to test
import traceback

try:
  
  dbutils.notebook.run("/source/PDM/LoadCuratedAgreement", timeout_seconds = 180, arguments = { "runid": "test" })
  
except:
  dbutils.notebook.exit("Error: \n" + traceback.format_exc())

# COMMAND ----------

# 3. ASSERT: download resulting files and validate the expected content
try:
  
  df = spark.read.format("csv")\
        .option("inferSchema", "false")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
    .load('dbfs:/mnt/curated/pdm/agreement.txt')

  assert df.columns == ['AGREEMENT_ID',
   'AGREEMENT_NAME_CODE',
   'AGREEMENT_NAME_DESCRIPTION',
   'AGREEMENT_PARTY_CODE',
   'AGREEMENT_PARTY_DESCRIPTION',
   'AGREEMENT_TYPE_CODE',
   'AGREEMENT_TYPE_DESCRIPTION',
   'AGREEMENT_CATEGORY_CODE',
   'AGREEMENT_CATEGORY_DESCRIPTION',
   'AGREEMENT_DATE']

  assert df.count() == 3

except AssertionError:
  dbutils.notebook.exit("Test failed: \n" + traceback.format_exc())
except:
  dbutils.notebook.exit("Error: \n" + traceback.format_exc())

# COMMAND ----------

# 4. CLEAN UP (optional, uncomment if running in Dev in irm_adf_cluster and you need to run other notebooks normally using actual DL filesystems)
# %run /tests/cleanupTestEnv