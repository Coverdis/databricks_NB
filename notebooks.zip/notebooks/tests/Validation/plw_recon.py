# Databricks notebook source
# Filename: plw_recon
# Description:
    # Reconciles Planisware schedule , cost and fte  data between source and staging table
    # Reconciles Planisware schedule , cost and fte  data between source and dimension and facts table    

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

# MAGIC %run /library/logs

# COMMAND ----------

import pytz
from datetime import *
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
import os
from glob import glob
import re
plan_raw_path = 'dbfs:/mnt/raw/validation/gsk_inc_export_project.txt'
activity_raw_path = 'dbfs:/mnt/raw/validation/gsk_inc_export_activity.txt'
cost_raw_path = 'dbfs:/mnt/raw/validation/gsk_cost_data.txt'
fte_raw_path = 'dbfs:/mnt/raw/validation/gsk_fte_data.txt'

dbutils.widgets.text("runid", "")
runid = dbutils.widgets.get("runid")
log_msg = '|'

# COMMAND ----------

# DBTITLE 1,Plan Validation
# read plan data from irm_stg.plw_plan table
plan = spark.read \
  .format("com.databricks.spark.sqldw") \
  .option("url", sqlDwUrl) \
  .option("tempDir", tempDir) \
  .option("dbtable", "irm_stg.PLW_PLAN")\
  .option("forwardSparkAzureStorageCredentials", "true") \
  .load()

# read plan data from irm.d_plan table
d_plan = spark.read \
  .format("com.databricks.spark.sqldw") \
  .option("url", sqlDwUrl) \
  .option("tempDir", tempDir) \
  .option("dbtable", "irm.D_PLAN")\
  .option("forwardSparkAzureStorageCredentials", "true") \
  .load()

# COMMAND ----------

# filtering the plan data from staging
plan = plan.filter((plan.SOURCE =='PLW-NEW') & (plan.REFERENCE_OBJECT_NUMBER.isNull()))
# getting plan object number count
plan_count = plan.select('plan_object_number').distinct().count()
# getting plan count and filtering d_plan data frame
d_plan = d_plan.filter((d_plan.PLAN_SOURCE == 'PLW-NEW') & (d_plan.PLAN_BASELINE_CODE == '0'))
d_plan_count = d_plan.select('plan_code').distinct().count()

# COMMAND ----------

# read project data from source
source_plan = spark.read.format('csv')\
            .option('inferSchema','false')\
            .option('header','true')\
            .option('multiLine','true')\
            .option('delimiter','|')\
            .option('quote','"')\
            .option('escape','"')\
            .option('nullValue','null')\
          .load(plan_raw_path)
source_plan = source_plan.toDF(*(col.replace('\r', '') for col in source_plan.columns))
for col_name in source_plan.columns:
  source_plan = source_plan.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ' '))

# COMMAND ----------

# getting plan object number count for source
source_count = source_plan.select('plan_internal_number').distinct().count()

# COMMAND ----------

# log for missing plan object number 
x = source_plan.join(plan,source_plan.plan_internal_number == plan.PLAN_OBJECT_NUMBER,'leftanti')
msg = ', '.join(map(str, [row['plan_internal_number'] for row in x.collect() ]))
row = [row['plan_internal_number'] for row in x.collect() ]
if len(row) == 0:
  logWarning('Notebook: plw_recon, '+'Entity: Plan, '+'RunID: ' + str(runid) + ' - Number of Plan in OA and PLW are same')
  plan_stag_flag = True
else:
  logError('Notebook: plw_recon, '+'Entity: Plan, '+'RunID: ' + str(runid) + ' - Following Plan are missing from OA  ' + str(msg))
  plan_stag_flag = False
  log_msg = log_msg + 'Plan(Staging)|'

# COMMAND ----------

# log for missing plan object number in dimesnion table
new_df = source_plan.join(d_plan,source_plan.plan_internal_number == d_plan.PLAN_CODE,'leftanti')
new_df = new_df.select('plan_internal_number').distinct()
msg = ', '.join(map(str, [row['plan_internal_number'] for row in new_df.collect() ]))
row = [row['plan_internal_number'] for row in new_df.collect() ]
if len(row) == 0:
  logWarning('Notebook: plw_recon, '+'Entity: Plan, '+'RunID: ' + str(runid) + ' - Number of Plan in OA(dimension and facts) and PLW are same ')
  plan_dim_flag = True
else:
  logError('Notebook: plw_recon, '+'Entity: Plan, '+'RunID: ' + str(runid) + ' - Following Plan are missing from OA(dimension and facts) ' + str(msg))
  plan_dim_flag = False
  log_msg = log_msg + "Plan(Dimension and Facts)|"

# COMMAND ----------

# DBTITLE 1,Activity Validation
# read activty data from irm_stg.plw_activty
activity = spark.read \
  .format("com.databricks.spark.sqldw") \
  .option("url", sqlDwUrl) \
  .option("tempDir", tempDir) \
  .option("dbtable", "irm_stg.plw_activity")\
  .option("forwardSparkAzureStorageCredentials", "true") \
  .load()

# read activity data from irm.d_task table
d_task = spark.read \
  .format("com.databricks.spark.sqldw") \
  .option("url", sqlDwUrl) \
  .option("tempDir", tempDir) \
  .option("dbtable", "irm.D_TASK")\
  .option("forwardSparkAzureStorageCredentials", "true") \
  .load()

# COMMAND ----------

# filtering activity data 
activity = activity.filter((activity.SOURCE == "PLW-NEW") &(activity.REFERENCE_OBJECT_NUMBER.isNull()))
# getting activity object number count for staging
activity_count = activity.select('activity_object_number').distinct().count()

# count of activity onb and filtering the d_task data frame
d_task = d_task.filter((d_task.TASK_SOURCE == 'PLW-NEW') & (d_task.TASK_BASELINE_CODE == '0'))
d_task_count = d_task.select('task_activity_code').distinct().count()

# COMMAND ----------

# DBTITLE 0,Plan Validation
# read source activity data from raw
source_activity = spark.read.format('csv')\
            .option('inferSchema','false')\
            .option('header','true')\
            .option('multiLine','true')\
            .option('delimiter','|')\
            .option('quote','"')\
            .option('escape','"')\
            .option('nullValue','null')\
          .load(activity_raw_path)
source_activity = source_activity.toDF(*(col.replace('\r', '') for col in source_activity.columns))
for col_name in source_activity.columns:
  source_activity = source_activity.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ' '))

# COMMAND ----------

# DBTITLE 0,Activity Validation
# getting activity internal  number count
source_activity_count = source_activity.select('activity_internal_number').distinct().count()

# COMMAND ----------

# log for missing activity object number
new_df = source_activity.join(activity,source_activity.activity_internal_number == activity.ACTIVITY_OBJECT_NUMBER,'leftanti')
new_df = new_df.select('plan_internal_number').distinct()
msg = ', '.join(map(str, [row['plan_internal_number'] for row in new_df.collect() ]))
row = [row['plan_internal_number'] for row in new_df.collect() ]
if len(row) == 0:
  logWarning('Notebook: plw_recon, '+'Entity: Activity, ' + 'RunID: ' + str(runid) +  ' - Number of Activity in OA and PLW are same')
  activity_stag_count_flag = True
else: 
  logError('Notebook: plw_recon, '+'Entity: Activity, '+'RunID: ' + str(runid) +' - Plan which has different Activity are  ' + str(msg))
  activity_stag_count_flag = False

# COMMAND ----------

# log for missing activity object number in dimension and facts
new_df = source_activity.join(d_task,source_activity.activity_internal_number == d_task.TASK_ACTIVITY_CODE,'leftanti')
new_df = new_df.select('plan_internal_number').distinct()
msg = ', '.join(map(str, [row['plan_internal_number'] for row in new_df.collect() ]))
row = [row['plan_internal_number'] for row in new_df.collect() ]
if len(row) == 0:
  logWarning('Notebook: plw_recon, '+'Entity: Activity, ' + 'RunID: ' + str(runid) +  ' - Number of Activity in OA(dimension and facts) and PLW are same')
  activity_dim_count_flag = True
else: 
  logError('Notebook: plw_recon, '+'Entity: Activity, '+'RunID: ' + str(runid) +' - Plan which has different Activity in dimension and facts table are  ' + str(msg))
  activity_dim_count_flag = False

# COMMAND ----------

# Sum off activity_object_number per plan in staging
df = activity.groupBy('plan_object_number').count()
df = df.withColumnRenamed('count','act_per_plan_count')

df1 = source_activity.groupBy('plan_internal_number').count()
df1 = df1.withColumnRenamed('count','source_act_per_plan_count')

x = df.join(df1,df.plan_object_number == df1.plan_internal_number,'left')
x = x.withColumn('FLAG',F.when((df.act_per_plan_count) == (df1.source_act_per_plan_count),'TRUE').otherwise('FALSE'))

#  log for mising activity per plan
msg = ', '.join(map(str, [row['plan_internal_number'] for row in x.collect() if row['FLAG'] == 'FALSE']))
row = [row['plan_internal_number'] for row in x.collect() if row['FLAG'] == 'FALSE']
if len(row) == 0:
  logWarning('Notebook: plw_recon, '+'Entity: Activity, ' +'RunID: '+ str(runid) +' - Plan and count of corresponding activities in OA matches with PLW')
  activity_stag_per_flag = True
else:
  logError('Notebook: plw_recon, ' +'Entity: Activity, '+'RunID: '+ str(runid) + ' - Plan which has different corresponding Activity are :- ' + str(msg))
  activity_stag_per_flag = False

# COMMAND ----------

# count off activity_object_number per plan in dimension
df = d_task.groupBy('task_plan_code').count()
df = df.withColumnRenamed('count','activity_per_plan_count')
# count off activity_object_number per plan in source
df1 = source_activity.groupBy('plan_internal_number').count()
df1 = df1.withColumnRenamed('count','source_activity_per_plan_count')
# joining both the df
x = df.join(df1,df.task_plan_code == df1.plan_internal_number,'left')
x = x.withColumn('FLAG',F.when((x.activity_per_plan_count) == (x.source_activity_per_plan_count),'TRUE').otherwise('FALSE'))
#  log for mising activity per plan
msg = ', '.join(map(str, [row['plan_internal_number'] for row in x.collect() if row['FLAG'] == 'FALSE']))
row = [row['plan_internal_number'] for row in x.collect() if row['FLAG'] == 'FALSE']
if len(row) == 0:
  logWarning('Notebook: plw_recon, '+'Entity: Activity, ' +'RunID: '+ str(runid) +' -  Plan and count of corresponding activities in OA(dimension and facts) matches with PLW')
  activity_dim_per_flag = True
else:
  logError('Notebook: plw_recon, ' +'Entity: Activity, '+'RunID: '+ str(runid) + ' - Plan which has different corresponding Activity in dimension and facts are :- ' + str(msg))
  activity_dim_per_flag = False

# COMMAND ----------

if ((activity_stag_count_flag == True) and (activity_stag_per_flag == True)):
  activity_stag_flag = True
else:
  activity_stag_flag = False
  log_msg = log_msg + 'Activity(Staging)|'

if ((activity_dim_per_flag == True) and (activity_dim_count_flag == True)):
  activity_dim_flag = True
else:
  activity_dim_flag = False
  log_msg = log_msg + 'Activity(Dimesnion and Facts)|'

# COMMAND ----------

if plan_count == source_count:
  print('Count is same')
else:
  print(abs(plan_count - source_count))
  print('Count is different')
  
if d_plan_count == source_count:
  print('Count is same in dimension and facts')
else:
  print(abs(d_plan_count - source_count))
  print('Count is different in dimension and facts')

# COMMAND ----------

# DBTITLE 0,Cost Validation
if activity_count == source_activity_count:
  print('Count is same')
else:
  print(abs(activity_count - source_activity_count))
  print('count is different')
  
if d_task_count == source_activity_count:
  print('Count is same in dimension and facts')
else:
  print(abs(d_task_count - source_activity_count))
  print('Count is different in dimension and facts')

# COMMAND ----------

# Verifying cost data from source and staging

# COMMAND ----------

# DBTITLE 1,Cost Validation
#  load irm_stg.plw_expense table
cost =  spark.read \
  .format("com.databricks.spark.sqldw") \
  .option("url", sqlDwUrl) \
  .option("tempDir", tempDir) \
  .option("dbtable", "irm_stg.PLW_EXPENSE")\
  .option("forwardSparkAzureStorageCredentials", "true") \
  .load()

# read activity data from irm.d_task table
f_expense = spark.read \
  .format("com.databricks.spark.sqldw") \
  .option("url", sqlDwUrl) \
  .option("tempDir", tempDir) \
  .option("dbtable", "irm.F_ESTIMATED_EXPENSE")\
  .option("forwardSparkAzureStorageCredentials", "true") \
  .load()

# filtering the data frame
cost = cost.filter((cost.SOURCE == "PLW-NEW") & (cost.REFERENCE_OBJECT_NUMBER.isNull()))
f_expense = f_expense.filter((f_expense.DATA_ORIGIN =='PLW_EXPENSE') & (f_expense.DATA_SOURCE == 'PLW-NEW') & (f_expense.ESTIMATE_VERSION == 'Current Plan'))

# COMMAND ----------

# Joining dim and fact table
df_plan = f_expense.join(d_plan,f_expense.PLAN_KEY == d_plan.PLAN_KEY,'left')
df = df_plan.select('plan_code').distinct()
# getting plan list
x = df.collect()
plan_list = []
for i in range(len(x)):
  plan_list.append(x[i][0])
#  selecting required column and plan onbs from the list
df_plan = cost.select('plan_object_number','activity_object_number','amount_gbp').filter((cost.PLAN_OBJECT_NUMBER).isin(plan_list))
# sum of amount gbp
sum_df = df_plan.groupBy('plan_object_number').agg(F.sum(df_plan.amount_gbp).alias('dim_sum'))
# count of plan and activity onb
cost_dim_plan_count = df_plan.select('plan_object_number').distinct().count()
cost_dim_activity_count = df_plan.select('activity_object_number').distinct().count()

# COMMAND ----------

#  plan object number count in staging
cost_plan_count = cost.select('plan_object_number').distinct().count()

#  get activity object number count in staging
cost_activity_count = cost.select('activity_object_number').distinct().count()

# calculating total amount gbp sum plan object number
staging_sum_df = cost.agg({'amount_gbp':'sum'})
staging_sum = staging_sum_df.collect()
staging_sum = round(float(staging_sum[0][0]),2)

# COMMAND ----------

# loading source cost data
source_cost = spark.read.format('csv')\
            .option('inferSchema','false')\
            .option('header','true')\
            .option('multiLine','true')\
            .option('delimiter','|')\
            .option('quote','"')\
            .option('escape','"')\
            .option('nullValue','null')\
          .load(cost_raw_path)
source_cost = source_cost.toDF(*(col.replace('\r', '') for col in source_cost.columns))
for col_name in source_cost.columns:
  source_cost = source_cost.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ' '))

# COMMAND ----------

#  counting source plan internal number
source_cost_plan_count = source_cost.select('plan_internal_number').distinct().count()

# counting source activity internal number / onb
source_cost_activity_count = source_cost.select('activity_onb').distinct().count()
# sum of aeac
source_sum_df = source_cost.agg({'aeac_gbp':'sum'})
source_sum = source_sum_df.collect()
source_sum = round(float(source_sum[0][0]),2)

# COMMAND ----------

# comparing plan count for staging table and in source for cost
new_df = source_cost.join(cost,source_cost.plan_internal_number == cost.PLAN_OBJECT_NUMBER,'leftanti')
new_df = new_df.select('plan_internal_number').distinct()
msg = ', '.join(map(str, [row['plan_internal_number'] for row in new_df.collect() ]))
row = [row['plan_internal_number'] for row in new_df.collect() ]
if len(row) == 0:
  logWarning('Notebook: plw_recon, ' + 'Entity: Cost, '+'RunID: ' + str(runid) +' - Number of Plan in OA and PLW are same for Cost forecast')
  cost_plan_flag = True
else:
  logError('Notebook: plw_recon, ' + 'Entity: Cost, ' +'RunID: ' + str(runid) +  ' - Following Plan are missing from OA for Cost forecast:-  ' + str(msg))
  cost_plan_flag = False

# COMMAND ----------

# comparing plan for dimension and facts table and in source for cost
new_df = source_cost.join(df_plan,source_cost.plan_internal_number == df_plan.plan_object_number,'leftanti')
new_df = new_df.select('plan_internal_number').distinct()
msg = ', '.join(map(str, [row['plan_internal_number'] for row in new_df.collect()]))
row = [row['plan_internal_number'] for row in new_df.collect() ]
if len(row) == 0:
  logWarning('Notebook: plw_recon, ' + 'Entity: Cost, '+'RunID: ' + str(runid) +' - Number of Plan in OA(dimension and facts) and PLW are same for Cost forecast')
  cost_dim_plan_flag = True
else:
  logError('Notebook: plw_recon, ' + 'Entity: Cost, ' +'RunID: ' + str(runid) +  ' - Following Plan are missing from OA(dimension and facts) for Cost forecast:-  ' + str(msg))
  cost_dim_plan_flag = False

# COMMAND ----------

# activity object number count for cost
new_df = source_cost.join(cost,source_cost.activity_onb == cost.ACTIVITY_OBJECT_NUMBER,'leftanti')
new_df = new_df.select('plan_internal_number').distinct()
msg = ', '.join(map(str, [row['plan_internal_number'] for row in new_df.collect() ]))
row = [row['plan_internal_number'] for row in new_df.collect() ]
if len(row) == 0:
  logWarning('Notebook: plw_recon, '+'Entity: Cost, ' +'RunID: ' + str(runid) +  ' -Activity in OA and PLW are same for Cost forecast')
  cost_activity_flag = True
else:
  logError('Notebook: plw_recon, '+'Entity: Cost, ' +'RunID: ' + str(runid) +  ' -Plan which has different Activity for Cost forecast :- ' + str(msg))
  cost_activity_flag = False

# COMMAND ----------

# log for activity onb if not matching with source(dimension and facts)
task_df = source_cost.join(df_plan,source_cost.activity_onb == df_plan.activity_object_number,'leftanti')
task_df = task_df.select('plan_internal_number').distinct()
msg = ', '.join(map(str, [row['plan_internal_number'] for row in task_df.collect()]))
row = [row['plan_internal_number'] for row in task_df.collect() ]
if len(row) == 0:
  logWarning('Notebook: plw_recon, ' + 'Entity: Cost, '+'RunID: ' + str(runid) +' - -Activity in OA(dimension and facts) and PLW are same for Cost forecast')
  cost_dim_activity_flag = True
else:
  logError('Notebook: plw_recon, ' + 'Entity: Cost, ' +'RunID: ' + str(runid) +  ' - Plan which has different Activity for Cost forecast(dimension and facts) :-  ' + str(msg))
  cost_dim_activity_flag = False 

# COMMAND ----------

source_cost = source_cost.withColumn('aeac_gbp',F.lit(source_cost.aeac_gbp).cast(DecimalType(38,5)))

# COMMAND ----------

#  getting plan wise sum of amount gbp from staging
df = cost.groupBy('plan_object_number').sum()
df = df.withColumnRenamed('sum(amount_gbp)','staging_sum_aeac')
df = df.select('plan_object_number','staging_sum_aeac')

# getting plan wise sum of amount gbp from source
df1 = source_cost.groupBy('plan_internal_number').agg(F.sum('aeac_gbp').alias('source_sum_aeac'))


# joining both the data frame
x = df.join(df1,df.plan_object_number == df1.plan_internal_number,'left')
x = x.withColumn('FLAG',(F.when((df1.source_sum_aeac) == (df.staging_sum_aeac),'TRUE').when((df1.source_sum_aeac) - (df.staging_sum_aeac) <= 0.9,'TRUE').otherwise('FALSE')))

# Finding if any plan has different amount gbp and logging the error 
msg = ', '.join(map(str, [row['plan_internal_number'] for row in x.collect() if row['FLAG'] == 'FALSE']))
row = [row['plan_internal_number'] for row in x.collect() if row['FLAG'] == 'FALSE']
# print(len(row))
if len(row) == 0:
  logWarning('Notebook: plw_recon, '+'Entity: Cost, ' +'RunID: ' + str(runid) +' - Sum of Cost forecast corresponding to a plan in OA matches with PLW')
  cost_sum_flag = True
else:
  logError('Notebook: plw_recon, '+'Entity: Cost, ' +'RunID: ' + str(runid) +' - Plans which has different Cost forecast in OA are:- ' + str(msg))
  cost_sum_flag = False

# COMMAND ----------

# log for amount gbp for dim and facts table if not matching with source
source_sum_df = source_cost.groupBy('plan_internal_number').agg(F.sum('aeac_gbp').alias('source_sum'))
sum_df = source_sum_df.join(sum_df,source_sum_df.plan_internal_number == sum_df.plan_object_number,'left')
sum_df = sum_df.withColumn('FLAG',(F.when(sum_df.source_sum == sum_df.dim_sum,'TRUE').when(sum_df.source_sum - sum_df.dim_sum <= 0.9,'TRUE')).otherwise('FALSE'))

msg = ', '.join(map(str, [row['plan_internal_number'] for row in sum_df.collect() if row['FLAG'] == 'FALSE']))
row = [row['plan_internal_number'] for row in sum_df.collect() if row['FLAG'] == 'FALSE' ]
if len(row) == 0:
  logWarning('Notebook: plw_recon, ' + 'Entity: Cost, '+'RunID: ' + str(runid) +' - Sum of Cost forecast corresponding to a plan in OA(dimension and facts) matches with PLW')
  cost_dim_sum_flag = True
else:
  logError('Notebook: plw_recon, ' + 'Entity: Cost, ' +'RunID: ' + str(runid) +  ' - Plans which has different Cost forecast in OA(dimension and facts) are:-  ' + str(msg))
  cost_dim_sum_flag = False

# COMMAND ----------

if ((cost_plan_flag == True) and (cost_activity_flag == True) and (cost_sum_flag == True)):
  cost_stag_flag = True
else:
  cost_stag_flag = False
  log_msg = log_msg + "Cost Forecast(Staging)|"
  
if ((cost_dim_plan_flag == True) and (cost_dim_activity_flag == True) and (cost_dim_sum_flag == True)):
  cost_dim_flag = True
else:
  cost_dim_flag = False
  log_msg = log_msg + "Cost Forecast(Dimension and Facts)|"

# COMMAND ----------

# DBTITLE 0,FTE Validation
#  comparing plan count for staging table and in source
if source_cost_plan_count == cost_plan_count:
  print('count is same')
else:
  print(abs(source_cost_plan_count - cost_plan_count))
  print('count is different')
  
#  comparing plan count for staging table and in source
if source_cost_plan_count == cost_dim_plan_count:
  print('count is same(dimension and facts)')
else:
  print(abs(source_cost_plan_count - cost_dim_plan_count))
  print('count is different(dimension and facts)')

# COMMAND ----------

# comparing activity count for staging and in source for cost
if source_cost_activity_count == cost_activity_count:
  print('count is same')
else:
  print(abs(source_cost_activity_count - cost_activity_count))
  print('count is different')
  
if source_cost_activity_count == cost_dim_activity_count:
  print('count is same(dimension and facts)')
else:
  print(abs(source_cost_activity_count - cost_dim_activity_count))
  print('count is different(dimension and facts)')

# COMMAND ----------

# comparing source and staging sum for amount gbp
if staging_sum == source_sum:
  print('Sum is equal')
else:
  print(abs(staging_sum - source_sum))
  print('Sum is different')

# COMMAND ----------

# Verifying fte data for source and staging.

# COMMAND ----------

# DBTITLE 1,FTE Validation
#  load irm_stg.resource_forecast table
fte =  spark.read \
  .format("com.databricks.spark.sqldw") \
  .option("url", sqlDwUrl) \
  .option("tempDir", tempDir) \
  .option("dbtable", "irm_stg.RESOURCE_FORECAST")\
  .option("forwardSparkAzureStorageCredentials", "true") \
  .load()

# read activity data from irm.d_task table
f_effort = spark.read \
  .format("com.databricks.spark.sqldw") \
  .option("url", sqlDwUrl) \
  .option("tempDir", tempDir) \
  .option("dbtable", "irm.F_ESTIMATED_EFFORT")\
  .option("forwardSparkAzureStorageCredentials", "true") \
  .load()

fte = fte.filter((fte.SOURCE == "PLW-NEW") & (fte.REFERENCE_OBJECT_NUMBER.isNull()))
f_effort = f_effort.filter((f_effort.DATA_ORIGIN =='PLW_RESOURCE_FORECAST') & (f_effort.DATA_SOURCE == 'PLW-NEW') & (f_effort.ESTIMATE_VERSION == 'Current Plan'))

# COMMAND ----------

# Joining facts and dimension table to get plan onb
fte_plan = f_effort.join(d_plan,f_effort.PLAN_KEY == d_plan.PLAN_KEY,'left')
# getting list of plan
y = fte_plan.select('plan_code').distinct()
y = y.collect()
fte_plan_list = []
for i in range(len(y)):
  fte_plan_list.append(y[i][0])
# Selecting required columns and plan onbs from the above list
fte_df = fte.select('plan_object_number','activity_object_number','std_ftes_forecast').filter((fte.PLAN_OBJECT_NUMBER).isin(fte_plan_list))
# Sum of std_ftes 
fte_sum_df = fte_df.groupBy('plan_object_number').agg(F.sum(fte_df.std_ftes_forecast).alias('fte_dim_sum'))

# COMMAND ----------

# getting row count for fte 

# getting plan object number count for fte
fte_plan_count = fte.select('plan_object_number').distinct().count()

# getting activity object number count for fte
fte_activity_count = fte.select('activity_object_number').distinct().count()

# count of plan and activity onbs
fte_dim_plan_count = fte_df.select('plan_object_number').distinct().count()
fte_dim_activity_count = fte_df.select('activity_object_number').distinct().count()

# COMMAND ----------

# getting overall sum of std_ftes_forecast for staging
fte_staging_sum_df = fte.agg({'STD_FTES_FORECAST':'sum'})
fte_staging_sum = fte_staging_sum_df.collect()
fte_staging_sum = round(float(fte_staging_sum[0][0]),2)

# COMMAND ----------

# loading source fte data
source_fte = spark.read.format('csv')\
            .option('inferSchema','false')\
            .option('header','true')\
            .option('multiLine','true')\
            .option('delimiter','|')\
            .option('quote','"')\
            .option('escape','"')\
            .option('nullValue','null')\
          .load(fte_raw_path)
source_fte = source_fte.toDF(*(col.replace('\r', '') for col in source_fte.columns))
for col_name in source_fte.columns:
  source_fte = source_fte.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ' '))

# COMMAND ----------

# getting plan internal number count for fte source
source_fte_plan_count = source_fte.select('plan_internal_number').distinct().count()

# getting activity onb count for fte source
source_fte_activity_count = source_fte.select('activity_onb').distinct().count()

# COMMAND ----------

# getting overall sum of std ftes for fte source
source_fte_sum_df = source_fte.agg({'fte':'sum'})
source_fte_sum = source_fte_sum_df.collect()
source_fte_sum = round(float(source_fte_sum[0][0]),2)

# COMMAND ----------

# Finding if any plan internal number is present in source but not in staging and logging the error
new_df = source_fte.join(fte,source_fte.plan_internal_number == fte.PLAN_OBJECT_NUMBER,'leftanti')
new_df = new_df.select('plan_internal_number').distinct()
msg = ', '.join(map(str, [row['plan_internal_number'] for row in new_df.collect()]))
row = [row['plan_internal_number'] for row in new_df.collect() ]
if len(row) == 0:
  logWarning('Notebook: plw_recon, '+ 'Entity: FTE, ' +'RunID: ' + str(runid) + ' -Plan in OA and PLW are same for FTE forecast')
  fte_plan_flag = True
else:
  logError('Notebook: plw_recon, '+ 'Entity: FTE, ' +'RunID: ' + str(runid) +' -Following Plan are missing from OA for FTE forecast  ' + str(msg))
  fte_plan_flag = False

# COMMAND ----------

# finding if any plan onb not present in dim and facts
new_fte_df = source_fte.join(fte_df,source_fte.plan_internal_number == fte_df.plan_object_number,'leftanti')
new_fte_df = new_fte_df.select('plan_internal_number').distinct()
msg = ', '.join(map(str, [row['plan_internal_number'] for row in new_fte_df.collect()]))
row = [row['plan_internal_number'] for row in new_fte_df.collect() ]
if len(row) == 0:
  logWarning('Notebook: plw_recon, ' + 'Entity: FTE, '+'RunID: ' + str(runid) +' - Number of Plan in OA(Dimension and Facts) and PLW are same for FTE forecast')
  fte_dim_plan_flag = True
else:
  logError('Notebook: plw_recon, ' + 'Entity: FTE, ' +'RunID: ' + str(runid) +  ' - Following Plan are missing from OA(Dimension and Facts) for FTE forecast:-  ' + str(msg))
  fte_dim_plan_flag = False 

# COMMAND ----------

#  Finding if any activity internal number is present in source but not in staging and logging the error
new_df = source_fte.join(fte,source_fte.activity_onb == fte.ACTIVITY_OBJECT_NUMBER,'leftanti')
new_df = new_df.select('plan_internal_number').distinct()
msg = ', '.join(map(str, [row['plan_internal_number'] for row in new_df.collect() ]))
row = [row['plan_internal_number'] for row in new_df.collect() ]
if len(row) == 0:
  logWarning('Notebook: plw_recon, ' + 'Entity: FTE, ' +'RunID: ' + str(runid) +' -Activity in OA and PLW are same for FTE forecast ')
  fte_activity_flag = True
else:
  logError('Notebook: plw_recon, '+ 'Entity: FTE, '  +'RunID: ' + str(runid) + ' -Plan which has different Activity in OA for FTE forecast:- ' + str(msg))
  fte_activity_flag = False

# COMMAND ----------

# finding if any activity onb onb not present in dim and facts
new_act_df = source_fte.join(fte_df,source_fte.activity_onb == fte_df.activity_object_number,'leftanti')
new_act_df = new_act_df.select('plan_internal_number').distinct()
msg = ', '.join(map(str, [row['plan_internal_number'] for row in new_act_df.collect()]))
row = [row['plan_internal_number'] for row in new_act_df.collect() ]
if len(row) == 0:
  logWarning('Notebook: plw_recon, ' + 'Entity: FTE, '+'RunID: ' + str(runid) +' - Number of Plan in OA(dimension and facts) and PLW are same for FTE forecast')
  fte_dim_activity_flag = True
else:
  logError('Notebook: plw_recon, ' + 'Entity: FTE, ' +'RunID: ' + str(runid) +  ' - Following Plan are missing from OA(dimension and facts) for FTE forecast:-  ' + str(msg))
  fte_dim_activity_flag = False

# COMMAND ----------

 # plan object number wise Sum for staging
df = fte.groupBy('plan_object_number').agg(F.sum('std_ftes_forecast').alias('staging_sum'))

 # plan object number wise Sum for source
df1 = source_fte.groupBy('plan_internal_number').agg(F.sum('fte').alias('source_sum'))

# Joining both
x = df.join(df1,df.plan_object_number == df1.plan_internal_number,'left')
x = x.withColumn('FLAG',(F.when((x.source_sum) == (x.staging_sum),'TRUE').when((x.source_sum) - (x.staging_sum) <= 0.9,'TRUE').otherwise('FALSE')))

# Finding if any plan internal number has different fte sum in staging and logging the error
msg = ', '.join(map(str, [row['plan_internal_number'] for row in x.collect() if row['FLAG'] == 'FALSE']))
row = [row['plan_internal_number'] for row in x.collect() if row['FLAG'] == 'FALSE']
if len(row) == 0:
  logWarning('Notebook: plw_recon, '+'Entity: FTE, '+ 'RunID: ' + str(runid) + ' - Sum of FTE forecast corresponding to a plan in OA matches with PLW')
  fte_sum_flag = True
else:
  logError('Notebook: plw_recon '+'Entity: FTE, ' +'RunID: ' + str(runid) + ' - Plan which has different FTE forecast in OA are:- ' + str(msg))
  fte_sum_flag = False

# COMMAND ----------

# Log if any fte sum for dim and facts is not matching with source
source_fte = source_fte.withColumn('fte',F.lit(source_fte.fte).cast('float'))
source_sum_fte = source_fte.groupBy('plan_internal_number').agg(F.sum(source_fte.fte).alias('fte_source_sum'))
sum_fte_df = source_sum_fte.join(fte_sum_df,source_sum_fte.plan_internal_number == fte_sum_df.plan_object_number,'left')
sum_fte_df = sum_fte_df.withColumn("FLAG",(F.when(source_sum_fte.fte_source_sum == fte_sum_df.fte_dim_sum,"TRUE").when(source_sum_fte.fte_source_sum - fte_sum_df.fte_dim_sum <= 0.9,"TRUE")).otherwise("FALSE"))

msg = ', '.join(map(str, [row['plan_internal_number'] for row in sum_fte_df.collect() if row['FLAG'] == 'FALSE']))
row = [row['plan_internal_number'] for row in sum_fte_df.collect() if row['FLAG'] == 'FALSE' ]
if len(row) == 0:
  logWarning('Notebook: plw_recon, ' + 'Entity: FTE, '+'RunID: ' + str(runid) +' -  - Sum of FTE forecast corresponding to a plan in OA(dimension and facts) matches with PLW')
  fte_dim_sum_flag = True
else:
  logError('Notebook: plw_recon, ' + 'Entity: FTE, ' +'RunID: ' + str(runid) +  ' - Plan which has different FTE forecast in OA(dimesnion and facts) are:-  ' + str(msg))
  fte_dim_sum_flag = False

# COMMAND ----------

if ((fte_plan_flag == True) and (fte_activity_flag == True) and (fte_sum_flag == True)):
  fte_stag_flag = True
else:
  fte_stag_flag = False
  log_msg = log_msg + "FTE Forecast(Staging)|"

if ((fte_dim_plan_flag == True) and (fte_dim_activity_flag == True) and (fte_dim_sum_flag == True)):
  fte_dim_flag = True
else:
  fte_dim_flag = False
  log_msg = log_msg + "FTE Forecast(Dimension and Facts)|"  

# COMMAND ----------

if source_fte_plan_count == fte_plan_count:
  print('Count is same')
else:
  print(abs(source_fte_plan_count - fte_plan_count))
  print('Count is different')
  
if source_fte_plan_count == fte_dim_plan_count:
  print('Count is same(dimension and facts)')
else:
  print(abs(source_fte_plan_count - fte_dim_plan_count))
  print('Count is different(dimension and facts)')

# COMMAND ----------

if source_fte_activity_count == fte_activity_count:
  print('Count is same')
else:
  print(abs(source_fte_activity_count - fte_activity_count))
  print('Count is different')
  
if source_fte_activity_count == fte_dim_activity_count:
  print('Count is same(dimension and facts)')
else:
  print(abs(source_fte_activity_count - fte_dim_activity_count))
  print('Count is different(dimension and facts)')

# COMMAND ----------

if source_fte_sum  == fte_staging_sum:
  print('sum is equal')
else:
  print(abs(source_fte_sum - fte_staging_sum))
  print('sum is different')

# COMMAND ----------

if ((plan_stag_flag == True) and (activity_stag_flag == True) and (cost_stag_flag == True) and (fte_stag_flag == True) and (plan_dim_flag == True) and (activity_dim_flag == True) and (cost_dim_flag == True) and (fte_dim_flag == True)):
  logInfo('Notebook: plw_recon '+'RunID: ' + str(runid) + ' -There is no variance between OA and Planisware for Plan/Activity/FTE Forecast & Cost forecast data in ' + environment + ' environment.')
else:
  logInfo('Notebook: plw_recon '+'RunID: ' + str(runid) + ' -There is variance between OA and Planisware for '+ log_msg +' data in ' + environment + ' environment.')