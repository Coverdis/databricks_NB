# Databricks notebook source
# MAGIC %scala
# MAGIC dbutils.widgets.text("query", "abc")

# COMMAND ----------

# MAGIC %scala
# MAGIC 
# MAGIC import java.util.Properties
# MAGIC import java.sql.DriverManager
# MAGIC 
# MAGIC val dbUsername = dbutils.secrets.get(scope = "azurekeyvault-databricks", key = "id-irm-sqldb-rw")
# MAGIC val dbPassword = dbutils.secrets.get(scope = "azurekeyvault-databricks", key = "pw-irm-sqldb-rw")
# MAGIC var dbDatabase = dbutils.secrets.get(scope = "azurekeyvault-databricks", key = "cfg-irm-datawarehouse-name")
# MAGIC var dbServer = dbutils.secrets.get(scope = "azurekeyvault-databricks", key = "cfg-irm-database-server-name")
# MAGIC val dbJdbcPort = "1433"
# MAGIC val dbUrl = s"jdbc:sqlserver://" + dbServer + ".database.windows.net:" + dbJdbcPort + ";database=" + dbDatabase + ";encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;"
# MAGIC 
# MAGIC val driverClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver"
# MAGIC 
# MAGIC val connectionProperties = new Properties()
# MAGIC 
# MAGIC connectionProperties.put("user", s"${dbUsername}")
# MAGIC connectionProperties.put("password", s"${dbPassword}")
# MAGIC connectionProperties.setProperty("Driver", driverClass)
# MAGIC 
# MAGIC val connection = DriverManager.getConnection(dbUrl, dbUsername, dbPassword)
# MAGIC val stmt = connection.createStatement()
# MAGIC 
# MAGIC val sql = dbutils.widgets.get("query")
# MAGIC stmt.execute(sql)
# MAGIC connection.close()