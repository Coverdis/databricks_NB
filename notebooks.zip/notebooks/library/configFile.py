# Databricks notebook source
# Prerequisites:
# 1. irm folder is created on blob storage path storage_account_name

# COMMAND ----------

environment = dbutils.secrets.get(scope = "azurekeyvault-databricks", key = "environment")

# SQL Data DB access settings
dbUser =  dbutils.secrets.get(scope = "azurekeyvault-databricks", key = "id-irm-sqldb-rw")
dbPass = dbutils.secrets.get(scope = "azurekeyvault-databricks", key = "pw-irm-sqldb-rw")
dbDatabase = dbutils.secrets.get(scope = "azurekeyvault-databricks", key = "cfg-irm-datawarehouse-name")
dbServer = dbutils.secrets.get(scope = "azurekeyvault-databricks", key = "cfg-irm-database-server-name")
dbJdbcPort =  "1433"
dbJdbcExtraOptions = "encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30"
sqlDwUrl = "jdbc:sqlserver://" + dbServer + ".database.windows.net:" + dbJdbcPort + ";database=" + dbDatabase + ";"+dbJdbcExtraOptions + ";user=" + dbUser+";password=" + dbPass

# COMMAND ----------

# Data lake gen 2 account access settings (mount foundation, raw, log, curated)

clientID = dbutils.secrets.get(scope = "azurekeyvault-databricks", key = "cfg-irm-client-id")
clientSecret = dbutils.secrets.get(scope = "azurekeyvault-databricks", key = "pw-irm-client-pwd")

configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": clientID,
           "fs.azure.account.oauth2.client.secret": clientSecret,
           "fs.azure.account.oauth2.client.endpoint": "https://login.microsoftonline.com/63982aff-fb6c-4c22-973b-70e4acfb63e6/oauth2/token"}

# COMMAND ----------

#Create mnt folder if not exists
rootdir = [str(i) for i in dbutils.fs.ls('/')]
folders = [rootdir[idx].lower().split(',')[1].split('=')[1].replace("/", "").replace("'", "") for idx, rows in enumerate(rootdir)] 

if 'mnt' not in folders:
  dbutils.fs.mkdirs('/mnt')

# COMMAND ----------

datalake_account_name = dbutils.secrets.get(scope = "azurekeyvault-databricks", key = "cfg-irm-datalake-account-name")
# "irmdatalakegen2"#dbutils.secrets.get(scope = "azurekeyvault-databricks", key = "cfg-irm-datalake-account-name")

mounts = [str(i) for i in dbutils.fs.ls('/mnt/')]
folders = [mounts[idx].lower().split(',')[1].split('=')[1].replace("/", "").replace("'", "") for idx, rows in enumerate(mounts)] 

mountName = 'raw'
if mountName in folders:
  print(mountName + " is already mounted")
else:
  dbutils.fs.mount(
  source = 'abfss://'+ mountName +'@' + datalake_account_name + '.dfs.core.windows.net',
  mount_point= "/mnt/" + mountName,
  extra_configs = configs)
  print(mountName + " is mounted")
  
mountName = 'log'
if mountName in folders:
  print(mountName + " is already mounted")
else:
  dbutils.fs.mount(
  source = "abfss://"+ mountName +"@" + datalake_account_name + ".dfs.core.windows.net",
  mount_point= "/mnt/" + mountName,
  extra_configs = configs)
  print(mountName + " is mounted")
  
mountName = 'foundation'
if mountName in folders:
  print(mountName + " is already mounted")
else:
  dbutils.fs.mount(
  source = "abfss://"+ mountName +"@" + datalake_account_name + ".dfs.core.windows.net",
  mount_point= "/mnt/" + mountName,
  extra_configs = configs)
  print(mountName + " is mounted")
  
mountName = 'curated'
if mountName in folders:
  print(mountName + " is already mounted")
else:
  dbutils.fs.mount(
  source = "abfss://"+ mountName +"@" + datalake_account_name + ".dfs.core.windows.net",
  mount_point= "/mnt/" + mountName,
  extra_configs = configs)
  print(mountName + " is mounted")
  
mountName = 'unified'
if mountName in folders:
  print(mountName + " is already mounted")
else:
  dbutils.fs.mount(
  source = "abfss://"+ mountName +"@" + datalake_account_name + ".dfs.core.windows.net",
  mount_point= "/mnt/" + mountName,
  extra_configs = configs)
  print(mountName + " is mounted")
  
mountName = 'downstream'
if mountName in folders:
  print(mountName + " is already mounted")
else:
  dbutils.fs.mount(
  source = "abfss://"+ mountName +"@" + datalake_account_name + ".dfs.core.windows.net",
  mount_point= "/mnt/" + mountName,
  extra_configs = configs)
  print(mountName + " is mounted")

# COMMAND ----------

# Storage blob account access settings for polybase

storage_account_name = dbutils.secrets.get(scope = "azurekeyvault-databricks", key = "cfg-irm-storage-account-name")
storage_account_access_key = dbutils.secrets.get(scope = "azurekeyvault-databricks", key = "pw-irm-storage-account-access-key")

file_type = "csv"
spark.conf.set(
  "fs.azure.account.key." + storage_account_name + ".blob.core.windows.net",
  storage_account_access_key)

# Prerequisite - irm folder is created on blob storage path storage_account_name
tempDir = "wasbs://irm@"+ storage_account_name +".blob.core.windows.net/TempDir"
RDIPDir = "wasbs://rdip@"+ storage_account_name +".blob.core.windows.net/"


# COMMAND ----------

# mount irmblobstorage
configs = {"fs.azure.account.key."+ storage_account_name +".blob.core.windows.net":dbutils.secrets.get(scope = "azurekeyvault-databricks", 
           key = "irm-blob-storage-key")}

mounts = [str(i) for i in dbutils.fs.ls('/mnt/')]
folders = [mounts[idx].lower().split(',')[1].split('=')[1].replace("/", "").replace("'", "") for idx, rows in enumerate(mounts)] 

mountName = 'rdip'
if mountName in folders:
  print(mountName + " is already mounted")
else:  
  dbutils.fs.mount(
  source = 'wasbs://'+ mountName + '@' + storage_account_name + '.blob.core.windows.net',
  mount_point= "/mnt/" + mountName,
  extra_configs = configs)
  print(mountName + " is mounted")

# COMMAND ----------

# # unmount mount point
# dbutils.fs.unmount("/mnt/log")
# dbutils.fs.unmount("/mnt/curated")
# dbutils.fs.unmount("/mnt/raw")
# dbutils.fs.unmount("/mnt/foundation")
# dbutils.fs.unmount("/mnt/unified")

# # refresh mount points
# dbutils.fs.refreshMounts()

# COMMAND ----------

# to configure the write semantics for Azure Synapse connector in the notebook session
spark.conf.set("spark.databricks.sqldw.writeSemantics", "polybase")

# COMMAND ----------

print("Environment setup complete") 

# COMMAND ----------

def file_exists(path):
  try:
    dbutils.fs.ls(path)
    return True
  except Exception as e:
    if 'java.io.FileNotFoundException' in str(e):
      return False
    else:
      raise