# Databricks notebook source
#File Name: LoadCuratedVxPLWActivity
#ADF Pipeline Name: 
#SQLDW Table: NA
  #Read Vx Planisware ACTIVITY data from ADL and load to curated layer

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

# MAGIC %run /source/Planisware/PLWConfig

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
from pyspark.sql.functions import explode
import os
from glob import glob
import re

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "888")
# dbutils.widgets.text("file_path", "")

runid = dbutils.widgets.get("runid")
# file_path = dbutils.widgets.get("file_path")

# COMMAND ----------

# read Vx activity data from foundation
vx_act = spark.read.format("csv")\
        .option("inferSchema","false")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("escape",  '"')\
        .option("delimiter","|")\
        .option("quote",  '"')\
        .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/vaccines/planisware/plw_activity.txt')

vx_act = vx_act.toDF(*(col.replace('\r', '') for col in vx_act.columns))
vx_act = vx_act.toDF(*(col.replace('.', '') for col in vx_act.columns))

# read Vx activity type data from foundation
vx_act_type = spark.read.format("csv")\
              .option("inferSchema","false")\
              .option("header","true")\
              .option("multiLine","true")\
              .option("escape",  '"')\
              .option("delimiter","|")\
              .option("quote",  '"')\
              .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/vaccines/planisware/plw_activity_type.txt')

vx_act_type = vx_act_type.toDF(*(col.replace('\r', '') for col in vx_act_type.columns))
vx_act_type = vx_act_type.toDF(*(col.replace('.', '') for col in vx_act_type.columns))

# COMMAND ----------

# getting attributes from Activity Type
vx_act = vx_act.join(vx_act_type.select('id', 'USER_ATTRIBUTE_PME_AT_ACT_IS_MLS', '_WT_AA_B_IS_GATE', 'user_attribute_pme_ua_at_b_study'), vx_act.wbs_type == vx_act_type.id, 'leftouter')
vx_act = vx_act.drop('id')

# COMMAND ----------

# renaming attributes
vx_act = vx_act.withColumnRenamed('USER_ATTRIBUTE_VACC_UA_PRJ_ONB', 'PLAN_OBJECT_NUMBER')
vx_act = vx_act.withColumnRenamed('USER_ATTRIBUTE_PME_UA_ACT_ACT_ONB', 'ACTIVITY_OBJECT_NUMBER')
vx_act = vx_act.withColumnRenamed('3BS', 'PROJECT_ID')
vx_act = vx_act.withColumnRenamed('_PM_DA_S_LINE_ID', 'ACTIVITY_LINE_ID')
vx_act = vx_act.withColumnRenamed('USER_ATTRIBUTE_PME_WPA_DESC', 'ACTIVITY_DESCRIPTION')
vx_act = vx_act.withColumnRenamed('DURATION', 'ACTIVITY_DURATION')
vx_act = vx_act.withColumnRenamed('USER_ATTRIBUTE_PME_ACT_PLAN_TYPE_DESC', 'ACTIVITY_FUNCTION_DESCRIPTION')
vx_act = vx_act.withColumnRenamed('VACC_RA_FUNCTION', 'ACTIVITY_FUNCTION_NAME')
vx_act = vx_act.withColumnRenamed('HIERARCHICAL_CODE', 'ACTIVITY_HIERARCHY_CODE')
# vx_act = vx_act.withColumnRenamed('NAME', 'ACTIVITY_NAME')
vx_act = vx_act.withColumnRenamed('_PM_DA_S_MSP_PREDECESSORS', 'ACTIVITY_PREDECESSOR_LINE_ID')
vx_act = vx_act.withColumnRenamed('_PM_DA_S_MSP_SUCCESSORS', 'ACTIVITY_SUCCESSOR_LINE_ID')
vx_act = vx_act.withColumnRenamed('NOTE_PAD', 'ACTIVITY_USER_COMMENT')
vx_act = vx_act.withColumnRenamed('USER_ATTRIBUTE_PME_DRVXT_NB_COUNTRIES', 'NUMBER_OF_COUNTRIES')
vx_act = vx_act.withColumnRenamed('USER_ATTRIBUTE_PME_DRVXT_NB_ABSTRACTS', 'NUMBER_OF_METHODS')
vx_act = vx_act.withColumnRenamed('USER_ATTRIBUTE_PME_DRVXT_NB_MANUSCRIPTS', 'NUMBER_OF_SAMPLES')
vx_act = vx_act.withColumnRenamed('USER_ATTRIBUTE_PME_DRVXT_NB_VISITS', 'NUMBER_OF_STUDY_VISITS')
# vx_act = vx_act.withColumnRenamed('USER_ATTRIBUTE_PME_DRVXT_NB_ASSAYS', 'NUMBER_OF_ASSESSMENTS')
vx_act = vx_act.withColumnRenamed('PROJECT', 'PLAN_NAME')
vx_act = vx_act.withColumnRenamed('USER_ATTRIBUTE_PME_UA_ACT_AT_SG_DESC', 'PLAN_PHASE_NAME')
vx_act = vx_act.withColumnRenamed('USER_ATTRIBUTE_PME_DRVXT_SAMPLE_SIZE', 'QUANTITY_OF_MATERIAL')
vx_act = vx_act.withColumnRenamed('WBS_TYPE', 'WBS_TYPE')
vx_act = vx_act.withColumnRenamed('USER_ATTRIBUTE_PME_WP_IS_A_STUDY', 'STUDY_FLAG')
vx_act = vx_act.withColumnRenamed('USER_ATTRIBUTE_PME_STUDY_ID', 'CLINICAL_STUDY_ID')
vx_act = vx_act.withColumnRenamed('VACC_NF_S_PLAN_TYPE', 'PLAN_TYPE_NAME')
vx_act = vx_act.withColumnRenamed('USER_ATTRIBUTE_PME_DRVXT_NB_ASSAYS', 'NUMBER_ASSAYS')
vx_act = vx_act.withColumnRenamed('USER_ATTRIBUTE_PME_AT_ACT_IS_MLS', 'ACTIVITY_MILESTONE_FLAG')
vx_act = vx_act.withColumnRenamed('USER_ATTRIBUTE_PME_DRVXT_STUDY_TYPE_CEG', 'STUDY_TYPE')
vx_act = vx_act.withColumnRenamed('TASK_TYPE', 'ACTIVITY_TASK_TYPE_NAME')

vx_act = vx_act.withColumn('SOURCE', F.lit('Vx-PLW'))

#display(vx_act)

# COMMAND ----------

vx_act = vx_act.withColumn('ACTIVITY_PLANNED_START_DATE', vx_act.real_start.cast(TimestampType()))
vx_act = vx_act.withColumn('ACTIVITY_PLANNED_END_DATE', vx_act.real_finish.cast(TimestampType()))
vx_act = vx_act.withColumn('ACTIVITY_ACTUAL_START_DATE', vx_act.effective_start.cast(TimestampType()))
vx_act = vx_act.withColumn('ACTIVITY_ACTUAL_END_DATE', vx_act.effective_finish.cast(TimestampType()))

vx_act = vx_act.withColumn('PLAN_OBJECT_NUMBER', F.lit(vx_act.PLAN_OBJECT_NUMBER.cast(LongType())))
vx_act = vx_act.withColumn('ACTIVITY_OBJECT_NUMBER', F.lit(vx_act.ACTIVITY_OBJECT_NUMBER.cast(LongType())))

vx_act = vx_act.withColumn('ACTIVITY_SCOPE_NAME', F.when(vx_act.user_attribute_pme_ua_at_is_ivp_ms == 'YES', 'Project Milestone').when((vx_act.user_attribute_pme_ua_at_b_study == 'YES') & (vx_act.ACTIVITY_MILESTONE_FLAG == 'YES'),'Study Milestone').when(vx_act.vacc_nf_b_act_is_a_wp == 'YES', 'Work Package').otherwise(F.lit(None)))

# COMMAND ----------

# adding null references for missing attributes
vx_act = addNullReference(vx_act, spark.createDataFrame([activity_cols], activity_cols))

# COMMAND ----------

# stagedf = spark.read.format("com.databricks.spark.sqldw")\
#   .option("url", sqlDwUrl)\
#   .option( "forward_spark_azure_storage_credentials", "True")\
#   .option("tempdir", tempDir)\
#   .option("maxStrLength", 4000)\
#   .option("dbtable", "irm_stg.PLW_ACTIVITY") \
#   .load()

# #display(stagedf)

# COMMAND ----------

# deltacols = set(stagedf.columns) - set(vx_act.columns)

# for col in deltacols:
#   vx_act = vx_act.withColumn(col, F.lit(None).cast(StringType()))

# COMMAND ----------

# cols = ['PLAN_OBJECT_NUMBER', 'ACTIVITY_OBJECT_NUMBER', 'ACTIVITY_NAME', 'ACTIVITY_DESCRIPTION', 'PLAN_NAME', 'CLINICAL_STUDY_ID', 'VESTED_UNIT_NAME', 'PROJECT_ID', 'WBS_TYPE', 'ACTIVITY_PLANNED_START_DATE', 'ACTIVITY_PLANNED_END_DATE', 'ACTIVITY_ACTUAL_START_DATE', 'ACTIVITY_ACTUAL_END_DATE', 'ACTIVITY_LINE_ID', 'PLAN_PHASE_NAME', 'PREDECESSORS', 'SUCCESSORS', 'ACTIVITY_SCOPE_NAME', 'SYNC_ISSUE', 'PAIR_DIFFERENTIATOR', 'BUDID_PROPAGATED', 'ACTIVITY_CLASS_TYPE_NAME', 'ACTIVITY_CLASS_TYPE_DESCRIPTION', 'ACTIVITY_ID', 'ACTIVITY_VERSION_INTERNAL_ID', 'PLAN_FILE_NAME', 'ACTIVITY_USER_COMMENT', 'WBS_ELEMENT_FLAG', 'ACTIVITY_TASK_FLAG', 'ACTIVITY_PARENT_ID', 'ACTIVITY_IMPOSED_START_DATE', 'ACTIVITY_IMPOSED_FINISH_DATE', 'ACTIVITY_DURATION', 'ACTIVITY_TOTAL_FLOAT_DURATION', 'ACTIVITY_FREE_FLOAT_DURATION', 'ACTIVITY_CALENDER_TOTAL_FLOAT_DURATION', 'ACTIVITY_CALENDER_FREE_FLOAT_DURATION', 'ACTIVITY_CALENDER_NAME', 'ACTIVITY_PROGRESS_DATE', 'ACTIVITY_EXTENDIBLE_TYPE_NAME', 'ACTIVITY_PRECEDENT_START_DATE', 'ACTIVITY_PRECEDENT_END_DATE', 'ACTIVITY_CALENDER_FLOAT_FLAG', 'ACTIVITY_START_FLAG', 'ACTIVITY_FINISH_FLAG', 'ACTIVITY_PROGRESS_PECENTAGE', 'BUDGET_START_DATE', 'BUDGET_END_DATE', 'BUDGET_DURATION', 'THERAPY_AREA_SHORT_NAME', 'COMPOUND_ASSET_LONG_NAME', 'DISEASE_NAME', 'INDICATION_NAME', 'BS_6', 'BS_7', 'BS_9', 'ACTIVITY_LAST_MODIFICATION_DATE', 'ATIVITY_HIERARCHY_CODE', 'ACTIVITY_SEQUENCE_NUMBER', 'ORIGIN_NUMBER', 'PLAN_ID', 'ACTIVITY_ORIGIN_ID', 'SOURCE_ACTIVITY_ID', 'ACTIVITY_LAST_SYNCHRONISATION_DATE', 'ACTIVITY_LAST_SYNCHRONISED_VERSION', 'ACTIVITY_LAST_SYNCHRONISED_RULE_NAME', 'ACTIVITY_TASK_TYPE_NAME', 'ACTIVITY_ALLOCATION_COUNT', 'ACTIVITY_WORK_STRUCTURE_COUNT', 'ACTIVITY_PLAN_COUNT', 'ACTIVITY_TIME_SYNTHESIS_COUNT', 'ACTIVITY_LAST_MODIFICATION_BY', 'ACTIVITY_EARLIEST_END_DATE', 'ACTIVITY_LATEST_START_DATE', 'ACTIVITY_INTERFACE_FLAG', 'WP_LIBRARY_INTERNAL_NUMBER', 'WP_LIBRARY_VERSION_NUMBER', 'WP_LIBRARY_INTERNAL_NAME', 'WP_LIBRARY_VERSION_NAME', 'ACTIVITY_MILESTONE_FLAG', 'ACTIVITY_SYNCHRONISE_INDICATOR', 'TARGET_ACTIVITY_ID', 'SOURCE_PLAN_FINISH_SYNCHRONISATION_DATE', 'SYNCHRONISATION_TARGET_PLAN_START_DATE', 'SOURCE_PLAN_START_SYNCHRONISATION_DATE', 'ACTIVITY_START_MILESTONE_FLAG', 'SYNCHRONISATION_TARGET_PLAN_FINISH_DATE', 'TARGET_PLAN_START_SYNCHRONISATION_DATE', 'TARGET_PLAN_FINISH_SYNCHRONISATION_DATE', 'ACTIVITY_SUCCESSOR_LINE_ID', 'ACTIVITY_PREDECESSOR_LINE_ID', 'ACTIVITY_IN_HOUSE_FLAG', 'GLP_FLAG', 'TEMPORARY_CLINICAL_STUDY_ID', 'ACTIVITY_LAUNCH_FLAG', 'ACTIVITY_DECISION_POINT_FLAG', 'ACTIVITY_INTEGRITY_CHECK_FLAG', 'ACTIVITY_USER_COMMENT_1', 'ACTIVITY_USER_FLAG', 'ACTIVITY_USER_COMMENT_2', 'ACTIVITY_USER_COMMENT_3', 'ACTIVITY_USER_COMMENT_4', 'SPECIES_NAME', 'ACTIVITY_FUNDING_STATUS_TYPE_NAME', 'GSK_SITE_NAME', 'CRO_SITE_NAME', 'ROA_TYPE_NAME', 'ACTIVITY_SUB_TYPE_NAME', 'ACTIVITY_NEGATIVE_LAG_FLAG', 'STUDY_FLAG', 'ACTIVITY_POSITIVE_LAG_FLAG', 'ACTIVITY_PREDECESSOR_CALENDER_MATCH_FLAG', 'ACTIVITY_BROKEN_LOGIC_FLAG', 'ACTIVITY_SOURCE_DATE_MISMATCH_FLAG', 'ACTIVITY_LARGE_LAG_FLAG', 'WBS_LINK_FLAG', 'ACTIVITY_INTERNAL_NAME', 'PSAP_FLAG', 'ACTIVITY_FUNCTION_NAME', 'ACTIVITY_FUNCTION_DESCRIPTION', 'PLAN_INTERNAL_ID', 'ACTIVITY_SUB-FUNCTION_NAME', 'ACTIVITY_PLAN_NAME', 'MDP_FLAG', 'PLAN_TYPE_NAME', 'CSAP_FLAG', 'PAIRING_TYPE', 'PAIRING_STATUS', 'ACTIVITY_SYNCHRONIZATION_NEEDED', 'ACTIVITY_USED_FOR_SYNC', 'DURATION', 'LEVEL', 'ACTIVITY_HIERARCHY_CODE', 'WORK_PACKAGE_CODE', 'CRITICAL_PATH', 'PROJECT_GROUP_CRITICAL_PATH_FLAG', 'ACTIVITY_RESOURCE_STRATEGY', 'BIOSTATS_RESOURCE_STRATEGY', 'ACTIVITY_RESOURCE_ID','NUMBER_OF_CENTERS', 'NUMBER_OF_STUDY_VISITS', 'COUNTRY', 'PLANNED_NUMBER_OF_PATIENTS', 'NUMBER_OF_DOSE_GROUPS', 'NEW_PROCESS_TECHNOLOGY_OR_PLATFORM', 'NUMBER_OF_ASSESSMENTS', 'STUDY_RESOURCE_STRATEGY', 'STUDY_BLINDING', 'NUMBER_OF_STAGES', 'QUANTITY_OF_MATERIAL', 'NUMBER_OF_SAMPLES', 'METHOD_VALIDATION', 'NUMBER_OF_BATCHES', 'SAME_PLANT_SITE', 'MANUFACTURE_TYPE', 'PARTNERSHIP_TYPE', 'STUDY_PHASE', 'STUDY_TYPE', 'STUDY_DESIGNATION', 'NON_TRADITIONAL_STUDY_DESIGN', 'NON_STANDARD_MOLECULE', 'SPECIFIC_HAZARD', 'FORMULATION_TYPE', 'NUMBER_OF_METHODS', 'NUMBER_OF_COUNTRIES', 'NUMBER_OF_IMAGES','MILESTONE_LONG_NAME', 'MILESTONE_SHORT_NAME', 'MILESTONE_ABBREVIATION', 'MILESTONE_SORT_ORDER', 'MILESTONE_PHASE_PROGRESSION', 'MILESTONE_SYNONYM', 'MILESTONE_CALC_GROUP', 'MILESTONE_CALC_MEMBER', 'PLANISWARE_ACTIVITY_TYPE', 'FIRST_SUBMISSION_MILESTONE', 'FIRST_APPROVAL_MILESTONE', 'FIRST_LAUNCH_MILESTONE', 'NEXT_PLANNED_MILESTONE', 'NEXT_PLANNED_DECISION_POINT_MILESTONE', 'LATEST_ACHIEVED_MILESTONE', 'LATEST_ACHIEVED_COMMIT_TO_MILESTONE','MILESTONE_STATUS','REFERENCE_OBJECT_NUMBER',
        
# 'PERSISTANT_OBJECT_NUMBER','COMPANION_DIAGNOSTICS','CMC_COMPLEXITY','GRPD_COMPLEXITY','NCR_COMLEXITY','TG_COMPLEXITY','SERM_COMPLEXITY','CANDIDATE_SELECTION','CPMS_RESOURCE_STRATEGY','CONFIRM_PROGRESS','NUMBER_BIOMARKER_TYPES','NUMBER_TARGETS','ACTIVITY_BASIS','ACTIVITY_ASSAY','NUMBER_CONSTRUCTS','NUMBER_MOLECULES','NUMBER_TISSUES','ACTIVITY_REAGENT','THROUGHPUT_ASSAY','TARGET_CLASS','NUMBER_HITS','NUMBER_ASSAYS','NUMBER_ANTIBODIES','NUMBER_INSERTED_GENES','CELL_TYPE','NUMBER_MODELS','NUMBER_SERIES','GENE_TECHNIQUE','NUMBER_CHEM_TRANSFORMATION','BUDGET_ID','SOURCE']

vx_act = vx_act.select(activity_cols)

# COMMAND ----------

vx_act = vx_act.dropna(how = 'all', subset = ('PLAN_OBJECT_NUMBER'))
vx_act = vx_act.dropna(how = 'all', subset = ('ACTIVITY_OBJECT_NUMBER'))

# COMMAND ----------

# write to curated
rawPath = 'dbfs:/mnt/raw/vaccines/'
unique_run_id = runid + '-LoadVxPLWPlan/'
csv_temp_curated = rawPath + unique_run_id + '/' + 'curated/'
curatedPath = 'dbfs:/mnt/curated/vaccines/planisware/'

vx_act.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + "vx_plw_activity.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)