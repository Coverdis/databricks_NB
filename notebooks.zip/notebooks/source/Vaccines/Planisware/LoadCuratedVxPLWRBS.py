# Databricks notebook source
#File Name: LoadCuratedPLWRBS
#ADF Pipeline Name: VxPlanisware_ADL
#SQLDW Table: NA
#Description:
  #Read Vaccines Planisware RBS data from ADL and load to curated ADL  

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
from pyspark.sql.functions import explode
processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "111")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

# read activity data
df = spark.read.format("csv")\
      .option("inferSchema","false")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter",",")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/vaccines/planisware/bi_av.csv')

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

# COMMAND ----------

# df = df.withColumn('ID', F.concat(F.regexp_replace('user_attribute_pme_ua_av_role', ' ', ''), df.user_attribute_pme_ra_av_rdc))
df = df.withColumnRenamed('user_attribute_pme_ua_av_role', 'ID')
df = df.withColumn('RBS_ID', F.lit(df.ID))
df = df.withColumn('INACTIVE', F.when(df.user_attribute_pme_ua_av_inactive_role == 'NO', 'false')\
                                .when(df.user_attribute_pme_ua_av_inactive_role == 'YES', 'true')\
                                .otherwise(df.user_attribute_pme_ua_av_inactive_role))
df = df.withColumn('LVL1_RBS_DESC', F.lit('GSK'))
df = df.withColumn('LVL2_RBS_DESC', F.lit('GSK Vaccines RD'))
df = df.withColumnRenamed('user_attribute_pme_ua_av_vet1', 'LVL3_RBS_DESC')
df = df.withColumn('LVL4_RBS_DESC', F.lit(df.LVL3_RBS_DESC).cast(StringType()))
df = df.withColumnRenamed('user_attribute_pme_ua_av_vet2', 'LVL5_RBS_DESC')
# df = df.withColumnRenamed('user_attribute_pme_ua_av_role', 'LVL6_RBS_DESC')
df = df.withColumn('LVL6_RBS_DESC', F.lit(df.ID))
df = df.withColumnRenamed('Rate', 'RATE')
df = df.withColumn('RATE_UNIT', F.lit('hour').cast(StringType()))

# COMMAND ----------

# # rename fields
# rbs = rbs.withColumnRenamed('OBJECT_NUMBER', 'RBS_OBJECT_NUMBER')
# rbs = rbs.withColumnRenamed('user_attribute_gsk_ua_resource_id', 'RBS_ID')
# rbs = rbs.withColumnRenamed('name', 'RBS_DESCRIPTION')
# rbs = rbs.withColumnRenamed('time_unit', 'RATE_UNIT')
# rbs = rbs.withColumnRenamed('level', 'LEVEL')
# rbs = rbs.withColumnRenamed('cost_unit', 'RATE_TYPE')
# rbs = rbs.withColumnRenamed('cost_value', 'RATE')
# rbs = rbs.withColumnRenamed('hierarchical_code', 'HIERARCHICAL_CODE')
# rbs = rbs.withColumnRenamed('inactive', 'INACTIVE')
# rbs = rbs.withColumnRenamed('order_number', 'ORDER_NUMBER')
# rbs = rbs.withColumnRenamed('element_of', 'PARENT_ID')
# rbs = rbs.withColumnRenamed('id', 'ID')

# rbs.createOrReplaceTempView('rbs_view')

# COMMAND ----------

# query="select  lvl6.id,rbs_id,lvl6_RBS_DESC,lvl6_order_number,inactive,rate_unit,rate_type,rate,lvl5_RBS_DESC,lvl5_order_number,lvl4_RBS_DESC,lvl4_order_number,lvl3_RBS_DESC,lvl3_order_number,lvl2_RBS_DESC,lvl2_order_number,lvl1_RBS_DESC,lvl1_order_number from \
# (select id,rbs_id,parent_id,comment as lvl6_RBS_DESC,order_number  as lvl6_order_number,inactive,rate_unit,rate_type,rate from rbs_view where  level=6)lvl6, \
# (select id,parent_id,comment as lvl5_RBS_DESC,order_number as lvl5_order_number from rbs_view where level=5) lvl5, \
# (select id,parent_id,comment as lvl4_RBS_DESC,order_number as lvl4_order_number from rbs_view where level=4) lvl4, \
# (select id,parent_id,comment as lvl3_RBS_DESC,order_number as lvl3_order_number from rbs_view where level=3) lvl3, \
# (select id,parent_id,comment as lvl2_RBS_DESC,order_number as lvl2_order_number from rbs_view where level=2) lvl2, \
# (select id,parent_id,comment as lvl1_RBS_DESC,order_number as lvl1_order_number from rbs_view where level=1) lvl1 \
# where lvl5.id=lvl6.parent_id \
# and lvl4.id=lvl5.parent_id \
# and lvl3.id=lvl4.parent_id \
# and lvl2.id=lvl3.parent_id \
# and lvl1.id=lvl2.parent_id"
# rbs = sqlContext.sql(query)
# rbs = rbs.withColumn('SOURCE', F.lit('PLW-NEW').cast(StringType()))

# COMMAND ----------

# write to curated
rawPath = 'dbfs:/mnt/raw/planisware/'
unique_run_id = runid + '-LoadPLWRBS/'
csv_temp_curated = rawPath + unique_run_id + '/' + 'curated/'
curatedPath = 'dbfs:/mnt/curated/vaccines/planisware/'

df.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + "vx_plw_rbs_hierarchy.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)