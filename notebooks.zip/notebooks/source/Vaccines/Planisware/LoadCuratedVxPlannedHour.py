# Databricks notebook source
#File Name: LoadCuratedVxPlannedHour
#ADF Pipeline Name: VxPLM_ADL
#SQLDW Table: NA 
  # Read Vx Planisware Planned Hour data from foundation and load to curated

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
from pyspark.sql.functions import explode
import numpy as np
import os
from glob import glob
import re

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "111")

runid = dbutils.widgets.get("runid")

# COMMAND ----------

# read planned hour file from foundation
planned_hour = spark.read.format("csv")\
        .option("inferSchema","false")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("escape",  '"')\
        .option("delimiter","|")\
        .option("quote",  '"')\
        .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/vaccines/planisware/plw_bi_ph.txt')

planned_hour = planned_hour.toDF(*(col.replace('\r', '') for col in planned_hour.columns))
planned_hour = planned_hour.toDF(*(col.replace('.', '') for col in planned_hour.columns))
planned_hour = planned_hour.toDF(*[x.upper() for x in planned_hour.columns])

planned_hour = planned_hour.withColumn('user_attribute_pme_ua_ph_act_onb',F.regexp_replace(F.col('user_attribute_pme_ua_ph_act_onb'), "[,]", ""))

# COMMAND ----------

planned_hour = planned_hour.filter('VACC_DA_SNAPSHOT_1 in ("Common", "New")')

# COMMAND ----------

# read activity data from curated
vx_plan = spark.read.format("csv")\
        .option("inferSchema","false")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("escape",  '"')\
        .option("delimiter","|")\
        .option("quote",  '"')\
        .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/vaccines/planisware/plw_project.txt')

vx_plan = vx_plan.toDF(*(col.replace('\r', '') for col in vx_plan.columns))
vx_plan = vx_plan.toDF(*(col.replace('.', '') for col in vx_plan.columns))

# COMMAND ----------

vx_plan = vx_plan.filter('vacc_ra_prj_status = "Active" and vacc_ra_prj_plt in ("CL", "TD", "CT", "PI", "VD", "MA", "RD", "PC", "ER", "SF", "RA", "VE", "PU")').select('OBJECT_NUMBER')

print(vx_plan.count())

# COMMAND ----------

# read activity data from curated
vx_act = spark.read.format("csv")\
        .option("inferSchema","false")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("escape",  '"')\
        .option("delimiter","|")\
        .option("quote",  '"')\
        .option("nullValue","null")\
  .load('dbfs:/mnt/curated/vaccines/planisware/vx_plw_activity.txt')

vx_act = vx_act.toDF(*(col.replace('\r', '') for col in vx_act.columns))
vx_act = vx_act.toDF(*(col.replace('.', '') for col in vx_act.columns))

for col_name in vx_act.columns:
  vx_act = vx_act.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

# COMMAND ----------

# vx_act = vx_act.filter("PLAN_OBJECT_NUMBER in ('121080786675','120583714575','121080675075')")

vx_act = vx_act.join(vx_plan, vx_plan.OBJECT_NUMBER == vx_act.PLAN_OBJECT_NUMBER, 'inner')

# COMMAND ----------

df = planned_hour.join(vx_act, planned_hour.user_attribute_pme_ua_ph_act_onb == vx_act.ACTIVITY_OBJECT_NUMBER, 'inner').select(['user_attribute_pme_ua_ph_result', 'user_attribute_pme_ua_ph_role', 'start_date', 'end_date', 'ACTIVITY_OBJECT_NUMBER', 'ACTIVITY_PLANNED_START_DATE', 'ACTIVITY_PLANNED_END_DATE', 'PLAN_OBJECT_NUMBER', 'USER_ATTRIBUTE_PME_UA_PH_VET2']).where('ACTIVITY_PLANNED_START_DATE is not null and ACTIVITY_PLANNED_END_DATE is not null and ACTIVITY_MILESTONE_FLAG = "NO"')

# COMMAND ----------

print(df.count())

# COMMAND ----------

# udf to calculate business days in a date range
@F.udf(returnType = IntegerType())
def getBusinessDays(sdate,edate):
    b_days = np.busday_count(sdate,edate)
    return int(b_days)

# COMMAND ----------

# splitting ftes monthly per activity for a role
df = df.withColumn("monthdiff", F.abs(F.months_between(F.date_add(F.last_day(F.add_months(df.ACTIVITY_PLANNED_START_DATE, -1)), 1),\
                                                       F.last_day(df.ACTIVITY_PLANNED_END_DATE))))\
    .withColumn("iterate", F.expr("split(repeat(',', monthdiff), ',')"))\
    .select("*", F.posexplode("iterate").alias("cnt", "val"))\
    .withColumn('temp_date', F.expr("add_months(ACTIVITY_PLANNED_START_DATE, cnt)"))

df = df.withColumn("month_start", F.when(df.cnt == '0', F.expr("add_months(ACTIVITY_PLANNED_START_DATE, cnt)"))\
                    .otherwise(F.lit(F.date_add(F.last_day(F.add_months(df.temp_date, -1)), 1))))

df = df.withColumn("month_end", F.when(F.month(df.ACTIVITY_PLANNED_END_DATE) == F.month(df.month_start), F.lit(F.to_date(df.ACTIVITY_PLANNED_END_DATE)))\
                    .otherwise(F.last_day(df.month_start)))

df = df.withColumn('days', F.lit(F.abs(getBusinessDays('month_start', 'month_end'))))\
       .drop(*['monthdiff', 'iterate', 'val'])

# COMMAND ----------

df = df.withColumn('sum', F.sum('days').over(Window.partitionBy(['ACTIVITY_OBJECT_NUMBER','USER_ATTRIBUTE_PME_UA_PH_ROLE'])))
df = df.withColumn('STD_FTES_FORECAST', (df.days * df.user_attribute_pme_ua_ph_result)/df.sum)

# COMMAND ----------

print(df.filter('ACTIVITY_PLANNED_START_DATE > ACTIVITY_PLANNED_END_DATE').count())
print(df.filter('std_ftes_forecast is not null').count())

# COMMAND ----------

# renaming columns
df = df.withColumnRenamed('USER_ATTRIBUTE_PME_UA_PH_ROLE', 'RBS')
# df = df.withColumnRenamed('STD_FTES_FORECAST', 'fte')

# creating null referernces
df = df.withColumn('ACTIVITY_VERSION_TYPE', F.lit(None).cast(StringType()))
# df = df.withColumn('ACTIVITY_BASELINE_NAME', F.lit(None).cast(StringType()))
# df = df.withColumn('ACTIVITY_BASELINE_TYPE', F.lit(None).cast(StringType()))
# df = df.withColumn('ORIGINAL_RATE', F.lit(None).cast(StringType()))
df = df.withColumn('AMOUNT_GBP', F.lit(None).cast(StringType()))
df = df.withColumn('WBS_TYPE', F.lit(None).cast(StringType()))
df = df.withColumn('PLANNED_SITES', F.lit(None).cast(StringType()))
df = df.withColumn('FORECASTED_IN_CSAP', F.lit(None).cast(StringType()))
df = df.withColumn('REFERENCE_OBJECT_NUMBER', F.lit(None).cast(LongType()))

# creating new columns for staging schema
df = df.withColumn('YEAR', F.year(df.month_start))
df = df.withColumn('MONTH', F.month(df.month_start))
df = df.withColumn('COST_TYPE', F.lit('IPE').cast(StringType()))
df = df.withColumn('COUNTRY', F.lit('Not-Defined').cast(StringType()))
df = df.withColumn('RESOURCE_TYPE', F.lit('FTE').cast(StringType()))
df = df.withColumn('SOURCE', F.lit('Vx-PLW').cast(StringType()))

# COMMAND ----------

df = df.select('ACTIVITY_OBJECT_NUMBER', 'RBS', 'USER_ATTRIBUTE_PME_UA_PH_VET2', 'STD_FTES_FORECAST', 'YEAR', 'MONTH', 'RESOURCE_TYPE', 'ACTIVITY_VERSION_TYPE', 'PLAN_OBJECT_NUMBER','WBS_TYPE','AMOUNT_GBP','COST_TYPE','COUNTRY','PLANNED_SITES', 'FORECASTED_IN_CSAP', 'REFERENCE_OBJECT_NUMBER', 'SOURCE')

# COMMAND ----------

print(df.count())

# COMMAND ----------

# write to curated
rawPath = 'dbfs:/mnt/raw/vaccines/'
unique_run_id = runid + '-LoadVxPLWPlannedHour/'
csv_temp_curated = rawPath + unique_run_id + '/' + 'curated/'
curatedPath = 'dbfs:/mnt/curated/vaccines/planisware/'

df.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + "vx_plw_planned_hour.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)