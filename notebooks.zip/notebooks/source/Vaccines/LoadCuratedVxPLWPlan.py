# Databricks notebook source
#File Name: LoadCuratedVxPLWPlan
#ADF Pipeline Name: 
#SQLDW Table: NA 
  #Read Vx Planisware PLAN data from ADL and load to curated layer

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

# MAGIC %run /source/Planisware/PLWConfig

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
from pyspark.sql.functions import explode
import os
from glob import glob
import re

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "111")
# dbutils.widgets.text("file_path", "")

runid = dbutils.widgets.get("runid")
# file_path = dbutils.widgets.get("file_path")

# COMMAND ----------

# read plan data from foundation
vx_plan = spark.read.format("csv")\
        .option("inferSchema","false")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("escape",  '"')\
        .option("delimiter","|")\
        .option("quote",  '"')\
        .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/vaccines/planisware/plw_project.txt')

vx_plan = vx_plan.toDF(*(col.replace('\r', '') for col in vx_plan.columns))
vx_plan = vx_plan.toDF(*(col.replace('.', '') for col in vx_plan.columns))


#for col_name in vx_plan.columns:
  #vx_plan = vx_plan.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

# COMMAND ----------

vx_plan = vx_plan.dropna(how = 'all', subset = 'OBJECT_NUMBER')

# COMMAND ----------

# read activity data from foundation
vx_act = spark.read.format("csv")\
        .option("inferSchema","false")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("escape",  '"')\
        .option("delimiter","|")\
        .option("quote",  '"')\
        .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/vaccines/planisware/plw_activity.txt')

vx_act = vx_act.toDF(*(col.replace('\r', '') for col in vx_act.columns))
vx_act = vx_act.toDF(*(col.replace('.', '') for col in vx_act.columns))

#for col_name in vx_plan.columns:
  #vx_plan = vx_plan.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

# COMMAND ----------

# renaming attributes
vx_plan = vx_plan.withColumnRenamed('ID', 'PLAN_NAME')
vx_plan = vx_plan.withColumnRenamed('_PV_AA_S_STATUS', 'PROJECT_PLAN_STATUS')
vx_plan = vx_plan.withColumnRenamed('USER_ATTRIBUTE_PME_UA_S_CURRENT_PRJ_PHASE', 'PLAN_CURRENT_PHASE')
vx_plan = vx_plan.withColumnRenamed('USER_ATTRIBUTE_VACC_UA_PRJ_OWNER_NAME', 'PLAN_OWNER_NAME')
vx_plan = vx_plan.withColumnRenamed('OWNER', 'PLAN_OWNER_ID')
vx_plan = vx_plan.withColumnRenamed('_PV_NF_S_VERSION', 'PLAN_VERSION_NUMBER')
vx_plan = vx_plan.withColumnRenamed('VACC_NF_S_MDM_STREAM_CODE', 'PROJECT_ID')
vx_plan = vx_plan.withColumnRenamed('VACC_RA_PRJ_PLT', 'PLAN_TYPE_NAME')
vx_plan = vx_plan.withColumnRenamed('OBJECT_NUMBER', 'PLAN_OBJECT_NUMBER')
vx_plan = vx_plan.withColumnRenamed('USER_ATTRIBUTE_PME_PLAN_TYPE_DESC', 'PLAN_TYPE_DESCRIPTION')
vx_plan = vx_plan.withColumnRenamed('LAST_MODIFICATION_USER', 'PLAN_LAST_MODIFIED_BY')
# vx_plan = vx_plan.withColumnRenamed('USER_ATTRIBUTE_PME_PROJECT_STATUS', 'PROJECT_STATUS')

# COMMAND ----------

# getting PROJECT_STATUS from activity df
vx_plan = vx_plan.join(vx_act, vx_plan.PLAN_NAME == vx_act.project, 'leftouter').select('PLAN_LAST_MODIFIED_BY', 'PLAN_OBJECT_NUMBER', 'PLAN_OWNER_ID', 'PLAN_TYPE_DESCRIPTION', 'PLAN_OWNER_NAME', 'PLAN_TYPE_NAME', 'PLAN_NAME', 'PLAN_VERSION_NUMBER', 'PROJECT_PLAN_STATUS', 'PLAN_CURRENT_PHASE', 'PROJECT_ID', 'USER_ATTRIBUTE_PME_PROJECT_STATUS')

vx_plan = vx_plan.drop_duplicates(['PLAN_OBJECT_NUMBER'])

# COMMAND ----------

# calculating PLAN_ACTIVITY_NUMBER from activity df
gby = vx_act.groupby('USER_ATTRIBUTE_VACC_UA_PRJ_ONB').count()

vx_plan = vx_plan.join(gby, vx_plan['PLAN_OBJECT_NUMBER'] == gby.USER_ATTRIBUTE_VACC_UA_PRJ_ONB, 'leftouter')

vx_plan = vx_plan.withColumnRenamed('count', 'PLAN_ACTIVITY_NUMBER')
vx_plan = vx_plan.withColumnRenamed('USER_ATTRIBUTE_PME_PROJECT_STATUS', 'PROJECT_STATUS')

# COMMAND ----------

# calculating PLAN_STATE
vx_plan = vx_plan.withColumn('PLAN_STATE', F.when(vx_plan.PLAN_NAME.rlike("\w+\d+\.\d+"), F.lit('Version')))

vx_plan = vx_plan.withColumn('PLAN_OBJECT_NUMBER', F.lit(vx_plan.PLAN_OBJECT_NUMBER.cast(LongType())))
vx_plan = vx_plan.withColumn('SOURCE', F.lit('Vx-PLW').cast(StringType()))

# COMMAND ----------

# adding null references for the missing attributes
vx_plan = addNullReference(vx_plan, spark.createDataFrame([plan_cols], plan_cols))

# COMMAND ----------

# calculating PLAN_CURRENT_PHASE
vx_plan = vx_plan.withColumn('PLAN_CURRENT_PHASE', F.when(vx_plan.PLAN_CURRENT_PHASE == 'Preclinical', 'Pre-Clinical Evaluation')
                                                          .when(vx_plan.PLAN_CURRENT_PHASE == 'Life Cycle Mgm', 'Phase IV')
                                                          .otherwise(vx_plan['PLAN_CURRENT_PHASE']))

# COMMAND ----------

vx_plan = vx_plan.select(plan_cols)

# COMMAND ----------

vx_plan = vx_plan.dropna(how = 'all', subset = 'PLAN_OBJECT_NUMBER')

# COMMAND ----------

# write to curated
rawPath = 'dbfs:/mnt/raw/vaccones/'
unique_run_id = runid + '-LoadVxPLWPlan/'
csv_temp_curated = rawPath + unique_run_id + '/' + 'curated/'
curatedPath = 'dbfs:/mnt/curated/vaccines/planisware/'

vx_plan.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + "vx_plw_plan.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)