# Databricks notebook source
#File Name: LoadCuratedDish
#ADF Pipeline Name: DISH_ADL
#SQLDW Table: NA
#Description:
  #Load DISH list data in curated layer of ADL

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "cso23-cweui-123hds-213j2")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

# read new activity data file 1
dish_list = spark.read.format("csv")\
          .option("inferSchema", "false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/dish/milestones.txt')

dish_list = dish_list.toDF(*(col.upper().replace('\r', '') for col in dish_list.columns))
for col_name in dish_list.columns:
  dish_list = dish_list.withColumn(col_name, F.regexp_replace(col_name, '[\\r\\n\\s+]', ' '))
  dish_list = dish_list.withColumn(col_name, F.when(F.col(col_name) == '', None).otherwise(dish_list[col_name]))

# COMMAND ----------

# rename fields

dish_list = dish_list.withColumnRenamed('listId', 'MILESTONE_LIST_ID')
dish_list = dish_list.withColumnRenamed('listName', 'MILESTONE_LIST_NAME')
dish_list = dish_list.withColumnRenamed('termId', 'MILESTONE_TERM_ID')
dish_list = dish_list.withColumnRenamed('longName', 'MILESTONE_LONG_NAME')
dish_list = dish_list.withColumnRenamed('shortName', 'MILESTONE_SHORT_NAME')
dish_list = dish_list.withColumnRenamed('preferredName', 'MILESTONE_PREFERRED_NAME')
dish_list = dish_list.withColumnRenamed('abbreviation', 'MILESTONE_ABBREVIATION')
dish_list = dish_list.withColumnRenamed('sortOrder', 'MILESTONE_SORT_ORDER')
dish_list = dish_list.withColumnRenamed('active', 'ACTIVE_FLAG')
dish_list = dish_list.withColumnRenamed('lastModified', 'MILESTONE_LAST_MODIFIED')
dish_list = dish_list.withColumnRenamed('PLW_Activity_Type', 'PLANISWARE_ACTIVITY_TYPE')
dish_list = dish_list.withColumnRenamed('Phase_Progression', 'MILESTONE_PHASE_PROGRESSION')
dish_list = dish_list.withColumnRenamed('synonym', 'MILESTONE_SYNONYM')
dish_list = dish_list.withColumnRenamed('Milestone_Calc_Group', 'MILESTONE_CALC_GROUP')
dish_list = dish_list.withColumnRenamed('Milestone_Calc_Member', 'MILESTONE_CALC_MEMBER')

# COMMAND ----------

# write to curated
rawPath = 'dbfs:/mnt/raw/dish/'
unique_run_id = runid + '-LoadCuratedDish/'
csv_temp_curated = rawPath + unique_run_id + 'curated/'
curatedPath = 'dbfs:/mnt/curated/dish/'

dish_list.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + "milestones_list.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)