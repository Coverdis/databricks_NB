# Databricks notebook source
#File Name:LoadCuratedPerson
#ADF Pipeline Name: AMARS_ADL
#SQLDW Table: NA
#Description:
  #Writes final file in curated layer  

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

dbutils.widgets.text("runid", "ashg1-s28s2-dwjw2-2ewhd")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *


raw_path = 'dbfs:/mnt/raw/amars/'
foundation_path = 'dbfs:/mnt/foundation/amars/'
curated_path = 'dbfs:/mnt/curated/amars/'

# COMMAND ----------

# read person VSED unvalidated view data
person_uv = spark.read.format("csv")\
      .option("inferSchema","false")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load(foundation_path + 'amars_vsed_unvalidated_vw.txt')

person_uv = person_uv.toDF(*(col.replace('\r', '') for col in person_uv.columns))

for col_name in person_uv.columns:
  person_uv = person_uv.withColumn(col_name, F.regexp_replace(col_name, '[\\r\\n]', ''))

person_uv = person_uv.selectExpr(
  'KEYUID as PERSON_KEY',
  'GSKMUDID as PERSON_MUD_ID',
  'GIVENNAME as FIRST_NAME',
  'SN as LAST_NAME',
  'MAIL as EMAIL_ID',
  'INITIALS AS INITIALS',
  'BUSINESSCATEGORY AS BUSINESS_CATEGORY',
  'TELEPHONENUMBER AS TELEPHONE_NUMBER',
  'CO AS COUNTRY',
  'OU AS DIVISION',
  'TITLE AS BUSINESS_TITLE',
  'ZZ_MANAGERUID AS MANAGER_USER_ID',
  'PERSONALTITLE AS PERSONAL_TITLE',
  'O AS EMPLOYING_COMPANY',
  'L AS LOCATION',
  'DEPARTMENTNUMBER AS DEPARTMENT_NUMBER',
  'GSKPREFERREDNAME AS GSK_PREFERRED_NAME',
  'GSKDEPARTMENTNAME AS GSK_DEPARTMENT_NAME',
  'DISPLAYNAME AS DISPLAY_NAME',
  'BUILDINGNAME AS BUILDING_NAME',
  'GSKSITECODE AS GSK_SITE_CODE',
  'GSKMAILSTOP AS GSK_MAIL_STOP',
  'GSKRESOURCETYPE AS GSK_RESOURCE_TYPE',
  'GSKGLOBALBUSINESSCATEGORY AS GSK_GLOBAL_BUSINESS_CATEGORY'
)

#display(person_uv)

# COMMAND ----------

# read person amars_tbl_gdi_vw data
person_gdi = spark.read.format("csv")\
      .option("inferSchema","false")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load(foundation_path + 'amars_tbl_gdi_vw.txt')

person_gdi = person_gdi.toDF(*(col.replace('\r', '') for col in person_gdi.columns))

for col_name in person_gdi.columns:
  person_gdi = person_gdi.withColumn(col_name, F.regexp_replace(col_name, '[\\r\\n]', ''))
  
person_gdi = person_gdi.selectExpr(
  'KEY_GSKGDI as PERSON_KEY',
  'GSKPARENTGDI as PERSON_MUD_ID',
  'GIVENNAME as FIRST_NAME',
  'SN as LAST_NAME',
  'INITIALS AS INITIALS',
  'C AS COUNTRY',
  'PERSONALTITLE AS PERSONAL_TITLE',
  'GSKRESPONSIBLEPERSON AS MANAGER_USER_ID',
  'GSKRELATIONSHIPTYPE AS GSK_RESOURCE_TYPE',
  'GSKGLOBALBUSINESSCATEGORY AS GSK_GLOBAL_BUSINESS_CATEGORY'
)

person_gdi = person_gdi.withColumn('EMAIL_ID', F.lit(None).cast(StringType()))
person_gdi = person_gdi.withColumn('BUSINESS_CATEGORY', F.lit(None).cast(StringType()))
person_gdi = person_gdi.withColumn('TELEPHONE_NUMBER', F.lit(None).cast(StringType()))
person_gdi = person_gdi.withColumn('BUSINESS_TITLE', F.lit(None).cast(StringType()))
person_gdi = person_gdi.withColumn('EMPLOYING_COMPANY', F.lit(None).cast(StringType()))
person_gdi = person_gdi.withColumn('DIVISION', F.lit(None).cast(StringType()))
person_gdi = person_gdi.withColumn('LOCATION', F.lit(None).cast(StringType()))
person_gdi = person_gdi.withColumn('DEPARTMENT_NUMBER', F.lit(None).cast(StringType()))
person_gdi = person_gdi.withColumn('GSK_PREFERRED_NAME', F.lit(None).cast(StringType()))
person_gdi = person_gdi.withColumn('GSK_DEPARTMENT_NAME', F.lit(None).cast(StringType()))
person_gdi = person_gdi.withColumn('DISPLAY_NAME', F.lit(None).cast(StringType()))
person_gdi = person_gdi.withColumn('BUILDING_NAME', F.lit(None).cast(StringType()))
person_gdi = person_gdi.withColumn('GSK_SITE_CODE', F.lit(None).cast(StringType()))
person_gdi = person_gdi.withColumn('GSK_MAIL_STOP', F.lit(None).cast(StringType()))

# display(person_gdi)

# COMMAND ----------

# find PERSON_KEY from gdi view that are not in vnvalidated view
dif = person_gdi.select(F.lower(person_gdi.PERSON_KEY).alias('PERSON_KEY')).subtract(person_uv.select(F.lower(person_uv.PERSON_KEY).alias('PERSON_KEY')))

filtered_rows = [row.PERSON_KEY for row in dif.collect()]

person_gdi = person_gdi.filter('PERSON_KEY IN ' + str(tuple(filtered_rows)))

person = person_uv.unionByName(person_gdi)

# display(person)

# COMMAND ----------

# write to cuarated
unique_run_id = runid + '-LoadCuratedPerson/'
csv_temp_curated = raw_path + unique_run_id + 'curated/'

person.coalesce(1).write \
    .option("sep", "|") \
    .option("header", "true") \
    .option("quote",'"') \
    .option("escape", '"') \
    .option("nullValue", "null")\
    .csv(csv_temp_curated)    

# copy part-* csv file to curated and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curated_path + 'amars_person.txt', recurse = True)

# remove foundation/curated temp folders
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)