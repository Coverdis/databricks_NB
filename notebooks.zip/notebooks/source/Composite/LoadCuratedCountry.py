# Databricks notebook source
#File Name: LoadCuratedCountry
#ADF Pipeline Name:  Composite_ADL
#SQLDW Table: N/A
#Description:
  #Load MDM Country List into Curated Layer

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
from pyspark.sql import DataFrame

dbutils.widgets.text('runid', 'sd823-dv83q-cdn82-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

# read the csv file in foundation
country = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/composite/country.txt')
country = country.toDF(*(col.replace(r'\r\n', '') for col in country.columns))


# COMMAND ----------

# Renaming columns
country = country.withColumnRenamed('Country ID','COUNTRY_ID')
country = country.withColumnRenamed('Country Name','COUNTRY_NAME')
country = country.withColumnRenamed('Long Name(ISO Long name)','ISO_LONG_NAME')
country = country.withColumnRenamed('Preferred Term','PREFERRED_TERM')
country = country.withColumnRenamed('Short Name(ISO Short name)','ISO_SHORT_NAME')
country = country.withColumnRenamed('Active Status','ACTIVE_STATUS')
country = country.withColumnRenamed('Abbreviation','ABBREVIATION')
country = country.withColumnRenamed('Country GSK Short Name','COUNTRY_GSK_SHORT_NAME')
country = country.withColumnRenamed('ISO 3166-1-alpha-2','ISO_2_DIGIT_CODE')
country = country.withColumnRenamed('ISO 3166-1-alpha-3','ISO_3_DIGIT_CODE')
country = country.withColumnRenamed('ISO 3166-1 numeric','ISO_3166_1_NUMERIC')
country = country.withColumnRenamed('EUTCT Identifier','EUTCT_IDENTIFIER')
country = country.withColumn('SOURCE', F.lit('MDM'))

# COMMAND ----------

country = country.select('COUNTRY_ID',
                    'COUNTRY_NAME',
                    'ISO_LONG_NAME',
                    'PREFERRED_TERM',
                    'ISO_SHORT_NAME',
                    'ACTIVE_STATUS',
                    'ABBREVIATION',
                    'COUNTRY_GSK_SHORT_NAME',
                    'ISO_2_DIGIT_CODE',
                    'ISO_3_DIGIT_CODE',
                    'SOURCE')

# COMMAND ----------

# write to curated

raw_path = 'dbfs:/mnt/raw/composite/'
unique_run_id = runid + '-LoadCuratedCountry/'
csv_temp_curated = raw_path + unique_run_id + 'curated/'

curated_path = 'dbfs:/mnt/curated/composite/'

country.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curated_path + "country.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)