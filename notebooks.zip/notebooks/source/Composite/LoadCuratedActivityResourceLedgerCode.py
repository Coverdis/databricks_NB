# Databricks notebook source
#File Name: LoadCuratedActivityResourceLedgerCode
#ADF Pipeline Name:  Composite_ADL
#SQLDW Table: N/A
#Description:
  #Load LedgerCode in curated Composite folder

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window

dbutils.widgets.text('runid', 'sd823-dv83q-cdn82-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

# read the csv file in foundation
activityresource = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/composite/activity_resource.txt')

activityresourcetype = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/composite/activity_resource_type.txt')

fundingsource = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/composite/activity_resource_funding_source.txt')

ledgercode = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/composite/legal_entity_activity_resource.txt')

ledgercode = ledgercode.withColumn('COUNTRY_CODE', F.when(ledgercode.COUNTRY_ID == 'URN:LSID:gsk.com/rd:item.DEX:8459', 'GB')
                        .when(ledgercode.COUNTRY_ID == 'URN:LSID:gsk.com/rd:item.DEX:8460', 'US')
                        .otherwise('UNK'))
ledgercode = ledgercode.withColumn('FINANCE_SYSTEM', F.when(ledgercode.FINANCE_SYSTEM_ROWID_OBJ == '3', 'CERPS')
                                   .when(ledgercode.FINANCE_SYSTEM_ROWID_OBJ == '2', 'JDE')
                                   .when(ledgercode.FINANCE_SYSTEM_ROWID_OBJ == '1', 'Hyperion')
                        .otherwise('UNK'))


# joining actitvityresource and fundingsource data
temp = activityresource.join(fundingsource, activityresource.ROWID_OBJECT == fundingsource.ACTIVITY_RESOURCE_ID,  how='left')\
                        .select(activityresource.ACTIVITY_RESOURCE_ID, activityresource.LOCAL_ACTIVITY_ID, activityresource.PROJECT_ID, fundingsource.ROWID_OBJECT)

# joining actitvityresource and fundingsource data with ledgercode
final = temp.join(ledgercode, temp.ROWID_OBJECT == ledgercode.ACTIVITY_RESOURCE_FUNDING_SOURCE_ROW_ID,  how='left')\
      .select(temp.ACTIVITY_RESOURCE_ID, temp.LOCAL_ACTIVITY_ID, temp.PROJECT_ID, ledgercode.LEDGER_CODE, ledgercode.STATUS, ledgercode.COUNTRY_CODE, ledgercode.FINANCE_SYSTEM)

final = final.toDF(*(col.replace('\r', '') for col in final.columns))

# COMMAND ----------

# rename columns to IB names and add source column

final = final.withColumnRenamed('ACTIVITY_RESOURCE_ID', 'activity_resource_id')
final = final.withColumnRenamed('LOCAL_ACTIVITY_ID', 'local_activity_id')
final = final.withColumnRenamed('PROJECT_ID', 'project_id')
final = final.withColumnRenamed('LEDGER_CODE', 'ledger_code')
final = final.withColumnRenamed('STATUS', 'ledger_code_status')
final = final.withColumnRenamed('COUNTRY_CODE', 'country_code')
final = final.withColumnRenamed('FINANCE_SYSTEM', 'finance_system')
final = final.withColumn('source', F.lit('MDM'))

# COMMAND ----------

# write to curated

raw_path = 'dbfs:/mnt/raw/composite/'
unique_run_id = runid + '-LoadCuratedActivityResourceLedgerCode/'
csv_temp_curated = raw_path + unique_run_id + 'curated/'

curated_path = 'dbfs:/mnt/curated/composite/'

final.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curated_path + "activityresourceledgercode.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)