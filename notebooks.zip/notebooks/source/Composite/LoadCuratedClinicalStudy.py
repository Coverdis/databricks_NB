# Databricks notebook source
#File Name: LoadCuratedClinicalStudy
#ADF Pipeline Name:  Composite_ADL
#SQLDW Table: N/A
#Description:
  #Load eTrack Clinical Study data in curated eTrack folder

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
from pyspark.sql import DataFrame

dbutils.widgets.text('runid', 'sd823-dv83q-cdn82-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

def add_columns(self, column_list):
    for col in column_list:
        self = self.withColumn(str(col), F.lit(None).cast(StringType()))
    return self
DataFrame.add_columns = add_columns

# COMMAND ----------

# read the csv file in foundation
study = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/composite/getclinicalstudydetails.txt')

#add null columns
study = study.add_columns(["therapy_area",
                           "funding_source",
                           "primary_asset",
                           "indication",
                           "enrolled_subjects",
                           "planned_subjects",
                           "actual_sites",
                           "planned_sites"])

study = study.select('CLINICAL_STUDY_MASTER_ID',
                    'CLINICAL_STUDY_NAME_ABBREVIATED_TITLE',
                    'CLINICAL_STUDY_NAME_FULL_TITLE',
                    'CLINICAL_STUDY_PHASE',
                    'CLINICAL_STUDY_STATUS',
                    'CLINICAL_STUDY_TYPE',
                    'RnD_PROJECT_ID',
                    'therapy_area',
                    'LEGACY_STUDY_ID',
                    'INVESTIGATOR_SPONSORED_STUDY',
                    'CLINICAL_STUDY_ACCOUNTABLE_PERSON_USER_ID',
                    'BUSINESS_AREA',
                    'funding_source',
                    'CLINICAL_STUDY_DESIGNATION_NAME',
                    'primary_asset',
                    'indication',
                    'enrolled_subjects',
                    'planned_subjects',
                    'actual_sites',
                    'planned_sites')

study = study.toDF(*(col.replace(r'\r\n', '') for col in study.columns))

#for col_name in study.columns:
study = study.withColumn("CLINICAL_STUDY_NAME_FULL_TITLE", F.regexp_replace("CLINICAL_STUDY_NAME_FULL_TITLE", "[\n\r]", " "))

# COMMAND ----------

# rename columns to IB names
study = study.withColumnRenamed('CLINICAL_STUDY_MASTER_ID', 'study_id')
study = study.withColumnRenamed('CLINICAL_STUDY_NAME_ABBREVIATED_TITLE', 'study_abbreviated_title')
study = study.withColumnRenamed('CLINICAL_STUDY_NAME_FULL_TITLE', 'study_full_title')
study = study.withColumnRenamed('CLINICAL_STUDY_PHASE', 'study_phase')
study = study.withColumnRenamed('CLINICAL_STUDY_STATUS', 'study_status')
study = study.withColumnRenamed('CLINICAL_STUDY_TYPE', 'study_type')
study = study.withColumnRenamed('RnD_PROJECT_ID', 'project_id')
study = study.withColumnRenamed('LEGACY_STUDY_ID', 'legacy_study_id')
study = study.withColumnRenamed('INVESTIGATOR_SPONSORED_STUDY', 'investigator_sponsored_flag')
study = study.withColumnRenamed('CLINICAL_STUDY_ACCOUNTABLE_PERSON_USER_ID', 'study_accountable_person')
study = study.withColumnRenamed('BUSINESS_AREA', 'business_area_name')
study = study.withColumnRenamed('CLINICAL_STUDY_DESIGNATION_NAME', 'study_designation')
study = study.withColumn('source', F.lit('MDM'))

# COMMAND ----------

# write to curated

raw_path = 'dbfs:/mnt/raw/composite/'
unique_run_id = runid + '-LoadCuratedClinicalStudy/'
csv_temp_curated = raw_path + unique_run_id + 'curated/'

curated_path = 'dbfs:/mnt/curated/composite/'

study.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curated_path + "clinicalstudy.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)