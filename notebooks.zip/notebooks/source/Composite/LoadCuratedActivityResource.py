# Databricks notebook source
#File Name: LoadCuratedActivityResource
#ADF Pipeline Name:  Composite_ADL
#SQLDW Table: N/A
#Description:
  #Load ActivityResource in curated Composite folder

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window

dbutils.widgets.text('runid', 'sd823-dv83q-cdn82-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

# read the csv file in foundation
activityresource = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/composite/activity_resource.txt')

activityresourcetype = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/composite/activity_resource_type.txt')

hyperionactivitycode = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/composite/work_package_hyperion_activity.txt')

extendedattributes = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/composite/actres_extended_attributes.txt')

# joining actitvityresource and fundingsource data
final = activityresource.join(hyperionactivitycode, hyperionactivitycode.ROWID_OBJECT == activityresource.WORK_PACKAGE_HYPERION_ACTIVITY_ID,  how='left')\
                        .join(activityresourcetype, activityresourcetype.ROWID_OBJECT == activityresource.ACTIVITY_RESOURCE_TYPE_ID,  how='left')\
                        .join(extendedattributes, activityresource.ROWID_OBJECT == extendedattributes.ACTRES_ROWID,  how='left')\
                        .select(activityresource.ACTIVITY_RESOURCE_ID,
                                activityresource.LOCAL_ACTIVITY_ID,
                                activityresource.ACTIVITY_DESCRIPTION,
                                activityresource.IS_ACTIVE,
                                activityresource.PROJECT_ID,
                                activityresourcetype.ACTIVITY_RESOURCE_TYPE,
                                hyperionactivitycode.HYPERION_ACTIVITY_ID,
                                extendedattributes.ACTIVITY_TYPE_CODE,
                                extendedattributes.ACTIVITY_INTERNAL_ID)

final = final.toDF(*(col.replace('\r', '') for col in final.columns))

# COMMAND ----------

# rename columns to IB names and add source column

final = final.withColumnRenamed('ACTIVITY_RESOURCE_ID', 'activity_resource_id')
final = final.withColumnRenamed('LOCAL_ACTIVITY_ID', 'local_activity_id')
final = final.withColumnRenamed('ACTIVITY_DESCRIPTION', 'activity_description')
final = final.withColumnRenamed('IS_ACTIVE', 'activity_resource_status')
final = final.withColumnRenamed('PROJECT_ID', 'project_id')
final = final.withColumnRenamed('ACTIVITY_RESOURCE_TYPE', 'activity_resource_type')
final = final.withColumnRenamed('HYPERION_ACTIVITY_ID', 'hyperion_activity_code')
final = final.withColumnRenamed('ACTIVITY_TYPE_CODE', 'activity_type_code')
final = final.withColumnRenamed('ACTIVITY_INTERNAL_ID', 'activity_object_number')
final = final.withColumn('source', F.lit('MDM'))

# COMMAND ----------

# write to curated

raw_path = 'dbfs:/mnt/raw/composite/'
unique_run_id = runid + '-LoadCuratedActivityResource/'
csv_temp_curated = raw_path + unique_run_id + 'curated/'

curated_path = 'dbfs:/mnt/curated/composite/'

final.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curated_path + "activityresource.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)