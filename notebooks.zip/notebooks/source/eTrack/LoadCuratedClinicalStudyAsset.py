# Databricks notebook source
#File Name: LoadCuratedClinicalStudyAsset
#ADF Pipeline Name:  GRIPStaging_ADL
#SQLDW Table: N/A
#Description:
  #Load eTrack Clinical Study Asset data in curated eTrack folder

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window

dbutils.widgets.text('runid', 'sd823-dv83q-cdn82-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

# read the csv file in foundation
study = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/etrack/stg_s_cl_ptcl_ls.txt')

asset = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/etrack/stg_s_prod_int.txt')

studyasset = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/etrack/stg_s_prod_applctn.txt')

#join with asset data to get primary asset
studyasset = studyasset.join(study, studyasset.x_ptcl_id == study.row_id, how='inner')\
                        .join(asset, studyasset.prdint_id == asset.row_id, how='left')\
                        .select(study.ptcl_num,
                               asset.part_num,
                               studyasset.x_asset_role)

#studyasset = studyasset.toDF(*(col.replace('\r', '') for col in studyasset.columns))


# COMMAND ----------

# rename columns to IB names
studyasset = studyasset.withColumnRenamed('ptcl_num', 'clinical_study_master_id')
studyasset = studyasset.withColumnRenamed('part_num', 'primary_asset')
studyasset = studyasset.withColumnRenamed('x_asset_role', 'asset_role')
studyasset = studyasset.withColumn('source', F.lit('eTrack'))

# COMMAND ----------

# write to curated

raw_path = 'dbfs:/mnt/raw/etrack/'
unique_run_id = runid + '-LoadCuratedClinicalStudyAsset/'
csv_temp_curated = raw_path + unique_run_id + 'curated/'

curated_path = 'dbfs:/mnt/curated/etrack/'

studyasset.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curated_path + "clinicalstudyasset.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)