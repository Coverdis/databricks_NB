# Databricks notebook source
#File Name: LoadCuratedClinicalStudy
#ADF Pipeline Name:  GRIPStaging_ADL
#SQLDW Table: N/A
#Description:
  #Load eTrack Clinical Study data in curated eTrack folder

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
from pyspark.sql import DataFrame

dbutils.widgets.text('runid', 'sd823-dv83q-cdn82-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

# read the csv file in foundation

study = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/etrack/stg_s_cl_ptcl_ls.txt')

study = study.toDF(*(col.replace('\r', '') for col in study.columns))

for col_name in study.columns:
  study = study.withColumn(col_name, F.regexp_replace(col_name, '[\\r\\n\\s+]', ' '))

study = study.filter("par_ptcl_id is null")

#add null columns
study = study.withColumn('project_id', F.lit(None).cast(StringType()))
study = study.withColumn('legacy_study_id', F.lit(None).cast(StringType()))
study = study.withColumn('study_accountable_person', F.lit(None).cast(StringType()))

# COMMAND ----------

asset = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/etrack/stg_s_prod_int.txt')

# COMMAND ----------

indication = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/etrack/stg_s_med_proc.txt')

# COMMAND ----------


#join with asset and indication data to get primary asset and indication
study = study.join(asset, study.prdint_id == asset.row_id, how='left')\
              .join(indication, study.x_pr_indication_id == indication.row_id, how='left')\
              .select(
                    study.ptcl_num,
                    study.x_ptcl_abbr_tl,
                    study.x_ptcl_title,
                    study.ptcl_phase,
                    study.ptcl_stat_cd,
                    study.ptcl_type_cd,
                    study.project_id,
                    study.ptcl_diagnosis,
                    study.legacy_study_id,
                    study.x_invest_initiated,
                    study.x_sponsor,
                    study.x_fso,
                    study.x_fully_outsourced,
                    study.study_accountable_person,
                    study.x_business_area,
                    study.x_fund_src,
                    study.x_study_classification,
                    asset.part_num,
                    indication.desc_text,
                    study.num_subj_enrl,
                    study.num_plan_subj,
                    study.x_actual_sites,
                    study.num_plan_site,
                    study.plw_tracked_study)

study = study.toDF(*(col.replace(r'\r\n', '') for col in study.columns))

#for col_name in study.columns:
study = study.withColumn("x_ptcl_title", F.regexp_replace("x_ptcl_title", "[\n\r]", " "))

# COMMAND ----------

# rename columns to IB names
study = study.withColumnRenamed('ptcl_num', 'clinical_study_master_id')
study = study.withColumnRenamed('x_ptcl_abbr_tl', 'study_abbreviated_title')
study = study.withColumnRenamed('x_ptcl_title', 'study_full_title')
study = study.withColumnRenamed('ptcl_phase', 'study_phase_type_name')
study = study.withColumnRenamed('ptcl_stat_cd', 'study_status_type_name')
study = study.withColumnRenamed('ptcl_type_cd', 'study_type_name')
study = study.withColumnRenamed('ptcl_diagnosis', 'therapy_area')
study = study.withColumnRenamed('x_invest_initiated', 'investigator_sponsored_flag')
study = study.withColumnRenamed('x_sponsor', 'sponsorship')
study = study.withColumnRenamed('x_fso', 'fso_model_flag')
study = study.withColumnRenamed('x_fully_outsourced', 'outsource_strategy')
study = study.withColumnRenamed('x_business_area', 'business_area_name')
study = study.withColumnRenamed('x_fund_src', 'funding_source')
study = study.withColumnRenamed('x_study_classification', 'study_designation')
study = study.withColumnRenamed('part_num', 'primary_asset')
study = study.withColumnRenamed('desc_text', 'indication')
study = study.withColumnRenamed('num_subj_enrl', 'enrolled_subjects')
study = study.withColumnRenamed('num_plan_subj', 'planned_subjects')
study = study.withColumnRenamed('x_actual_sites', 'actual_sites')
study = study.withColumnRenamed('num_plan_site', 'planned_sites')
study = study.withColumn('source', F.lit('eTrack'))

# COMMAND ----------

# write to curated

raw_path = 'dbfs:/mnt/raw/etrack/'
unique_run_id = runid + '-LoadCuratedClinicalStudy/'
csv_temp_curated = raw_path + unique_run_id + 'curated/'

curated_path = 'dbfs:/mnt/curated/etrack/'

study.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curated_path + "clinicalstudy.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)