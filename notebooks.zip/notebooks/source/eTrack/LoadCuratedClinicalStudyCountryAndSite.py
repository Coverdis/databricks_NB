# Databricks notebook source
#File Name: LoadCuratedClinicalStudyCountryAndSite
#ADF Pipeline Name:  GRIPStaging_ADL
#SQLDW Table: N/A
#Description:
  #Load eTrack Clinical Study Country and Site data in curated eTrack folder

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window

dbutils.widgets.text('runid', 'sd823-dv83q-cdn82-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

# read the csv file in foundation
df = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/etrack/stg_s_cl_ptcl_ls.txt')

studysite = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/etrack/stg_s_ptcl_site_ls.txt')

#apply filters on the data
studycountry = df.filter("par_ptcl_id is not null")
#study = df.filter("par_ptcl_id is null").select("row_id", "ptcl_num")

#join study site with study country to get country data
studysite = studysite.withColumn('ptcl_stat_cd', F.lit(None).cast(StringType()))
studysite = studysite.withColumn('x_actual_sites', F.lit(None).cast(StringType()))
studysite = studysite.withColumn('num_plan_site', F.lit(None).cast(StringType()))
studysite = studycountry.join(studysite, studysite.ptcl_rgn_id == studycountry.row_id, how='left')\
                        .select(studycountry.ptcl_num,
                                studycountry.region_cd,
                                studysite.site_num,
                                studysite.status_cd,
                                 studysite.x_actual_sites,
                                 studysite.num_plan_site)

studycountry = studycountry.withColumn('site_num', F.lit(None).cast(StringType()))
studycountry = studycountry.withColumn('status_cd', F.lit(None).cast(StringType()))
studycountry = studycountry.select('ptcl_num',
                                   'region_cd',
                                   'site_num',
                                   'ptcl_stat_cd',
                                   'x_actual_sites',
                                   'num_plan_site')

#studysite = studysite.toDF(*(col.replace('\r', '') for col in studysite.columns))

# COMMAND ----------

#merge dataframes to get one final dataframe
final = studycountry.union(studysite)

# rename columns to IB names
final = final.withColumnRenamed('ptcl_num', 'study_id')
final = final.withColumnRenamed('region_cd', 'study_country')
final = final.withColumnRenamed('site_num', 'study_centre')
final = final.withColumnRenamed('status_cd', 'current_status')
final = final.withColumnRenamed('x_actual_sites', 'actual_sites')
final = final.withColumnRenamed('num_plan_site', 'planned_sites')

final = final.withColumn('source', F.lit('eTrack'))

# COMMAND ----------

# write to curated

raw_path = 'dbfs:/mnt/raw/etrack/'
unique_run_id = runid + '-LoadCuratedClinicalStudyCountryAndSite/'
csv_temp_curated = raw_path + unique_run_id + 'curated/'

curated_path = 'dbfs:/mnt/curated/etrack/'

final.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curated_path + "clinicalstudycountryandsite.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)