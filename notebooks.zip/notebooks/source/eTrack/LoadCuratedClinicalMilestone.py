# Databricks notebook source
#File Name: LoadCuratedClinicalMilestone
#ADF Pipeline Name:  GRIPStaging_ADL
#SQLDW Table: N/A
#Description:
  #Load eTrack ClinicalMilestone data in curated eTrack folder

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window

dbutils.widgets.text('runid', 'sd823-dv83q-cdn82-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

# read the csv file in foundation
studyandcountry = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/etrack/stg_s_cl_ptcl_ls.txt')

studysite = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/etrack/stg_s_ptcl_site_ls.txt')

milestone = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/etrack/stg_s_evt_act_mv.txt')

#apply filters on the data
milestone = milestone.filter("todo_cd='Clinical Milestone'")

#get study and study country milestones
studyandcountry = studyandcountry.withColumn('site_num', F.lit(None).cast(StringType()))

studyandcountrymilestone = milestone.join(studyandcountry, studyandcountry.row_id == milestone.cl_ptcl_id, how='inner')\
                                    .select(studyandcountry.ptcl_num,
                                            studyandcountry.region_cd,
                                            studyandcountry.site_num,
                                            milestone.evt_stat_cd, milestone.name,
                                            milestone.comments, milestone.comments_long,
                                            milestone.todo_plan_start_dt,
                                            milestone.todo_actl_start_dt)

#get study site milestones
studysite = studyandcountry.join(studysite, studysite.ptcl_rgn_id == studyandcountry.row_id, how='inner')\
                            .select(studyandcountry.ptcl_num,
                                    studyandcountry.region_cd,
                                    studysite.row_id,
                                    studysite.site_num)

sitemilestone = milestone.join(studysite, studysite.row_id == milestone.cl_ptcl_st_id, how='inner')\
                        .select(studysite.ptcl_num,
                                studysite.region_cd,
                                studysite.site_num,
                                milestone.evt_stat_cd,
                                milestone.name,
                                milestone.comments,
                                milestone.comments_long,
                                milestone.todo_plan_start_dt,
                                milestone.todo_actl_start_dt)

#milestone = milestone.toDF(*(col.replace('\r', '') for col in study.columns))

# COMMAND ----------

final = studyandcountrymilestone.union(sitemilestone)
final = final.withColumnRenamed('ptcl_num', 'clinical_study_master_id')
final = final.withColumnRenamed('region_cd', 'study_country_name')
final = final.withColumnRenamed('site_num', 'study_site')
final = final.withColumnRenamed('evt_stat_cd', 'milestone_type')
final = final.withColumnRenamed('name', 'milestone')
final = final.withColumnRenamed('comments', 'milestone_acronym')
final = final.withColumnRenamed('comments_long', 'milestone_generic_name')
final = final.withColumnRenamed('todo_plan_start_dt', 'milestone_planned_date')
final = final.withColumnRenamed('todo_actl_start_dt', 'milestone_actual_date')

final = final.withColumn('source', F.lit('eTrack'))

# COMMAND ----------

# write to curated

raw_path = 'dbfs:/mnt/raw/etrack/'
unique_run_id = runid + '-LoadCuratedClinicalMilestone/'
csv_temp_curated = raw_path + unique_run_id + 'curated/'

curated_path = 'dbfs:/mnt/curated/etrack/'

final.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curated_path + "clinicalmilestone.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)