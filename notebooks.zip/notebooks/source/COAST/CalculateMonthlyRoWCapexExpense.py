# Databricks notebook source
#File Name:CalculateMonthlyRoWCapexExpense
#ADF Pipeline Name: Coast_ADL
#Description:
  #Year and runid is being passed from ADF.
  #Pulls ytd COAST capex expenses for a particular year from foundation layer
  #Calculates MTD values for entire year for CAPEX comming from COAST system 
  #Writes final file in curated layer

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

dbutils.widgets.text("year", "")
dbutils.widgets.text("runid", "1111")

# COMMAND ----------

runid = dbutils.widgets.get("runid")
year = dbutils.widgets.get("year")

rawPath = 'dbfs:/mnt/raw/coast/capex'
foundationPath = 'dbfs:/mnt/foundation/coast/'
curatedPath = 'dbfs:/mnt/curated/coast/'

# COMMAND ----------

#pull RoW CAPEX data from  COAST
coast_capex_df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(foundationPath + year + "/fdw_capex-*-*.txt")

coast_capex_df = coast_capex_df.toDF(*(col.replace('\r', '') for col in coast_capex_df.columns))

# COMMAND ----------

from pyspark.sql.types import *
import pyspark.sql.functions as F

coast_capex_df_mtd = coast_capex_df.withColumn('MONTH', F.month(coast_capex_df.GL_PERIOD).cast(IntegerType())).withColumn('YEAR', F.year(coast_capex_df.GL_PERIOD).cast(IntegerType()))

# COMMAND ----------

from pyspark.sql.window import Window

windowSpec = \
  Window \
    .partitionBy(coast_capex_df_mtd['LOC_ID'], coast_capex_df_mtd['COST_CENTER_CODE'], coast_capex_df_mtd['AUTHORIZATION_NUMBER_CODE'], coast_capex_df_mtd['PHYSICAL_SITE_CODE'], coast_capex_df_mtd['CURRENCY_CODE'], coast_capex_df_mtd['ACTUAL_OR_ESTIMATE_CODE'],coast_capex_df_mtd['YEAR']) \
    .orderBy(coast_capex_df_mtd['MONTH'].desc(), coast_capex_df_mtd['YEAR'].desc()) 

coast_capex_df_final = coast_capex_df_mtd.select(
  coast_capex_df_mtd.GL_PERIOD, 
  coast_capex_df_mtd.LOC_ID,
  coast_capex_df_mtd.COST_CENTER_CODE,
  coast_capex_df_mtd.AUTHORIZATION_NUMBER_CODE,
  coast_capex_df_mtd.LOCAL_ACTUAL_YTD_AMOUNT,
  coast_capex_df_mtd.PHYSICAL_SITE_CODE,
  coast_capex_df_mtd.CURRENCY_CODE,
  F.round(coast_capex_df_mtd.LOCAL_ACTUAL_YTD_AMOUNT - F.lag(coast_capex_df_mtd.LOCAL_ACTUAL_YTD_AMOUNT, -1, 0).over(windowSpec), 2).alias("MTDAMOUNT"),
  coast_capex_df_mtd.MONTH,
  coast_capex_df_mtd.YEAR,
  coast_capex_df_mtd.DATA_SOURCE,
  coast_capex_df_mtd.STAGING_SOURCE,
  coast_capex_df_mtd.FDW_EXPORT_ID,
  coast_capex_df_mtd.ACTUAL_OR_ESTIMATE_CODE
)

# COMMAND ----------

# Write to curated
csv_temp_curated = rawPath + runid + year + '/' + 'curated'

coast_capex_df_final.coalesce(1).write\
          .option("sep", "|")\
          .option("header", "true")\
          .option("quote",  '"')\
          .option("escape", '"')\
          .option("nullValue", "null")\
        .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + '/' + "fdw_capex_" + year + ".txt", recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + runid + year, recurse = True)