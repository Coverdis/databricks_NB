# Databricks notebook source
# copy ROW Headcount data from foundation to source

# COMMAND ----------

dbutils.widgets.text('runid', 'dv033s-vdk393-vskso2-bdg034')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

import os
from glob import glob
row_hc_foundation = [x.split('/')[-2:] for x in glob('/dbfs/mnt/foundation/coast/**/fdw_row_hc-*.txt', recursive=True)]

# COMMAND ----------

source = ['dbfs:/mnt/foundation/coast/{0}/{1}'.format(row_hc_foundation[item][0], row_hc_foundation[item][1]) for item in range(0, len(row_hc_foundation))]
target = ['dbfs:/mnt/curated/coast/{0}/{1}'.format(row_hc_foundation[item][0], row_hc_foundation[item][1]) for item in range(0, len(row_hc_foundation))]

# for i, path in enumerate(source):
#   dbutils.fs.cp(source[i], target[i], recurse = True)
[dbutils.fs.cp(x,x.replace('foundation','curated')) for x in source]