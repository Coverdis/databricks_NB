# Databricks notebook source
#File Name:CalculateMonthlyRoWOpexExpense
#ADF Pipeline Name: Coast_ADL, FDR_ADL_DW-RoW-Expense-HC_OneTime
#SQLDW Table:NA
#Description:
  #Identifies new files in foundation layer by comparing maximum creation date of SQL DW table with modified time of file in ADL
  #Pulls ytd COAST opex expenses or historical RoW expesne from FDR
  #Calculates MTD values for entire year. Year and runid is 
#   being passed from ADF. 
  #Writes final file in curated layer  

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

dbutils.widgets.text("year", "")
dbutils.widgets.text("runid", "")
dbutils.widgets.text("source", "")

runid = dbutils.widgets.get("runid")
year = dbutils.widgets.get("year")

source = dbutils.widgets.get("source")
YEAR=int(year)
YEAR


# COMMAND ----------

import pytz
from datetime import datetime
import pyspark.sql.functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

rawPath = 'dbfs:/mnt/raw/coast/opex'
foundationPath = 'dbfs:/mnt/foundation/coast/'
curatedPath = 'dbfs:/mnt/curated/coast/'

# COMMAND ----------

#pull RoW EPE data from  COAST
coast_epe_df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(foundationPath + year + "/fdw_opex_epe-*-*.txt")

coast_epe_df = coast_epe_df.toDF(*(col.replace('\r', '') for col in coast_epe_df.columns))
for col_name in coast_epe_df.columns:
  coast_epe_df = coast_epe_df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))
  
coast_epe_df = coast_epe_df.withColumn('COST_TYPE', F.lit('EPE'))

#pull RoW IPE data from  COAST
coast_ipe_df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(foundationPath + year + "/fdw_opex_non_epe-*-*.txt")

coast_ipe_df = coast_ipe_df.toDF(*(col.replace('\r', '') for col in coast_ipe_df.columns))
for col_name in coast_ipe_df.columns:
  coast_ipe_df = coast_ipe_df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

coast_ipe_df = coast_ipe_df.withColumn('COST_TYPE', F.lit('IPE')).withColumn('BUDID_CODE', F.lit(None))

coast_df = coast_epe_df.unionByName(coast_ipe_df)

# COMMAND ----------

coast_df = coast_df.withColumn('LEDGER_AMOUNT', coast_df.LEDGER_AMOUNT.cast(DecimalType()))

coast_df = coast_df.withColumn('FISCMONTH', F.month(coast_df.GL_PERIOD).cast(IntegerType())).withColumn('FISCYEAR', F.year(coast_df.GL_PERIOD).cast(IntegerType()))
# coast_df_mtd=coast_df.groupBy('GL_PERIOD','COST_CENTER_CODE','ACCOUNT_CODE','BUDID_CODE','CURRENCY_CODE','FISCYEAR','FISCMONTH','ACTUAL_OR_ESTIMATE_CODE','COST_TYPE').sum('LEDGER_AMOUNT').withColumnRenamed('sum(LEDGER_AMOUNT)','LEDGER_AMOUNT')

# COMMAND ----------

if source=='FDR' and YEAR <=2020:
  windowSpec = \
  Window \
    .partitionBy( coast_df['COST_CENTER_CODE'], coast_df['ACCOUNT_CODE'], coast_df['BUDID_CODE'], coast_df['CURRENCY_CODE'], coast_df['FISCYEAR'],coast_df['ACTUAL_OR_ESTIMATE_CODE'] ,coast_df['COST_TYPE'],coast_df['FISCMONTH']) \
    .orderBy(coast_df['FISCMONTH'].desc(), coast_df['FISCYEAR'].desc(),coast_df['CREATED_DATE'].desc()) 
  coast_df=coast_df.withColumn('Rank',F.rank().over(windowSpec)).where("Rank='1'")

  coast_df_final = coast_df.select(
  coast_df.GL_PERIOD,
  coast_df.COST_CENTER_CODE,
  coast_df.ACCOUNT_CODE,
  coast_df.BUDID_CODE,
  coast_df.LEDGER_AMOUNT,
  coast_df.CURRENCY_CODE,
  coast_df.LEDGER_AMOUNT.alias("MTDAMOUNT"),
  coast_df.COST_TYPE,
  coast_df.FISCMONTH,
  coast_df.FISCYEAR,
  coast_df.ACTUAL_OR_ESTIMATE_CODE
  )
else:
  windowSpec = \
    Window \
      .partitionBy( coast_df['COST_CENTER_CODE'], coast_df['ACCOUNT_CODE'], coast_df['BUDID_CODE'], coast_df['CURRENCY_CODE'], coast_df['FISCYEAR'],coast_df['ACTUAL_OR_ESTIMATE_CODE'] ,coast_df['COST_TYPE']) \
      .orderBy(coast_df['FISCMONTH'].desc(), coast_df['FISCYEAR'].desc()) 

  coast_df_final = coast_df.select(
    coast_df.GL_PERIOD,
    coast_df.COST_CENTER_CODE,
    coast_df.ACCOUNT_CODE,
    coast_df.BUDID_CODE,
    coast_df.LEDGER_AMOUNT,
    coast_df.CURRENCY_CODE,
    F.round(coast_df.LEDGER_AMOUNT - F.lag(coast_df.LEDGER_AMOUNT, -1, 0).over(windowSpec), 2).alias("MTDAMOUNT"),
    coast_df.COST_TYPE,
    coast_df.FISCMONTH,
    coast_df.FISCYEAR,
    coast_df.ACTUAL_OR_ESTIMATE_CODE)

# COMMAND ----------

# Read exchange rate file
exchange_rates_df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load("dbfs:/mnt/foundation/fdr/exchange_rates_r.txt")

exchange_rates_df = exchange_rates_df.toDF(*(col.replace('\r', '') for col in exchange_rates_df.columns))
Latest_Year_ER=exchange_rates_df.select(F.max(exchange_rates_df.EXCHANGE_YEAR)).collect()[0][0]




# COMMAND ----------

# Create MTDAMOUNT_GBP field

coast_expenses_gbp_df = coast_df_final.join(exchange_rates_df,
                                (Latest_Year_ER == exchange_rates_df.EXCHANGE_YEAR) &
                                (coast_df_final.CURRENCY_CODE == exchange_rates_df.CURRENCY_CODE), 'left').drop(exchange_rates_df.CURRENCY_CODE).drop(exchange_rates_df.EXCHANGE_YEAR).drop(exchange_rates_df.SPOT_RATE).drop(exchange_rates_df.AVERAGE_RATE)

coast_expenses_gbp_df = coast_expenses_gbp_df.withColumn('MTDAMOUNT_GBP', F.round((coast_expenses_gbp_df.MTDAMOUNT / coast_expenses_gbp_df.BUDGET_RATE), 2)).drop(coast_expenses_gbp_df.BUDGET_RATE)

coast_expenses_gbp_df = coast_expenses_gbp_df.join(exchange_rates_df,
                                (coast_expenses_gbp_df.FISCYEAR == exchange_rates_df.EXCHANGE_YEAR) &
                                (coast_expenses_gbp_df.CURRENCY_CODE == exchange_rates_df.CURRENCY_CODE), 'left').drop(exchange_rates_df.CURRENCY_CODE).drop(exchange_rates_df.EXCHANGE_YEAR).drop(exchange_rates_df.SPOT_RATE).drop(exchange_rates_df.AVERAGE_RATE)

coast_expenses_gbp_df = coast_expenses_gbp_df.withColumn('MTDAMOUNT_HIST_GBP', F.round((coast_expenses_gbp_df.MTDAMOUNT / coast_expenses_gbp_df.BUDGET_RATE), 2)).drop(coast_expenses_gbp_df.BUDGET_RATE)

# display(coast_expenses_gbp_df)

# Rename columns as DW Columns
coast_expenses_gbp_df = coast_expenses_gbp_df.withColumnRenamed('MTDAMOUNT', 'AMOUNT_LOC')
coast_expenses_gbp_df = coast_expenses_gbp_df.withColumnRenamed('MTDAMOUNT_GBP', 'AMOUNT_GBP')
coast_expenses_gbp_df = coast_expenses_gbp_df.withColumnRenamed('MTDAMOUNT_HIST_GBP', 'AMOUNT_HIST_GBP')
coast_expenses_gbp_df = coast_expenses_gbp_df.withColumnRenamed('LEDGER_AMOUNT', 'LEDGER_AMOUNT_LOC_YTD')

# COMMAND ----------

# Write to curated
csv_temp_curated = rawPath + runid + year + '/' + 'curated'

coast_expenses_gbp_df.coalesce(1).write\
          .option("sep", "|")\
          .option("header", "true")\
          .option("quote",  '"')\
          .option("escape", '"')\
          .option("nullValue", "null")\
          .option("quoteAll", "true")\
          .mode('overwrite')\
        .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + '/' + "fdw_opex_epe_ipe_" + year + ".txt", recurse = True)



# COMMAND ----------

# remove temp folder
dbutils.fs.rm(rawPath + runid + year, recurse = True)