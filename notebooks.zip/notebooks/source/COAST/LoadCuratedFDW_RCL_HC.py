# Databricks notebook source
# copy RCL Headcount data from foundation to source

# COMMAND ----------

dbutils.widgets.text('runid', 'bvv9we-df9034-sdv222-bdg034')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

import os
from glob import glob
rcl_hc_foundation = [x.split('/')[-2:] for x in glob('/dbfs/mnt/foundation/coast/**/fdw_rcl_hc-*.txt', recursive=True)]

# COMMAND ----------

source = ['dbfs:/mnt/foundation/coast/{0}/{1}'.format(rcl_hc_foundation[item][0], rcl_hc_foundation[item][1]) for item in range(0, len(rcl_hc_foundation))]
target = ['dbfs:/mnt/curated/coast/{0}/{1}'.format(rcl_hc_foundation[item][0], rcl_hc_foundation[item][1]) for item in range(0, len(rcl_hc_foundation))]

[dbutils.fs.cp(x,x.replace('foundation','curated')) for x in source]


# COMMAND ----------

# f = dbutils.fs.ls('dbfs:/mnt/foundation/coast/2019/')

# # [f[idx] for idx, name in enumerate(f) if ('fdw_rcl_hc' in name)]

# [f[idx] for idx, name[1] in enumerate(f) if ('fdw_rcl_hc' in name[1])]

# COMMAND ----------

# [f[idx] for idx, name in enumerate(f) if ('fdw_rcl_hc' in name[1])]