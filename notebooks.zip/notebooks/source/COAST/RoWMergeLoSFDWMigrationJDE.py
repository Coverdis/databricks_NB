# Databricks notebook source
#File Name:RoWMergeLoSFDWMigrationJDE
#ADF Pipeline Name: 
#SQLDW - NA
#Description:
  # It does below for RoW data
  ## Merges RoW transaction that are present in FDR that have come from JDE and FDW_Migration
  ## Merges RoW ending balance that are present in FDR in LoS table

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

dbutils.widgets.text("runid", "csm281-cd2cds-dss211-cved3e4-dv432")

runid = dbutils.widgets.get("runid")

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window

# read exchange rates file
exchangeRatesDF = spark.read.format('csv') \
      .option('header', 'true') \
      .option("inferSchema","true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/fdr/exchange_rates_r.txt')

exchangeRatesDF = exchangeRatesDF.toDF(*(col.replace('\r', '') for col in exchangeRatesDF.columns))
for col_name in exchangeRatesDF.columns:
  exchangeRatesDF = exchangeRatesDF.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))
Latest_Year_ER=exchangeRatesDF.select(F.max(exchangeRatesDF.EXCHANGE_YEAR)).collect()[0][0]

# read wbs_elemt_cerps_l for wbs to costcenter mapping for company code GB01
costCenterMapping = spark.read.format('csv') \
      .option('header', 'true') \
      .option("inferSchema","true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
    .load('dbfs:/mnt/curated/hyperion_drm/cost_center_hierarchy.txt')

costCenterMapping = costCenterMapping.toDF(*(col.replace('\r', '') for col in costCenterMapping.columns))
costCenterMapping = costCenterMapping.select('COST_CENTER_CODE', 'COUNTRY_CODE')

for col_name in costCenterMapping.columns:
  costCenterMapping = costCenterMapping.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))
#remove leading zeros from responsible cost center code
costCenterMapping = costCenterMapping.withColumn('COST_CENTER_CODE', F.regexp_replace(costCenterMapping.COST_CENTER_CODE, '^0*', ''))

# COMMAND ----------

rawPath = 'dbfs:/mnt/raw/coast/row/'
foundationPath = 'dbfs:/mnt/foundation/fdr/'
# logPath = 'dbfs:/mnt/log/cerps/gllineitem/'
curatedPath = 'dbfs:/mnt/curated/coast/gllineitem/'

# read summary file from foundation
summaryDF = spark.read.format('csv')\
    .option("inferSchema", "false")\
    .option("header", "true")\
    .option("multiLine", "true")\
    .option("delimiter", "|")\
    .option("quote", '"')\
    .option("escape", '"')\
    .option("nullValue", "null")\
  .load(foundationPath + 'actual_summary_l.txt')

summaryDF = summaryDF.toDF(*(col.replace('\r', '') for col in summaryDF.columns))
#skip HMA is any
summaryDF = summaryDF.filter('scenario in ("Actual - Source", "Actual - Management Adjustments")')

# remove leading/trailing spaces from values
for col_name in summaryDF.columns:
  summaryDF = summaryDF.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ''))

summaryDF = summaryDF.withColumn('ABS_CODE', F.regexp_replace(summaryDF.ABS_CODE, '^0*', ''))
summaryDF = summaryDF.withColumn('OBS_CODE', F.regexp_replace(summaryDF.OBS_CODE, '^0*', ''))
summaryDF = summaryDF.withColumn('GL_DATE', summaryDF.GL_DATE.cast(TimestampType()))
summaryDF = summaryDF.withColumn('FISCYEAR', F.year(summaryDF.GL_DATE))
# newDF = newDF.withColumn('RANK', F.lit(1).cast(IntegerType()))

# COMMAND ----------

# join with cost center hierarchy to get country code
summaryDF = summaryDF.join(costCenterMapping, summaryDF.OBS_CODE == costCenterMapping.COST_CENTER_CODE, 'left').drop(costCenterMapping.COST_CENTER_CODE)

# exclude US and UK data and reatin Rest of the world data
summaryDF = summaryDF.filter('COUNTRY_CODE NOT IN ("US", "UK")')

# COMMAND ----------

#get summary RoW that has come from JDE and FDW migration
summaryJDE_FDW_DF = summaryDF.filter('DATA_SOURCE IN ("FDW Migration", "JDE OneWorld (CCRPDTA.F0901) via DataStage")')

# COMMAND ----------

losDF = spark.read.format('csv') \
      .option('header', 'true') \
      .option("inferSchema","true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/fdr/actual_summary_los_l.txt')

losDF = losDF.toDF(*(col.replace('\r', '') for col in losDF.columns))

#drop HMA
losDF = losDF.filter('scenario in ("Actual - Source", "Actual - Management Adjustments")')

losDF = losDF.withColumn('ABS_CODE', F.regexp_replace(losDF.ABS_CODE, '^0*', ''))
# los = los.withColumn('PROFIT_CTR', F.regexp_replace(los.PROFIT_CTR, '^0*', ''))
losDF = losDF.withColumn('OBS_CODE', F.regexp_replace(losDF.OBS_CODE, '^0*', ''))
losDF = losDF.withColumn('GL_DATE', losDF.GL_DATE.cast(TimestampType()))
# los = los.withColumn('FISCMONTH', F.lpad(F.month(los.GL_DATE), 2, '0'))
losDF = losDF.withColumn('ENDING_BALANCE_YEAR', F.year(losDF.GL_DATE) - 1)
# los = los.withColumn('FISCPER', F.concat(los.FISCYEAR, F.lit('0'), los.FISCMONTH))

# COMMAND ----------

# join with cost center hierarchy to get country code
losDF = losDF.join(costCenterMapping, losDF.OBS_CODE == costCenterMapping.COST_CENTER_CODE, 'left').drop(costCenterMapping.COST_CENTER_CODE)

# keep only US and UK data
losDF = losDF.filter('COUNTRY_CODE NOT IN ("US", "UK")')

# COMMAND ----------

#identify minimum year for which summary is present for cc,account and bud id
summaryDFMin = summaryDF.groupBy('OBS_CODE', 'ABS_CODE', 'WBS_CODE').agg(F.min('FISCYEAR'))
summaryDFMin = summaryDFMin.withColumnRenamed('min(FISCYEAR)','FISCYEAR_MIN')

##Pull LoS data that is not present in summary LoS for RoW
losMissingDF = losDF.join(summaryDFMin, (summaryDFMin.OBS_CODE == losDF.OBS_CODE) & (summaryDFMin.ABS_CODE == losDF.ABS_CODE) & (summaryDFMin.WBS_CODE == losDF.WBS_CODE), "left").drop(summaryDFMin.OBS_CODE).drop(summaryDFMin.ABS_CODE).drop(summaryDFMin.WBS_CODE)

#get LoS data for which summary does not exist or LoS data prior to summary data
losMissingDF = losMissingDF.filter('FISCYEAR_MIN is null or ENDING_BALANCE_YEAR < FISCYEAR_MIN')

# COMMAND ----------

#pick oldest los year row
ranked_los =  losMissingDF.withColumn(
    'RANK', F.rank().over(Window.partitionBy('obs_code', 'abs_code', 'wbs_code').orderBy(F.asc('ENDING_BALANCE_YEAR'))))
ranked_los = ranked_los.filter('RANK = 1')

# COMMAND ----------

summaryJDE_FDW_DF = summaryJDE_FDW_DF.select(
  'OBS_CODE',
  'ABS_CODE',
  'WBS_CODE',
  'GL_DATE',
  'CURRENCY_CODE',
  'AMT_MTD',
  'SCENARIO',
  'VERSION',
  'CREATION_DATE',
  'DATA_SOURCE',
  'COUNTRY_CODE'
)

ranked_los = ranked_los.select(
  'OBS_CODE',
  'ABS_CODE',
  'WBS_CODE',
  'GL_DATE',
  'CURRENCY_CODE',
  'AMT_MTD',
  'SCENARIO',
  'VERSION',
  'CREATION_DATE',
  'DATA_SOURCE',
  'COUNTRY_CODE'
)

finalDF = summaryJDE_FDW_DF.unionByName(ranked_los)

# COMMAND ----------

finalDF = finalDF.withColumn('FISCMONTH', F.lpad(F.month(finalDF.GL_DATE), 2, '0'))
finalDF = finalDF.withColumn('FISCYEAR', F.year(finalDF.GL_DATE))
finalDF = finalDF.withColumn('BUDID_CODE', finalDF.WBS_CODE.cast(StringType()))
finalDF = finalDF.withColumn('ACTUAL_OR_ESTIMATE_CODE', F.lit('Actual').cast(StringType()))
finalDF = finalDF.withColumn('LOC_ID', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('LEDGER_AMOUNT_LOC_YTD', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('STAGING_SOURCE', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('FDW_EXPORT_ID', F.lit(None).cast(StringType()))
# finalDF = finalDF.withColumn('BUDID_CODE', F.regexp_replace(finalDF.BUDID_CODE, 'UNK', None))
finalDF = finalDF.withColumn('BUDID_CODE', F.translate(finalDF.BUDID_CODE, 'UNK', ''))

# COMMAND ----------


# add DEB_CRE_GBP field
finalDF = finalDF.join(exchangeRatesDF, (Latest_Year_ER == exchangeRatesDF.EXCHANGE_YEAR) & (finalDF.CURRENCY_CODE == exchangeRatesDF.CURRENCY_CODE), 'left').drop(exchangeRatesDF.CURRENCY_CODE).drop(exchangeRatesDF.EXCHANGE_YEAR).drop(exchangeRatesDF.SPOT_RATE).drop(exchangeRatesDF.AVERAGE_RATE)
finalDF = finalDF.withColumn('DEB_CRE_GBP', F.round((finalDF.AMT_MTD / finalDF.BUDGET_RATE), 2)).drop(finalDF.BUDGET_RATE)

finalDF = finalDF.join(exchangeRatesDF, (finalDF.FISCYEAR == exchangeRatesDF.EXCHANGE_YEAR) & (finalDF.CURRENCY_CODE == exchangeRatesDF.CURRENCY_CODE), 'left').drop(exchangeRatesDF.CURRENCY_CODE).drop(exchangeRatesDF.EXCHANGE_YEAR).drop(exchangeRatesDF.SPOT_RATE).drop(exchangeRatesDF.AVERAGE_RATE)
finalDF = finalDF.withColumn('DEB_CRE_HIST_GBP', F.round((finalDF.AMT_MTD / finalDF.BUDGET_RATE), 2)).drop(finalDF.BUDGET_RATE)

# COMMAND ----------



# add cost type field
finalDF = finalDF.withColumn('COST_TYPE', 
                             F.when(finalDF.BUDID_CODE.isNull(), 'IPE').otherwise('EPE').cast(StringType())
                            )

# rename fields as in sql dw
finalDF = finalDF.withColumnRenamed('OBS_CODE', 'COST_CENTER_CODE')
finalDF = finalDF.withColumnRenamed('ABS_CODE', 'ACCOUNT_CODE')
finalDF = finalDF.withColumnRenamed('GL_DATE', 'GL_PERIOD')
finalDF = finalDF.withColumnRenamed('AMT_MTD', 'AMOUNT_LOC')
finalDF = finalDF.withColumnRenamed('DEB_CRE_GBP', 'AMOUNT_GBP')
finalDF = finalDF.withColumnRenamed('DEB_CRE_HIST_GBP', 'AMOUNT_HIST_GBP')


# finalDF = finalDF.withColumnRenamed('DATA_SOURCE', 'SOURCE')

# COMMAND ----------

finalDF = finalDF.select(
  'GL_PERIOD',
  'LOC_ID',
  'COST_CENTER_CODE',
  'ACCOUNT_CODE',
  'BUDID_CODE',
  'LEDGER_AMOUNT_LOC_YTD',
  'CURRENCY_CODE',
  'AMOUNT_LOC',
  'COST_TYPE',
  'FISCMONTH',
  'FISCYEAR',
  'DATA_SOURCE',
  'STAGING_SOURCE',
  'FDW_EXPORT_ID',
  'ACTUAL_OR_ESTIMATE_CODE',
  'AMOUNT_GBP',
  'AMOUNT_HIST_GBP'
)

finalDF = finalDF.toDF(*(col.replace('\r', '') for col in finalDF.columns))
for col_name in finalDF.columns:
  finalDF = finalDF.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ''))
  

# COMMAND ----------



coast_df = spark.read.format('csv') \
    .option('header', 'true') \
    .option("inferSchema","false")\
    .option("header","true")\
    .option("multiLine","true")\
    .option("delimiter","|")\
    .option("quote", '"')\
    .option("escape",'"')\
    .option("nullValue", "null")\
  .load("dbfs:/mnt/curated/coast/fdw_opex_epe_ipe_*.txt")

coast_df = coast_df.toDF(*(col.replace('\r', '') for col in coast_df.columns))
for col_name in coast_df.columns:
  coast_df = coast_df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ''))
# coast_df = coast_df.withColumnRenamed('DATA_SOURCE', 'SOURCE')  
delta_df = finalDF.subtract(coast_df)

finalDF = coast_df.unionByName(delta_df)

# COMMAND ----------

# MAGIC %run  /library/ParallelClass

# COMMAND ----------

# create global temp view of dataframe to be accessible from child notebooks
dataset_temp_view = 'RoWMergeLoSFDWMigrationJDE'
finalDF.createOrReplaceGlobalTempView(dataset_temp_view)

# get list of year
fiscper = finalDF.select('FISCYEAR').distinct().collect()
year = [i[0] for i in fiscper]

query = list(map(lambda x: 'FISCYEAR = {0}'.format(x), year))
dataset = [dataset_temp_view] * len(query)
path = list(map(lambda x: 'dbfs:/mnt/curated/coast/fdw_opex_epe_ipe_{0}.txt'.format(x), year))

# list of notebooks based on the month and year parameter: child notebook path, timeout, parameters, retry
# notebooks = list(map(lambda y: NotebookData(path = 'WriteFilesADL', timeout = 300, parameters = {'year': y}, retry = 2), year))
notebooks = list(map(lambda x, y, z: NotebookData(path = '/library/LoadFilesADL', timeout = 300, parameters = {'args': x, 'dataset': y, 'path': z}, retry = 2), query, dataset, path))

# calling child notebooks with number of parallel notebook runs
res = NotebookData.parallelNotebooks(notebooks, 4)
# blocking call to wait for completion of child notebooks run
result = [f.result(timeout = 10000) for f in res] # This is a blocking call.
# print(result)

# COMMAND ----------

# drop global temp view
spark.catalog.dropGlobalTempView(dataset_temp_view)