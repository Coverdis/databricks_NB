# Databricks notebook source
# Load IPE_Forecast data to curated

# COMMAND ----------

dbutils.widgets.text('runid', 'sdchs-dv83q-s8923-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

dbutils.fs.cp('dbfs:/mnt/foundation/hyperion_essbase/esb_ipe_est_3pd/', 'dbfs:/mnt/curated/hyperion_essbase/esb_ipe_est_3pd/', recurse = True)