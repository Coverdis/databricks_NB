# Databricks notebook source
# Load EPE_Budget data to curated

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

dbutils.widgets.text('runid', 'sdchs-dv83q-dsocd-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
import os
from glob import glob
import re

runid = dbutils.widgets.text("runid", "kldf30-vdkd3-vdkd2-9vfjd3")
runid = dbutils.widgets.get("runid")
foundation_path = 'dbfs:/mnt/foundation/hyperion_essbase/esb_epe_budu1u2u3/esb_epe_budu1u2u3.txt'
curated_path = 'dbfs:/mnt/curated/hyperion_essbase/epe_budget.txt'

# COMMAND ----------

df = spark.read.format('csv') \
      .option('header', 'true') \
      .option("inferSchema","false")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
    .load(foundation_path)

df = df.toDF(*(col.replace('\r', '') for col in df.columns))
for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ''))    

# COMMAND ----------

display(df.filter("project='18473REG' and entity='23318161' "))

# COMMAND ----------

#standardize data
df = df.withColumn('Years', (2000 + F.regexp_extract(df.Years, r'\d+', 0)).cast(IntegerType()))
df = df.withColumn('Month', F.when(df.Month == 'Jan', '1').otherwise( 
                            F.when(df.Month == 'Feb', '2').otherwise(
                            F.when(df.Month == 'Mar', '3').otherwise(
                            F.when(df.Month == 'Apr', '4').otherwise(
                            F.when(df.Month == 'May', '5').otherwise(
                            F.when(df.Month == 'Jun', '6').otherwise(
                            F.when(df.Month == 'Jul', '7').otherwise(
                            F.when(df.Month == 'Aug', '8').otherwise(
                            F.when(df.Month == 'Sep', '9').otherwise(
                            F.when(df.Month == 'Oct', '10').otherwise(
                            F.when(df.Month == 'Nov', '11').otherwise(
                            F.when(df.Month == 'Dec', '12')))))))))))))
df = df.withColumn('Project', F.regexp_replace(df.Project, 'PR.', ''))
df = df.withColumn('Entity', F.regexp_replace(df.Entity, 'CC.', ''))
df = df.withColumn('Account', F.regexp_replace(df.Account, 'AC.', ''))

# COMMAND ----------

#pull only current GBP data
df=df.filter('Currency="GBP-Current-Budget"')

# COMMAND ----------

#rename columns
df = df.withColumn('GL_PERIOD', F.concat_ws('-', df.Years, df.Month, F.lit(1)).cast(TimestampType()))
df = df.withColumn('COMP_CODE', F.lit(None).cast(StringType()))
df = df.withColumn('WBS_CODE', F.lit(None).cast(StringType()))
df = df.withColumn('DOCUMENT_NO', F.lit(None).cast(StringType()))
df = df.withColumn('AMOUNT_LOC', F.lit(None).cast(StringType()))
df = df.withColumn('CURRENCY_CODE', F.lit('GBP').cast(StringType()))
df = df.withColumn('COST_TYPE', F.lit('EPE'))
df = df.withColumn('SOURCE', F.lit('Hyperion-Budget'))
df = df.withColumnRenamed('Entity', 'COST_CENTER_CODE')
df = df.withColumnRenamed('Project', 'BUDID_CODE')
df = df.withColumnRenamed('Account', 'ACCOUNT_CODE')
df = df.withColumnRenamed('Amount', 'AMOUNT_GBP')
df = df.withColumnRenamed('Month', 'FISCMONTH')
df = df.withColumnRenamed('Years', 'FISCYEAR')
df = df.withColumnRenamed('Scenario', 'ACTUAL_OR_ESTIMATE_CODE')
df = df.withColumnRenamed('BegBalance', 'BEGINNING_BALANCE')


# COMMAND ----------

df = df.select(
    'GL_PERIOD',
    'COMP_CODE',
    'COST_CENTER_CODE',
    'ACCOUNT_CODE',
    'WBS_CODE',
    'BUDID_CODE',
    'DOCUMENT_NO',
    'AMOUNT_LOC',
    'AMOUNT_GBP',
    'CURRENCY_CODE',
    'FISCMONTH',
    'FISCYEAR',
    'SOURCE',
    'ACTUAL_OR_ESTIMATE_CODE',
    'COST_TYPE',
    'BEGINNING_BALANCE'
)

# COMMAND ----------

# write to curated
csv_temp_curated = 'dbfs:/mnt/raw/' + runid + '-LoadCuratedEPEBudget/'

df.coalesce(1).write\
            .option("sep", "|")\
            .option("header", "true")\
            .option("quote",  '"')\
            .option("escape", '"')\
            .option("nullValue", "null")\
            .option("quoteAll", "true")\
            .mode('overwrite')\
          .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curated_path, recurse = True)

# remove temp folder
dbutils.fs.rm(csv_temp_curated, recurse = True)