# Databricks notebook source
#File Name: LoadCuratedEPEForecast
#ADF Pipeline Name: HypEssbase_ADL 
#SQLDW Table: NA
#Description:
  # Load EPE forecast in curated

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
from datetime import datetime
import re

dbutils.widgets.text('runid', 'sdchs-dv83q-csaq1-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

df = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/hyperion_essbase/esb_epe_est_3pd/')

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

# COMMAND ----------

# display(df.filter('Project = "PR.51487M08" and Entity = "CC.23310275" and Account = "AC.5706000"').orderBy('Project', 'Entity', 'Account', 'Month', 'Years', 'Currency', 'Scenario'))

# COMMAND ----------

df = df.withColumn('Year', (2000 + F.regexp_extract(df.Years, r'\d+', 0)).cast(IntegerType()))
df = df.withColumn('Month', F.when(df.Month == 'Jan', '1').otherwise( 
                            F.when(df.Month == 'Feb', '2').otherwise(
                            F.when(df.Month == 'Mar', '3').otherwise(
                            F.when(df.Month == 'Apr', '4').otherwise(
                            F.when(df.Month == 'May', '5').otherwise(
                            F.when(df.Month == 'Jun', '6').otherwise(
                            F.when(df.Month == 'Jul', '7').otherwise(
                            F.when(df.Month == 'Aug', '8').otherwise(
                            F.when(df.Month == 'Sep', '9').otherwise(
                            F.when(df.Month == 'Oct', '10').otherwise(
                            F.when(df.Month == 'Nov', '11').otherwise(
                            F.when(df.Month == 'Dec', '12')))))))))))))

# COMMAND ----------

# create columns

df = df.withColumn('GL_PERIOD', F.concat_ws('-', df.Year, df.Month, F.lit(1)).cast(TimestampType()))
df = df.withColumn('COMP_CODE', F.lit(None).cast(StringType()))
df = df.withColumn('COST_CENTER_CODE', F.regexp_replace(df.Entity, 'CC.', ''))
df = df.withColumn('ACCOUNT_CODE', F.regexp_replace(df.Account, 'AC.', ''))
df = df.withColumn('WBS_CODE', F.lit(None).cast(StringType()))
df = df.withColumn('BUDID_CODE', F.regexp_replace(df.Project, '^\w{2}\.', ''))
df = df.withColumn('DOCUMENT_NO', F.lit(None).cast(StringType()))
df = df.withColumnRenamed('Amount', 'AMOUNT_LOC')
df = df.withColumn('AMOUNT_GBP', df.AMOUNT_LOC)
df = df.withColumn('CURRENCY_CODE', F.lit('GBP').cast(StringType()))
df = df.withColumnRenamed('Month', 'FISCMONTH')
df = df.withColumnRenamed('Year', 'FISCYEAR')
df = df.withColumnRenamed('Scenario', 'ACTUAL_OR_ESTIMATE_CODE')
df = df.withColumn('COST_TYPE', F.lit('EPE'))
df = df.withColumnRenamed('BegBalance', 'BEGINNING_BALANCE')

# filter only for GBP values, LOC values are present as GBPs in dataset 
df = df.filter('Currency = "GBP-Current-Budget"')

# COMMAND ----------

df = df.select(
    'GL_PERIOD',
    'COMP_CODE',
    'COST_CENTER_CODE',
    'ACCOUNT_CODE',
    'WBS_CODE',
    'BUDID_CODE',
    'DOCUMENT_NO',
    'AMOUNT_LOC',
    'AMOUNT_GBP',
    'CURRENCY_CODE',
    'FISCMONTH',
    'FISCYEAR',
    'ACTUAL_OR_ESTIMATE_CODE',
    'COST_TYPE',
    'BEGINNING_BALANCE'
)

# df = df.drop_duplicates()

# COMMAND ----------

# MAGIC %run  /library/ParallelClass

# COMMAND ----------

# create global temp view of dataframe to be accessible from child notebooks
dataset_temp_view = 'ForecastCurated'
df.createOrReplaceGlobalTempView(dataset_temp_view)

# get list of year and month
fiscper = df.select('FISCYEAR', 'FISCMONTH').distinct().collect()
year = [i[0] for i in fiscper]
month = [i[1].lstrip('0') for i in fiscper]

query = list(map(lambda x, y: 'FISCYEAR = {0} and FISCMONTH = {1}'.format(x, y), year, month))
dataset = [dataset_temp_view] * len(query)
path = list(map(lambda x, y: 'dbfs:/mnt/curated/hyperion_essbase/epe_forecast/{0}/Forecast-{1}-{2}.txt'.format(x, x, y), year, month))

# list of notebooks based on the month and year parameter: child notebook path, timeout, parameters, retry
# notebooks = list(map(lambda y: NotebookData(path = '/library/LoadFilesADL', timeout = 1500, parameters = {'year': y}, retry = 2), year))
notebooks = list(map(lambda x, y, z: NotebookData(path = '/library/LoadFilesADL', timeout = 300, parameters = {'args': x, 'dataset': y, 'path': z}, retry = 2), query, dataset, path))

# calling child notebooks with number of parallel notebook runs
res = NotebookData.parallelNotebooks(notebooks, 4)
# blocking call to wait for completion of child notebooks run
result = [f.result(timeout = 10000) for f in res] # This is a blocking call.
# print(result)

# COMMAND ----------

# drop global temp view
spark.catalog.dropGlobalTempView(dataset_temp_view)

# COMMAND ----------

# dbutils.fs.cp('dbfs:/mnt/foundation/hyperion_essbase/esb_epe_est_3pd/', 'dbfs:/mnt/curated/hyperion_essbase/esb_epe_est_3pd/', recurse = True)