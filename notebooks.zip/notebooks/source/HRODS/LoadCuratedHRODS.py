# Databricks notebook source
#File Name: LoadCuratedHRODS
#ADF Pipeline Name: HRODS_ADL
#SQLDW Table: NA
#Description:
  # Load HRODS Worker from foundation to curated
  # Load HRODS Position form foundation to curated

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *

dbutils.widgets.text('runid', 'paj3s-ad83q-ajn82-pkpss')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

#read HRODS Worker
workerdf = spark.read.format("csv")\
      .option("inferSchema", "false")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/hrods/hrods.view_IRM_Worker.txt')

workerdf = workerdf.toDF(*(col.replace('\r', '') for col in workerdf.columns))

# COMMAND ----------

df11= workerdf.select('VSD_MUD_ID','MANAGED_ORG_CODE').filter("vsd_mud_id ='dj378909'")
print(df11.count())

# COMMAND ----------

#read HRODS Position
posdf = spark.read.format("csv")\
      .option("inferSchema", "false")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/hrods/hrods.view_IRM_Position.txt')

posdf = posdf.toDF(*(col.replace('\r', '') for col in posdf.columns))

# COMMAND ----------

#renaming HRODS Worker columns
workerdf = workerdf.withColumnRenamed('EMP_GEID', 'NUMERIC_GLOBAL_ID')
workerdf = workerdf.withColumnRenamed('SYS_ID', 'SOURCE_SYS_ID')
workerdf = workerdf.withColumnRenamed('VSD_MUD_ID', 'PERSON_MUD_ID')
workerdf = workerdf.withColumnRenamed('CONTRACT_TYP_CODE_GBL', 'CONTRACT_TYPE_CODE')
workerdf = workerdf.withColumnRenamed('CONTRACT_TYP_DESC_GBL', 'GSK_RESOURCE_TYPE')
workerdf = workerdf.withColumnRenamed('CONTRACT_TYP_CODE_GBL', 'CONTRACT_TYPE_CODE')
workerdf = workerdf.withColumnRenamed('DER_MGRLVG_DISPLAY_NAME', 'MANAGER_NAME')
workerdf = workerdf.withColumnRenamed('WORK_CTRY_ISO3_CODE_GBL', 'COUNTRY')
workerdf = workerdf.withColumnRenamed('ORIG_HIRE_DT', 'ORIGINAL_HIRE_DATE')
workerdf = workerdf.withColumnRenamed('SERVICE_DT', 'SERVICE_DATE')
workerdf = workerdf.withColumnRenamed('TERMINATION_DT', 'TERMINATION_DATE')
workerdf = workerdf.withColumnRenamed('CONTRACT_END_DT', 'CONTRACT_END_DATE')
workerdf = workerdf.withColumnRenamed('EXPECTED_END_DT', 'EXPECTED_END_DATE')
workerdf = workerdf.withColumnRenamed('LAST_WORKED_DT', 'LAST_WORKED_DATE')
workerdf = workerdf.withColumnRenamed('EMP_TIME_STATUS_CODE_GBL', 'EMPLOYEMENT_STATUS')
workerdf = workerdf.withColumnRenamed('HOURS_CONT', 'HOURS_WORKED')
workerdf = workerdf.withColumnRenamed('HOURS_STD', 'STANDARD_WORKING_HOURS')
workerdf = workerdf.withColumnRenamed('MANAGEMENT_LEVEL_CODE_GBL', 'MANAGEMENT_LEVEL_CODE')
workerdf = workerdf.withColumnRenamed('MANAGEMENT_LEVEL', 'MANAGEMENT_LEVEL_DESC')
workerdf = workerdf.withColumnRenamed('LEGL_FIRST_NAME', 'FIRST_NAME')
workerdf = workerdf.withColumnRenamed('LEGL_LAST_NAME_PRIM', 'LAST_NAME')
workerdf = workerdf.withColumnRenamed('LEGL_MIDDLE_NAME', 'LEGAL_MIDDLE_NAME')
workerdf = workerdf.withColumnRenamed('LEGL_NAME_FULL', 'DISPLAY_NAME')
workerdf = workerdf.withColumnRenamed('LEGL_NAME_SUFFIX', 'LEGAL_NAME_SUFFIX')
workerdf = workerdf.withColumnRenamed('LEGL_NAME_TITLE', 'PERSONAL_TITLE')
workerdf = workerdf.withColumnRenamed('PREF_FIRST_NAME', 'GSK_PREFERRED_NAME')
workerdf = workerdf.withColumnRenamed('PREF_NAME_FULL', 'PREFERRED_FULL_NAME')
workerdf = workerdf.withColumnRenamed('PREF_MIDDLE_NAME', 'PREFERRED_MIDDLE_NAME')
workerdf = workerdf.withColumnRenamed('PREF_LAST_NAME_PRIM', 'PREFERRED_LAST_NAME')
workerdf = workerdf.withColumnRenamed('PRIM_WRK_PHN_NBR', 'TELEPHONE_NUMBER')
workerdf = workerdf.withColumnRenamed('REPORT_TO_MANAGER', 'MANAGER_EMP_ID') #
workerdf = workerdf.withColumnRenamed('REPORT_TO_POS', 'MANAGER_POS_NO')
workerdf = workerdf.withColumnRenamed('SUPORG_DESC', 'SUPERVISORY_ORG_DESC')
workerdf = workerdf.withColumnRenamed('VSD_EMAIL_ADDRESS', 'EMAIL_ID')
workerdf = workerdf.withColumnRenamed('WORKER_TYPE_CODE_GBL', 'WORKER_TYPE_CODE')
workerdf = workerdf.withColumnRenamed('WORKER_TYPE_DESC_GBL', 'WORKER_TYPE_DESC')
workerdf = workerdf.withColumnRenamed('CURRENT_HIRE_DT', 'CURRENT_HIRE_DATE')
workerdf = workerdf.withColumnRenamed('WORK_SITE_ID_DESC_GBL', 'LOCATION')
workerdf = workerdf.withColumnRenamed('SUPORG_CODE', 'SUPERVISORY_ORG_CODE')
workerdf = workerdf.withColumnRenamed('SUPORG_LEVEL', 'SUPERVISORY_ORG_LEVEL') #
workerdf = workerdf.withColumnRenamed('BUSINESS_UNIT_DESC', 'BUSINESS_CATEGORY')
workerdf = workerdf.withColumnRenamed('DIVISION_DESC', 'DIVISION')
workerdf = workerdf.withColumnRenamed('MANAGED_ORG_DESC', 'MANAGED_ORGANIZATION')

for x in range(1, 11):
  workerdf = workerdf.withColumnRenamed('SUPORG_CODE_VET' + str(x), 'SUPERVISORY_ORG_CODE_VET' + str(x)) #
  workerdf = workerdf.withColumnRenamed('SUPORG_DESC_VET' + str(x), 'SUPERVISORY_ORG_DESC_VET' + str(x)) #
  workerdf = workerdf.withColumnRenamed('SUPORG_MANAGER_ID_VET' + str(x), 'SUPERVISORY_ORG_MANAGER_ID_VET' + str(x)) #

# creating placeholder fields
workerdf = workerdf.withColumn('PERSON_KEY', F.lit(None).cast(StringType()))
workerdf = workerdf.withColumn('INITIALS', F.lit(None).cast(StringType()))
workerdf = workerdf.withColumn('EMPLOYING_COMPANY', F.lit(None).cast(StringType()))
workerdf = workerdf.withColumn('GSK_DEPARTMENT_NAME', F.lit(None).cast(StringType()))
workerdf = workerdf.withColumn('BUILDING_NAME', F.lit(None).cast(StringType()))
workerdf = workerdf.withColumn('GSK_SITE_CODE', F.lit(None).cast(StringType()))
workerdf = workerdf.withColumn('GSK_MAIL_STOP', F.lit(None).cast(StringType()))
workerdf = workerdf.withColumn('GSK_GLOBAL_BUSINESS_CATEGORY', F.lit(None).cast(StringType()))
workerdf = workerdf.withColumn('MANAGER_USER_ID', F.lit(None).cast(StringType()))
workerdf = workerdf.withColumn('DEPARTMENT_NUMBER', F.lit(None).cast(StringType()))

  
#renaming HRODS Position columns
posdf = posdf.withColumnRenamed('SYS_ID', 'SOURCE_SYS_ID')
posdf = posdf.withColumnRenamed('REPORT_TO_POS', 'MANAGER_POS_NO')
posdf = posdf.withColumnRenamed('AVAILABLE_FROM_DT', 'AVAILABLE_FROM_DATE')
posdf = posdf.withColumnRenamed('POS_CREATE_DT', 'POSITION_CREATE_DATE')
posdf = posdf.withColumnRenamed('JOB_REQ_ID', 'JOB_REQUIREMENT_ID')
posdf = posdf.withColumnRenamed('JOB_REQ_DESCR', 'JOB_REQUIREMENT_DESC')
posdf = posdf.withColumnRenamed('JOB_REQ_STATUS', 'JOB_REQUIREMENT_STATUS')
posdf = posdf.withColumnRenamed('JOB_REQ_OPEN_DT', 'JOB_REQUIREMENT_OPEN_DATE')
posdf = posdf.withColumnRenamed('EARLIEST_HIRE_DT', 'EARLIEST_HIRE_DATE')
posdf = posdf.withColumnRenamed('FUTURE_FILL_DT', 'FUTURE_FILL_DATE')
posdf = posdf.withColumnRenamed('SUPORG_CODE', 'SUPERVISORY_ORG_CODE')
posdf = posdf.withColumnRenamed('PRIM_WORK_SITE_ID', 'PRIMARY_WORK_SITE_ID')
posdf = posdf.withColumnRenamed('PRIM_WORK_SITE_NAME', 'PRIMARY_WORK_SITE_NAME')

# COMMAND ----------

worker_managed_org_df= workerdf.select('PERSON_MUD_ID','MANAGED_ORG_CODE','MANAGED_ORGANIZATION').filter('PERSON_MUD_ID is not null')
print(worker_managed_org_df.count())

# COMMAND ----------

# droppping duplicate EMP_ID from the table
workerdf = workerdf.drop_duplicates(['EMP_ID'])
# dropping nulls from PERSON_MUD_ID
workerdf = workerdf.filter('PERSON_MUD_ID is not null')

# COMMAND ----------

#write HRODS Worker to curated layer
raw_path = 'dbfs:/mnt/raw/hrods/'
unique_run_id = runid + '-LoadCuratedHRODSWorker/'
csv_temp_curated = raw_path + unique_run_id + '/' + 'curated'

curated_path = 'dbfs:/mnt/curated/hrods/'

workerdf.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("quoteAll", "true")\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

#copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curated_path + "hrods.view_IRM_Worker.txt", recurse = True)

#remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)


#write HRODS Worker Managed Organisation to curated layer
raw_path = 'dbfs:/mnt/raw/hrods/'
unique_run_id = runid + '-LoadCuratedHRODSWorkerMangedOrg/'
csv_temp_curated = raw_path + unique_run_id + '/' + 'curated'

curated_path = 'dbfs:/mnt/curated/hrods/'

worker_managed_org_df.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("quoteAll", "true")\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

#copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curated_path + "hrods.view_IRM_Worker_Managed_Org.txt", recurse = True)

#remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)


# COMMAND ----------

#write HRODS Position to curated layer
raw_path = 'dbfs:/mnt/raw/hrods/'
unique_run_id = runid + '-LoadCuratedHRODSPosition/'
csv_temp_curated = raw_path + unique_run_id + '/' + 'curated'

curated_path = 'dbfs:/mnt/curated/hrods/'

posdf.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("quoteAll", "true")\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

#copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curated_path + "hrods.view_IRM_Position.txt", recurse = True)

#remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)