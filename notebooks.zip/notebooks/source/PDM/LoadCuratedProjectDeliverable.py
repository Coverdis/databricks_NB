# Databricks notebook source
#File Name: LoadCuratedProjectDeliverable
#ADF Pipeline Name: 
#SQLDW Table: 
#Description:
  # Load project_deliverable from foundation to curated 

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window

dbutils.widgets.text('runid', 'sdchs-dv83q-cdn82-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

project_deliverable = spark.read.format("csv")\
      .option("inferSchema", "false")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/pdm/project_deliverable.txt')

project_deliverable = project_deliverable.toDF(*(col.replace('\r', '') for col in project_deliverable.columns))
for col_name in project_deliverable.columns:
  project_deliverable = project_deliverable.withColumn(col_name, F.regexp_replace(col_name, '[\\r\\n\\s+]', ' '))

project_deliverable = project_deliverable.withColumnRenamed('PROJECT_ID', 'PROJECT_CODE')
project_deliverable = project_deliverable.withColumnRenamed('DESCRIPTION', 'PROJECT_DESCRIPTION')
project_deliverable = project_deliverable.withColumnRenamed('DELIVERABLE_STATUS_LONG_NAME', 'PROJECT_STATUS')
project_deliverable = project_deliverable.withColumnRenamed('CURRENT_PHASE', 'PROJECT_CURRENT_PHASE')
project_deliverable = project_deliverable.withColumnRenamed('CURRENT_PHASE_DISPLAY_ORDER', 'CURRENT_PHASE_DISPLAY_ORDER')
project_deliverable = project_deliverable.withColumnRenamed('MEDICAL_CONDITION_CODE', 'MEDICAL_CONDITION_CODE')
project_deliverable = project_deliverable.withColumnRenamed('MC_SHORT_NAME', 'INDICATION')
project_deliverable = project_deliverable.withColumnRenamed('TA_SHORT_NAME', 'THERAPEUTIC_AREA_SHORT_NAME')
project_deliverable = project_deliverable.withColumnRenamed('TA_LONG_NAME', 'THERAPEUTIC_AREA_LONG_NAME')

project_deliverable = project_deliverable.withColumnRenamed('START_PHASE_LONG_NAME', 'START_PHASE')
project_deliverable = project_deliverable.withColumnRenamed('DISPLAY_ORDER', 'START_PHASE_DISPLAY_ORDER')
project_deliverable = project_deliverable.withColumnRenamed('DELIVERABLE_TYPE_SHORT_NAME', 'DELIVERABLE_TYPE')
project_deliverable = project_deliverable.withColumnRenamed('ACTIVE_SUBSTANCE', 'ACTIVE_SUBSTANCE_ID')
project_deliverable = project_deliverable.withColumnRenamed('CS_TYPE_SHORT_NAME', 'CANDIDATE_SELECTION_TYPE_NAME')
project_deliverable = project_deliverable.withColumnRenamed('ROA_SHORT_NAME', 'ROUTE_OF_ADMINISTRATION')
project_deliverable = project_deliverable.withColumnRenamed('THERAPY_TYPE_SHORT_NAME', 'THERAPY_TYPE')
project_deliverable = project_deliverable.withColumnRenamed('THERAPY_TYPE_COMMENTS', 'THERAPY_TYPE_COMMENT')
project_deliverable = project_deliverable.withColumnRenamed('PD_DEFAULT_FUNDING_PARTY_DESC', 'DEFAULT_FUNDING_PARTY')

# COMMAND ----------

active_substance = spark.read.format("csv")\
      .option("inferSchema", "false")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/pdm/active_substance.txt')

active_substance = active_substance.toDF(*(col.replace('\r', '') for col in active_substance.columns))
for col_name in active_substance.columns:
  active_substance = active_substance.withColumn(col_name, F.regexp_replace(col_name, '[\\r\\n\\s+]', ' '))
  
# display(active_substance)

# COMMAND ----------

project_deliverable = project_deliverable.join(active_substance.selectExpr('ACTIVE_SUBSTANCE_ID', 'ACTIVE_SUBSTANCE_TYPE_DESC as ACTIVE_SUBSTANCE_DESCRIPTION', 'ACTIVE_SUBSTANCE_TYPE_CODE', 'FL_COMBINATION', 'COMPOUND_REPORTED_NAME'), ['ACTIVE_SUBSTANCE_ID'], 'left')

# COMMAND ----------

# write to curated

raw_path = 'dbfs:/mnt/raw/pdm/'
unique_run_id = runid + '-LoadCuratedProjectDeliverable/'
csv_temp_curated = raw_path + unique_run_id + 'curated/'

curated_path = 'dbfs:/mnt/curated/pdm/'

project_deliverable.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curated_path + "project_deliverable.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)