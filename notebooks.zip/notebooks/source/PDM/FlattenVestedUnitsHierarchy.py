# Databricks notebook source
#File Name:FlattenVestedUnitsHierarchy
#ADF Pipeline Name: 
#SQLDW: irm_stg.FlattenVestedUnitsHierarchy
#Description:
  #Flatten Vested Units Hierarchy comming from Hyperion DRM
  #Writes flatten Vested Units Hierarchy file in curated layer

# COMMAND ----------

# MAGIC %run "/library/configFile"

# COMMAND ----------

dbutils.widgets.text("runid", "ssad2-we23d-sd782-uhbg2-dfj34")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *

rawPath = 'dbfs:/mnt/raw/pdm/'
foundationPath = 'dbfs:/mnt/foundation/pdm/'
curatedPath = 'dbfs:/mnt/curated/pdm/'

# COMMAND ----------

df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(foundationPath + "drm_vested_unit_code.txt")

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

# COMMAND ----------

df.createOrReplaceTempView("VUH")

query = "select LVL4N as NODE_ID, LVL4PN as PARENT_NODE_ID, LEVEL4_DESCRIPTION as DESCRIPTION, LVL4DEX as DEXCODE, DISPLAY_ORDER, \
			   LVL4N, LVL4PN, LEVEL4_DESCRIPTION, LVL3N, LVL3PN, LEVEL3_DESCRIPTION, LVL2N, LVL2PN, LEVEL2_DESCRIPTION, LVL1N, LVL1PN, LEVEL1_DESCRIPTION \
		from (SELECT NODE_ID as LVL4N, PARENT_NODE_ID as LVL4PN, DESCRIPTION as LEVEL4_DESCRIPTION, NAME as LVL4DEX, DISPLAY_ORDER FROM VUH) lvl4, \
			 (SELECT NODE_ID as LVL3N, PARENT_NODE_ID as LVL3PN, DESCRIPTION as LEVEL3_DESCRIPTION FROM VUH) lvl3, \
			 (SELECT NODE_ID as LVL2N, PARENT_NODE_ID as LVL2PN, DESCRIPTION as LEVEL2_DESCRIPTION FROM VUH) lvl2, \
			 (SELECT NODE_ID as LVL1N, PARENT_NODE_ID as LVL1PN, DESCRIPTION as LEVEL1_DESCRIPTION FROM VUH WHERE DESCRIPTION = 'Research & Development') lvl1 \
		WHERE lvl2.LVL2PN=lvl1.LVL1N AND lvl3.LVL3PN=lvl2.LVL2N AND lvl4.LVL4PN=lvl3.LVL3N \
        UNION \
		select LVL3N as NODE_ID, LVL3PN as PARENT_NODE_ID, LEVEL3_DESCRIPTION as DESCRIPTION, LVL3DEX as DEXCODE, DISPLAY_ORDER, \
			   null as LVL4N, null as LVL4PN, null as LEVEL4_DESCRIPTION, LVL3N, LVL3PN, LEVEL3_DESCRIPTION, LVL2N, LVL2PN, LEVEL2_DESCRIPTION, LVL1N, LVL1PN, LEVEL1_DESCRIPTION \
		from (SELECT NODE_ID as LVL3N, PARENT_NODE_ID as LVL3PN, DESCRIPTION as LEVEL3_DESCRIPTION, NAME as LVL3DEX, DISPLAY_ORDER FROM VUH) lvl3, \
			 (SELECT NODE_ID as LVL2N, PARENT_NODE_ID as LVL2PN, DESCRIPTION as LEVEL2_DESCRIPTION FROM VUH) lvl2, \
			 (SELECT NODE_ID as LVL1N, PARENT_NODE_ID as LVL1PN, DESCRIPTION as LEVEL1_DESCRIPTION FROM VUH WHERE DESCRIPTION = 'Research & Development') lvl1 \
		WHERE lvl2.LVL2PN=lvl1.LVL1N AND lvl3.LVL3PN=lvl2.LVL2N \
        UNION \
        select LVL2N as NODE_ID, LVL2PN as PARENT_NODE_ID, LEVEL2_DESCRIPTION as DESCRIPTION, LVL2DEX as DEXCODE, DISPLAY_ORDER, \
			   null as LVL4N, null as LVL4PN, null as LEVEL4_DESCRIPTION, null as LVL3N, null as LVL3PN, null as LEVEL3_DESCRIPTION, LVL2N, LVL2PN, LEVEL2_DESCRIPTION, LVL1N, LVL1PN, LEVEL1_DESCRIPTION \
        from (SELECT NODE_ID as LVL2N, PARENT_NODE_ID as LVL2PN, DESCRIPTION as LEVEL2_DESCRIPTION, NAME as LVL2DEX, DISPLAY_ORDER FROM VUH) lvl2, \
             (SELECT NODE_ID as LVL1N, PARENT_NODE_ID as LVL1PN, DESCRIPTION as LEVEL1_DESCRIPTION FROM VUH WHERE DESCRIPTION = 'Research & Development') lvl1 \
        WHERE lvl2.LVL2PN=lvl1.LVL1N"

vestedunit = sqlContext.sql(query)

# COMMAND ----------

unique_run_id = runid + '-FlattenDRMVestedUnitsHierarchy/'
csv_temp_curated = rawPath + unique_run_id + 'curated/'

vestedunit.coalesce(1).write\
          .option("sep", "|")\
          .option("header", "true")\
          .option("quote",  '"')\
          .option("escape", '"')\
          .option("nullValue", "null")\
          .option("quoteAll", "true")\
          .mode('overwrite')\
        .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + "vested_unit_hierarchy.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)