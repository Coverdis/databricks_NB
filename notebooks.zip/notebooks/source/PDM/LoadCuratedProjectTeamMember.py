# Databricks notebook source
#File Name: LoadCuratedProjectTeamMember
#ADF Pipeline Name: PDM_ADL
#SQLDW Table: NA
  #Read Project Team Member PLAN data from ADL and load to curated layer

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "111")
# dbutils.widgets.text("file_path", "")

runid = dbutils.widgets.get("runid")
# file_path = dbutils.widgets.get("file_path")

# COMMAND ----------

# read new project data file 1
ptm = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/pdm/project_team_member.txt')

ptm = ptm.toDF(*(col.upper().replace('\r', '') for col in ptm.columns))
ptm = ptm.drop('@ODATA.ID')
for col_name in ptm.columns:
  ptm = ptm.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ''))
  ptm = ptm.withColumn(col_name, F.regexp_replace(F.col(col_name), '[\\r\\n]', ' '))
  

# COMMAND ----------

# renaming the fields as per buleprinting standards
ptm = ptm.withColumnRenamed('TEAM_MEMBER_ID', 'TEAM_MEMBER_ID')
ptm = ptm.withColumnRenamed('TEAM_ID', 'TEAM_ID')
ptm = ptm.withColumnRenamed('USER_ID', 'PERSON_MUD_ID')
ptm = ptm.withColumnRenamed('ROLE_CODE', 'ROLE_DEX_CODE')
ptm = ptm.withColumnRenamed('ROLE_SHORT_NAME', 'ROLE_CODE')
ptm = ptm.withColumnRenamed('ROLE_LONG_NAME', 'ROLE_DESCRIPTION')
ptm = ptm.withColumnRenamed('ROLE_SORT_ORDER', 'SORT_ORDER')
ptm = ptm.withColumnRenamed('IS_EDITOR', 'IS_EDITOR')
ptm = ptm.withColumnRenamed('CREATE_DATE', 'CREATE_DATE')
ptm = ptm.withColumnRenamed('CREATE_USER', 'CREATE_USER')
ptm = ptm.withColumnRenamed('MODIFY_DATE', 'MODIFY_DATE')
ptm = ptm.withColumnRenamed('MODIFY_USER', 'MODIFY_USER')
ptm = ptm.withColumnRenamed('IN_DISTRIBUTION_LIST', 'IN_DISTRIBUTION_LIST')

# COMMAND ----------

cols = ['TEAM_MEMBER_ID', 'TEAM_ID', 'PERSON_MUD_ID', 'ROLE_DEX_CODE', 'ROLE_CODE', 'ROLE_DESCRIPTION', 'SORT_ORDER', 'IS_EDITOR', 'CREATE_DATE', 'CREATE_USER', 'MODIFY_DATE', 'MODIFY_USER', 'IN_DISTRIBUTION_LIST']

ptm=ptm.select(cols)

# COMMAND ----------

# write to curated
rawPath = 'dbfs:/mnt/raw/pdm/'
unique_run_id = runid + '-LoadCuratedProjectTeamMember/'
csv_temp_curated = rawPath + unique_run_id + 'curated/'
curatedPath = 'dbfs:/mnt/curated/pdm/'

ptm.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + "project_team_member.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)