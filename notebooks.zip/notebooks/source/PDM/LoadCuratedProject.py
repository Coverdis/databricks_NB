# Databricks notebook source
#File Name: LoadCuratedProject
#ADF Pipeline Name:  PDM_ADL
#SQLDW Table: irm_stg.PROJECT
#Description:
  #Load PDM project data in unified project management folder

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window

dbutils.widgets.text('runid', 'sd823-dv83q-cdn82-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

project = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/pdm/project.txt')


  
project = project.toDF(*(col.replace('\r', '') for col in project.columns))

for col_name in project.columns:
  project = project.withColumn(col_name, F.regexp_replace(col_name, '[\\r\\n\\s]', ' '))

# COMMAND ----------

project.count()

# COMMAND ----------

project = project.withColumnRenamed('PROJECT_ID', 'PROJECT_CODE')
project = project.withColumnRenamed('DESCRIPTION', 'PROJECT_DESCRIPTION')
project = project.withColumnRenamed('PROJ_STATUS_SHORT_NAME', 'PROJECT_STATUS')
project = project.withColumnRenamed('PROJ_STATUS_LONG_NAME', 'PROJECT_STATUS_LONG_NAME')
project = project.withColumnRenamed('CREATE_DATE', 'PROJECT_CREATION_DATE')
project = project.withColumnRenamed('CREATE_USER', 'PROJECT_CREATION_USER_ID')
project = project.withColumnRenamed('MODIFY_DATE', 'PROJECT_MODIFICATION_DATE')
project = project.withColumnRenamed('MODIFY_USER', 'PROJECT_MODIFICATION_USER_ID')
project = project.withColumnRenamed('PROJ_FORM_LONG_NAME', 'PROJECT_FORM_NAME')
project = project.withColumnRenamed('OWNER', 'PROJECT_OWNER_USER_ID')
project = project.withColumnRenamed('STATUS_CHANGE_DATE', 'PROJECT_STATUS_CHANGE_DATE')
project = project.withColumnRenamed('STATUS_CHANGE_COMMENT', 'PROJECT_STATUS_CHANGE_COMMENT')
project = project.withColumnRenamed('STATUS_TERM_REASON_CODE', 'PROJECT_STATUS_TERMINATION_REASON')
# project = project.withColumnRenamed('DISH', 'DISH_ID')

# COMMAND ----------

# write to curated

raw_path = 'dbfs:/mnt/raw/pdm/'
unique_run_id = runid + '-LoadCuratedProject/'
csv_temp_curated = raw_path + unique_run_id + 'curated/'

curated_path = 'dbfs:/mnt/curated/pdm/'

project.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curated_path + "project.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)