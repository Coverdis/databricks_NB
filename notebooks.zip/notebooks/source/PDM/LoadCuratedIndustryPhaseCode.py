# Databricks notebook source
# Load industry_phase_code.txt from foundation to curated 

# COMMAND ----------

dbutils.widgets.text('runid', 'ghdjs-dv83q-cdn82-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

dbutils.fs.cp('dbfs:/mnt/foundation/pdm/industry_phase_code.txt', 'dbfs:/mnt/curated/pdm/industry_phase_code.txt', recurse = True)