# Databricks notebook source
#File Name: LoadCuratedPortfolio
#ADF Pipeline Name: PDM_ADL
#SQLDW Table: NA
#Description:
  # Load portfolio from foundation to curated 

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *

dbutils.widgets.text('runid', 'pedtu-dv83q-cdn82-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

df = spark.read.format("csv")\
      .option("inferSchema", "false")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/pdm/portfolio.txt')

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(F.col(col_name), '[\\r\\n\\s+]', ' '))

# COMMAND ----------

# rename fields
df = df.withColumnRenamed('PORTFOLIO_DUP_MEMBERS_FLAG', 'PORTFOLIO_DUPLICATE_MEMBERS_FLAG')
df = df.withColumnRenamed('PORTFOLIO_CATEGORY_DESC', 'PORTFOLIO_CATEGORY_DESCRIPTION')

# COMMAND ----------

# write to curated layer
raw_path = 'dbfs:/mnt/raw/pdm/'
unique_run_id = runid + '-LoadCuratedPortfolio/'
csv_temp_unified = raw_path + unique_run_id + '/' + 'curated'

curated_path = 'dbfs:/mnt/curated/pdm/'

df.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("quoteAll", "true")\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .mode('overwrite')\
      .csv(csv_temp_unified)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_unified)[-1][0], curated_path + "portfolio.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)