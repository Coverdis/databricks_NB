# Databricks notebook source
# Load therapeutic_area_code.txt from foundation to curated 

# COMMAND ----------

dbutils.widgets.text('runid', 'uyirw-dv83q-cdn82-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

dbutils.fs.cp('dbfs:/mnt/foundation/pdm/therapeutic_area_code.txt', 'dbfs:/mnt/curated/pdm/therapeutic_area_code.txt', recurse = True)