# Databricks notebook source
# Load project_team.txt from foundation to curated 

# COMMAND ----------

dbutils.widgets.text('runid', 'cvbns-dv83q-cdn82-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

dbutils.fs.cp('dbfs:/mnt/foundation/pdm/project_team.txt', 'dbfs:/mnt/curated/pdm/project_team.txt', recurse = True)