# Databricks notebook source
#File Name: LoadCuratedProjectGene
#ADF Pipeline Name:  PDM_ADL
#SQLDW Table: irm_stg.PROJECT_GENE
#Description:
  #Load PDM project gene data in curated pdm folder

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window

dbutils.widgets.text('runid', 'sd823-dv83q-cdn82-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

project = spark.read.format("csv")\
      .option("inferSchema", "true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/pdm/project_gene.txt')


  
project = project.toDF(*(col.replace('\r', '') for col in project.columns))

for col_name in project.columns:
  project = project.withColumn(col_name, F.regexp_replace(col_name, '[\\r\\n\\s]', ' '))

# COMMAND ----------

project.count()

# COMMAND ----------

project = project.withColumnRenamed('PROJECT_ID', 'PROJECT_CODE')
project = project.withColumnRenamed('GENEMASTERID', 'GENE_MASTER_ID')
project = project.withColumnRenamed('GENESYMBOL', 'GENE_SYMBOL')
project = project.withColumnRenamed('GENENAME', 'GENE_NAME')
project = project.withColumnRenamed('GENESYNONYM', 'GENE_SYNONYM')
# project = project.withColumnRenamed('DISH', 'DISH_ID')

# COMMAND ----------

# write to curated

raw_path = 'dbfs:/mnt/raw/pdm/'
unique_run_id = runid + '-LoadCuratedProject/'
csv_temp_curated = raw_path + unique_run_id + 'curated/'

curated_path = 'dbfs:/mnt/curated/pdm/'

project.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curated_path + "project_gene.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)