# Databricks notebook source
#File Name:FlattenActiveSubstanceHierarchy
#ADF Pipeline Name: PDM_ADL
#SQLDW: NA
#Description:
  #Flatten active substance hierarchy file comming from PDM
  #Writes flatten Active Substance hierarchy file in curated layer

# COMMAND ----------

# MAGIC %run "/library/configFile"

# COMMAND ----------

dbutils.widgets.text("runid", "ssad2-we23d-sd782-uhbg2-dfj34")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *

rawPath = 'dbfs:/mnt/raw/pdm/'
foundationPath = 'dbfs:/mnt/foundation/pdm/'
curatedPath = 'dbfs:/mnt/curated/pdm/'

# COMMAND ----------

df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(foundationPath + "drm_as_type_code.txt")

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

# COMMAND ----------

df.createOrReplaceTempView("ASH")

query = "select * from (SELECT PARENT_NODE_ID as LVL3PN, NODE_ID as LVL3N, DEX_ID as LVL3DEX, DESCRIPTION as LEVEL3_DESCRIPTION,DISPLAY_ORDER FROM ASH) lvl3, \
 (SELECT PARENT_NODE_ID as LVL2PN, NODE_ID as LVL2N, DEX_ID as LVL2DEX, DESCRIPTION as LEVEL2_DESCRIPTION FROM ASH) lvl2, (SELECT PARENT_NODE_ID as LVL1PN, NODE_ID as LVL1N, DEX_ID as LVL1DEX, DESCRIPTION as LEVEL1_DESCRIPTION FROM ASH WHERE DESCRIPTION = 'Active Substance Type') lvl1 WHERE lvl2.LVL2PN=lvl1.LVL1N AND lvl3.LVL3PN=lvl2.LVL2N"

activesubstance = sqlContext.sql(query)

# COMMAND ----------

unique_run_id = runid + '-FlattenActiveSubstanceHierarchy/'
csv_temp_curated = rawPath + unique_run_id + 'curated/'

activesubstance.coalesce(1).write\
          .option("sep", "|")\
          .option("header", "true")\
          .option("quote",  '"')\
          .option("escape", '"')\
          .option("nullValue", "null")\
          .option("quoteAll", "true")\
          .mode('overwrite')\
        .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + "active_substance_hierarchy.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(csv_temp_curated, recurse = True)