# Databricks notebook source
#File Name: LoadCuratedMigratedActivity
#ADF Pipeline Name: PDM_ADL_Plan-Activity-MigratedOneTime
#SQLDW Table: NA
#Description:
  #Store Migrated ACTIVITY data in curated layer of ADL

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

# MAGIC %run /source/Planisware/PLWConfig

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "lry43-hrow2-vsio1-d3kdm")
# dbutils.widgets.text("file_path", "")

# file_path = dbutils.widgets.get("file_path")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

# read new activity data file 1
activity = spark.read.format("csv")\
          .option("inferSchema", "false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/pdm/v_cur_wbs_node.txt')

activity = activity.toDF(*(col.upper().replace('\r', '') for col in activity.columns))
activity = activity.drop('@ODATA.ID')
for col_name in activity.columns:
  activity = activity.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ''))
  activity = activity.withColumn(col_name, F.regexp_replace(F.col(col_name), '[\\r\\n]', ' '))
print(activity.count())    

# COMMAND ----------

activity = colRename(migrated_act_dict , activity)

activity = addNullReference(activity, spark.createDataFrame([activity_cols], activity_cols))

activity = activity.withColumn('SOURCE', F.lit('PDM-MIGRATED').cast(StringType()))

# COMMAND ----------

#fix dates to align with SQL DW date format
activity=activity.withColumn('ACTIVITY_PLANNED_START_DATE',F.to_date(activity.ACTIVITY_PLANNED_START_DATE, 'yyyy-MM-dd'))
activity=activity.withColumn('ACTIVITY_PLANNED_END_DATE',F.to_date(activity.ACTIVITY_PLANNED_END_DATE, 'yyyy-MM-dd'))
activity=activity.withColumn('ACTIVITY_ACTUAL_START_DATE',F.to_date(activity.ACTIVITY_ACTUAL_START_DATE, 'yyyy-MM-dd'))
activity=activity.withColumn('ACTIVITY_ACTUAL_END_DATE',F.to_date(activity.ACTIVITY_ACTUAL_END_DATE, 'yyyy-MM-activity'))


# COMMAND ----------

#create date which is non null based on planned dates
activity = activity.withColumn('PlannedMilestoneDate',(F.when(activity.ACTIVITY_PLANNED_END_DATE.isNotNull(),activity.ACTIVITY_PLANNED_END_DATE).otherwise(activity.ACTIVITY_PLANNED_START_DATE)).cast(DateType()))

#create date which is non null based on actual dates
activity = activity.withColumn('ActualMilestoneDate',(F.when(activity.ACTIVITY_ACTUAL_END_DATE.isNotNull(),activity.ACTIVITY_ACTUAL_END_DATE).otherwise(activity.ACTIVITY_ACTUAL_START_DATE)).cast(DateType()))

# COMMAND ----------

# create NEXT_PLANNED_MILESTONE
activity = activity.drop('NEXT_PLANNED_MILESTONE')
activity_temp = activity.filter('upper(ACTIVITY_SCOPE_NAME) like "%PROJECT MILESTONE%" and ACTIVITY_ACTUAL_START_DATE is null and ACTIVITY_ACTUAL_END_DATE is null')
activity_temp = activity_temp.withColumn(
    'NEXT_PLANNED_MILESTONE', F.dense_rank().over(Window.partitionBy('PLAN_OBJECT_NUMBER').orderBy(activity_temp.PlannedMilestoneDate)))
activity_temp = activity_temp.withColumn('NEXT_PLANNED_MILESTONE', F.when(activity_temp.NEXT_PLANNED_MILESTONE == 1, 'True').otherwise('False'))
activity = activity.join(activity_temp.select('ACTIVITY_OBJECT_NUMBER', 'NEXT_PLANNED_MILESTONE'), ["ACTIVITY_OBJECT_NUMBER"], 'left')

# COMMAND ----------

# create NEXT_PLANNED_DECISION_POINT_MILESTONE
activity = activity.drop('NEXT_PLANNED_DECISION_POINT_MILESTONE')
activity_temp = activity.filter('upper(ACTIVITY_SCOPE_NAME) like "%PROJECT MILESTONE%" and upper(WBS_TYPE) like "%COMMIT%" and ACTIVITY_ACTUAL_START_DATE is null and ACTIVITY_ACTUAL_END_DATE is null')
activity_temp = activity_temp.withColumn(
    'NEXT_PLANNED_DECISION_POINT_MILESTONE', F.dense_rank().over(Window.partitionBy('PLAN_OBJECT_NUMBER').orderBy(activity_temp.PlannedMilestoneDate)))
activity_temp = activity_temp.withColumn('NEXT_PLANNED_DECISION_POINT_MILESTONE', F.when(activity_temp.NEXT_PLANNED_DECISION_POINT_MILESTONE == 1, 'True').otherwise('False'))
activity = activity.join(activity_temp.select('ACTIVITY_OBJECT_NUMBER', 'NEXT_PLANNED_DECISION_POINT_MILESTONE'), ['ACTIVITY_OBJECT_NUMBER'], 'left')

# create LATEST_ACHIEVED_MILESTONE
activity = activity.drop('LATEST_ACHIEVED_MILESTONE')
activity_temp = activity.filter('upper(ACTIVITY_SCOPE_NAME) like "%PROJECT MILESTONE%" and ActualMilestoneDate is not null')
activity_temp = activity_temp.withColumn(
    'LATEST_ACHIEVED_MILESTONE', F.dense_rank().over(Window.partitionBy('PLAN_OBJECT_NUMBER').orderBy(activity_temp.ActualMilestoneDate.desc())))
activity_temp = activity_temp.withColumn('LATEST_ACHIEVED_MILESTONE', F.when(activity_temp.LATEST_ACHIEVED_MILESTONE == 1, 'True').otherwise('False'))
activity = activity.join(activity_temp.select('ACTIVITY_OBJECT_NUMBER', 'LATEST_ACHIEVED_MILESTONE'), ['ACTIVITY_OBJECT_NUMBER'], 'left')

# COMMAND ----------

# create LATEST_ACHIEVED_COMMIT_TO_MILESTONE
activity = activity.drop('LATEST_ACHIEVED_COMMIT_TO_MILESTONE')
activity_temp = activity.filter('upper(ACTIVITY_SCOPE_NAME) like "%PROJECT MILESTONE%" and upper(WBS_TYPE) like "%COMMIT%" and ActualMilestoneDate is not null')
activity_temp = activity_temp.withColumn(
    'LATEST_ACHIEVED_COMMIT_TO_MILESTONE', F.dense_rank().over(Window.partitionBy('PLAN_OBJECT_NUMBER').orderBy(activity_temp.ActualMilestoneDate.desc())))
activity_temp = activity_temp.withColumn('LATEST_ACHIEVED_COMMIT_TO_MILESTONE', F.when(activity_temp.LATEST_ACHIEVED_COMMIT_TO_MILESTONE == 1, 'True').otherwise('False'))
activity = activity.join(activity_temp.select('ACTIVITY_OBJECT_NUMBER', 'LATEST_ACHIEVED_COMMIT_TO_MILESTONE'), ['ACTIVITY_OBJECT_NUMBER'], 'left')
print(activity.count())

# COMMAND ----------

#cols = ['PLAN_OBJECT_NUMBER', 'ACTIVITY_OBJECT_NUMBER', 'ACTIVITY_NAME', 'ACTIVITY_DESCRIPTION', 'PLAN_NAME', 'CLINICAL_STUDY_ID', 'VESTED_UNIT_NAME', 'PROJECT_ID', 'WBS_TYPE', 'ACTIVITY_PLANNED_START_DATE', 'ACTIVITY_PLANNED_END_DATE', 'ACTIVITY_ACTUAL_START_DATE', 'ACTIVITY_ACTUAL_END_DATE', 'ACTIVITY_LINE_ID', 'PLAN_PHASE_NAME', 'PREDECESSORS', 'SUCCESSORS', 'ACTIVITY_SCOPE_NAME', 'SYNC_ISSUE', 'PAIR_DIFFERENTIATOR', 'ACTIVITY_CLASS_TYPE_NAME', 'ACTIVITY_CLASS_TYPE_DESCRIPTION', 'ACTIVITY_ID', 'ACTIVITY_VERSION_INTERNAL_ID', 'PLAN_FILE_NAME', 'ACTIVITY_USER_COMMENT', 'WBS_ELEMENT_FLAG', 'ACTIVITY_TASK_FLAG', 'ACTIVITY_PARENT_ID', 'ACTIVITY_IMPOSED_START_DATE', 'ACTIVITY_IMPOSED_FINISH_DATE', 'ACTIVITY_DURATION', 'ACTIVITY_TOTAL_FLOAT_DURATION', 'ACTIVITY_FREE_FLOAT_DURATION', 'ACTIVITY_CALENDER_TOTAL_FLOAT_DURATION', 'ACTIVITY_CALENDER_FREE_FLOAT_DURATION', 'ACTIVITY_CALENDER_NAME', 'ACTIVITY_PROGRESS_DATE', 'ACTIVITY_EXTENDIBLE_TYPE_NAME', 'ACTIVITY_PRECEDENT_START_DATE', 'ACTIVITY_PRECEDENT_END_DATE', 'ACTIVITY_CALENDER_FLOAT_FLAG', 'ACTIVITY_START_FLAG', 'ACTIVITY_FINISH_FLAG', 'ACTIVITY_PROGRESS_PECENTAGE', 'BUDGET_START_DATE', 'BUDGET_END_DATE', 'BUDGET_DURATION', 'THERAPY_AREA_SHORT_NAME', 'COMPOUND_ASSET_LONG_NAME', 'DISEASE_NAME', 'INDICATION_NAME', 'BS_6', 'BS_7', 'BS_9', 'ACTIVITY_LAST_MODIFICATION_DATE', 'ATIVITY_HIERARCHY_CODE', 'ACTIVITY_SEQUENCE_NUMBER', 'ORIGIN_NUMBER', 'PLAN_ID', 'ACTIVITY_ORIGIN_ID', 'SOURCE_ACTIVITY_ID', 'ACTIVITY_LAST_SYNCHRONISATION_DATE', 'ACTIVITY_LAST_SYNCHRONISED_VERSION', 'ACTIVITY_LAST_SYNCHRONISED_RULE_NAME', 'ACTIVITY_TASK_TYPE_NAME', 'ACTIVITY_ALLOCATION_COUNT', 'ACTIVITY_WORK_STRUCTURE_COUNT', 'ACTIVITY_PLAN_COUNT', 'ACTIVITY_TIME_SYNTHESIS_COUNT', 'ACTIVITY_LAST_MODIFICATION_BY', 'ACTIVITY_EARLIEST_END_DATE', 'ACTIVITY_LATEST_START_DATE', 'ACTIVITY_INTERFACE_FLAG', 'WP_LIBRARY_INTERNAL_NUMBER', 'WP_LIBRARY_VERSION_NUMBER', 'WP_LIBRARY_INTERNAL_NAME', 'WP_LIBRARY_VERSION_NAME', 'ACTIVITY_MILESTONE_FLAG', 'ACTIVITY_SYNCHRONISE_INDICATOR', 'TARGET_ACTIVITY_ID', 'SOURCE_PLAN_FINISH_SYNCHRONISATION_DATE', 'SYNCHRONISATION_TARGET_PLAN_START_DATE', 'SOURCE_PLAN_START_SYNCHRONISATION_DATE', 'ACTIVITY_START_MILESTONE_FLAG', 'SYNCHRONISATION_TARGET_PLAN_FINISH_DATE', 'TARGET_PLAN_START_SYNCHRONISATION_DATE', 'TARGET_PLAN_FINISH_SYNCHRONISATION_DATE', 'ACTIVITY_SUCCESSOR_LINE_ID', 'ACTIVITY_PREDECESSOR_LINE_ID', 'ACTIVITY_IN_HOUSE_FLAG', 'GLP_FLAG', 'TEMPORARY_CLINICAL_STUDY_ID', 'ACTIVITY_LAUNCH_FLAG', 'ACTIVITY_DECISION_POINT_FLAG', 'ACTIVITY_INTEGRITY_CHECK_FLAG', 'ACTIVITY_USER_COMMENT_1', 'ACTIVITY_USER_FLAG', 'ACTIVITY_USER_COMMENT_2', 'ACTIVITY_USER_COMMENT_3', 'ACTIVITY_USER_COMMENT_4', 'SPECIES_NAME', 'ACTIVITY_FUNDING_STATUS_TYPE_NAME', 'GSK_SITE_NAME', 'CRO_SITE_NAME', 'ROA_TYPE_NAME', 'ACTIVITY_SUB_TYPE_NAME', 'BIOSTATS_RESOURCE_STRATEGY', 'ACTIVITY_NEGATIVE_LAG_FLAG', 'STUDY_FLAG', 'ACTIVITY_POSITIVE_LAG_FLAG', 'ACTIVITY_PREDECESSOR_CALENDER_MATCH_FLAG', 'ACTIVITY_BROKEN_LOGIC_FLAG', 'ACTIVITY_SOURCE_DATE_MISMATCH_FLAG', 'ACTIVITY_LARGE_LAG_FLAG', 'WBS_LINK_FLAG', 'ACTIVITY_INTERNAL_NAME', 'PSAP_FLAG', 'ACTIVITY_FUNCTION_NAME', 'ACTIVITY_FUNCTION_DESCRIPTION', 'PLAN_INTERNAL_ID', 'ACTIVITY_SUB-FUNCTION_NAME', 'ACTIVITY_PLAN_NAME', 'MDP_FLAG', 'PLAN_TYPE_NAME', 'CSAP_FLAG', 'PAIRING_TYPE', 'PAIRING_STATUS', 'ACTIVITY_SYNCHRONIZATION_NEEDED', 'ACTIVITY_USED_FOR_SYNC', 'DURATION', 'LEVEL', 'ACTIVITY_HIERARCHY_CODE', 'WORK_PACKAGE_CODE', 'CRITICAL_PATH', 'NEXT_PLANNED_MILESTONE', 'NEXT_PLANNED_DECISION_POINT_MILESTONE', 'LATEST_ACHIEVED_MILESTONE', 'LATEST_ACHIEVED_COMMIT_TO_MILESTONE','ACTIVITY_RESOURCE_STRATEGY', 'NUMBER_OF_CENTERS', 'NUMBER_OF_STUDY_VISITS', 'COUNTRY', 'ACTIVITY_RESOURCE_ID', 'PLANNED_NUMBER_OF_PATIENTS', 'NUMBER_OF_DOSE_GROUPS', 'NEW_PROCESS_TECHNOLOGY_OR_PLATFORM', 'NUMBER_OF_ASSESSMENTS', 'STUDY_RESOURCE_STRATEGY', 'STUDY_BLINDING', 'NUMBER_OF_STAGES', 'QUANTITY_OF_MATERIAL', 'NUMBER_OF_SAMPLES', 'METHOD_VALIDATION', 'NUMBER_OF_BATCHES', 'SAME_PLANT_SITE', 'MANUFACTURE_TYPE', 'PARTNERSHIP_TYPE', 'STUDY_PHASE', 'STUDY_TYPE', 'STUDY_DESIGNATION', 'NON_TRADITIONAL_STUDY_DESIGN', 'NON_STANDARD_MOLECULE', 'SPECIFIC_HAZARD', 'FORMULATION_TYPE', 'NUMBER_OF_METHODS', 'NUMBER_OF_COUNTRIES', 'NUMBER_OF_IMAGES', 'BUDID_PROPAGATED', 'SOURCE', 'REFERENCE_OBJECT_NUMBER', 'ADMINISTRATION_ROUTE_TYPE', 'CONTRACT_RESEARCH_ORG_SITE_NAME', 'GSK_SITE_NETWORK_CODE', 'NCR_COMPLEXITY', 'GRPD_COMPLEXITY', 'CMC_COMPLEXITY', 'TG_COMPLEXITY', 'PROJECT_GROUP_CRITICAL_PATH_FLAG']

activity = activity.select(activity_cols)

# COMMAND ----------

# write to curated
rawPath = 'dbfs:/mnt/raw/planisware/'
unique_run_id = runid + '-LoadCuratedMigratedActivity/'
csv_temp_curated = rawPath + unique_run_id
curatedPath = 'dbfs:/mnt/curated/pdm/'
#
activity.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + "pdm_migrated_activity.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)