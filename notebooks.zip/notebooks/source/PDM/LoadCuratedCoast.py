# Databricks notebook source
# Load active_substance.txt from foundation to curated 

# COMMAND ----------

dbutils.widgets.text('runid', 'vfj3s-dv83q-cdn82-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

dbutils.fs.cp('dbfs:/mnt/foundation/pdm/active_substance.txt', 'dbfs:/mnt/curated/pdm/active_substance.txt', recurse = True)