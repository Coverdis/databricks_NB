# Databricks notebook source
#File Name: LoadCuratedPLWWorkstructure
#ADF Pipeline Name: Planisware_Reference_ADL
#SQLDW Table: NA
  #Read Planisware PLAN data from ADL and load to curated layer

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.functions import explode
processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "111")
# dbutils.widgets.text("file_path", "")

runid = dbutils.widgets.get("runid")
# file_path = dbutils.widgets.get("file_path")

# COMMAND ----------

df_json = spark.read.format("json")\
          .option("multiLine","true")\
          .option("nullValue","null")\
    .load('dbfs:/mnt/raw/planisware/new/workstructure/*.json')

df_json=df_json.withColumnRenamed('@odata.context','context')
print(df_json.count())
df_json_1=df_json.filter('context is not NULL')
print(df_json_1.count())

tempDf = df_json_1.select(explode("value").alias("value_exploded"))
df = tempDf.selectExpr( 'value_exploded.*')
df=df.drop('@odata.id')

# COMMAND ----------

# rename fields

#df = df.withColumnRenamed('PLAN_OBJECT_NUMBER', 'PLAN_OBJECT_NUMBER')
df = df.withColumnRenamed('OBJECT_NUMBER', 'WORKSTRUCTURE_OBJECT_NUMBER') 
df = df.withColumnRenamed('gsk_nf_s_per_onb', 'ACTIVITY_OBJECT_NUMBER') 

df = df.withColumnRenamed('NAME', 'ACTIVITY_NAME') # changed
df = df.withColumnRenamed('COMMENT', 'ACTIVITY_DESCRIPTION') # changed
df = df.withColumnRenamed('PROJECT', 'PLAN_NAME')
df = df.withColumnRenamed('GSK_AA_S_ETRK_STUDY_NB', 'CLINICAL_STUDY_ID') # changed
df = df.withColumnRenamed('8BS', 'VESTED_UNIT_NAME') # changed
df = df.withColumnRenamed('2BS', 'PROJECT_ID') # changed
df = df.withColumnRenamed('WBS_TYPE', 'WBS_TYPE') 
df = df.withColumnRenamed('gsk_da_d_ps', 'ACTIVITY_PLANNED_START_DATE') # changed
df = df.withColumnRenamed('gsk_da_d_pf', 'ACTIVITY_PLANNED_END_DATE') # changed
df = df.withColumnRenamed('EFFECTIVE_START', 'ACTIVITY_ACTUAL_START_DATE') # changed
df = df.withColumnRenamed('EFFECTIVE_FINISH', 'ACTIVITY_ACTUAL_END_DATE') # changed
df = df.withColumnRenamed('_PM_DA_S_LINE_ID', 'ACTIVITY_LINE_ID') # changed
df = df.withColumnRenamed('USER_ATTRIBUTE_GSK_UA_S_PHASE', 'PLAN_PHASE_NAME') # changed
df = df.withColumnRenamed('_SC_NF_S_PREDECESSOR', 'PREDECESSORS')
df = df.withColumnRenamed('_SC_NF_S_SUCCESSOR', 'SUCCESSORS')
df = df.withColumnRenamed('USER_ATTRIBUTE_GSK_UA_S_ACT_SCOPE', 'ACTIVITY_SCOPE_NAME') # changed
df = df.withColumnRenamed('USER_ATTRIBUTE_GSK_UA_S_SYNC_ISSUES', 'SYNC_ISSUE')
df = df.withColumnRenamed('USER_ATTRIBUTE_GSK_UA_S_DIFFERENTIATOR', 'PAIR_DIFFERENTIATOR')

# create fields for curated/unified
df = df.withColumnRenamed('CLASS', 'ACTIVITY_CLASS_TYPE_NAME')
df = df.withColumnRenamed('CLASS_COMMENT', 'ACTIVITY_CLASS_TYPE_DESCRIPTION')
#df = df.withColumnRenamed('OBJECT_NUMBER', 'ACTIVITY_INTERNAL_ID')
df = df.withColumnRenamed('ID', 'ACTIVITY_ID')
df = df.withColumnRenamed('MODIFY_VERSION', 'ACTIVITY_VERSION_INTERNAL_ID')
df = df.withColumnRenamed('DATASET', 'PLAN_FILE_NAME')
#df = df.withColumnRenamed('NAME', 'ACTIVITY_NAME')
#df = df.withColumnRenamed('COMMENT', 'ACTIVITY_DESCRIPTION')
df = df.withColumnRenamed('NOTE_PAD', 'ACTIVITY_USER_COMMENT')
df = df.withColumnRenamed('IS_NETWORK', 'WBS_ELEMENT_FLAG')
df = df.withColumnRenamed('IS_TASK', 'ACTIVITY_TASK_FLAG')
df = df.withColumnRenamed('NETWORK', 'ACTIVITY_PARENT_ID')
df = df.withColumnRenamed('IMPOSED_START', 'ACTIVITY_IMPOSED_START_DATE')
df = df.withColumnRenamed('IMPOSED_END', 'ACTIVITY_IMPOSED_FINISH_DATE')
df = df.withColumnRenamed('DURATION', 'ACTIVITY_DURATION')
df = df.withColumnRenamed('TOTAL_FLOAT', 'ACTIVITY_TOTAL_FLOAT_DURATION')
df = df.withColumnRenamed('FREE_FLOAT', 'ACTIVITY_FREE_FLOAT_DURATION')
df = df.withColumnRenamed('CALENDAR_TOTAL_FLOAT', 'ACTIVITY_CALENDER_TOTAL_FLOAT_DURATION')
df = df.withColumnRenamed('CALENDAR_FREE_FLOAT', 'ACTIVITY_CALENDER_FREE_FLOAT_DURATION')
#df = df.withColumnRenamed('REAL_START', 'ACTIVITY_PLANNED_START_DATE')
#df = df.withColumnRenamed('REAL_FINISH', 'ACTIVITY_PLANNED_END_DATE')
df = df.withColumnRenamed('CALENDAR', 'ACTIVITY_CALENDER_NAME')
df = df.withColumnRenamed('CURRENT_DATE', 'ACTIVITY_PROGRESS_DATE')
df = df.withColumnRenamed('STRECHING', 'ACTIVITY_EXTENDIBLE_TYPE_NAME')
df = df.withColumnRenamed('START_1', 'ACTIVITY_PRECEDENT_START_DATE')
df = df.withColumnRenamed('FINISH_1', 'ACTIVITY_PRECEDENT_END_DATE')
df = df.withColumnRenamed('INCONSISTENT_PLACEMENT', 'ACTIVITY_CALENDER_FLOAT_FLAG')
df = df.withColumnRenamed('HAS_STARTED', 'ACTIVITY_START_FLAG')
df = df.withColumnRenamed('IS_FINISHED', 'ACTIVITY_FINISH_FLAG')
#df = df.withColumnRenamed('PROJECT', 'PLAN_NAME')
df = df.withColumnRenamed('PHYSICAL_FURTHERANCE', 'ACTIVITY_PROGRESS_PECENTAGE')
df = df.withColumnRenamed('BUDGET_START', 'BUDGET_START_DATE')
df = df.withColumnRenamed('BUDGET_FINISH', 'BUDGET_END_DATE')
df = df.withColumnRenamed('BUDGET_DURATION', 'BUDGET_DURATION')
df = df.withColumnRenamed('0BS', 'THERAPY_AREA_SHORT_NAME')
df = df.withColumnRenamed('1BS', 'COMPOUND_ASSET_LONG_NAME')
#df = df.withColumnRenamed('2BS', 'PROJECT_ID')
df = df.withColumnRenamed('3BS', 'DISEASE_NAME')
df = df.withColumnRenamed('4BS', 'INDICATION_NAME')
df = df.withColumnRenamed('6BS', 'BS_6')
df = df.withColumnRenamed('7BS', 'BS_7')
#df = df.withColumnRenamed('8BS', 'VESTED_UNIT_NAME')
df = df.withColumnRenamed('9BS', 'BS_9')
df = df.withColumnRenamed('LAST_MODIFICATION', 'ACTIVITY_LAST_MODIFICATION_DATE')
df = df.withColumnRenamed('HIERARCHICAL_CODE', 'ATIVITY_HIERARCHY_CODE')
df = df.withColumnRenamed('ORDER_NUMBER', 'ACTIVITY_SEQUENCE_NUMBER')
df = df.withColumnRenamed('ORIGIN_NUMBER', 'ORIGIN_NUMBER')
df = df.withColumnRenamed('ORIGIN_PROJECT', 'PLAN_ID')
df = df.withColumnRenamed('ORIGIN_WORK_STRUCTURE', 'ACTIVITY_ORIGIN_ID')
df = df.withColumnRenamed('SYNCHRONIZE_WITH', 'SOURCE_ACTIVITY_ID')
df = df.withColumnRenamed('LAST_SYNC_DATE', 'ACTIVITY_LAST_SYNCHRONISATION_DATE')
df = df.withColumnRenamed('SYNC_VERSION', 'ACTIVITY_LAST_SYNCHRONISED_VERSION')
df = df.withColumnRenamed('LAST_SYNC_RULE', 'ACTIVITY_LAST_SYNCHRONISED_RULE_NAME')
df = df.withColumnRenamed('TASK_TYPE', 'ACTIVITY_TASK_TYPE_NAME')
#df = df.withColumnRenamed('EFFECTIVE_START', 'ACTIVITY_ACTUAL_START_DATE')
#df = df.withColumnRenamed('EFFECTIVE_FINISH', 'ACTIVITY_ACTUAL_END_DATE')
df = df.withColumnRenamed('ALLOC_COUNTER', 'ACTIVITY_ALLOCATION_COUNT')
df = df.withColumnRenamed('WS_COUNT', 'ACTIVITY_WORK_STRUCTURE_COUNT')
df = df.withColumnRenamed('PROJECT_COUNT', 'ACTIVITY_PLAN_COUNT')
df = df.withColumnRenamed('TS_COUNT', 'ACTIVITY_TIME_SYNTHESIS_COUNT')
df = df.withColumnRenamed('LAST_MODIFICATION_USER', 'ACTIVITY_LAST_MODIFICATION_BY')
df = df.withColumnRenamed('FINISH_NO_EARLIER', 'ACTIVITY_EARLIEST_END_DATE')
df = df.withColumnRenamed('START_NO_LATER', 'ACTIVITY_LATEST_START_DATE')
df = df.withColumnRenamed('_PM_AA_B_IS_AN_INTERFACE', 'ACTIVITY_INTERFACE_FLAG')
df = df.withColumnRenamed('_PM_AA_N_LIBRARY_ACT_ONB', 'WP_LIBRARY_INTERNAL_NUMBER')
df = df.withColumnRenamed('_PM_AA_N_LIBRARY_ACT_OVN', 'WP_LIBRARY_VERSION_NUMBER')
df = df.withColumnRenamed('_PM_AA_S_LIBRARY_ACT_ONB', 'WP_LIBRARY_INTERNAL_NAME')
df = df.withColumnRenamed('_PM_AA_S_LIBRARY_ACT_OVN', 'WP_LIBRARY_VERSION_NAME')
#df = df.withColumnRenamed('WBS_TYPE', 'ACTIVITY_TYPE_NAME')
df = df.withColumnRenamed('_MILESTONE', 'ACTIVITY_MILESTONE_FLAG')
df = df.withColumnRenamed('_PM_SF_SYNC_SOURCE_TA', 'ACTIVITY_SYNCHRONISE_INDICATOR')
df = df.withColumnRenamed('_PM_NF_S_USED_FOR_SYNC', 'TARGET_ACTIVITY_ID')
df = df.withColumnRenamed('_PM_SF_SYNC_PF_SOURCE', 'SOURCE_PLAN_FINISH_SYNCHRONISATION_DATE')
df = df.withColumnRenamed('_PM_NF_D_SYNC_TARGET_PS', 'SYNCHRONISATION_TARGET_PLAN_START_DATE')
df = df.withColumnRenamed('_PM_SF_SYNC_PS_SOURCE', 'SOURCE_PLAN_START_SYNCHRONISATION_DATE')
df = df.withColumnRenamed('START_MILESTONE', 'ACTIVITY_START_MILESTONE_FLAG')
df = df.withColumnRenamed('_PM_NF_D_SYNC_TARGET_PF', 'SYNCHRONISATION_TARGET_PLAN_FINISH_DATE')
df = df.withColumnRenamed('_PM_SF_SYNC_PS_TARGET', 'TARGET_PLAN_START_SYNCHRONISATION_DATE')
df = df.withColumnRenamed('_PM_SF_SYNC_PF_TARGET', 'TARGET_PLAN_FINISH_SYNCHRONISATION_DATE')
#df = df.withColumnRenamed('_PM_DA_S_LINE_ID', 'ACTIVITY_LINE_ID')
df = df.withColumnRenamed('_PM_DA_S_MSP_SUCCESSORS', 'ACTIVITY_SUCCESSOR_LINE_ID')
df = df.withColumnRenamed('_PM_DA_S_MSP_PREDECESSORS', 'ACTIVITY_PREDECESSOR_LINE_ID')
#df = df.withColumnRenamed('GSK_AA_B_IN_HOUSE', 'ACTIVITY_IN_HOUSE_FLAG')
df = df.withColumn('ACTIVITY_IN_HOUSE_FLAG',F.lit(None).cast(StringType()))
df = df.withColumnRenamed('GSK_AA_B_GLP', 'GLP_FLAG')
#df = df.withColumnRenamed('GSK_AA_S_ETRK_STUDY_NB', 'PERMANENT_CLINICAL_STUDY_ID')
df = df.withColumnRenamed('GSK_AA_S_TEMP_STUDY_NB', 'TEMPORARY_CLINICAL_STUDY_ID')
df = df.withColumnRenamed('GSK_AA_B_TO_LAUNCH', 'ACTIVITY_LAUNCH_FLAG')
df = df.withColumnRenamed('GSK_AA_B_DECISION_PT', 'ACTIVITY_DECISION_POINT_FLAG')
df = df.withColumnRenamed('GSK_AA_B_FLAGGED', 'ACTIVITY_INTEGRITY_CHECK_FLAG')
df = df.withColumnRenamed('GSK_AA_S_USERTEXT1', 'ACTIVITY_USER_COMMENT_1')
df = df.withColumnRenamed('GSK_AA_B_USERFLAG1', 'ACTIVITY_USER_FLAG')
df = df.withColumnRenamed('GSK_AA_S_USERTEXT2', 'ACTIVITY_USER_COMMENT_2')
df = df.withColumnRenamed('GSK_AA_S_USERTEXT3', 'ACTIVITY_USER_COMMENT_3')
df = df.withColumnRenamed('GSK_AA_S_USERTEXT4', 'ACTIVITY_USER_COMMENT_4')
# df = df.withColumnRenamed('GSK_AA_S_ACT_UNIQ_ID', 'ACTIVITY_ID') # id is also named as activity_id
df = df.withColumnRenamed('GSK_RA_ACT_SPECIES', 'SPECIES_NAME')
df = df.withColumnRenamed('GSK_RA_FUNDED_STATUS', 'ACTIVITY_FUNDING_STATUS_TYPE_NAME')
df = df.withColumnRenamed('GSK_RA_GSK_SITE', 'GSK_SITE_NAME')
df = df.withColumnRenamed('GSK_RA_CRO_SITE', 'CRO_SITE_NAME')
df = df.withColumnRenamed('GSK_RA_WP_ROA', 'ROA_TYPE_NAME')
df = df.withColumnRenamed('GSK_RA_ACTSUBTYPE', 'ACTIVITY_SUB_TYPE_NAME')
df = df.withColumnRenamed('GSK_NF_B_NEG_LAG', 'ACTIVITY_NEGATIVE_LAG_FLAG')
df = df.withColumnRenamed('GSK_NF_B_SY_GROUP', 'STUDY_FLAG')
df = df.withColumnRenamed('GSK_NF_B_POS_LAG', 'ACTIVITY_POSITIVE_LAG_FLAG')
df = df.withColumnRenamed('GSK_NF_B_PRED_CAL_NO_MATCH', 'ACTIVITY_PREDECESSOR_CALENDER_MATCH_FLAG')
df = df.withColumnRenamed('GSK_NF_B_BROKEN_LOGIC', 'ACTIVITY_BROKEN_LOGIC_FLAG')
df = df.withColumnRenamed('GSK_NF_B_SOURCE_DATE_MATCH', 'ACTIVITY_SOURCE_DATE_MISMATCH_FLAG')
df = df.withColumnRenamed('GSK_NF_B_LONG_LAG', 'ACTIVITY_LARGE_LAG_FLAG')
df = df.withColumnRenamed('GSK_NF_B_SUMMARY_LINKS', 'WBS_LINK_FLAG')

df = df.withColumnRenamed('USER_ATTRIBUTE_GSK_UA_S_ACT_ID_EXPORT', 'ACTIVITY_INTERNAL_NAME')
df = df.withColumnRenamed('USER_ATTRIBUTE_GSK_UA_B_PSAP', 'PSAP_FLAG')

df = df.withColumnRenamed('USER_ATTRIBUTE_GSK_UA_S_FUNCTION', 'ACTIVITY_FUNCTION_NAME')
df = df.withColumnRenamed('USER_ATTRIBUTE_GSK_UA_S_FUNCTION_DESC', 'ACTIVITY_FUNCTION_DESCRIPTION')

df = df.withColumnRenamed('USER_ATTRIBUTE_GSK_UA_S_ACT_PLAN_ONB', 'PLAN_INTERNAL_ID')
df = df.withColumnRenamed('USER_ATTRIBUTE_GSK_UA_S_ACT_WORKSTREAM', 'ACTIVITY_SUB-FUNCTION_NAME')
df = df.withColumnRenamed('USER_ATTRIBUTE_GSK_UA_S_PLAN_NAME', 'ACTIVITY_PLAN_NAME')
df = df.withColumnRenamed('USER_ATTRIBUTE_GSK_UA_B_LINE_PLAN', 'MDP_FLAG')
df = df.withColumnRenamed('USER_ATTRIBUTE_GSK_UA_S_PRJ_PLAN_TYPE', 'PLAN_TYPE_NAME')
df = df.withColumnRenamed('USER_ATTRIBUTE_GSK_UA_B_DETAILED_PLAN', 'CSAP_FLAG')
df = df.withColumnRenamed('MCN_NF_B_ON_CRIT_PATH', 'CRITICAL_PATH')

# COMMAND ----------

# transform date fields

date_fields = ['ACTIVITY_IMPOSED_START_DATE', 'ACTIVITY_IMPOSED_FINISH_DATE', 'ACTIVITY_PLANNED_START_DATE', 'ACTIVITY_PLANNED_END_DATE', 'ACTIVITY_PROGRESS_DATE', 'ACTIVITY_PRECEDENT_START_DATE', 'ACTIVITY_PRECEDENT_END_DATE', 'BUDGET_START_DATE', 'BUDGET_END_DATE', 'ACTIVITY_LAST_MODIFICATION_DATE', 'ACTIVITY_LAST_SYNCHRONISATION_DATE', 'ACTIVITY_ACTUAL_START_DATE', 'ACTIVITY_ACTUAL_END_DATE', 'ACTIVITY_EARLIEST_END_DATE', 'ACTIVITY_LATEST_START_DATE', 'SYNCHRONISATION_TARGET_PLAN_START_DATE', 'SYNCHRONISATION_TARGET_PLAN_FINISH_DATE', 'SOURCE_PLAN_START_SYNCHRONISATION_DATE', 'SOURCE_PLAN_FINISH_SYNCHRONISATION_DATE', 'TARGET_PLAN_START_SYNCHRONISATION_DATE', 'TARGET_PLAN_FINISH_SYNCHRONISATION_DATE']

for field in date_fields:
  df = df.withColumn(field, F.from_unixtime(F.regexp_extract(df[field], '\d+', 0)/1000).cast(TimestampType()))
  df = df.withColumn(field, 
                         F.when(F.datediff(F.to_date(F.lit("1970-01-01")), F.to_date(df[field], "yyyy-MM-dd")) == 0, 
                                None
                               ).otherwise(df[field])
               )

# COMMAND ----------

cols = [ 'WORKSTRUCTURE_OBJECT_NUMBER', 'ACTIVITY_OBJECT_NUMBER', 'ACTIVITY_NAME', 'ACTIVITY_DESCRIPTION', 'PLAN_NAME', 'CLINICAL_STUDY_ID', 'VESTED_UNIT_NAME', 'PROJECT_ID', 'WBS_TYPE', 'ACTIVITY_PLANNED_START_DATE', 'ACTIVITY_PLANNED_END_DATE', 'ACTIVITY_ACTUAL_START_DATE', 'ACTIVITY_ACTUAL_END_DATE', 'ACTIVITY_LINE_ID', 'PLAN_PHASE_NAME', 'PREDECESSORS', 'SUCCESSORS', 'ACTIVITY_SCOPE_NAME', 'SYNC_ISSUE', 'PAIR_DIFFERENTIATOR', 'ACTIVITY_CLASS_TYPE_NAME', 'ACTIVITY_CLASS_TYPE_DESCRIPTION', 'ACTIVITY_ID', 'ACTIVITY_VERSION_INTERNAL_ID', 'PLAN_FILE_NAME', 'ACTIVITY_USER_COMMENT', 'WBS_ELEMENT_FLAG', 'ACTIVITY_TASK_FLAG', 'ACTIVITY_PARENT_ID', 'ACTIVITY_IMPOSED_START_DATE', 'ACTIVITY_IMPOSED_FINISH_DATE', 'ACTIVITY_DURATION', 'ACTIVITY_TOTAL_FLOAT_DURATION', 'ACTIVITY_FREE_FLOAT_DURATION', 'ACTIVITY_CALENDER_TOTAL_FLOAT_DURATION', 'ACTIVITY_CALENDER_FREE_FLOAT_DURATION', 'ACTIVITY_CALENDER_NAME', 'ACTIVITY_PROGRESS_DATE', 'ACTIVITY_EXTENDIBLE_TYPE_NAME', 'ACTIVITY_PRECEDENT_START_DATE', 'ACTIVITY_PRECEDENT_END_DATE', 'ACTIVITY_CALENDER_FLOAT_FLAG', 'ACTIVITY_START_FLAG', 'ACTIVITY_FINISH_FLAG', 'ACTIVITY_PROGRESS_PECENTAGE', 'BUDGET_START_DATE', 'BUDGET_END_DATE', 'BUDGET_DURATION', 'THERAPY_AREA_SHORT_NAME', 'COMPOUND_ASSET_LONG_NAME', 'DISEASE_NAME', 'INDICATION_NAME', 'BS_6', 'BS_7', 'BS_9', 'ACTIVITY_LAST_MODIFICATION_DATE', 'ATIVITY_HIERARCHY_CODE', 'ACTIVITY_SEQUENCE_NUMBER', 'ORIGIN_NUMBER', 'PLAN_ID', 'ACTIVITY_ORIGIN_ID', 'SOURCE_ACTIVITY_ID', 'ACTIVITY_LAST_SYNCHRONISATION_DATE', 'ACTIVITY_LAST_SYNCHRONISED_VERSION', 'ACTIVITY_LAST_SYNCHRONISED_RULE_NAME', 'ACTIVITY_TASK_TYPE_NAME', 'ACTIVITY_ALLOCATION_COUNT', 'ACTIVITY_WORK_STRUCTURE_COUNT', 'ACTIVITY_PLAN_COUNT', 'ACTIVITY_TIME_SYNTHESIS_COUNT', 'ACTIVITY_LAST_MODIFICATION_BY', 'ACTIVITY_EARLIEST_END_DATE', 'ACTIVITY_LATEST_START_DATE', 'ACTIVITY_INTERFACE_FLAG', 'WP_LIBRARY_INTERNAL_NUMBER', 'WP_LIBRARY_VERSION_NUMBER', 'WP_LIBRARY_INTERNAL_NAME', 'WP_LIBRARY_VERSION_NAME', 'ACTIVITY_MILESTONE_FLAG', 'ACTIVITY_SYNCHRONISE_INDICATOR', 'TARGET_ACTIVITY_ID', 'SOURCE_PLAN_FINISH_SYNCHRONISATION_DATE', 'SYNCHRONISATION_TARGET_PLAN_START_DATE', 'SOURCE_PLAN_START_SYNCHRONISATION_DATE', 'ACTIVITY_START_MILESTONE_FLAG', 'SYNCHRONISATION_TARGET_PLAN_FINISH_DATE', 'TARGET_PLAN_START_SYNCHRONISATION_DATE', 'TARGET_PLAN_FINISH_SYNCHRONISATION_DATE', 'ACTIVITY_SUCCESSOR_LINE_ID', 'ACTIVITY_PREDECESSOR_LINE_ID', 'ACTIVITY_IN_HOUSE_FLAG', 'GLP_FLAG', 'TEMPORARY_CLINICAL_STUDY_ID', 'ACTIVITY_LAUNCH_FLAG', 'ACTIVITY_DECISION_POINT_FLAG', 'ACTIVITY_INTEGRITY_CHECK_FLAG', 'ACTIVITY_USER_COMMENT_1', 'ACTIVITY_USER_FLAG', 'ACTIVITY_USER_COMMENT_2', 'ACTIVITY_USER_COMMENT_3', 'ACTIVITY_USER_COMMENT_4', 'SPECIES_NAME', 'ACTIVITY_FUNDING_STATUS_TYPE_NAME', 'GSK_SITE_NAME', 'CRO_SITE_NAME', 'ROA_TYPE_NAME', 'ACTIVITY_SUB_TYPE_NAME', 'ACTIVITY_NEGATIVE_LAG_FLAG', 'STUDY_FLAG', 'ACTIVITY_POSITIVE_LAG_FLAG', 'ACTIVITY_PREDECESSOR_CALENDER_MATCH_FLAG', 'ACTIVITY_BROKEN_LOGIC_FLAG', 'ACTIVITY_SOURCE_DATE_MISMATCH_FLAG', 'ACTIVITY_LARGE_LAG_FLAG', 'WBS_LINK_FLAG', 'ACTIVITY_INTERNAL_NAME', 'PSAP_FLAG', 'ACTIVITY_FUNCTION_NAME', 'ACTIVITY_FUNCTION_DESCRIPTION', 'PLAN_INTERNAL_ID', 'ACTIVITY_SUB-FUNCTION_NAME', 'ACTIVITY_PLAN_NAME', 'MDP_FLAG', 'PLAN_TYPE_NAME', 'CSAP_FLAG']

df = df.select(cols)

# COMMAND ----------

#load to SQL DW
df.write\
  .format("com.databricks.spark.sqldw")\
  .option("url", sqlDwUrl)\
  .option( "forward_spark_azure_storage_credentials", "True")\
  .option("tempdir", tempDir)\
  .option("maxStrLength", 4000)\
  .option("dbtable", "irm_stg.PLW_WORKSTRUCTURE") \
  .mode("overwrite")\
  .save()

# COMMAND ----------

# write to curated
rawPath = 'dbfs:/mnt/raw/planisware/'
unique_run_id = runid + '-LoadCuratedPLWWorkstructure/'
csv_temp_curated = rawPath + unique_run_id
curatedPath = 'dbfs:/mnt/raw/planisware/new/'

df.repartition(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + "plw_workstructure.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)