# Databricks notebook source
#File Name: LoadCuratedPLWPlan
#ADF Pipeline Name: Planisware_ADL
#SQLDW Table: NA
  #Read Planisware PLAN data from ADL and load to curated layer
  #loadflag: full - will truncate and reload all the data in each layer
  #loadflag: incremental - will append the data to the existing in curated layer replacing the modified plans from the incremental load

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

# MAGIC %run /source/Planisware/PLWConfig

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
from pyspark.sql.functions import explode
import os
from glob import glob
import re

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "111")
dbutils.widgets.dropdown("fullloadflag", "true", ['true', 'false'])

runid = dbutils.widgets.get("runid")
fullloadflag = dbutils.widgets.get("fullloadflag")

# COMMAND ----------

# read plan data from curated layer
project = spark.read.format("csv")\
      .option("inferSchema","false")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
    .load('dbfs:/mnt/curated/planisware/new/plw_plan.txt')

project = project.toDF(*(col.replace('\r', '') for col in project.columns))

# COMMAND ----------

# on full load the data loaded from curated will be deleted
if fullloadflag == 'true':
  project = project.limit(0)

# COMMAND ----------

# read delta project data - having newly modified plans
delta_project = spark.read.format("csv")\
      .option("inferSchema","false")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/planisware/new/plw_plan.txt')

delta_project = delta_project.toDF(*(col.replace('\r', '') for col in delta_project.columns))

delta_project = delta_project.toDF(*[c.upper() for c in delta_project.columns])

print(delta_project.count())

# COMMAND ----------

delta_project = delta_project.withColumn('EXPORT_ID', F.lit(delta_project.EXPORT_ID.cast(IntegerType())))
# max_exp_df = delta_project.groupby('PLAN_INTERNAL_NUMBER').agg({'EXPORT_ID': 'max'})
# max_exp_df = max_exp_df.withColumnRenamed('max(EXPORT_ID)', 'MAX_EXPORT_ID')
# max_exp_df = max_exp_df.withColumnRenamed('PLAN_INTERNAL_NUMBER', 'PLAN_INTERNAL_NUMBER0')

# COMMAND ----------

# delta_project = delta_project.join(max_exp_df, (delta_project.EXPORT_ID == max_exp_df['MAX_EXPORT_ID']) & (delta_project.PLAN_INTERNAL_NUMBER == max_exp_df['PLAN_INTERNAL_NUMBER0']), 'rightouter')

# COMMAND ----------

if delta_project.count() == 0:
  dbutils.notebook.exit('There are no new Plans to be pulled for incremental load')

# COMMAND ----------

# getting the maximum of EXPORT_ID from delta file
export_id = delta_project.agg({"EXPORT_ID": "max"}).collect()[0][0]
print(export_id)

# COMMAND ----------

# Updating max EXPORT_ID to STAGE_LOAD_LOG for incremental load
sql = "Update STAGE_LOAD_LOG set value = '"+ str(export_id) +"', datetime = '"+ processTime +"' where type = 'plw_export_id'"
dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})

# COMMAND ----------

delta_project = delta_project.drop('EXPORT_ID')

# COMMAND ----------

# column renaming and adding null references
delta_project = colRename(new_plan_dict , delta_project)

delta_project = addNullReference(delta_project, spark.createDataFrame([plan_cols], plan_cols))

delta_project = delta_project.select(plan_cols)

# adding null reference to curated file if a new column is being added
if len(delta_project.columns) != len(project.columns):
  project = addNullReference(project, spark.createDataFrame([plan_cols], plan_cols))
project = project.select(plan_cols)

# COMMAND ----------

# appending newly modified plans to the project df
plan = project.join(delta_project, project.PLAN_OBJECT_NUMBER == delta_project.PLAN_OBJECT_NUMBER, 'leftanti')
project = plan.union(delta_project)

# COMMAND ----------

# loading the file with all deleted flagged plans using pp_deleted_date from planisware table
deletedPlans = spark.read.format("csv")\
      .option("inferSchema","false")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/planisware/new/plw_plan_deleted.txt')

deletedPlans = deletedPlans.toDF(*(col.replace('\r', '') for col in deletedPlans.columns))
print(deletedPlans.count())

# COMMAND ----------

# removing all deletd plans from the project df
project = project.join(deletedPlans, project.PLAN_OBJECT_NUMBER == deletedPlans.PLAN_INTERNAL_NUMBER, 'leftanti')
print(project.count())

# COMMAND ----------

#load null values from reference
project = project.withColumn('REFERENCE_OBJECT_NUMBER', F.lit(None).cast(LongType()))
project = project.withColumn('BUDGET_ID', project.BUDGET_ID.cast(LongType()))
project = project.withColumn('REFERENCE_ARCHIVE_DATE', F.lit(None).cast(TimestampType()))
project = project.withColumn('SOURCE', F.lit('PLW-NEW').cast(StringType()))

# COMMAND ----------

project = project.withColumn('PLAN_ACTIVE_FLAG', F.when((project.PLAN_STATE == 'Active') | (project.PLAN_STATE == 'In development'), "true").otherwise("false"))

# COMMAND ----------

# updating data type for all date fields
for field in plan_date_fields:
    project = project.withColumn(field, project[field].cast(TimestampType()))

# COMMAND ----------

project = project.select(plan_cols)

# COMMAND ----------

# write to curated
rawPath = 'dbfs:/mnt/raw/planisware/'
unique_run_id = runid + '-LoadPLWPlan/'
csv_temp_curated = rawPath + unique_run_id + '/' + 'curated/'
curatedPath = 'dbfs:/mnt/curated/planisware/new/'

project.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + "plw_plan.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)