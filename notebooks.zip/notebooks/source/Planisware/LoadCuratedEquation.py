# Databricks notebook source
#File Name:LoadCuratedEquation
#ADF Pipeline Name: Planisware_ADL-Equations
#SQLDW - irm_stg.EQUATIONS
#Description:
  #Merges the drivers of EQUATIONS
  #Write data in SQL DW for PLANISWARE EQUATIONS

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
import os
from glob import glob
import re
import pytz
from datetime import datetime
processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')



# COMMAND ----------

dbutils.widgets.text("runid", "111")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

# MAGIC %run /source/Planisware/PLWConfig

# COMMAND ----------

foundationPath = 'dbfs:/mnt/foundation/planisware/new/equations.txt'
rawPath = 'dbfs:/mnt/raw/planisware/equations/'
curatedPath = 'dbfs:/mnt/curated/planisware/new'
csv_temp_curated = rawPath + runid + '/' + 'curated'


# COMMAND ----------

df = spark.read.format("csv")\
      .option("inferSchema", "false")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load(foundationPath)

# COMMAND ----------

df=df.withColumn('equation',F.when(df.equation.isNull(),'0').otherwise(df.equation))

# COMMAND ----------

# UDF to parse the pattern to extract the drivers
def unique_driver_lst(str):
  spl=str.split(' ')
  split_str1=[re.sub("[^A-Za-z_]","",x) for x in spl ]
  split_str2=[x for x in split_str1 if "_" in x]
  split_str2=list(set(split_str2))
  return split_str2

# COMMAND ----------

# Registering the UDF
unique_driver_lst_udf = F.udf(unique_driver_lst, StringType())

# COMMAND ----------

# Calling the UDF 
df=df.withColumn('driver_lst',unique_driver_lst_udf(F.col('equation')))


# COMMAND ----------

# Exploding the drivers based on the no of object number records
df=df.select('*',F.explode(F.split(F.col("driver_lst"), ",")).alias("driver_lst_L"))

# COMMAND ----------

# UDF to mapping the technical drivers to blueprinted driver names
def mapping_drivers(str):
  pattern = re.compile(r'\s+')
 
  str1=str.replace('[','').replace(']','')
  str1 = re.sub(pattern, '', str1)
  if str1.upper() in odata_act_dict.keys():
    return odata_act_dict[str1.upper()]
  elif str1.lower() in odata_act_dict.keys():
    return odata_act_dict[str1.lower()]
  else:
    return str1

# COMMAND ----------

# Register the UDF for mapping drivers
mapping_Driver_udf = F.udf(mapping_drivers, StringType())

# COMMAND ----------

# Calling the registerd Mapping drivers UDF
df=df.withColumn('Driver_Name',mapping_Driver_udf(F.col('driver_lst_L')))


# COMMAND ----------

# Renaming the headers
df=df.withColumnRenamed('equ_name','equation_name')
df=df.withColumnRenamed('equ_onb','equation_object_number')
df=df.withColumnRenamed('equ_equation_template','equation_template')
df=df.withColumnRenamed('plan_type','plan_type_name')
df=df.withColumnRenamed('wbs_type','wbs_type')
df=df.withColumnRenamed('Driver_Name','driver_name')
df=df.withColumnRenamed('equ_resource','id')

# COMMAND ----------

df=df.select('equation_name','equation_object_number','equation','equation_template','plan_type_name','wbs_type','driver_name','id')

# COMMAND ----------

df=df.groupBy(df.columns).count().where("count = 1")

# COMMAND ----------

# write ranked to curated temp folder
df.write.option("sep", "|")\
          .option("header", "true")\
          .option("quote",  '"')\
          .option("escape", '"')\
          .option("nullValue", "null")\
          .option("quoteAll", "true")\
          .mode('overwrite')\
        .csv(csv_temp_curated)
# copy part-* csv file to curated and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + '/' +'equations.txt', recurse = True)

# remove foundation/curated temp folders
dbutils.fs.rm(csv_temp_curated, recurse = True)