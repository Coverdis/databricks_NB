# Databricks notebook source
#File Name: LoadCuratedPLWReferenceHistory
#ADF Pipeline Name: Planisware_Reference_ADL
#SQLDW Table: NA
  #Read Planisware PLAN data from ADL and load to curated layer

# COMMAND ----------

# MAGIC %run /source/Planisware/PLWConfig

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
from pyspark.sql.functions import explode,lit
processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "")
dbutils.widgets.text("reference_object_number", "")
runid = dbutils.widgets.get("runid")
reference_object_number = dbutils.widgets.get("reference_object_number")

# COMMAND ----------

#get reference data
df_json = spark.read.format("json")\
          .option("multiLine","true")\
          .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/planisware/new/reference/'+reference_object_number+'.json')

df_json=df_json.withColumnRenamed('@odata.context','context')
df_json_1=df_json.filter('context is not NULL')
tempDf = df_json_1.select(explode("value").alias("value_exploded"))
reference_df = tempDf.selectExpr( 'value_exploded.*')
reference_df=reference_df.drop('@odata.id')

#change dates


# COMMAND ----------


date_fields=['archive_date' , 'current_date','last_modification']
# date_fields = ['PLAN_CREATION_DATE', 'PLAN_MODIFICATION_DATE', 'PROJECT_PLANNED_START_DATE', 'PLAN_CURRENT_DATE', 'PROJECT_PLANNED_END_DATE', 'PLAN_LAST_MODIFICATION_DATE', 'PLAN_LOCKED_DATE', 'PROJECT_ACTUAL_START_DATE', 'PROJECT_ACTUAL_END_DATE', 'BUDGET_PLANNED_START_DATE', 'BUDGET_PLANNED_END_DATE', 'PLAN_LAST_REVIEWED_DATE','LAST_MODIFICATION','REFERENCE_ARCHIVE_DATE' ,'CURRENT_DATE']

for field in date_fields:
  if field in reference_df.columns:
    reference_df = reference_df.withColumn(field, F.from_unixtime(F.regexp_extract(reference_df[field], '\d+',0)/1000).cast(TimestampType()))
    reference_df = reference_df.withColumn(field, 
                         F.when(F.datediff(F.to_date(F.lit("1970-01-01")), F.to_date(reference_df[field], "yyyy-MM-dd")) == 0, 
                                None
                               ).otherwise(reference_df[field]))
# display(reference_df)
                                                   
                                                   

# COMMAND ----------

df_json = spark.read.format("json")\
          .option("multiLine","true")\
          .option("nullValue","null")\
     .load('dbfs:/mnt/foundation/planisware/new/reference_history/'+ reference_object_number + '.json')

df_json=df_json.withColumnRenamed('@odata.context','context')
tempDf = df_json.select(explode("value").alias("value_exploded"))
df = tempDf.selectExpr( 'value_exploded.*')
replace_values=F.udf(lambda x :  x.replace('-','_'))
df=df.withColumn('ATTRIBUTE',replace_values(df['ATTRIBUTE']))

# COMMAND ----------

# Function to return the Pivot dataframe by converting in to pandas dataframe 
# Takes input as dataframe , coverting to pandas to perform the pivot the values 
# Return in the list of Spark Dataframe , pandas dataframe , pivoted_spark dataframe

def pivoting_Table(df , filter_value  ,idx ,col ,val ):
  df = df.filter( df.OBJECT_CLASS == filter_value )
  df_pd = df.toPandas()
  df_pd.drop_duplicates(inplace=True)
  df_pvt = df_pd.pivot(idx ,col ,val )
  df_pvt.reset_index(inplace=True)
  df1_spark = spark.createDataFrame(df_pvt.astype('str'))
  return df1_spark , df , df_pvt

# COMMAND ----------

# Calling the Pivot UDF and storing in to the respective variable for plan & Activity
plan_df= pivoting_Table(df ,  'ORDO-PROJECT' , 'PROJECT_ONB' , 'ATTRIBUTE', 'VALUE')
plan_spark_df = plan_df[0]
Activity_df = pivoting_Table(df ,  'WORK-STRUCTURE' , 'OBJECT_ONB' , 'ATTRIBUTE', 'VALUE')
Activity_spark_df=Activity_df[0]

# COMMAND ----------

# Creating variable to store the Project ONB & Reference ONB respectively

PROJECT_ONB_val =df.select('PROJECT_ONB').distinct().collect()[0][0]
REFERENCE_ONB_val =df.select('REFERENCE_ONB').distinct().collect()[0][0]


# COMMAND ----------

# Creating column for Reference obj number in plan dataframe
plan_spark_df=plan_spark_df.withColumn('REFERENCE_OBJECT_NUMBER', F.lit(REFERENCE_ONB_val))


# calling the Renaming function to Plan Dataframe

plan_spark_df_new = colRename(odata_plan_dict, plan_spark_df)

# COMMAND ----------

reference_df_new = colRename(odata_plan_dict, reference_df)
ref_drop_col=[x for  x in plan_spark_df_new.columns if x in reference_df_new.columns]
reference_df_new = reference_df_new.select([x for x in reference_df_new.columns if x not in ref_drop_col])
reference_df_upd=reference_df_new.withColumn('REFERENCE_OBJECT_NUMBER', F.lit(REFERENCE_ONB_val))

# COMMAND ----------

# Creating column for Reference obj number in Activity dataframe
Activity_spark_df=Activity_spark_df.withColumn('PROJECT_ONB', F.lit(PROJECT_ONB_val)).withColumn('REFERENCE_OBJECT_NUMBER', F.lit(REFERENCE_ONB_val))

# calling the Renaming function to Activity Dataframe
Activity_spark_df_new = colRename(odata_act_dict, Activity_spark_df)
# display(Activity_spark_df_new)

# COMMAND ----------

spark.conf.set("spark.sql.crossJoin.enabled", "true")

plan_ref_spark_df = plan_spark_df_new.join(reference_df_upd,on='REFERENCE_OBJECT_NUMBER',how='left')


# COMMAND ----------

Null_columns=['PLAN_CURRENT_DATE',
'PROJECT_PLANNED_END_DATE',
'ORIGIN_DATE']
for col in Null_columns:
  if col in plan_ref_spark_df.columns:
    plan_ref_spark_df= plan_ref_spark_df.withColumn(col,lit(None).cast(StringType()))

# COMMAND ----------

# # transform Plan date fields

# date_fields=['PLAN_LAST_MODIFICATION_DATE' , 'REFERENCE_ARCHIVE_DATE']
# # date_fields = ['PLAN_CREATION_DATE', 'PLAN_MODIFICATION_DATE', 'PROJECT_PLANNED_START_DATE', 'PLAN_CURRENT_DATE', 'PROJECT_PLANNED_END_DATE', 'PLAN_LAST_MODIFICATION_DATE', 'PLAN_LOCKED_DATE', 'PROJECT_ACTUAL_START_DATE', 'PROJECT_ACTUAL_END_DATE', 'BUDGET_PLANNED_START_DATE', 'BUDGET_PLANNED_END_DATE', 'PLAN_LAST_REVIEWED_DATE','LAST_MODIFICATION','REFERENCE_ARCHIVE_DATE' ,'CURRENT_DATE']

# for field in date_fields:
#   if field in plan_ref_spark_df.columns:
#     plan_ref_spark_df = plan_ref_spark_df.withColumn(field, F.from_unixtime(F.regexp_extract(plan_ref_spark_df[field], '\d+',0)/1000).cast(TimestampType()))
#     plan_ref_spark_df = plan_ref_spark_df.withColumn(field, 
#                          F.when(F.datediff(F.to_date(F.lit("1970-01-01")), F.to_date(plan_ref_spark_df[field], "yyyy-MM-dd")) == 0, 
#                                 None
#                                ).otherwise(plan_ref_spark_df[field])
#                )
# Null_columns=['PLAN_CURRENT_DATE',
# 'PROJECT_PLANNED_END_DATE',
# 'ORIGIN_DATE']
# for col in Null_columns:
#   if col in plan_ref_spark_df.columns:
#     plan_ref_spark_df= plan_ref_spark_df.withColumn(col,F.lit(None))


# COMMAND ----------

# transform Activity date fields

# activity_date_fields = ['ACTIVITY_IMPOSED_START_DATE', 'ACTIVITY_IMPOSED_FINISH_DATE', 'ACTIVITY_PLANNED_START_DATE', 'ACTIVITY_PLANNED_END_DATE', 'ACTIVITY_PROGRESS_DATE', 'ACTIVITY_PRECEDENT_START_DATE', 'ACTIVITY_PRECEDENT_END_DATE', 'BUDGET_START_DATE', 'BUDGET_END_DATE', 'ACTIVITY_LAST_MODIFICATION_DATE', 'ACTIVITY_LAST_SYNCHRONISATION_DATE', 'ACTIVITY_ACTUAL_START_DATE', 'ACTIVITY_ACTUAL_END_DATE', 'ACTIVITY_EARLIEST_END_DATE', 'ACTIVITY_LATEST_START_DATE', 'SYNCHRONISATION_TARGET_PLAN_START_DATE', 'SYNCHRONISATION_TARGET_PLAN_FINISH_DATE', 'SOURCE_PLAN_START_SYNCHRONISATION_DATE', 'SOURCE_PLAN_FINISH_SYNCHRONISATION_DATE', 'TARGET_PLAN_START_SYNCHRONISATION_DATE', 'TARGET_PLAN_FINISH_SYNCHRONISATION_DATE']

for field in activity_date_fields:
   if field in Activity_spark_df_new.columns:
    Activity_spark_df_new=Activity_spark_df_new.withColumn(field,F.to_date(Activity_spark_df_new[field],'dd-MMM-yyyy'))
    #Activity_spark_df_new=Activity_spark_df_new.withColumn(field,F.from_unixtime(F.unix_timestamp(Activity_spark_df_new[field],'dd-MMM-yyyy')))
    
# for field in activity_date_fields:
#   if field in Activity_spark_df_new.columns:
#     Activity_spark_df_new = Activity_spark_df_new.withColumn(field, F.from_unixtime(F.regexp_extract(Activity_spark_df_new[field], '\d+', 0)/1000).cast(TimestampType()))
#     Activity_spark_df_new = Activity_spark_df_new.withColumn(field, 
#                          F.when(F.datediff(F.to_date(F.lit("1970-01-01")), F.to_date(Activity_spark_df_new[field], "yyyy-MM-dd")) == 0, 
#                                 None
#                                ).otherwise(Activity_spark_df_new[field])
#                )

# COMMAND ----------

# read plan data from irm_stg.plw_plan in SQL DW
jdbc_plan_df=spark.read.format("com.databricks.spark.sqldw")\
  .option("url", sqlDwUrl)\
  .option( "forward_spark_azure_storage_credentials", "True")\
  .option("tempdir", tempDir)\
  .option("maxStrLength", 4000)\
  .option("dbtable", "irm_stg.plw_plan") \
  .load()

# read plan data from irm_stg.plw_plan in SQL DW
jdbc_activity_df=spark.read.format("com.databricks.spark.sqldw")\
  .option("url", sqlDwUrl)\
  .option( "forward_spark_azure_storage_credentials", "True")\
  .option("tempdir", tempDir)\
  .option("maxStrLength", 4000)\
  .option("dbtable", "irm_stg.plw_activity") \
  .load()

# COMMAND ----------

def adding_diff_columns(df , jdbcdf , exclude_col):
  jdbcdf_set = set(jdbcdf.columns)
  plan_df_set = set(df.columns)
  jdbcdf_set_diff= jdbcdf_set - plan_df_set

  for x in jdbcdf_set_diff :
    if x not in exclude_col:
      df=df.withColumn(x,lit(None).cast(StringType()))
  return df 


# COMMAND ----------

exclude_col = ['RUN_ID','CREATION_DATE','CREATED_BY','UPDATION_DATE','UPDATED_BY','GSK_AA_A_BASELINE_MS']
exclude_col_activity=['MILESTONE_LONG_NAME','MILESTONE_SHORT_NAME',
'MILESTONE_ABBREVIATION','MILESTONE_SORT_ORDER','MILESTONE_PHASE_PROGRESSION','MILESTONE_SYNONYM','MILESTONE_CALC_GROUP',
 'MILESTONE_CALC_MEMBER','NEXT_PLANNED_MILESTONE','NEXT_PLANNED_DECISION_POINT_MILESTONE','LATEST_ACHIEVED_MILESTONE',
'LATEST_ACHIEVED_COMMIT_TO_MILESTONE' ,'FIRST_LAUNCH_MILESTONE',
 'FIRST_SUBMISSION_MILESTONE',
 'FIRST_APPROVAL_MILESTONE','PLANISWARE_ACTIVITY_TYPE']+exclude_col
plan_load_df = adding_diff_columns(plan_ref_spark_df, jdbc_plan_df ,exclude_col) 
activity = adding_diff_columns(Activity_spark_df_new, spark.createDataFrame([activity_cols], activity_cols), exclude_col_activity)
# display(plan_load_df)

# COMMAND ----------

plan_load_df = plan_load_df.withColumn('SOURCE', F.lit('PLW-NEW'))

# COMMAND ----------

# write Plan data to curated
rawPath = 'dbfs:/mnt/raw/planisware/'
unique_run_id = runid + reference_object_number + '-LoadCuratedPLWReferenceHistory/'
csv_temp_curated = rawPath + unique_run_id
curatedPath = 'dbfs:/mnt/curated/planisware/new/reference_plan/'
plan_load_df.repartition(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath +str(REFERENCE_ONB_val)+".txt", recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)

# COMMAND ----------

#create a date which is non null based on actual and planned dates
activity = activity.withColumn('MilestoneDate',(F.when(activity.ACTIVITY_ACTUAL_END_DATE.isNotNull(), activity.ACTIVITY_ACTUAL_END_DATE) .when(activity.ACTIVITY_ACTUAL_START_DATE.isNotNull(),activity.ACTIVITY_ACTUAL_START_DATE).when(activity.ACTIVITY_PLANNED_END_DATE.isNotNull(),activity.ACTIVITY_PLANNED_END_DATE).otherwise(activity.ACTIVITY_PLANNED_START_DATE)))

#create date which is non null based on planned dates
activity = activity.withColumn('PlannedMilestoneDate',(F.when(activity.ACTIVITY_PLANNED_END_DATE.isNotNull(),activity.ACTIVITY_PLANNED_END_DATE).otherwise(activity.ACTIVITY_PLANNED_START_DATE)))

#create date which is non null based on actual dates
activity=activity.withColumn('ActualMilestoneDate',(F.when(activity.ACTIVITY_ACTUAL_END_DATE.isNotNull(),activity.ACTIVITY_ACTUAL_END_DATE).otherwise(activity.ACTIVITY_ACTUAL_START_DATE)))

# COMMAND ----------

condition_next_planned_milestone = F.upper(activity.ACTIVITY_SCOPE_NAME).contains('PROJECT MILESTONE') & activity.ACTIVITY_ACTUAL_START_DATE.isNull() & activity.ACTIVITY_ACTUAL_END_DATE.isNull()
condition_next_planned_decision_point_milestone = F.upper(activity.ACTIVITY_SCOPE_NAME).contains('PROJECT MILESTONE') & F.upper(activity.ACTIVITY_SUB_TYPE_NAME).contains('COMMIT') & activity.ACTIVITY_ACTUAL_START_DATE.isNull() & activity.ACTIVITY_ACTUAL_END_DATE.isNull()
condition_latest_achieved_milestone = F.upper(activity.ACTIVITY_SCOPE_NAME).contains('PROJECT MILESTONE') & activity.ActualMilestoneDate.isNotNull()
condition_latest_achieved_commit_to_milestone = F.upper(activity.ACTIVITY_SCOPE_NAME).contains('PROJECT MILESTONE') & F.upper(activity.ACTIVITY_SUB_TYPE_NAME).contains('COMMIT') & activity.ActualMilestoneDate.isNotNull()


rank_next_planned_milestone = Window.partitionBy('PLAN_OBJECT_NUMBER').orderBy(*[F.when(condition_next_planned_milestone, F.lit(1)).desc(), activity.PlannedMilestoneDate])
rank_next_planned_decision_point_milestone = Window.partitionBy('PLAN_OBJECT_NUMBER').orderBy(*[F.when(condition_next_planned_decision_point_milestone, F.lit(1)).desc(), activity.PlannedMilestoneDate])
rank_latest_achieved_milestone = Window.partitionBy('PLAN_OBJECT_NUMBER').orderBy(*[F.when(condition_latest_achieved_milestone, F.lit(1)).desc(), activity.ActualMilestoneDate.desc()])
rank_latest_achieved_commit_to_milestone = Window.partitionBy('PLAN_OBJECT_NUMBER').orderBy(*[F.when(condition_latest_achieved_commit_to_milestone, F.lit(1)).desc(), activity.ActualMilestoneDate.desc()])



activity = activity.withColumn('NEXT_PLANNED_MILESTONE', F.when(condition_next_planned_milestone, F.rank().over(rank_next_planned_milestone)))
activity = activity.withColumn('NEXT_PLANNED_MILESTONE', F.when(activity.NEXT_PLANNED_MILESTONE == 1, 'True').otherwise('False')) 

activity = activity.withColumn('NEXT_PLANNED_DECISION_POINT_MILESTONE', F.when(condition_next_planned_decision_point_milestone, F.rank().over(rank_next_planned_decision_point_milestone)))
activity = activity.withColumn('NEXT_PLANNED_DECISION_POINT_MILESTONE', F.when(activity.NEXT_PLANNED_DECISION_POINT_MILESTONE == 1, 'True').otherwise('False')) 

activity = activity.withColumn('LATEST_ACHIEVED_MILESTONE', F.when(condition_latest_achieved_milestone, F.rank().over(rank_latest_achieved_milestone)))
activity = activity.withColumn('LATEST_ACHIEVED_MILESTONE', F.when(activity.LATEST_ACHIEVED_MILESTONE == 1, 'True').otherwise('False')) 

activity = activity.withColumn('LATEST_ACHIEVED_COMMIT_TO_MILESTONE', F.when(condition_latest_achieved_commit_to_milestone, F.rank().over(rank_latest_achieved_commit_to_milestone)))
activity = activity.withColumn('LATEST_ACHIEVED_COMMIT_TO_MILESTONE', F.when(activity.LATEST_ACHIEVED_COMMIT_TO_MILESTONE == 1, 'True').otherwise('False')) 

# COMMAND ----------

activity = activity.withColumn('SOURCE', F.lit('PLW-NEW'))

# COMMAND ----------

activity = activity.select(activity_cols)

# COMMAND ----------

# write Activity file to curated
rawPath = 'dbfs:/mnt/raw/planisware/'
unique_run_id = runid + reference_object_number+ '-LoadCuratedPLWReferenceHistory/'
csv_temp_curated = rawPath + unique_run_id
curatedPath = 'dbfs:/mnt/curated/planisware/new/reference_activity/'
activity.repartition(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath +str(REFERENCE_ONB_val)+".txt", recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)

# COMMAND ----------

dbutils.fs.cp('dbfs:/mnt/curated/planisware/new/reference_plan/{}.txt'.format(reference_object_number), 'dbfs:/mnt/unified/project_management/reference_plan/{}.txt'.format(reference_object_number), recurse = True)

# dbfs:/mnt/unified/project_management/reference_plan/129844705554.txt