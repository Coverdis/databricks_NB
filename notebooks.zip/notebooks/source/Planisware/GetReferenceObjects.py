# Databricks notebook source
#File Name: GetReferenceObjects
#ADF Pipeline Name: Planisware_forecast_default_report_ADL
#SQLDW Table: NA
#Description:
  #It takes the object numbers from plan and creates a reference file. 

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

dbutils.widgets.text("runid", "111")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

reference_list = spark.read.format("json")\
          .option("multiLine","true")\
          .option("nullValue","null")\
    .load('dbfs:/mnt/raw/planisware/new/template/plw_reference_list.json')
tempDf = reference_list.select(explode("value").alias("value_exploded"))
reference_list = tempDf.selectExpr( 'value_exploded.*')
 

reference_list = reference_list.toDF(*(col.upper().replace('\r', '') for col in reference_list.columns))

#field = 'archive_date'
#reference_list=reference_list.drop('@ODATA.ID')
#reference_list = reference_list.withColumn(field, F.from_unixtime(F.regexp_extract(reference_list[field], '\d+', 0)/1000).cast(TimestampType()))
#reference_list = reference_list.withColumn(field, 
 #                      F.when(F.datediff(F.to_date(F.lit("1970-01-01")), F.to_date(reference_list[field], "yyyy-MM-dd")) == 0, 
  #                            None
  #                          ).otherwise(reference_list[field])
   #          )

# COMMAND ----------

#path='dbfs:/mnt/foundation/planisware/new/template'
#if file_exists(path):
 # print (1)
  #ref_json = spark.read.format("json")\
   #       .option("multiLine","true")\
    #      .option("nullValue","null")\
    #.load('dbfs:/mnt/foundation/planisware/new/reference/*.json')

  #tempDf = ref_json.select(explode("value").alias("value_exploded"))
  #ref_old = tempDf.selectExpr( 'value_exploded.*')

  #ref_old=ref_old.select('OBJECT_NUMBER','name')
  #reference_list = reference_list.join(ref_old, ['OBJECT_NUMBER'], 'left')
  #reference_list = reference_list.filter('name is null')

# COMMAND ----------

#if Limit!='': reference_list=reference_list.limit(int(Limit))

# COMMAND ----------

# write to curated

tmp_file_path = 'dbfs:/mnt/raw/planisware/new/template' + 'plw_reference-' + runid
rawPath = 'dbfs:/mnt/raw/planisware/new/template/'
reference_list=reference_list.select('object_number')
reference_list.coalesce(1).write\
            .option("sep", "|")\
            .option("header", "true")\
            .option("quote",  '"')\
            .option("escape", '"')\
            .option("nullValue", "null")\
            .option("quoteAll", "true")\
        .csv(tmp_file_path)
# copy part-* csv file to curated and rename
dbutils.fs.cp(dbutils.fs.ls(tmp_file_path)[-1][0], rawPath + 'plw_reference.txt', recurse = True)

# remove temp folders
dbutils.fs.rm(tmp_file_path, recurse = True)