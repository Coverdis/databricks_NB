# Databricks notebook source
#File Name: LoadCuratedPLWPlanLegacy
#ADF Pipeline Name: Planisware_Legacy_ADL
#SQLDW Table: NA
  #Read Planisware PLAN data from ADL and load to curated layer

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

# MAGIC %run /source/Planisware/PLWConfig

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.functions import explode

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "111")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

# read new project data in json format
project_json = spark.read.format("json")\
          .option("multiLine","true")\
          .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/planisware/legacy/project/*.json')

project_json=project_json.withColumnRenamed('@odata.context','context')
#convert json array in to column
tempDf = project_json.select(explode("value").alias("value_exploded"))
project = tempDf.selectExpr('value_exploded.*')

# COMMAND ----------

project = project.toDF(*(col.upper().replace('\r', '') for col in project.columns))
project = project.drop('@ODATA.ID')
for col_name in project.columns:
  project = project.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ''))
  project = project.withColumn(col_name, F.regexp_replace(F.col(col_name), '[\\r\\n]', ' '))
  

# remove rows where object_number is null
project = project.filter('OBJECT_NUMBER IS NOT NULL')

# COMMAND ----------

project = colRename(legacy_plan_dict , project)

project = addNullReference(project, spark.createDataFrame([plan_cols], plan_cols))

#load null values from reference
project = project.withColumn('REFERENCE_OBJECT_NUMBER', F.lit(None).cast(LongType()))
project = project.withColumn('REFERENCE_ARCHIVE_DATE', F.lit(None).cast(TimestampType()))

project = project.withColumn('SOURCE', F.lit('PLW-LEGACY').cast(StringType()))

# COMMAND ----------

date_fields = ['PLAN_LAST_REVIEWED_DATE','PLAN_CREATION_DATE','PLAN_MODIFICATION_DATE','BUDGET_PLANNED_END_DATE','BUDGET_PLANNED_START_DATE', 'PROJECT_PLANNED_END_DATE', 'PLAN_LAST_MODIFICATION_DATE', 'PLAN_LOCKED_DATE', 'PROJECT_ACTUAL_START_DATE', 'PLAN_CURRENT_DATE', 'PROJECT_PLANNED_START_DATE','PROJECT_ACTUAL_END_DATE']

for field in date_fields:
  project = project.withColumn(field, F.from_unixtime(F.regexp_extract(project[field], '\d+', 0)/1000).cast(TimestampType()))
  project = project.withColumn(field, 
                         F.when(F.datediff(F.to_date(F.lit("1970-01-01")), F.to_date(project[field], "yyyy-MM-dd")) == 0, 
                                None
                               ).otherwise(project[field])
               )

# COMMAND ----------

#cols = ['PLAN_OBJECT_NUMBER', 'PLAN_CURRENT_PHASE', 'PLAN_OWNER_NAME', 'PLAN_OWNER_ID', 'PLAN_NAME', 'PLAN_LAST_REVIEWED_DATE', 'PLAN_LAST_REVIEWED_BY', 'PLAN_CREATION_DATE', 'PLAN_DESCRIPTION', 'VESTED_UNIT_NAME', 'PROJECT_ID', 'PLAN_STATE', 'PLAN_TYPE_NAME', 'PLAN_MODIFIED_VERSION', 'PLAN_MODIFICATION_DATE', 'PLAN_USER_COMMENT', 'PLAN_VERSION_STATUS_TYPE_NAME', 'THERAPY_AREA_ABBREVIATION', 'COMPOUND_ASSET_GSK_ASSET_NUMBER', 'DISEASE_NAME', 'PRIMARY_INDICATION_FLAG', 'BUDGET_PLANNED_END_DATE', 'BUDGET_NAME', 'BUDGET_PLANNED_START_DATE', 'PLAN_CALENDAR_NAME', 'PLAN_CLASS_TYPE_NAME', 'PLAN_CLASS_TYPE_DESCRIPTION', 'PLAN_DELETED_FLAG', 'PROJECT_PLANNED_END_DATE', 'PLAN_TEMPLATE_FLAG', 'PLAN_SCHEDULE_REVIEW_FLAG', 'PLAN_TEMPLATE_SEQUENCE_NUMBER', 'PROJECT_LOAD_FLAG', 'CLINICAL_STUDY_LIST', 'PLAN_ID', 'PLAN_ACTIVE_FLAG', 'PLAN_LAST_MODIFICATION_DATE', 'PLAN_LAST_MODIFIED_BY', 'PLAN_COMMON_FILE_LIST', 'PLAN_LOAD_FLAG', 'PLAN_LOCKED_BY_', 'PLAN_LOCKED_DATE', 'PLAN_TIME_UNIT_NAME', 'NUMBER_OF_OBJECTS', 'PLAN_ORIGIN_ID', 'PLAN_PERMANENT_LOCK_FLAG', 'PROJECT_ACTUAL_END_DATE', 'PROJECT_ACTUAL_START_DATE', 'PLAN_ACCESS_RIGHT_TYPE_NAME', 'PLAN_STATE_TYPE_NAME', 'PLAN_TEMPLATE_NAME', 'CSAP_FLAG', 'MDP_FLAG', 'PLAN_VISIBLE_FLAG', 'PSAP_FLAG', 'PLAN_VERSION_FLAG', 'PLAN_FULL_NAME', 'PLAN_TYPE_DESCRIPTION', 'PROJECT_FULL_NAME', 'THERAPY_AREA_LONG_NAME', 'PLAN_VERSION_DESCRIPTION', 'PLAN_VERSION_NUMBER', 'PLAN_ACTIVITY_NUMBER', 'BUDGET_ID', 'PLAN_PLACEHOLDER_ATTRIBUTE_1', 'PLAN_PLACEHOLDER_ATTRIBUTE_2', 'PLAN_PLACEHOLDER_ATTRIBUTE_3', 'PLAN_CURRENT_DATE', 'PROJECT_READ_ONLY_USER_GROUP_NAME', 'PROJECT_READ_WRITE_USER_GROUP_NAME', 'PROJECT_PLANNED_START_DATE', 'PROJECT_PLAN_STATUS', 'STUDY_ID', 'PROJECT_PLAN_STATUS_DESCRIPTION','PLAN_STRATEGIC_FRAMEWORK', 'ASSET_ORIGIN', 'WHAT_WILL_PROJECT_BE_DELIVERING', 'IMMUNOMODULATOR_FLAG', 'PROJECT_DELIVERABLE_TYPE','BIOSTATS_RESOURCE_STRATEGY','PLAN_PIPELINE_SPLIT','PARTNERSHIP_TYPE','SCENARIO_CODE','SCENARIO_GROUP','SCENARIO_TYPE','SCENARIO_VERSION','SCENARIO_STATUS','PLW_ACCESS','REPORT_ACCESS','SCENARIO_DOC','REFERENCE_OBJECT_NUMBER', 'REFERENCE_PROJECT','REFERENCE_BASELINE_TYPE','REFERENCE_ALTERNATE_NAME','REFERENCE_CREATED_BY','REFERENCE_ARCHIVE_DATE','SOURCE', 'BASELINE_FLAG', 'PROJECT_STUDY_PHASE']

project = project.select(plan_cols)

# COMMAND ----------

# write to curated
rawPath = 'dbfs:/mnt/raw/planisware/'
unique_run_id = runid + '-LoadPLWPlanLegacy/'
csv_temp_curated = rawPath + unique_run_id + '/' + 'curated/'
curatedPath = 'dbfs:/mnt/curated/planisware/legacy/'

project.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + "plw_plan_legacy.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)