# Databricks notebook source
# MAGIC %run /library/configFile

# COMMAND ----------

dbutils.widgets.text('runid', 'pxnjs2-xdsd32-fdf223-cedsh2')
dbutils.widgets.text('fullloadflag', 'false')
dbutils.widgets.text('planstate', 'version')
runid = dbutils.widgets.get('runid')
fullloadflag=dbutils.widgets.get('fullloadflag')
planstate=dbutils.widgets.get('planstate')

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.functions import explode
from pyspark.sql.types import *

# COMMAND ----------

plan_new = spark.read.format("json")\
          .option("multiLine","true")\
          .option("nullValue","null")\
    .load('dbfs:/mnt/raw/planisware/new/plan_modified_date.json')

tempDf = plan_new.select(explode("value").alias("value_exploded"))
plan_new = tempDf.selectExpr( 'value_exploded.*')
 

plan_new = plan_new.toDF(*(col.upper().replace('\r', '') for col in plan_new.columns))

field = 'user_attribute_gsk_ua_d_plan_last_mod_date_azure'
plan_new=plan_new.drop('@ODATA.ID')
plan_new = plan_new.withColumn(field, F.from_unixtime(F.regexp_extract(plan_new[field], '\d+', 0)/1000).cast(TimestampType()))
plan_new = plan_new.withColumn(field, 
                       F.when(F.datediff(F.to_date(F.lit("1970-01-01")), F.to_date(plan_new[field], "yyyy-MM-dd")) == 0, 
                              None
                             ).otherwise(plan_new[field])
             )


# COMMAND ----------

print(fullloadflag)

# COMMAND ----------

path='dbfs:/mnt/foundation/planisware/new/project'
if file_exists(path) and fullloadflag!='true':

  plan_json = spark.read.format("json")\
          .option("multiLine","true")\
          .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/planisware/new/project/*.json')

  tempDf = plan_json.select(explode("value").alias("value_exploded"))
  plan_old = tempDf.selectExpr( 'value_exploded.*')

  plan_old=plan_old.select('OBJECT_NUMBER','user_attribute_gsk_ua_d_plan_last_mod_date_azure')
  field = 'user_attribute_gsk_ua_d_plan_last_mod_date_azure'

  plan_old = plan_old.withColumn(field, F.from_unixtime(F.regexp_extract(plan_old[field], '\d+', 0)/1000).cast(TimestampType()))
  plan_old = plan_old.withColumn(field, 
                         F.when(F.datediff(F.to_date(F.lit("1970-01-01")), F.to_date(plan_old[field], "yyyy-MM-dd")) == 0, 
                                None
                               ).otherwise(plan_old[field])
               )

  old_field_name = 'user_attribute_gsk_ua_d_plan_last_mod_date_azure_OLD'
  plan_old = plan_old.withColumnRenamed(field, old_field_name)
  plan = plan_new.join(plan_old, ['OBJECT_NUMBER'], 'left')
  plan = plan.withColumn('DIFF', F.when(F.isnull(plan['user_attribute_gsk_ua_d_plan_last_mod_date_azure_OLD']), F.lit(100)).otherwise(plan['user_attribute_gsk_ua_d_plan_last_mod_date_azure'].cast(LongType()) - plan['user_attribute_gsk_ua_d_plan_last_mod_date_azure_OLD'].cast(LongType())))
  plan = plan.filter('DIFF > 0')
  delta_df = plan.select('OBJECT_NUMBER', 'user_attribute_gsk_ua_d_plan_last_mod_date_azure','_STA_RA_PRJ_STATUS')
else :
  delta_df=plan_new
  print(delta_df.count())

# COMMAND ----------

#filter current or version based on planstate flag
if planstate=='version': delta_df = delta_df.filter("_STA_RA_PRJ_STATUS == 'Version'")
if planstate=='current': delta_df = delta_df.filter("_STA_RA_PRJ_STATUS != 'Version'")

# COMMAND ----------

# write to curated

tmp_file_path = 'dbfs:/mnt/raw/planisware/new/' + 'FindDeltaPLWPlans-' + runid
rawPath = 'dbfs:/mnt/raw/planisware/new/'

delta_df.coalesce(1).write\
            .option("sep", "|")\
            .option("header", "true")\
            .option("quote",  '"')\
            .option("escape", '"')\
            .option("nullValue", "null")\
            .option("quoteAll", "true")\
        .csv(tmp_file_path)
# copy part-* csv file to curated and rename
dbutils.fs.cp(dbutils.fs.ls(tmp_file_path)[-1][0], rawPath + 'delta_plans_object_number.txt', recurse = True)

# remove temp folders
dbutils.fs.rm(tmp_file_path, recurse = True)

# COMMAND ----------

#delete plans from foundation layer that have been deleted from planisware. This does not include versions.
import glob
import os

#filelist=glob.glob("/home/ismail/*.txt")
path='dbfs:/mnt/foundation/planisware/new/project'
if file_exists(path):
  plan_json = spark.read.format("json")\
          .option("multiLine","true")\
          .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/planisware/new/project/*.json')

  tempDf = plan_json.select(explode("value").alias("value_exploded"))
  plan_old = tempDf.selectExpr( 'value_exploded.*')
  plan_old=plan_old.select('OBJECT_NUMBER','_STA_RA_PRJ_STATUS')
  plan_old=plan_old.filter('_STA_RA_PRJ_STATUS!="Version"')
  delete_plan = plan_old.join(plan_new, ['OBJECT_NUMBER'], 'left')
  delete_plan=delete_plan.filter('user_attribute_gsk_ua_d_plan_last_mod_date_azure is null')
  delete_plan=delete_plan.withColumn('OBJECT_NUMBER',delete_plan['OBJECT_NUMBER'].cast(StringType()))
  path='dbfs:/mnt/foundation/planisware/new/'
  for row in delete_plan.rdd.collect():
    print(row['OBJECT_NUMBER'])
    if file_exists(path+'project/'+ row['OBJECT_NUMBER'] +'.json'): dbutils.fs.rm(path+'project/'+ row['OBJECT_NUMBER'] +'.json')
    if file_exists(path+'activity/'+ row['OBJECT_NUMBER'] +'.json'): dbutils.fs.rm(path+'activity/'+ row['OBJECT_NUMBER'] +'.json')
    if file_exists(path+'epe_forecast/'+ row['OBJECT_NUMBER'] +'.json'): dbutils.fs.rm(path+'epe_forecast/'+ row['OBJECT_NUMBER'] +'.json')
    if file_exists(path+'resource_forecast/'+ row['OBJECT_NUMBER'] +'.json'): dbutils.fs.rm(path+'resource_forecast/'+ row['OBJECT_NUMBER'] +'.json')
  