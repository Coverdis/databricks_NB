# Databricks notebook source
#File Name: LoadCuratedPLWRBS
#ADF Pipeline Name: Planisware_ADL
#SQLDW Table: NA
#Description:
  #Read new Planisware RBS data from ADL and load to curated ADL  

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
from pyspark.sql.functions import explode
processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "111")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

rbs_json = spark.read.format("json")\
          .option("multiLine","true")\
          .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/planisware/new/rbs.json')

rbs_json=rbs_json.withColumnRenamed('@odata.context','context')
print(rbs_json.count())
#convert json array in to column
tempDf = rbs_json.select(explode("value").alias("value_exploded"))
rbs = tempDf.selectExpr( 'value_exploded.*')

# COMMAND ----------

# rename fields
rbs = rbs.withColumnRenamed('OBJECT_NUMBER', 'RBS_OBJECT_NUMBER')
rbs = rbs.withColumnRenamed('user_attribute_gsk_ua_resource_id', 'RBS_ID')
rbs = rbs.withColumnRenamed('name', 'RBS_DESCRIPTION')
rbs = rbs.withColumnRenamed('time_unit', 'RATE_UNIT')
rbs = rbs.withColumnRenamed('level', 'LEVEL')
rbs = rbs.withColumnRenamed('cost_unit', 'RATE_TYPE')
rbs = rbs.withColumnRenamed('cost_value', 'RATE')
rbs = rbs.withColumnRenamed('hierarchical_code', 'HIERARCHICAL_CODE')
rbs = rbs.withColumnRenamed('inactive', 'INACTIVE')
rbs = rbs.withColumnRenamed('order_number', 'ORDER_NUMBER')
rbs = rbs.withColumnRenamed('element_of', 'PARENT_ID')
rbs = rbs.withColumnRenamed('id', 'ID')
rbs = rbs.withColumnRenamed('res_manager','RESOURCE_MANAGER')

rbs.createOrReplaceTempView('rbs_view')

# COMMAND ----------

query="select  lvl6.id,rbs_id,lvl6_RBS_DESC,lvl6_order_number,inactive,rate_unit,rate_type,rate,lvl5_RBS_DESC,lvl5_order_number,lvl4_RBS_DESC,lvl4_order_number,lvl3_RBS_DESC,lvl3_order_number,lvl2_RBS_DESC,lvl2_order_number,lvl1_RBS_DESC,lvl1_order_number,resource_manager from \
(select id,rbs_id,parent_id,comment as lvl6_RBS_DESC,order_number  as lvl6_order_number,inactive,rate_unit,rate_type,rate,resource_manager from rbs_view where  level=6)lvl6, \
(select id,parent_id,comment as lvl5_RBS_DESC,order_number as lvl5_order_number from rbs_view where level=5) lvl5, \
(select id,parent_id,comment as lvl4_RBS_DESC,order_number as lvl4_order_number from rbs_view where level=4) lvl4, \
(select id,parent_id,comment as lvl3_RBS_DESC,order_number as lvl3_order_number from rbs_view where level=3) lvl3, \
(select id,parent_id,comment as lvl2_RBS_DESC,order_number as lvl2_order_number from rbs_view where level=2) lvl2, \
(select id,parent_id,comment as lvl1_RBS_DESC,order_number as lvl1_order_number from rbs_view where level=1) lvl1 \
where lvl5.id=lvl6.parent_id \
and lvl4.id=lvl5.parent_id \
and lvl3.id=lvl4.parent_id \
and lvl2.id=lvl3.parent_id \
and lvl1.id=lvl2.parent_id"
rbs = sqlContext.sql(query)
rbs = rbs.withColumn('SOURCE', F.lit('PLW-NEW').cast(StringType()))

# COMMAND ----------

# write to curated
rawPath = 'dbfs:/mnt/raw/planisware/'
unique_run_id = runid + '-LoadPLWRBS/'
csv_temp_curated = rawPath + unique_run_id + '/' + 'curated/'
curatedPath = 'dbfs:/mnt/curated/planisware/new/'

rbs.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + "plw_rbs_hierarchy.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)

# COMMAND ----------

