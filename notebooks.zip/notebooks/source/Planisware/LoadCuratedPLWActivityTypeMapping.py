# Databricks notebook source
#File Name: LoadCuratedPLWActivityTypeMapping
#ADF Pipeline Name: Planisware_ADL
#SQLDW Table: NA
#Description:
  #Copy Planisware new and old activity type mapping to curated layer

# COMMAND ----------

dbutils.widgets.text('runid', 'csdads-xdsd32-fdf223-df1221w')
runid = dbutils.widgets.get('runid')
dbutils.fs.ls('dbfs:/mnt/foundation/planisware')

# COMMAND ----------

import pandas as pd
import openpyxl as opxl

xl = opxl.load_workbook('/dbfs/mnt/foundation/planisware/PSAP Mapping Table.xlsx')
ws = xl['ProjMSStudyMS']

data = ws.values
cols = next(data)[0:]

df = pd.DataFrame(data, columns = cols)
# df = df.where((pd.notnull(df)), None)

# COMMAND ----------

from pyspark.sql.types import *

mySchema = StructType([ StructField("NAME", StringType(), True),\
                        StructField("NEW_ACTIVITY_TYPE", StringType(), True),\
                        StructField("OLD_ACTIVITY_TYPE", StringType(), True),\
                        StructField("TYPE", StringType(), True),\
                        StructField("SOURCE", StringType(), True)
                      ])

df = spark.createDataFrame(df, schema = mySchema)

# remove duplicates
df = df.dropDuplicates()

# COMMAND ----------

# write to curated

tmp_file_path = 'dbfs:/mnt/raw/planisware' + 'LoadCuratedPLWActivityTypeMapping-' + runid
curatedPath = 'dbfs:/mnt/curated/planisware/'

df.coalesce(1).write\
            .option("sep", "|")\
            .option("header", "true")\
            .option("quote",  '"')\
            .option("escape", '"')\
            .option("nullValue", "null")\
            .option("quoteAll", "true")\
        .csv(tmp_file_path)
# copy part-* csv file to curated and rename
dbutils.fs.cp(dbutils.fs.ls(tmp_file_path)[-1][0], curatedPath + 'MappingTable.txt', recurse = True)

# remove temp folders
dbutils.fs.rm(tmp_file_path, recurse = True)