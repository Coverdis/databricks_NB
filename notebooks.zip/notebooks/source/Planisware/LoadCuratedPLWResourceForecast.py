# Databricks notebook source
#File Name: LoadCuratedPLWResourceForecast
#ADF Pipeline Name: Planisware_ADL
#SQLDW Table: NA
#Description:
  #Store Planisware FTE data in curated layer of ADL
  #loadflag: full - will truncate and reload all the data in each layer
  #loadflag: incremental - will append the data to the existing in curated layer replacing the modified plans from the incremental load

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
from pyspark.sql.functions import explode
processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "")
dbutils.widgets.dropdown("baselineflag", "false", ['true', 'false'])
dbutils.widgets.text("reference_object_number", "")
dbutils.widgets.dropdown("fullloadflag", "true", ['true', 'false'])

runid = dbutils.widgets.get("runid")
baselineflag=dbutils.widgets.get("baselineflag")
referenceobjectnumber=dbutils.widgets.get("reference_object_number")
fullloadflag = dbutils.widgets.get("fullloadflag") # this is only applicable for non baseline data

# COMMAND ----------

if baselineflag=='true':
  sourcefilepath='foundation/planisware/new/reference_resource_forecast/'+referenceobjectnumber+'.json'
  targetfilepath='curated/planisware/new/reference_resource_forecast/'+referenceobjectnumber+'.txt'
  df_json = spark.read.format("json")\
          .option("multiLine","true")\
          .option("nullValue","null")\
    .load('dbfs:/mnt/'+sourcefilepath)
  df_json=df_json.withColumnRenamed('@odata.context','context')
  #convert json array in to column
  tempDf = df_json.select(explode("value").alias("value_exploded"))
  #some time there is not RF for baselines so exit when RF file is empty
  if len(tempDf.collect())==0: dbutils.notebook.exit('EmptyRFJSON')
  df = tempDf.selectExpr( 'value_exploded.*')
  df=df.drop('@odata.id')


# COMMAND ----------

if baselineflag != 'true':
  # read rf data from curated layer
  rf = spark.read.format("csv")\
        .option("inferSchema","false")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
      .load('dbfs:/mnt/curated/planisware/new/plw_resource_forecast.txt')

  rf = rf.toDF(*(col.replace('\r', '') for col in rf.columns))

# COMMAND ----------

if baselineflag != 'true' and fullloadflag == 'true':
  rf = rf.limit(0)

# COMMAND ----------

if baselineflag!='true': 
  sourcefilepath='foundation/planisware/new/resource_forecast/resource_forecast.txt'
  targetfilepath='curated/planisware/new/plw_resource_forecast.txt'
  df = spark.read.format('csv')\
      .option("inferSchema", "false")\
      .option("header", "true")\
      .option("multiLine", "true")\
      .option("delimiter", "|")\
      .option("quote", '"')\
      .option("escape", '"')\
      .option("nullValue", "null")\
    .load('dbfs:/mnt/'+sourcefilepath)

  df = df.toDF(*(col.replace('\r', '') for col in df.columns))
  #--create/update entry in DW log table
#   sql="Update DW_load_log set Last_execution='"+ planisware_status_date +"' where Table_name='prod_stage.fte_forecast'"
#   dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})

# COMMAND ----------

df = df.withColumnRenamed('PROJECT_ONB', 'PLAN_OBJECT_NUMBER')
df = df.withColumnRenamed('RESOURCE_NAME', 'RBS')
df = df.withColumnRenamed('PROJECT_NAME', 'PROJECT_ID')
df = df.withColumnRenamed('FTE', 'STD_FTES_FORECAST')
df = df.withColumnRenamed('ACTIVITY_ONB', 'ACTIVITY_OBJECT_NUMBER')
df = df.withColumnRenamed('REFERENCE_ONB', 'REFERENCE_OBJECT_NUMBER')
 

if baselineflag!='true': 
  df = df.withColumn('REFERENCE_OBJECT_NUMBER',F.lit(None).cast(IntegerType()))
  #df = df.withColumn("START_DATE", F.to_date(df['START_DATE'], "mm/dd/yyyy"))
  #df = df.withColumn("END_DATE", F.to_date(df['END_DATE'], "mm/dd/yyyy"))

  
if baselineflag=='true':  
  df = df.withColumn("START_DATE", F.to_date(df['START_DATE'], "dd-MMM-yyyy"))
  df = df.withColumn("END_DATE", F.to_date(df['END_DATE'], "dd-MMM-yyyy"))

df = df.withColumn('RESOURCE_TYPE', F.lit('FTE').cast(StringType()))
df = df.withColumn('YEAR',F.year('START_DATE'))
df = df.withColumn('MONTH',F.month('START_DATE'))
df = df.withColumn('SOURCE', F.lit('PLW-NEW').cast(StringType()))

# COMMAND ----------

if baselineflag != 'true':
  df = df.union(rf)

# COMMAND ----------

if baselineflag != 'true':
  # loading the file with all deleted flagged plans using pp_deleted_date from planisware table
  deletedPlans = spark.read.format("csv")\
        .option("inferSchema","false")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/planisware/new/plw_plan_deleted.txt')

  deletedPlans = deletedPlans.toDF(*(col.replace('\r', '') for col in deletedPlans.columns))
  print(deletedPlans.count())

# COMMAND ----------

if baselineflag != 'true':
  # removing all deletd plans from df
  df = df.join(deletedPlans, df.PLAN_OBJECT_NUMBER == deletedPlans.PLAN_INTERNAL_NUMBER, 'leftanti')
  print(df.count())

# COMMAND ----------

# write to curated
rawPath = 'dbfs:/mnt/raw/planisware/'
unique_run_id = runid + '-LoadPLWResourceForecast/'
if baselineflag=='true': unique_run_id=runid + referenceobjectnumber + '-LoadCuratedPLWResourceForecast/'
csv_temp_curated = rawPath + unique_run_id + '/' + 'curated/'

df.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], 'dbfs:/mnt/' + targetfilepath, recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)

# COMMAND ----------

dbutils.notebook.exit('Success')