# Databricks notebook source
# Load PLW_IRM_EAC_Export to curated

# COMMAND ----------

dbutils.widgets.text('runid', 'sdchs-dsuw2-cdn82-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

dbutils.fs.cp('dbfs:/mnt/foundation/planisware/plw_irm_eac_export.txt', 'dbfs:/mnt/curated/planisware/plw_irm_eac_export.txt', recurse = True)