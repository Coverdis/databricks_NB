# Databricks notebook source
#File Name: LoadCuratedPLWReference
#ADF Pipeline Name: Planisware_Baseline_ADL
#SQLDW Table: NA
  # Reads Plansiware Reference metadata and calculates delta of baselines to be created

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.functions import explode
from glob import glob

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "111")

runid = dbutils.widgets.get("runid")

# COMMAND ----------

# read new planisware data 
df = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load('dbfs:/mnt/raw/planisware/new/reference/plw_reference_list.txt')

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ''))

# COMMAND ----------

# column renaming
df = df.withColumn('REFERENCE_CREATED_BY', F.lower(df.reference_created_by))
df = df.withColumnRenamed('reference_type', 'REFERENCE_BASELINE_TYPE')
df = df.withColumnRenamed('reference_project', 'PLAN_OBJECT_NUMBER')
df = df.withColumnRenamed('reference_archive_date', 'REFERENCE_ARCHIVE_DATE')
df = df.withColumnRenamed('reference_alt_name', 'REFERENCE_ALTERNATE_NAME')
df = df.withColumnRenamed('reference_onb', 'REFERENCE_OBJECT_NUMBER')

# COMMAND ----------

# reading all the reference onbs from plan stage table for comparison
ref_df = spark.read.format("com.databricks.spark.sqldw")\
  .option("url", sqlDwUrl)\
  .option( "forward_spark_azure_storage_credentials", "True")\
  .option("tempdir", tempDir)\
  .option("maxStrLength", 4000)\
  .option("dbtable", "irm_stg.plw_plan") \
  .load()

ref_df = ref_df.filter('REFERENCE_OBJECT_NUMBER is not null').select('REFERENCE_OBJECT_NUMBER')

# COMMAND ----------

# calculating delta
delta = df.join(F.broadcast(ref_df), df.REFERENCE_OBJECT_NUMBER == ref_df.REFERENCE_OBJECT_NUMBER, 'leftanti')
delta = delta.select('REFERENCE_BASELINE_TYPE', 'PLAN_OBJECT_NUMBER', 'REFERENCE_CREATED_BY', 'REFERENCE_ARCHIVE_DATE', 'REFERENCE_ALTERNATE_NAME', 'REFERENCE_OBJECT_NUMBER')

# COMMAND ----------

if delta.count() == 0:
  dbutils.notebook.exit('No delta to be baselined')

# COMMAND ----------

# write to curated
csv_temp_raw = 'dbfs:/mnt/raw/planisware/new/' + 'plw_reference-' + runid
rawPath = 'dbfs:/mnt/raw/planisware/new/'

delta.write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_raw)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_raw)[-1][0], rawPath + "plw_reference.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(csv_temp_raw, recurse = True)

# COMMAND ----------

# MAGIC %sql
# MAGIC REFRESH "dbfs:/mnt/raw/planisware/new/plw_reference.txt";

# COMMAND ----------

dbutils.notebook.exit('Success')