# Databricks notebook source
#File Name: LoadCuratedPLW_IRM_Export
#ADF Pipeline Name:Planiesware_Legacy_ADL
#SQLDW Table: NA
#Description:
  #Load resource forecast to curated layer

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *

dbutils.widgets.text('runid', 'sdchs-0sdjd-cdn82-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

resource_forecast_df = spark.read.format('csv') \
      .option("inferSchema","false")\
      .option('header', 'true')\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/planisware/plw_irm_export.txt')

resource_forecast_df = resource_forecast_df.toDF(*(col.replace('\r', '') for col in resource_forecast_df.columns))
for col_name in resource_forecast_df.columns:
  resource_forecast_df = resource_forecast_df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ''))

resource_forecast_df = resource_forecast_df.withColumnRenamed('LOAD', 'STD_FTES_FORECAST')
resource_forecast_df = resource_forecast_df.withColumnRenamed('ACTIVITY_ID', 'ACTIVITY_OBJECT_NUMBER')
resource_forecast_df = resource_forecast_df.withColumnRenamed('TYPE', 'RESOURCE_TYPE')
resource_forecast_df = resource_forecast_df.withColumn('SOURCE', F.lit('PLW-LEGACY').cast(StringType()))

# COMMAND ----------

resource_forecast_df = resource_forecast_df.select(
  'STD_FTES_FORECAST',
  'RESOURCE_TYPE',
  'RBS',
  'MONTH',
  'YEAR',
  'ACTIVITY_OBJECT_NUMBER',
  'PLAN_TYPE',
  'SOURCE'
)

# COMMAND ----------

# write to unified layer
raw_path = 'dbfs:/mnt/raw/planisware'
unique_run_id = runid + '-LoadCuratedPLW_IRM_Export/'
csv_temp_unified = raw_path + unique_run_id + '/' + 'curated'

curated_path = 'dbfs:/mnt/curated/planisware/'

resource_forecast_df.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("quoteAll", "true")\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .mode('overwrite')\
      .csv(csv_temp_unified)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_unified)[-1][0], curated_path + "plw_irm_export.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)