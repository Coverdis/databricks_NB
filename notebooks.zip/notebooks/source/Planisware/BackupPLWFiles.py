# Databricks notebook source
#File Name: BackupPLWFiles
#ADF Pipeline Name: Planisware_Baseline_ADL
#SQLDW Table: NA
#Description:
  # Backs up PLW Files in the event of baseline pipeline failure

# COMMAND ----------

# MAGIC %run /library/logs

# COMMAND ----------

import pytz
from datetime import datetime

processDate = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%d')

# COMMAND ----------

dbutils.widgets.text('runid', 'vfj3s-dv83q-lala-tudu')
runid = dbutils.widgets.get("runid")

# COMMAND ----------

dbutils.fs.cp('dbfs:/mnt/foundation/planisware/new/plw_plan.txt', 'dbfs:/mnt/raw/planisware/new/baselinebackup/'+ processDate + '_' + runid +'/plan_' + processDate + '_' + runid + '.txt', recurse = True)
dbutils.fs.cp('dbfs:/mnt/foundation/planisware/new/plw_activity.txt', 'dbfs:/mnt/raw/planisware/new/baselinebackup/'+ processDate + '_' + runid +'/activity_' + processDate + '_' + runid + '.txt', recurse = True)
dbutils.fs.cp('dbfs:/mnt/foundation/planisware/new/resource_forecast/resource_forecast.txt', 'dbfs:/mnt/raw/planisware/new/baselinebackup/'+ processDate + '_' + runid +'/resource_forecast_' + processDate + '_' + runid + '.txt', recurse = True)
dbutils.fs.cp('dbfs:/mnt/foundation/planisware/new/epe_forecast/epe_forecast.txt', 'dbfs:/mnt/raw/planisware/new/baselinebackup/'+ processDate + '_' + runid +'/epe_forecast_' + processDate + '_' + runid + '.txt', recurse = True)