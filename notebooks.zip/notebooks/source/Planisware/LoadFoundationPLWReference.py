# Databricks notebook source
#File Name: LoadFoundationPLWReference
#ADF Pipeline Name: Planisware_Reference_ADL
#SQLDW Table: NA
  #Reads Planisware data from foundation, creates baseline snapshots and loads back into foundation

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

# MAGIC %run /library/logs

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.functions import explode
from glob import glob

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')
processDate = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%d')

dbutils.widgets.text("runid", "111")
dbutils.widgets.dropdown("source", "plan", ['plan', 'activity', 'resource_forecast', 'epe_forecast'])

runid = dbutils.widgets.get("runid")
source = dbutils.widgets.get("source")

# COMMAND ----------

# reading delta file
df = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load('dbfs:/mnt/raw/planisware/new/plw_reference.txt')

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ''))

df = df.withColumnRenamed('REFERENCE_CREATED_BY', 'REFERENCE_CREATED_BY_DELTA')
df = df.withColumnRenamed('REFERENCE_BASELINE_TYPE', 'REFERENCE_BASELINE_TYPE_DELTA')
df = df.withColumnRenamed('PLAN_OBJECT_NUMBER', 'PLAN_OBJECT_NUMBER_DELTA')
df = df.withColumnRenamed('REFERENCE_ARCHIVE_DATE', 'REFERENCE_ARCHIVE_DATE_DELTA')
df = df.withColumnRenamed('REFERENCE_ALTERNATE_NAME', 'REFERENCE_ALTERNATE_NAME_DELTA')
df = df.withColumnRenamed('REFERENCE_OBJECT_NUMBER', 'REFERENCE_OBJECT_NUMBER_DELTA')
  
deltadf = df
print(deltadf.count())

# COMMAND ----------

# read new planisware Plan data from stage table
plan = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/planisware/new/plw_plan.txt')

plan = plan.toDF(*(col.replace('\r', '') for col in plan.columns))

plan = plan.where(~((plan.plan_state == 'Version') & (plan.scenario_type.like('%scenario%'))))

for col_name in plan.columns:
  plan = plan.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ''))

plan = plan.withColumnRenamed('PLAN_INTERNAL_NUMBER', 'PLAN_OBJECT_NUMBER')

# plan onbs in delta files missing from plan in foundation
missing_plan_onbs = deltadf.join(plan, plan.PLAN_OBJECT_NUMBER == deltadf.PLAN_OBJECT_NUMBER_DELTA, 'leftanti')
missing_plan_onbs.count()

# COMMAND ----------

if source == 'plan':
  
  # selecting plans that matches with Plan onbs from baseline input file
  plan_ref = deltadf.join(plan, deltadf.PLAN_OBJECT_NUMBER_DELTA == plan.PLAN_OBJECT_NUMBER, 'inner')

  # renaming Reference attributes and dropping redundant ones
  plan_ref = plan_ref.withColumn('REFERENCE_BASELINE_TYPE', plan_ref.REFERENCE_BASELINE_TYPE_DELTA)
  plan_ref = plan_ref.withColumn('REFERENCE_CREATED_BY', plan_ref.REFERENCE_CREATED_BY_DELTA)
  plan_ref = plan_ref.withColumn('REFERENCE_ARCHIVE_DATE', plan_ref.REFERENCE_ARCHIVE_DATE_DELTA.cast(TimestampType()))
  plan_ref = plan_ref.withColumn('REFERENCE_ALTERNATE_NAME', plan_ref.REFERENCE_ALTERNATE_NAME_DELTA)
  plan_ref = plan_ref.withColumn('REFERENCE_OBJECT_NUMBER', plan_ref.REFERENCE_OBJECT_NUMBER_DELTA.cast(LongType()))
  plan_ref = plan_ref.drop(*['REFERENCE_BASELINE_TYPE_DELTA', 'REFERENCE_CREATED_BY_DELTA', 'REFERENCE_ARCHIVE_DATE_DELTA', 'REFERENCE_ALTERNATE_NAME_DELTA', 'REFERENCE_OBJECT_NUMBER_DELTA', 'PLAN_OBJECT_NUMBER_DELTA'])
  
  # logging to Azure Log Analytics - when Reference onbs from the input are not baselined
  if plan_ref.select('REFERENCE_OBJECT_NUMBER').distinct().count() != deltadf.count():
    chk = deltadf.join(plan_ref, plan_ref.PLAN_OBJECT_NUMBER == deltadf.PLAN_OBJECT_NUMBER_DELTA, 'leftanti')
    chk = chk.select(F.concat_ws('|', chk.REFERENCE_OBJECT_NUMBER_DELTA, chk.PLAN_OBJECT_NUMBER_DELTA).alias('Con'))
    msg = ', '.join(map(str, [row['Con'] for row in chk.collect()]))
    logWarning('Notebook: LoadFoundationPLWReference' + str(source) + ' - Following REREFENCE ONB|PLAN ONB not baselined: ' + str(msg))
  
   # if first join results in no match
  if plan_ref.count() == 0:
    dbutils.notebook.exit('There are no Plans to be baselined')

# COMMAND ----------

# removing missing plan onbs from delta
deltadf = deltadf.join(missing_plan_onbs, deltadf.PLAN_OBJECT_NUMBER_DELTA == missing_plan_onbs.PLAN_OBJECT_NUMBER_DELTA, 'leftanti')
print(deltadf.count())

# COMMAND ----------

if source == 'activity':
  
  # read new planisware activity data from stage table  
  activity = spark.read.format("csv")\
            .option("inferSchema","false")\
            .option("header","true")\
            .option("multiLine","true")\
            .option("delimiter","|")\
            .option("quote", '"')\
            .option("escape",'"')\
            .option("nullValue","null")\
      .load('dbfs:/mnt/foundation/planisware/new/plw_activity.txt')

  activity = activity.toDF(*(col.replace('\r', '') for col in activity.columns))

  for col_name in activity.columns:
    activity = activity.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ''))
  
  activity = activity.withColumnRenamed('PLAN_INTERNAL_NUMBER', 'PLAN_OBJECT_NUMBER')

  activity_ref = activity.join(missing_plan_onbs, activity.PLAN_OBJECT_NUMBER == missing_plan_onbs.PLAN_OBJECT_NUMBER_DELTA, 'leftanti')
  
  # selecting activity that matches with Plan onbs from baseline input file
  activity_ref = deltadf.join(activity, deltadf.PLAN_OBJECT_NUMBER_DELTA == activity.PLAN_OBJECT_NUMBER, 'inner') 

  # renaming Reference attributes and dropping redundant ones
  activity_ref = activity_ref.withColumn('REFERENCE_OBJECT_NUMBER', activity_ref.REFERENCE_OBJECT_NUMBER_DELTA.cast(LongType()))
  activity_ref = activity_ref.drop(*['REFERENCE_BASELINE_TYPE_DELTA', 'REFERENCE_CREATED_BY_DELTA', 'REFERENCE_ARCHIVE_DATE_DELTA', 'REFERENCE_ALTERNATE_NAME_DELTA', 'REFERENCE_OBJECT_NUMBER_DELTA', 'PLAN_OBJECT_NUMBER_DELTA'])
  
  # logging to Azure Log Analytics - when Reference onbs from the input are not baselined
  if activity_ref.select('REFERENCE_OBJECT_NUMBER').distinct().count() != deltadf.count():
    chk = deltadf.join(activity_ref, activity_ref.PLAN_OBJECT_NUMBER == deltadf.PLAN_OBJECT_NUMBER_DELTA, 'leftanti')
    chk = chk.select(F.concat_ws('|', chk.REFERENCE_OBJECT_NUMBER_DELTA, chk.PLAN_OBJECT_NUMBER_DELTA).alias('Con'))
    msg = ', '.join(map(str, [row['Con'] for row in chk.collect()]))
    logWarning('Notebook: LoadFoundationPLWReference' + str(source) + ' - Following REREFENCE ONB|PLAN ONB not baselined: ' + str(msg))
    
  # if first join results in no match
  if activity_ref.count() == 0:
    dbutils.notebook.exit('There are no Activities to be baselined')

# COMMAND ----------

if source == 'resource_forecast':
  
  # read resource forecast data from stage table
  rf = spark.read.format("csv")\
            .option("inferSchema","false")\
            .option("header","true")\
            .option("multiLine","true")\
            .option("delimiter","|")\
            .option("quote", '"')\
            .option("escape",'"')\
            .option("nullValue","null")\
      .load('dbfs:/mnt/foundation/planisware/new/resource_forecast/resource_forecast.txt')  

  rf = rf.toDF(*(col.replace('\r', '') for col in rf.columns))

  for col_name in rf.columns:
    rf = rf.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ''))
  
  rf = rf.withColumnRenamed('PROJECT_ONB', 'PLAN_OBJECT_NUMBER')
  
  # selecting forecasts that matches with Plan onbs from baseline input file
  rf_ref = deltadf.join(rf, deltadf.PLAN_OBJECT_NUMBER_DELTA == rf.PLAN_OBJECT_NUMBER, 'inner')
  
  # renaming Reference attributes and dropping redundant ones
  rf_ref = rf_ref.withColumn('REFERENCE_OBJECT_NUMBER', rf_ref.REFERENCE_OBJECT_NUMBER_DELTA.cast(LongType()))
  rf_ref = rf_ref.drop(*['REFERENCE_BASELINE_TYPE_DELTA', 'REFERENCE_CREATED_BY_DELTA', 'REFERENCE_ARCHIVE_DATE_DELTA', 'REFERENCE_ALTERNATE_NAME_DELTA', 'REFERENCE_OBJECT_NUMBER_DELTA', 'PLAN_OBJECT_NUMBER_DELTA'])
  
  # logging to Azure Log Analytics - when Reference onbs from the input are not baselined
  if rf_ref.select('REFERENCE_OBJECT_NUMBER').distinct().count() != deltadf.count():
    chk = deltadf.join(rf_ref, rf_ref.PLAN_OBJECT_NUMBER == deltadf.PLAN_OBJECT_NUMBER_DELTA, 'leftanti')
    chk = chk.select(F.concat_ws('|', chk.REFERENCE_OBJECT_NUMBER_DELTA, chk.PLAN_OBJECT_NUMBER_DELTA).alias('Con'))
    msg = ', '.join(map(str, [row['Con'] for row in chk.collect()]))
    logWarning('Notebook: LoadFoundationPLWReference' + str(source) + ' - Following REREFENCE ONB|PLAN ONB not baselined: ' + str(msg))
    
  # if first join results in no match
  if rf_ref.count() == 0:
    dbutils.notebook.exit('There are no Resource Forecasts to be baselined')

# COMMAND ----------

if source == 'epe_forecast':
  
  # read epe forecast data from stage table
  epe = spark.read.format("csv")\
            .option("inferSchema","false")\
            .option("header","true")\
            .option("multiLine","true")\
            .option("delimiter","|")\
            .option("quote", '"')\
            .option("escape",'"')\
            .option("nullValue","null")\
      .load('dbfs:/mnt/foundation/planisware/new/epe_forecast/epe_forecast.txt')

  epe = epe.toDF(*(col.replace('\r', '') for col in epe.columns))

  for col_name in epe.columns:
    epe = epe.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ''))
  
  epe = epe.withColumnRenamed('PROJECT_ONB', 'PLAN_OBJECT_NUMBER')
  
  # selecting forecasts that matches with Plan onbs from baseline input file
  epe_ref = deltadf.join(epe, deltadf.PLAN_OBJECT_NUMBER_DELTA == epe.PLAN_OBJECT_NUMBER, 'inner')

  # renaming Reference attributes and dropping redundant ones
  epe_ref = epe_ref.withColumn('REFERENCE_OBJECT_NUMBER', epe_ref.REFERENCE_OBJECT_NUMBER_DELTA.cast(LongType()))
  epe_ref = epe_ref.drop(*['REFERENCE_BASELINE_TYPE_DELTA', 'REFERENCE_CREATED_BY_DELTA', 'REFERENCE_ARCHIVE_DATE_DELTA', 'REFERENCE_ALTERNATE_NAME_DELTA', 'REFERENCE_OBJECT_NUMBER_DELTA', 'PLAN_OBJECT_NUMBER_DELTA'])
  
  # logging to Azure Log Analytics - when Reference onbs from the input are not baselined
  if epe_ref.select('REFERENCE_OBJECT_NUMBER').distinct().count() != deltadf.count():
    chk = deltadf.join(epe_ref, epe_ref.PLAN_OBJECT_NUMBER == deltadf.PLAN_OBJECT_NUMBER_DELTA, 'leftanti')
    chk = chk.select(F.concat_ws('|', chk.REFERENCE_OBJECT_NUMBER_DELTA, chk.PLAN_OBJECT_NUMBER_DELTA).alias('Con'))
    msg = ', '.join(map(str, [row['Con'] for row in chk.collect()]))
    logWarning('Notebook: LoadFoundationPLWReference' + str(source) + ' - Following REREFENCE ONB|PLAN ONB not baselined: ' + str(msg))
  
   # if first join results in no match
  if epe_ref.count() == 0:
    dbutils.notebook.exit('There are no EPE Forecasts to be baselined')

# COMMAND ----------

# UDF to write baseline files for respective source to Foundation
def writedf(source):
  if source == 'plan':
    df = plan_ref
    path = 'dbfs:/mnt/foundation/planisware/new/reference_plan/reference_plan_' + processDate + '_' + runid + '.txt'
  elif source == 'activity':
    df = activity_ref
    path = 'dbfs:/mnt/foundation/planisware/new/reference_activity/reference_activity_' + processDate + '_' + runid + '.txt'
  elif source == 'resource_forecast':
    df = rf_ref
    path = 'dbfs:/mnt/foundation/planisware/new/reference_resource_forecast/reference_resource_forecast_' + processDate + '_' + runid + '.txt'
  elif source == 'epe_forecast':
    df = epe_ref
    path = 'dbfs:/mnt/foundation/planisware/new/reference_epe_forecast/reference_epe_forecast_' + processDate + '_' + runid + '.txt'
  else:
    print('Invalid Source')
    

  rawPath = 'dbfs:/mnt/raw/planisware/'
  unique_run_id = runid + '-LoadCuratedPLWReference-' 
  csv_temp_curated = rawPath + unique_run_id + source + '/'

  df.coalesce(1).write\
          .option("sep", "|")\
          .option("header", "true")\
          .option("quote",  '"')\
          .option("quoteAll", "true")\
          .option("escape", '"')\
          .option("nullValue", "null")\
          .mode('overwrite')\
        .csv(csv_temp_curated)

  dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], path, recurse = True)
  dbutils.fs.rm(csv_temp_curated, recurse = True)

# COMMAND ----------

# call to UDF
writedf(source)