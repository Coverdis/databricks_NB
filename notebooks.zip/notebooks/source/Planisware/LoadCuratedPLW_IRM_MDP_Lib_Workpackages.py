# Databricks notebook source
# Load PLW_IRM_MDP_Lib_Workpackages to curated

# COMMAND ----------

dbutils.widgets.text('runid', 'sdchs-38dfjh-cdn82-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

dbutils.fs.cp('dbfs:/mnt/foundation/planisware/plw_irm_mdp_lib_workpackages.txt', 'dbfs:/mnt/curated/planisware/plw_irm_mdp_lib_workpackages.txt', recurse = True)