# Databricks notebook source
#File Name: LoadCuratedPLWWBSType
#ADF Pipeline Name: Planisware_ADL
#SQLDW Table: NA
#Description:
  #Load Planisware WBS_TYPE data in curated layer of ADL

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.functions import explode

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "vfl239-vsd823-vdl22o-0c9049")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

df_json = spark.read.format("json")\
          .option("multiLine","true")\
          .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/planisware/new/wbs_type/wbs_type.json')
df_json=df_json.withColumnRenamed('@odata.context','context')
#convert json array in to column
tempDf = df_json.select(explode("value").alias("value_exploded"))
wbs_type = tempDf.selectExpr( 'value_exploded.*')
wbs_type=wbs_type.drop('@odata.id')

# COMMAND ----------

# rename fields

wbs_type = wbs_type.withColumnRenamed('NAME', 'WBS_TYPE')
wbs_type = wbs_type.withColumnRenamed('USER_ATTRIBUTE_GSK_UA_S_PRIMARY_SYNC_SOURCE', 'PRIMARY_SOURCE_PLAN_TYPE_NAME')
wbs_type = wbs_type.withColumnRenamed('USER_ATTRIBUTE_GSK_UA_S_SECONDARY_SYNC_SOURCE', 'SECONDARY_SOURCE_PLAN_TYPE_NAME')
wbs_type = wbs_type.withColumnRenamed('USER_ATTRIBUTE_GSK_UA_B_MDP_TARGET', 'MDP_SYNCHRONISE_FLAG')
wbs_type = wbs_type.withColumnRenamed('USER_ATTRIBUTE_GSK_UA_B_PSAP_TARGET', 'PSAP_SYNCHRONISE_FLAG')
wbs_type = wbs_type.withColumnRenamed('USER_ATTRIBUTE_GSK_UA_B_CSAP_TARGET', 'CSAP_SYNCHRONISE_FLAG')
wbs_type = wbs_type.withColumnRenamed('USER_ATTRIBUTE_GSK_UA_B_USE_WP_SYNC', 'STUDY_ID_USAGE_FLAG')
wbs_type = wbs_type.withColumnRenamed('USER_ATTRIBUTE_GSK_UA_B_USE_PHASE_SYNC', 'ACTIVITY_PHASE_USAGE_FLAG')

# COMMAND ----------

cols = ['WBS_TYPE', 'PRIMARY_SOURCE_PLAN_TYPE_NAME', 'SECONDARY_SOURCE_PLAN_TYPE_NAME', 'MDP_SYNCHRONISE_FLAG', 'PSAP_SYNCHRONISE_FLAG', 'CSAP_SYNCHRONISE_FLAG', 'STUDY_ID_USAGE_FLAG', 'ACTIVITY_PHASE_USAGE_FLAG']

wbs_type = wbs_type.select(cols)

# COMMAND ----------

# write to curated
rawPath = 'dbfs:/mnt/raw/planisware/'
unique_run_id = runid + '-LoadCuratedPLWWBSType/'
csv_temp_curated = rawPath + unique_run_id + 'curated/'
curatedPath = 'dbfs:/mnt/curated/planisware/new/'

wbs_type.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + "plw_wbs_type.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)