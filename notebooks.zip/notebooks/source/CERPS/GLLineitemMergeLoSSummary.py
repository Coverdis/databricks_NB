# Databricks notebook source


#File Name:GLLineitemArchive
#ADF Pipeline Name: ActualSummaryLOSArchive
#SQLDW - NA
#Description:
  # Merges summary data in FDR prior to Feb 2018 in curated layer
  # Merges LoS data for US and UK in curated layer

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

dbutils.widgets.text("runid", "a003b-xcs82-f439c-l303d-ce2ks")

runid = dbutils.widgets.get("runid")

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window

# read exchange rates file
exchangeRatesDF = spark.read.format('csv') \
      .option('header', 'true') \
      .option("inferSchema","true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/fdr/exchange_rates_r.txt')

exchangeRatesDF = exchangeRatesDF.toDF(*(col.replace('\r', '') for col in exchangeRatesDF.columns))
for col_name in exchangeRatesDF.columns:
  exchangeRatesDF = exchangeRatesDF.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

# read wbs_elemt_cerps_l for wbs to costcenter mapping for company code GB01
costCenterMapping = spark.read.format('csv') \
      .option('header', 'true') \
      .option("inferSchema","true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
    .load('dbfs:/mnt/curated/hyperion_drm/cost_center_hierarchy.txt')

costCenterMapping = costCenterMapping.toDF(*(col.replace('\r', '') for col in costCenterMapping.columns))
costCenterMapping = costCenterMapping.select('COST_CENTER_CODE', 'COUNTRY_CODE')

for col_name in costCenterMapping.columns:
  costCenterMapping = costCenterMapping.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))
#remove leading zeros from responsible cost center code
costCenterMapping = costCenterMapping.withColumn('COST_CENTER_CODE', F.regexp_replace(costCenterMapping.COST_CENTER_CODE, '^0*', ''))

# COMMAND ----------

Latest_Year_ER=exchangeRatesDF.select(F.max(exchangeRatesDF.EXCHANGE_YEAR)).collect()[0][0]
# Latest_Year_ER

# COMMAND ----------

rawPath = 'dbfs:/mnt/raw/cerps/gllineitem/'
foundationPath = 'dbfs:/mnt/foundation/fdr/'
# logPath = 'dbfs:/mnt/log/cerps/gllineitem/'
curatedPath = 'dbfs:/mnt/curated/cerps/gllineitem/'

# read summary file from foundation
summaryDF = spark.read.format('csv')\
    .option("inferSchema", "false")\
    .option("header", "true")\
    .option("multiLine", "true")\
    .option("delimiter", "|")\
    .option("quote", '"')\
    .option("escape", '"')\
    .option("nullValue", "null")\
  .load(foundationPath + 'actual_summary_l.txt')

summaryDF = summaryDF.toDF(*(col.replace('\r', '') for col in summaryDF.columns))
#skip HMA is any
summaryDF = summaryDF.filter('scenario in ("Actual - Source", "Actual - Management Adjustments")')

# remove leading/trailing spaces from values
for col_name in summaryDF.columns:
  summaryDF = summaryDF.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ''))

summaryDF = summaryDF.withColumn('ABS_CODE', F.regexp_replace(summaryDF.ABS_CODE, '^0*', ''))
summaryDF = summaryDF.withColumn('OBS_CODE', F.regexp_replace(summaryDF.OBS_CODE, '^0*', ''))
summaryDF = summaryDF.withColumn('GL_DATE', summaryDF.GL_DATE.cast(TimestampType()))
summaryDF = summaryDF.withColumn('FISCYEAR', F.year(summaryDF.GL_DATE))
# newDF = newDF.withColumn('RANK', F.lit(1).cast(IntegerType()))

# COMMAND ----------

# join with cost center hierarchy to get country code
summaryDF = summaryDF.join(costCenterMapping, summaryDF.OBS_CODE == costCenterMapping.COST_CENTER_CODE, 'left').drop(costCenterMapping.COST_CENTER_CODE)

# keep only US and UK data
summaryDF = summaryDF.filter('COUNTRY_CODE IN ("US", "UK")')

# COMMAND ----------

losDF = spark.read.format('csv') \
      .option('header', 'true') \
      .option("inferSchema","true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/fdr/actual_summary_los_l.txt')

losDF = losDF.toDF(*(col.replace('\r', '') for col in losDF.columns))

#drop HMA
losDF = losDF.filter('scenario in ("Actual - Source","Actual - Management Adjustments")')

losDF = losDF.withColumn('ABS_CODE', F.regexp_replace(losDF.ABS_CODE, '^0*', ''))
# los = los.withColumn('PROFIT_CTR', F.regexp_replace(los.PROFIT_CTR, '^0*', ''))
losDF = losDF.withColumn('OBS_CODE', F.regexp_replace(losDF.OBS_CODE, '^0*', ''))
losDF = losDF.withColumn('GL_DATE', losDF.GL_DATE.cast(TimestampType()))
# los = los.withColumn('FISCMONTH', F.lpad(F.month(los.GL_DATE), 2, '0'))
losDF = losDF.withColumn('ENDING_BALANCE_YEAR', F.year(losDF.GL_DATE) - 1)
# los = los.withColumn('FISCPER', F.concat(los.FISCYEAR, F.lit('0'), los.FISCMONTH))

# COMMAND ----------

# join with cost center hierarchy to get country code
losDF = losDF.join(costCenterMapping, losDF.OBS_CODE == costCenterMapping.COST_CENTER_CODE, 'left').drop(costCenterMapping.COST_CENTER_CODE)

# keep only US and UK data
losDF = losDF.filter('COUNTRY_CODE IN ("US", "UK")')

# COMMAND ----------

#identify minimum year for which summary is present for cc,account and bud id
summaryDFMin = summaryDF.groupBy('OBS_CODE', 'ABS_CODE', 'WBS_CODE').agg(F.min('FISCYEAR'))
summaryDFMin = summaryDFMin.withColumnRenamed('min(FISCYEAR)','FISCYEAR_MIN')

# COMMAND ----------

#identify LoS expense that are not present in summary expense 
losMissingDF = losDF.join(summaryDFMin, (summaryDFMin.OBS_CODE == losDF.OBS_CODE) & (summaryDFMin.ABS_CODE == losDF.ABS_CODE) & (summaryDFMin.WBS_CODE == losDF.WBS_CODE), "left").drop(summaryDFMin.OBS_CODE).drop(summaryDFMin.ABS_CODE).drop(summaryDFMin.WBS_CODE)

#get LoS data for which summary does not exist or LoS data prior to summary data
losMissingDF = losMissingDF.filter('FISCYEAR_MIN is null or ENDING_BALANCE_YEAR < FISCYEAR_MIN')

# COMMAND ----------

ranked_los =  losMissingDF.withColumn(
    'RANK', F.rank().over(Window.partitionBy('obs_code', 'abs_code', 'wbs_code').orderBy(F.asc('ENDING_BALANCE_YEAR'))))
ranked_los = ranked_los.filter('RANK = 1')

# COMMAND ----------

summaryDF = summaryDF.select(
  'OBS_CODE',
  'ABS_CODE',
  'WBS_CODE',
  'GL_DATE',
  'CURRENCY_CODE',
  'AMT_MTD',
  'SCENARIO',
  'VERSION',
  'CREATION_DATE',
  'DATA_SOURCE',
  'COUNTRY_CODE'
)

ranked_los = ranked_los.select(
  'OBS_CODE',
  'ABS_CODE',
  'WBS_CODE',
  'GL_DATE',
  'CURRENCY_CODE',
  'AMT_MTD',
  'SCENARIO',
  'VERSION',
  'CREATION_DATE',
  'DATA_SOURCE',
  'COUNTRY_CODE'
)

finalDF = summaryDF.unionByName(ranked_los)

# COMMAND ----------

finalDF = finalDF.withColumn('BW_REQUEST_ID', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('BW_PACKET_ID', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('BW_RECORD_NUMBER', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('BW_RECORDMODE', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('DOCUMENT_NO', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('CHRT_ACCTS', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('COMP_CODE', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('CO_AREA', F.lit(None).cast(StringType()))
# finalDF = finalDF.withColumn('COST_CENTER_CODE', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('COSTELMNT', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('YCOSTSA', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('CUSTOMER', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('DOC_HD_TXT', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('AC_DOC_TYP', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('FISCVARNT', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('FUNC_AREA', F.lit(None).cast(StringType()))
# finalDF = finalDF.withColumn('ACCOUNT_CODE', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('YLIITID', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('AC_LEDGER', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('MATERIAL', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('COORDER', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('PLANT', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('PROFIT_CTR', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('OI_EBELN', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('REF_KEY3', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('VENDOR', F.lit(None).cast(StringType()))
# finalDF = finalDF.withColumn('VERSION', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('BUDID_CODE', finalDF.WBS_CODE.cast(StringType()))
finalDF = finalDF.withColumn('WBS_CODE', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('CURRENCY', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('DOC_CURRCY', F.lit(None).cast(StringType()))
# finalDF = finalDF.withColumn('CURRENCY_CODE', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('LOC_CURRC2', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('LOC_CURRC3', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('AMOUNT', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('YAMT_LC', F.lit(None).cast(StringType()))
# finalDF = finalDF.withColumn('AMOUNT_LOC', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('DEB_CRE_L2', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('CREDIT_DC', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('CREDIT_LC', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('CREDIT_LC2', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('DEBIT_LC2', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('DEBIT_DC', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('DEBIT_LC', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('DEB_CRE_DC', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('CLEAR_DATE', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('DOC_DATE', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('PSTNG_DATE', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('CALMONTH2', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('CALYEAR', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('CALQUARTER', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('YFISCHYR', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('YFISCQTR', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('FISCYEAR', F.year(finalDF.GL_DATE))
finalDF = finalDF.withColumn('FISCPER', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('OI_EBELP', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('YLOADDATE', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('FISCMONTH', F.lpad(F.month(finalDF.GL_DATE), 2, '0'))
finalDF = finalDF.withColumn('YTIMEZONE', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('ORDER_QUAN', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('QUANTITY', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('PO_UNIT', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('UNIT', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('ITEM_NUM', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('RECTYPE', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('POST_KEY', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('TCTTIMSTMP', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('CALMONTH', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('YIDISPIT', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('PAYDT', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('BILLEXCHUS', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('FS_CTR_NO', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('FS_CTR_TP', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('VALUE_DATE', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('BLINE_DATE', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('ASGN_NO', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('SEGMENT', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('REF_KEY1', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('REF_KEY2', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('BILL_NUM', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('DOC_NUMBER', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('XSAFIDTYP', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('PMNT_BLOCK', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('PYMT_METH', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('COUNTRY', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('OI_PTRM', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('PSM_AWKEY', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('YSMARTNO', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('TRXN_KEY', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('MOVE_TYPE', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('YIITMCLR', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('ID_BUPLA', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('YOFFACTY', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('YOFFACCT', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('YICLRREV', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('CLR_DOC_FY', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('YCLRITEM', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('NEG_POSTNG', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('SP_GL_IND', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('CREATEDON', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('CLR_DOC_NO', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('ACCT_TYPE', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('REF_DOC_NO', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('LOC_CURTP2', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('LOC_CURTP3', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('ASSET', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('FI_AWTYP', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('FI_DOCSTAT', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('ASSET_MAIN', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('DCINDIC', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('INV_DOC_NO', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('SCHED_LINE', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('S_ORD_ITEM', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('RT_TAXCODE', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('NETDUEDATE', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('YCOMOBJ', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('LOGSYS', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('POSTXT', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('LOAD_DATE', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('BODS_TABLE_CODE', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('BODS_STAGING_DATE', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('BAL_FLAG', F.lit(1).cast(IntegerType()))
# finalDF = finalDF.withColumn('AMOUNT_GBP', F.lit(None).cast(StringType()))
# finalDF = finalDF.withColumn('COST_TYPE', F.lit(None).cast(StringType()))
finalDF = finalDF.withColumn('RANK', F.lit(1).cast(IntegerType()))
# finalDF = finalDF.withColumn('ACTUAL_OR_ESTIMATE_CODE', F.lit('Actual').cast(StringType()))
# finalDF = finalDF.withColumn('BUDID_CODE', F.regexp_replace(finalDF.BUDID_CODE, 'UNK', None))
finalDF = finalDF.withColumn('BUDID_CODE', F.translate(finalDF.BUDID_CODE, 'UNK', ''))

# COMMAND ----------

# finalDF = finalDF.withColumn('RANK', F.lit(1).cast(IntegerType()))
# finalDF = finalDF.withColumn('FISCMONTH', F.lpad(F.month(finalDF.GL_DATE), 2, '0'))
# finalDF = finalDF.withColumn('FISCYEAR', F.year(finalDF.GL_DATE))
# finalDF = finalDF.withColumn('FISCPER', F.concat(finalDF.FISCYEAR, F.lit('0'), finalDF.FISCMONTH))
# finalDF = finalDF.withColumn('BAL_FLAG', F.lit(1).cast(IntegerType()))
# finalDF = finalDF.withColumn('BUDID_CODE', finalDF.WBS_CODE.cast(StringType()))
# finalDF = finalDF.withColumn('WBS_CODE', F.lit(None).cast(StringType()))
# finalDF = finalDF.withColumn('COMP_CODE', F.lit(None).cast(StringType()))
# finalDF = finalDF.withColumn('DOCUMENT_NO', F.lit(None).cast(StringType()))
# finalDF = finalDF.withColumn('ACTUAL_OR_ESTIMATE_CODE', F.lit('Actual').cast(StringType()))
# finalDF = finalDF.withColumn('BUDID_CODE', F.regexp_replace(finalDF.BUDID_CODE, 'UNK', None))

# COMMAND ----------

# add DEB_CRE_GBP field
finalDF = finalDF.join(exchangeRatesDF, (Latest_Year_ER == exchangeRatesDF.EXCHANGE_YEAR) & (finalDF.CURRENCY_CODE == exchangeRatesDF.CURRENCY_CODE), 'left').drop(exchangeRatesDF.CURRENCY_CODE).drop(exchangeRatesDF.EXCHANGE_YEAR).drop(exchangeRatesDF.SPOT_RATE).drop(exchangeRatesDF.AVERAGE_RATE)
finalDF = finalDF.withColumn('DEB_CRE_GBP', F.round((finalDF.AMT_MTD / finalDF.BUDGET_RATE), 2)).drop(finalDF.BUDGET_RATE)

finalDF = finalDF.join(exchangeRatesDF, (finalDF.FISCYEAR == exchangeRatesDF.EXCHANGE_YEAR) & (finalDF.CURRENCY_CODE == exchangeRatesDF.CURRENCY_CODE), 'left').drop(exchangeRatesDF.CURRENCY_CODE).drop(exchangeRatesDF.EXCHANGE_YEAR).drop(exchangeRatesDF.SPOT_RATE).drop(exchangeRatesDF.AVERAGE_RATE)
finalDF = finalDF.withColumn('DEB_CRE_HIST_GBP', F.round((finalDF.AMT_MTD / finalDF.BUDGET_RATE), 2)).drop(finalDF.BUDGET_RATE)


# add cost type field
finalDF = finalDF.withColumn('COST_TYPE', 
                             F.when(finalDF.BUDID_CODE.isNull(), 'IPE').otherwise('EPE').cast(StringType())
                            )

# rename fields as in sql dw
finalDF = finalDF.withColumnRenamed('OBS_CODE', 'COST_CENTER_CODE')
finalDF = finalDF.withColumnRenamed('ABS_CODE', 'ACCOUNT_CODE')
finalDF = finalDF.withColumnRenamed('GL_DATE', 'GL_PERIOD')
finalDF = finalDF.withColumnRenamed('AMT_MTD', 'AMOUNT_LOC')
finalDF = finalDF.withColumnRenamed('DEB_CRE_GBP', 'AMOUNT_GBP')
finalDF = finalDF.withColumnRenamed('DEB_CRE_HIST_GBP', 'AMOUNT_HIST_GBP')
finalDF = finalDF.withColumnRenamed('DATA_SOURCE', 'SOURCE')


# New change 
finalDF = finalDF.withColumnRenamed('DOC_DATE', 'DOCUMENT_DATE')
finalDF = finalDF.withColumnRenamed('PSTNG_DATE', 'POSTING_DATE')
finalDF = finalDF.withColumnRenamed('OI_EBELN', 'PURCHASE_DOCUMENT_NUMBER')
finalDF = finalDF.withColumnRenamed('POSTXT', 'ITEM_TEXT')

# COMMAND ----------

finalDF = finalDF.select(
  'BW_REQUEST_ID', 'BW_PACKET_ID', 'BW_RECORD_NUMBER', 'BW_RECORDMODE', 'DOCUMENT_NO', 'CHRT_ACCTS', 'COMP_CODE', 'CO_AREA', 'COST_CENTER_CODE', 'COSTELMNT', 'YCOSTSA', 'CUSTOMER', 'DOC_HD_TXT', 'AC_DOC_TYP', 'FISCVARNT', 'FUNC_AREA', 'ACCOUNT_CODE', 'YLIITID', 'AC_LEDGER', 'MATERIAL', 'COORDER', 'PLANT', 'PROFIT_CTR', 'PURCHASE_DOCUMENT_NUMBER', 'REF_KEY3', 'VENDOR', 'VERSION', 'WBS_CODE', 'CURRENCY', 'DOC_CURRCY', 'CURRENCY_CODE', 'LOC_CURRC2', 'LOC_CURRC3', 'AMOUNT', 'YAMT_LC', 'AMOUNT_LOC', 'DEB_CRE_L2', 'CREDIT_DC', 'CREDIT_LC', 'CREDIT_LC2', 'DEBIT_LC2', 'DEBIT_DC', 'DEBIT_LC', 'DEB_CRE_DC', 'CLEAR_DATE', 'DOCUMENT_DATE', 'POSTING_DATE', 'CALMONTH2', 'CALYEAR', 'CALQUARTER', 'YFISCHYR', 'YFISCQTR', 'FISCYEAR', 'FISCPER', 'OI_EBELP', 'YLOADDATE', 'FISCMONTH', 'YTIMEZONE', 'ORDER_QUAN', 'QUANTITY', 'PO_UNIT', 'UNIT', 'ITEM_NUM', 'RECTYPE', 'POST_KEY', 'TCTTIMSTMP', 'CALMONTH', 'YIDISPIT', 'PAYDT', 'BILLEXCHUS', 'FS_CTR_NO', 'FS_CTR_TP', 'VALUE_DATE', 'BLINE_DATE', 'ASGN_NO', 'SEGMENT', 'REF_KEY1', 'REF_KEY2', 'BILL_NUM', 'DOC_NUMBER', 'XSAFIDTYP', 'PMNT_BLOCK', 'PYMT_METH', 'COUNTRY', 'OI_PTRM', 'PSM_AWKEY', 'YSMARTNO', 'TRXN_KEY', 'MOVE_TYPE', 'YIITMCLR', 'ID_BUPLA', 'YOFFACTY', 'YOFFACCT', 'YICLRREV', 'CLR_DOC_FY', 'YCLRITEM', 'NEG_POSTNG', 'SP_GL_IND', 'CREATEDON', 'CLR_DOC_NO', 'ACCT_TYPE', 'REF_DOC_NO', 'LOC_CURTP2', 'LOC_CURTP3', 'ASSET', 'FI_AWTYP', 'FI_DOCSTAT', 'ASSET_MAIN', 'DCINDIC', 'INV_DOC_NO', 'SCHED_LINE', 'S_ORD_ITEM', 'RT_TAXCODE', 'NETDUEDATE', 'YCOMOBJ', 'LOGSYS', 'ITEM_TEXT', 'LOAD_DATE', 'BODS_TABLE_CODE', 'BODS_STAGING_DATE', 'BAL_FLAG', 'BUDID_CODE', 'AMOUNT_GBP','AMOUNT_HIST_GBP', 'COST_TYPE', 'RANK'
)

# COMMAND ----------

# MAGIC %run  /library/ParallelClass

# COMMAND ----------

# create global temp view of dataframe to be accessible from child notebooks
dataset_temp_view = 'GLLineitemMergeLoSSummary'
finalDF.createOrReplaceGlobalTempView(dataset_temp_view)

# get list of year and month
fiscper = finalDF.select('FISCYEAR', 'FISCMONTH').distinct().collect()
year = [i[0] for i in fiscper]
month = [i[1].lstrip('0') for i in fiscper]

query = list(map(lambda x, y: 'FISCYEAR = {0} and FISCMONTH = {1}'.format(x, y), year, month))
dataset = [dataset_temp_view] * len(query)
path = list(map(lambda x, y: 'dbfs:/mnt/curated/cerps/gllineitem/{0}/GLLineitem-{1}-{2}.txt'.format(x, x, y), year, month))

# list of notebooks based on the month and year parameter: child notebook path, timeout, parameters, retry
notebooks = list(map(lambda x, y, z: NotebookData(path = '/library/LoadFilesADL', timeout = 300, parameters = {'args': x, 'dataset': y, 'path': z}, retry = 2), query, dataset, path))

# calling child notebooks with number of parallel notebook runs
res = NotebookData.parallelNotebooks(notebooks, 6)
# blocking call to wait for completion of child notebooks run
result = [f.result(timeout = 10000) for f in res] # This is a blocking call.
# print(result)

# COMMAND ----------

# drop global temp view
spark.catalog.dropGlobalTempView(dataset_temp_view)