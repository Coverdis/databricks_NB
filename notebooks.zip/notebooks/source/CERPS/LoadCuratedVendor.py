# Databricks notebook source
#File Name: LoadCuratedVendor
#ADF Pipeline Name: CERPS_ADL
#SQLDW Table: NA
#Description:
  # Load CERPS vendor master from foundation to curated 

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *

dbutils.widgets.text('runid', 'vfj3s-dv83q-cdn82-cdnms')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

df = spark.read.format("csv")\
      .option("inferSchema", "false")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load('dbfs:/mnt/foundation/cerps/vendor_cerps_l.txt')

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

#for col_name in df.columns:
#  df = df.withColumn(col_name, F.regexp_replace(F.col(col_name), '[\\r\\n\\s+]', ' '))

# COMMAND ----------

# rename fields
df = df.withColumnRenamed('VENDOR', 'VENDOR_ID')
df = df.withColumnRenamed('NAME', 'VENDOR_NAME')
df = df.withColumnRenamed('POSTAL_CD', 'POSTAL_CODE')
df = df.withColumn('SOURCE',F.lit('CERPS').cast(StringType()))

# COMMAND ----------

df=df.select('VENDOR_ID','VENDOR_NAME','STREET','CITY','REGION','COUNTRY','POSTAL_CODE','SOURCE')

# COMMAND ----------

# write to curated layer
raw_path = 'dbfs:/mnt/raw/cerps/'
unique_run_id = runid + '-LoadCuratedVendor/'
csv_temp_unified = raw_path + unique_run_id + '/' + 'curated'

curated_path = 'dbfs:/mnt/curated/cerps/'

df.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("quoteAll", "true")\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .mode('overwrite')\
      .csv(csv_temp_unified)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_unified)[-1][0], curated_path + "vendor.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(raw_path + unique_run_id, recurse = True)