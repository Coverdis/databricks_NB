# Databricks notebook source
#File Name:POMerge
#ADF Pipeline Name: CERPS_ADL_DW
#SQLDW - NA
#Description:
  #Merges transaction in raw with foundation and curated layer for purchase order
  #Write data in foundation layer for PO -CERPS for a month and year 

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

dbutils.widgets.text("year", "")
dbutils.widgets.text("month", "")
dbutils.widgets.text("filename", "")
dbutils.widgets.text("runid", "111")

deltaFileName = dbutils.widgets.get("filename")
deltaFileMonth = dbutils.widgets.get("month")
deltaFileYear = dbutils.widgets.get("year")
runid = dbutils.widgets.get("runid")
print (deltaFileName)
print (deltaFileMonth)
print (deltaFileYear)

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
import pytz
from datetime import datetime

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

exchangeRatesDF = spark.read.format('csv') \
      .option('header', 'true') \
      .option("inferSchema","true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/fdr/exchange_rates_r.txt')

exchangeRatesDF = exchangeRatesDF.toDF(*(col.replace('\r', '') for col in exchangeRatesDF.columns))
for col_name in exchangeRatesDF.columns:
  exchangeRatesDF = exchangeRatesDF.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

# read wbs element and budid mapping file
budidMapDF = spark.read.format('csv') \
      .option('header', 'true') \
      .option("inferSchema","true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/fdr/cerps_wbselemt_budid_map.txt')

budidMapDF = budidMapDF.toDF(*(col.replace('\r', '') for col in budidMapDF.columns))
for col_name in budidMapDF.columns:
  budidMapDF = budidMapDF.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

# COMMAND ----------

rawPath = 'dbfs:/mnt/raw/cerps/po/'
foundationPath = 'dbfs:/mnt/foundation/cerps/po/'
curatedPath = 'dbfs:/mnt/curated/cerps/po/'

# temp csv folder - run id is being added to make sure files do not mess up while running code in parallel
csv_temp_foundation = rawPath + 'foundation/' + runid +'/'+ deltaFileYear +'/'+ deltaFileMonth
csv_temp_curated = rawPath + 'curated/' + runid +'/'+ deltaFileYear +'/'+ deltaFileMonth

# read delta file from raw
newDF = spark.read.format('csv')\
  .option("inferSchema", "false")\
  .option("header", "true")\
  .option("multiLine", "true")\
  .option("delimiter", "|")\
  .option("quote", '"')\
  .option("escape", '"')\
  .option("nullValue", "null")\
.load(rawPath + deltaFileName)

newDF = newDF.toDF(*(col.replace('\r', '') for col in newDF.columns))
# remove leading/trailing spaces from values
for col_name in newDF.columns:
  newDF = newDF.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

newDF = newDF.withColumn('GL_ACCOUNT', F.regexp_replace(newDF.GL_ACCOUNT, '^0*', ''))
newDF = newDF.withColumn('PROFIT_CTR', F.regexp_replace(newDF.PROFIT_CTR, '^0*', ''))
newDF = newDF.withColumn('COSTCENTER', F.regexp_replace(newDF.COSTCENTER, '^0*', ''))

# COMMAND ----------

if file_exists(foundationPath + deltaFileYear +'/' + deltaFileName)==True:
  baseFile = spark.read.format('csv')\
    .option("inferSchema", "false")\
    .option("header", "true")\
    .option("multiLine", "true")\
    .option("delimiter", "|")\
    .option("quote", '"')\
    .option("escape", '"')\
    .option("nullValue", "null")\
  .load(foundationPath + deltaFileYear +'/' + deltaFileName)

  baseFile = baseFile.toDF(*(col.replace('\r', '') for col in baseFile.columns))
  for col_name in baseFile.columns:
    baseFile = baseFile.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

  # find rows that are not in base but are in delta, this is to avoid loading duplicates in base file
  changeddf = newDF.subtract(baseFile)
  # merge with base data
  newDF = baseFile.unionByName(changeddf)

  
  
# write df to foundation temp folder 
newDF.coalesce(1).write\
          .option("sep", "|")\
          .option("header", "true")\
          .option("quote",  '"')\
          .option("escape", '"')\
          .option("nullValue", "null")\
          .mode('overwrite')\
        .csv(csv_temp_foundation)
  

# COMMAND ----------

# Cast BW_RECORD_NUMBER and BW_REQUEST_ID to Integer for ordering ranking in below step
newDF = newDF.withColumn('BW_RECORD_NUMBER', newDF.BW_RECORD_NUMBER.cast(IntegerType()))
newDF = newDF.withColumn('BW_REQUEST_ID', newDF.BW_REQUEST_ID.cast(IntegerType()))

# create rank field

ranked =  newDF.withColumn(
      'RANK', F.rank().over(Window.partitionBy('oi_ebeln', 'processkey', 'oi_ebelp', 'sched_line', 'bbp_acc_no').orderBy(F.desc('BW_REQUEST_ID'),F.desc('BW_PACKET_ID'), F.desc('BW_RECORD_NUMBER'), 'BW_RECORDMODE')))

#calulate bud id
ranked = ranked.join(budidMapDF, ranked.WBS_ELEMT == budidMapDF.CERPS_WBS_ELEMT, 'left').drop(budidMapDF.CERPS_WBS_ELEMT)
#calcualte GBP amount via exchange rate
# add AMOUNT_GBP field
ranked = ranked.join(exchangeRatesDF, (ranked.FISCYEAR == exchangeRatesDF.EXCHANGE_YEAR) & (ranked.LOC_CURRCY == exchangeRatesDF.CURRENCY_CODE), 'left').drop(exchangeRatesDF.CURRENCY_CODE).drop(exchangeRatesDF.EXCHANGE_YEAR).drop(exchangeRatesDF.SPOT_RATE).drop(exchangeRatesDF.AVERAGE_RATE)
ranked = ranked.withColumn('AMOUNT_GBP', F.round((ranked.ORDER_VAL / ranked.BUDGET_RATE), 2))
ranked = ranked.withColumn('INVOICE_VALUE_GBP', F.round((ranked.INV_RC_VAL / ranked.BUDGET_RATE), 2)).drop(ranked.BUDGET_RATE)


# rename fields as in sql dw
ranked = ranked.withColumnRenamed('COSTCENTER', 'COST_CENTER_CODE')
ranked = ranked.withColumnRenamed('GL_ACCOUNT', 'ACCOUNT_CODE')
ranked = ranked.withColumnRenamed('WBS_ELEMT', 'WBS_CODE')
ranked = ranked.withColumnRenamed('ORDER_VAL', 'AMOUNT_LOC')
ranked = ranked.withColumnRenamed('LOC_CURRCY', 'CURRENCY_CODE')
ranked = ranked.withColumnRenamed('FISCPER3', 'FISCMONTH')
ranked = ranked.withColumnRenamed('RD_BUDID', 'BUDID_CODE')
ranked = ranked.withColumnRenamed('OI_EBELN', 'PURCHASE_DOCUMENT_NUMBER')
ranked = ranked.withColumnRenamed('REQUESTER', 'REQUESTER')
ranked = ranked.withColumnRenamed('VENDOR', 'VENDOR_ID')
ranked = ranked.withColumnRenamed('INV_RC_VAL', 'INVOICE_VALUE')
ranked = ranked.withColumnRenamed('DOC_DATE', 'DOCUMENT_DATE')
ranked = ranked.withColumnRenamed('PSTNG_DATE', 'POSTING_DATE')
ranked = ranked.withColumnRenamed('txtlg', 'PO_DESCRIPTION')

ranked = ranked.withColumn('DOCUMENT_NO', F.lit('None').cast(StringType()))
ranked = ranked.withColumn('COST_TYPE', F.lit('EPE').cast(StringType()))

# ranked = ranked.withColumn('AMOUNT_LOC', ranked.AMOUNT_LOC.cast(DecimalType(31, 2)))

# COMMAND ----------

# write ranked to curated temp folder
ranked.coalesce(1).write\
          .option("sep", "|")\
          .option("header", "true")\
          .option("quote",  '"')\
          .option("escape", '"')\
          .option("nullValue", "null")\
          .option("quoteAll", "true")\
          .mode('overwrite')\
        .csv(csv_temp_curated)

# remove delta file from raw
#dbutils.fs.rm(rawPath + deltaFileName, recurse = True)