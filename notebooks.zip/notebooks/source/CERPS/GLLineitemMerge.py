# Databricks notebook source
#File Name:GLLineitemMerge
#ADF Pipeline Name: CERPS_ADL_DW
#SQLDW - irm_stg.Expense
#Description:
  #Merges transaction in raw with foundation and curated layer
  #Write data in SQL DW for CERPS for a month and year 

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

dbutils.widgets.text("year", "")
dbutils.widgets.text("month", "")
dbutils.widgets.text("filename", "")
dbutils.widgets.text("runid", "111")

deltaFileName = dbutils.widgets.get("filename")
deltaFileMonth = dbutils.widgets.get("month")
deltaFileYear = dbutils.widgets.get("year")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
import pytz
from datetime import datetime

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

# read accounts file to add balance account flag
balDF = spark.read.format('csv') \
      .option('header', 'true') \
      .option("inferSchema","true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/cerps/cerps_fdr_stage/gl_account_cerps_l.txt')
balDF = balDF.toDF(*(col.replace('\r', '') for col in balDF.columns))
balDF = balDF.withColumn('GL_ACCOUNT', F.regexp_replace(balDF.GL_ACCOUNT, '^0*', ''))
# remove leading/trailing spaces from values
for col_name in balDF.columns:
  balDF = balDF.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))
balDF = balDF.select('GL_ACCOUNT', 'BAL_FLAG')
balDF = balDF.dropDuplicates()

# display(balDF)

# read R&D company codes
ccDF = spark.read.format('csv') \
      .option('header', 'true') \
      .option("inferSchema","true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/fdr/company_code_cerps_l.txt')

ccDF = ccDF.toDF(*(col.replace('\r', '') for col in ccDF.columns))
for col_name in ccDF.columns:
  ccDF = ccDF.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

# read R&D profit centers
pcDF = spark.read.format('csv') \
      .option('header', 'true') \
      .option("inferSchema","true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/fdr/profit_center_cerps_l.txt')

pcDF = pcDF.withColumn('PROFIT_CTR', F.regexp_replace(pcDF.PROFIT_CTR, '^0*', ''))
pcDF = pcDF.withColumnRenamed('PROFIT_CTR', 'PROFIT_CENTER')

pcDF = pcDF.toDF(*(col.replace('\r', '') for col in pcDF.columns))
for col_name in pcDF.columns:
  pcDF = pcDF.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

# read R&D account range
rangeDF = spark.read.format('csv') \
      .option('header', 'true') \
      .option("inferSchema","true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/fdr/cerps_acct_code_range.txt')

rangeDF = rangeDF.toDF(*(col.replace('\r', '') for col in rangeDF.columns))
for col_name in rangeDF.columns:
  rangeDF = rangeDF.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

accStartRange = rangeDF.filter('app_type = "HYP_HCP"').select('strt_acct_range').collect()[0][0]
accEndRange = rangeDF.filter('app_type = "HYP_HCP"').select('end_acct_range').collect()[0][0]

# read exchange rates file
exchangeRatesDF = spark.read.format('csv') \
      .option('header', 'true') \
      .option("inferSchema","true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/fdr/exchange_rates_r.txt')

exchangeRatesDF = exchangeRatesDF.toDF(*(col.replace('\r', '') for col in exchangeRatesDF.columns))
for col_name in exchangeRatesDF.columns:
  exchangeRatesDF = exchangeRatesDF.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))
Latest_Year_ER=exchangeRatesDF.select(F.max(exchangeRatesDF.EXCHANGE_YEAR)).collect()[0][0]

# read wbs element and budid mapping file
budidMapDF = spark.read.format('csv') \
      .option('header', 'true') \
      .option("inferSchema","true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/fdr/cerps_wbselemt_budid_map.txt')

budidMapDF = budidMapDF.toDF(*(col.replace('\r', '') for col in budidMapDF.columns))
for col_name in budidMapDF.columns:
  budidMapDF = budidMapDF.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))
  
# read wbs_elemt_cerps_l for wbs to costcenter mapping for company code GB01
costCenterMapping = spark.read.format('csv') \
      .option('header', 'true') \
      .option("inferSchema","true")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
    .load('dbfs:/mnt/foundation/cerps/cerps_fdr_stage/wbs_elemt_cerps_l.txt')

costCenterMapping = costCenterMapping.toDF(*(col.replace('\r', '') for col in costCenterMapping.columns))
for col_name in costCenterMapping.columns:
  costCenterMapping = costCenterMapping.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))
#remove leading zeros from responsible cost center mapping

costCenterMapping = costCenterMapping.withColumn('RESP_CCTR', F.regexp_replace(costCenterMapping.RESP_CCTR, '^0*', ''))
costCenterMapping = costCenterMapping.filter('comp_code = "GB01"')

# COMMAND ----------

rawPath = 'dbfs:/mnt/raw/cerps/gllineitem/'
foundationPath = 'dbfs:/mnt/foundation/cerps/gllineitem/'
# logPath = 'dbfs:/mnt/log/cerps/gllineitem/'
curatedPath = 'dbfs:/mnt/curated/cerps/gllineitem/'

# temp csv folder - run id is being added to make sure files do not mess up while running code in parallel
csv_temp_foundation = rawPath + runid + deltaFileYear + deltaFileMonth + '/' + 'foundation'
csv_temp_curated = rawPath + runid + deltaFileYear + deltaFileMonth + '/' + 'curated'

# read delta file from raw
newDF = spark.read.format('csv')\
  .option("inferSchema", "false")\
  .option("header", "true")\
  .option("multiLine", "true")\
  .option("delimiter", "|")\
  .option("quote", '"')\
  .option("escape", '"')\
  .option("nullValue", "null")\
.load(rawPath + deltaFileName)

newDF = newDF.toDF(*(col.replace('\r', '') for col in newDF.columns))
# remove leading/trailing spaces from values
for col_name in newDF.columns:
  newDF = newDF.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

newDF = newDF.withColumn('GL_ACCOUNT', F.regexp_replace(newDF.GL_ACCOUNT, '^0*', ''))
newDF = newDF.withColumn('PROFIT_CTR', F.regexp_replace(newDF.PROFIT_CTR, '^0*', ''))
newDF = newDF.withColumn('COSTCENTER', F.regexp_replace(newDF.COSTCENTER, '^0*', ''))

# COMMAND ----------

# ranked = None

# check if year folder is present in foundation
try:
  dbutils.fs.ls(foundationPath + deltaFileYear)
  # check if file with name in raw folder is present in foundation
  try:
    dbutils.fs.ls(foundationPath + deltaFileYear + '/' + deltaFileName)
    # read base file from foundation
    baseFile = spark.read.format('csv')\
      .option("inferSchema", "false")\
      .option("header", "true")\
      .option("multiLine", "true")\
      .option("delimiter", "|")\
      .option("quote", '"')\
      .option("escape", '"')\
      .option("nullValue", "null")\
    .load(foundationPath + deltaFileYear +'/' + deltaFileName)
    
    baseFile = baseFile.toDF(*(col.replace('\r', '') for col in baseFile.columns))
    for col_name in baseFile.columns:
      baseFile = baseFile.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))
      
    # find rows that are not in base but are in delta, this is to avoid loading duplicates in base file
    changeddf = newDF.subtract(baseFile)
    # merge with base data
    newDF = baseFile.unionByName(changeddf)
  except Exception as exception:
    print(exception.message)
except:
  # if year folder does not exist then create folder
  dbutils.fs.mkdirs(foundationPath + deltaFileYear)
finally:  
  # write df to foundation temp folder 
  newDF.write\
            .option("sep", "|")\
            .option("header", "true")\
            .option("quote",  '"')\
            .option("escape", '"')\
            .option("nullValue", "null")\
            .mode('overwrite')\
          .csv(csv_temp_foundation)
  # copy part-* csv file to foundation and rename
#   dbutils.fs.cp(dbutils.fs.ls(csv_temp_foundation)[-1][0], foundationPath + deltaFileYear + '/' + deltaFileName, recurse = True)

# COMMAND ----------

# print(newDF.select('gl_account').subtract(balDF.select('gl_account')).collect())

if newDF.select('gl_account').subtract(balDF.select('gl_account')).count() > 0:
    raise ValueError('Input file has more accounts than gl_account_cerps_l file.')

# add bal_flag field
newDF = newDF.join(balDF.select('GL_ACCOUNT', 'BAL_FLAG'), newDF.GL_ACCOUNT == balDF.GL_ACCOUNT, 'left').drop(balDF.GL_ACCOUNT)
# add r&d company, profit center, costcenter and budid data
newDF = newDF.join(ccDF.filter("REQ_HYP = 'Y'").select('COMPANY'), newDF.COMP_CODE == ccDF.COMPANY, 'left')
newDF = newDF.join(pcDF.filter("REQ_HYP = 'Y'").select('PROFIT_CENTER'), newDF.PROFIT_CTR == pcDF.PROFIT_CENTER, 'left')
newDF = newDF.join(budidMapDF, newDF.WBS_ELEMT == budidMapDF.CERPS_WBS_ELEMT, 'left').drop(budidMapDF.CERPS_WBS_ELEMT)

newDF = newDF.join(costCenterMapping, newDF.WBS_ELEMT == costCenterMapping.WBS_ELEMT, 'left').drop(costCenterMapping.WBS_ELEMT).drop(costCenterMapping.COMP_CODE)
newDF = newDF.withColumn('COSTCENTER', F.when((newDF.COMP_CODE == 'GB01') & (newDF.RESP_CCTR.isNotNull()) & (newDF.COSTCENTER.isNull()), newDF.RESP_CCTR).otherwise(newDF.COSTCENTER))

# filter by account range
newDF = newDF.filter('gl_account between ' + str(accStartRange) + ' and '+ str(accEndRange) + ' and (company is not null or profit_center is not null)')
newDF = newDF.drop('COMPANY', 'PROFIT_CENTER', 'RESP_CCTR')

# remove blank cost center
newDF = newDF.filter("COSTCENTER is not NULL and COSTCENTER <> ''")

# COMMAND ----------

# add DEB_CRE_GBP field
newDF = newDF.join(exchangeRatesDF, (Latest_Year_ER == exchangeRatesDF.EXCHANGE_YEAR) & (newDF.LOC_CURRCY == exchangeRatesDF.CURRENCY_CODE), 'left').drop(exchangeRatesDF.CURRENCY_CODE).drop(exchangeRatesDF.EXCHANGE_YEAR).drop(exchangeRatesDF.SPOT_RATE).drop(exchangeRatesDF.AVERAGE_RATE)
newDF = newDF.withColumn('DEB_CRE_GBP', F.round((newDF.DEB_CRE_LC / newDF.BUDGET_RATE), 2)).drop(newDF.BUDGET_RATE)

newDF = newDF.join(exchangeRatesDF, (newDF.FISCYEAR == exchangeRatesDF.EXCHANGE_YEAR) & (newDF.LOC_CURRCY == exchangeRatesDF.CURRENCY_CODE), 'left').drop(exchangeRatesDF.CURRENCY_CODE).drop(exchangeRatesDF.EXCHANGE_YEAR).drop(exchangeRatesDF.SPOT_RATE).drop(exchangeRatesDF.AVERAGE_RATE)
newDF = newDF.withColumn('DEB_CRE_HIST_GBP', F.round((newDF.DEB_CRE_LC / newDF.BUDGET_RATE), 2)).drop(newDF.BUDGET_RATE)

# COMMAND ----------


# add cost type field
newDF = newDF.withColumn('COST_TYPE', 
                         F.when(newDF.WBS_ELEMT.isNull(), 'IPE').otherwise(
                           F.when(newDF.WBS_ELEMT.like('%-IM-%'), 'CAPEX').otherwise(
                             F.when(newDF.WBS_ELEMT.like('%-AM-%'), 'IPE').otherwise(
                               F.when(newDF.WBS_ELEMT.like('%-CT-%'), 'EPE').otherwise(
                                  F.when(newDF.WBS_ELEMT.like('%-RD-%'), 'EPE')
                               )
                             )
                           )
                         )
                        )

# newDF = newDF.withColumn('GL_PERIOD', F.concat_ws('-', newDF.FISCYEAR, newDF.FISCPER3, F.lit(1)).cast(TimestampType()))
# newDF = newDF.withColumn('SOURCE', F.lit('CERPS').cast(StringType()))
# newDF = newDF.withColumn('ACTUAL_OR_ESTIMATE_CODE', F.lit('Actual').cast(StringType()))

# Cast BW_RECORD_NUMBER and BW_REQUEST_ID to Integer for ordering ranking in below step
newDF = newDF.withColumn('BW_RECORD_NUMBER', newDF.BW_RECORD_NUMBER.cast(IntegerType()))
newDF = newDF.withColumn('BW_REQUEST_ID', newDF.BW_REQUEST_ID.cast(IntegerType()))

# create rank field
ranked =  newDF.withColumn(
    'RANK', F.rank().over(Window.partitionBy('ac_doc_no', 'item_num', 'comp_code', 'fiscper', 'fiscvarnt', 'rectype', 'ac_ledger').orderBy(F.desc('BW_REQUEST_ID'), F.desc('BW_RECORD_NUMBER'), 'BW_RECORDMODE')))

# rename fields as in sql dw
ranked = ranked.withColumnRenamed('COSTCENTER', 'COST_CENTER_CODE')
ranked = ranked.withColumnRenamed('GL_ACCOUNT', 'ACCOUNT_CODE')
ranked = ranked.withColumnRenamed('WBS_ELEMT', 'WBS_CODE')
ranked = ranked.withColumnRenamed('AC_DOC_NO', 'DOCUMENT_NO')
ranked = ranked.withColumnRenamed('DEB_CRE_LC', 'AMOUNT_LOC')
ranked = ranked.withColumnRenamed('DEB_CRE_GBP', 'AMOUNT_GBP')
ranked = ranked.withColumnRenamed('DEB_CRE_HIST_GBP', 'AMOUNT_HIST_GBP')

ranked = ranked.withColumnRenamed('LOC_CURRCY', 'CURRENCY_CODE')
ranked = ranked.withColumnRenamed('FISCPER3', 'FISCMONTH')
ranked = ranked.withColumnRenamed('RD_BUDID', 'BUDID_CODE')
ranked = ranked.withColumnRenamed('Postxt', 'ITEM_TEXT')
ranked = ranked.withColumnRenamed('oi_ebeln', 'PURCHASE_DOCUMENT_NUMBER')
ranked = ranked.withColumnRenamed('DOC_DATE', 'DOCUMENT_DATE')
ranked = ranked.withColumnRenamed('PSTNG_DATE', 'POSTING_DATE')


# ranked = ranked.withColumn('AMOUNT_LOC', ranked.AMOUNT_LOC.cast(DecimalType(31, 2)))

# COMMAND ----------

# write ranked to curated temp folder
ranked.write\
          .option("sep", "|")\
          .option("header", "true")\
          .option("quote",  '"')\
          .option("escape", '"')\
          .option("nullValue", "null")\
          .option("quoteAll", "true")\
          .mode('overwrite')\
        .csv(csv_temp_curated)
# copy part-* csv file to curated and rename
# dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + deltaFileYear + '/' + deltaFileName, recurse = True)

# remove foundation/curated temp folders
# dbutils.fs.rm(rawPath + runid + deltaFileYear + deltaFileMonth, recurse = True)

# remove delta file from raw
dbutils.fs.rm(rawPath + deltaFileName, recurse = True)