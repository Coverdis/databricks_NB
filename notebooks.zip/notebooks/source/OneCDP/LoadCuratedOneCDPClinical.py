# Databricks notebook source
#File Name: LoadCuratedOneCDPClinical
#ADF Pipeline Name: ETRACK_ADL
#SQLDW Table: NA
#Description:
  # Load OneCDP clinical data from foundation to curated layer

# COMMAND ----------

# MAGIC %run "/library/configFile"

# COMMAND ----------

dbutils.widgets.text("runid", "dslse2-cwik21-cwl111-o032kdmmm")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
process_time = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

# COMMAND ----------

# Load ET Data
clinical_df = spark.read.format("csv")\
        .option("inferSchema","true")\
        .option("header","true")\
        .option("multiLine","true")\
        .option("delimiter","|")\
        .option("quote", '"')\
        .option("escape",'"')\
        .option("nullValue","null")\
  .load("dbfs:/mnt/foundation/one_cdp/clinical.txt")

clinical_df = clinical_df.toDF(*(col.replace('\r', '') for col in clinical_df.columns))

for col_name in clinical_df.columns:
  clinical_df = clinical_df.withColumn(col_name, F.regexp_replace(col_name, '[\\r\\n]', ''))
  
clinical_df = clinical_df.withColumn('StudyShortDesc', F.regexp_replace(clinical_df['StudyShortDesc'], '&lt;/?p&gt;', ''))
clinical_df = clinical_df.withColumn('StudyLongDesc', F.regexp_replace(clinical_df['StudyLongDesc'], '&lt;/?p&gt;', ''))
clinical_df = clinical_df.withColumn('StudyShortDesc', F.regexp_replace(clinical_df['StudyShortDesc'], '</?.*?>', ''))
clinical_df = clinical_df.withColumn('StudyLongDesc', F.regexp_replace(clinical_df['StudyLongDesc'], '</?.*?>', ''))
clinical_df = clinical_df.withColumn('StudyShortDesc', F.regexp_replace(clinical_df['StudyShortDesc'], '&amp;', '&'))
clinical_df = clinical_df.withColumn('StudyLongDesc', F.regexp_replace(clinical_df['StudyLongDesc'], '&amp;', '&'))
clinical_df = clinical_df.withColumn('StudyShortDesc', F.regexp_replace(clinical_df['StudyShortDesc'], '&nbsp;', ' '))
clinical_df = clinical_df.withColumn('StudyLongDesc', F.regexp_replace(clinical_df['StudyLongDesc'], '&nbsp;', ' '))

# COMMAND ----------

# renaming the fields
clinical_df = clinical_df.withColumnRenamed('StudyID', 'CLINICAL_STUDY_ID')
clinical_df = clinical_df.withColumnRenamed('StudyShortDesc', 'STUDY_DESCRIPTION_SHORT')
clinical_df = clinical_df.withColumnRenamed('StudyLongDesc', 'STUDY_DESCRIPTION_LONG')
clinical_df = clinical_df.withColumnRenamed('StudyPhase', 'STUDY_PHASE')
clinical_df = clinical_df.withColumnRenamed('FunctionDesc', 'FUNCTION')
clinical_df = clinical_df.withColumnRenamed('CurrentStrategy', 'CURRENT_STRATEGY')
clinical_df = clinical_df.withColumnRenamed('BaselineStrategy', 'BASELINE_STRATEGY')

clinical_df = clinical_df.withColumnRenamed('StudyStatus', 'STUDY_STATUS_TYPE_NAME')
clinical_df = clinical_df.withColumnRenamed('StudyType', 'STUDY_TYPE_NAME')
clinical_df = clinical_df.withColumnRenamed('StudyTherapyArea', 'THERAPY_AREA')
clinical_df = clinical_df.withColumnRenamed('InvestigatorSponsoredStudy_Flag', 'INVESTIGATOR_SPONSORED_FLAG')
clinical_df = clinical_df.withColumnRenamed('StudySponsorship', 'SPONSORSHIP')
clinical_df = clinical_df.withColumnRenamed('BusinessArea', 'BUSINESS_AREA_NAME')
clinical_df = clinical_df.withColumnRenamed('FundingSource', 'FUNDING_SOURCE')
clinical_df = clinical_df.withColumnRenamed('StudyDesignation', 'STUDY_DESIGNATION')
clinical_df = clinical_df.withColumnRenamed('EnrolledNumberOfSubjects', 'ENROLLED_SUBJECTS')

# COMMAND ----------

# filter not null study id
clinical_df = clinical_df.filter("CAST(StudyID AS BIGINT) IS NOT NULL")

# COMMAND ----------

clinical_df = clinical_df.select(
  'CLINICAL_STUDY_ID',
  'STUDY_DESCRIPTION_SHORT',
  'STUDY_DESCRIPTION_LONG',
  'STUDY_PHASE',
  'FUNCTION',
  'CURRENT_STRATEGY',
  'BASELINE_STRATEGY',
  'STUDY_STATUS_TYPE_NAME',
  'STUDY_TYPE_NAME',
  'THERAPY_AREA',
  'INVESTIGATOR_SPONSORED_FLAG',
  'SPONSORSHIP',
  'BUSINESS_AREA_NAME',
  'FUNDING_SOURCE',
  'STUDY_DESIGNATION',
  'ENROLLED_SUBJECTS'  
)
# display(clinical_df)

# COMMAND ----------

# write to curated
rawPath = 'dbfs:/mnt/raw/one_cdp/'
unique_run_id = runid + '-LoadCuratedOneCDPClinical/'
csv_temp_curated = rawPath + unique_run_id + '/' + 'curated/'
curatedPath = 'dbfs:/mnt/curated/one_cdp/'

clinical_df.coalesce(1).write\
        .option("sep", "|")\
        .option("header", "true")\
        .option("quote",  '"')\
        .option("escape", '"')\
        .option("nullValue", "null")\
        .option("quoteAll", "true")\
        .mode('overwrite')\
      .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + "clinical.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)