# Databricks notebook source
#File Name:FlattenDRMCCHierarchy
#ADF Pipeline Name: HypDRM_ADL
#ADW Table name: NA
#Description:
  #Flatten CC hierarchy comming from DRM
  #Writes final file in curated layer
  

# COMMAND ----------

# MAGIC %run "/library/configFile"

# COMMAND ----------

dbutils.widgets.text('runid', 'abc111000')
runid = dbutils.widgets.get("runid")

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F

rawPath = 'dbfs:/mnt/raw/hyperion_drm/'
foundationPath = 'dbfs:/mnt/foundation/hyperion_drm/'
curatedPath = 'dbfs:/mnt/curated/hyperion_drm/'

# COMMAND ----------

df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(foundationPath + "drm_organization_dim_exp.txt")

df = df.toDF(*(col.upper().replace('\r', '') for col in df.columns))

# COMMAND ----------

df = df.selectExpr(
  "Suffix as COST_CENTER_CODE", 
  "ParentNode as PARENT_CODE" , 
  "Desc as COST_CENTER_DESCRIPTION", 
  "CostCenterStatus as COST_CENTER_STATUS", 
  "OrgCurrency as CURRENCY_CODE", 
  "OrgCountryCode as COUNTRY_CODE", 
  "CountryDesc as COUNTRY_DESC", 
  "CostType as COST_TYPE", 
  "CostTypeLookup as COST_TYPE_DESC",
  "COSTCENTERMARKETCODE as MARKET_CODE"
)

df = df.withColumn('COST_CENTER_CODE', F.regexp_replace(df.COST_CENTER_CODE,'^\s+|\s+$|\r//g', ''))
df = df.withColumn('PARENT_CODE', F.regexp_replace(df.PARENT_CODE,'^\s+|\s+$|\r//g', ''))
df = df.withColumn('COST_CENTER_DESCRIPTION', F.regexp_replace(df.COST_CENTER_DESCRIPTION,'^\s+|\s+$|\r//g', ''))
df = df.withColumn('COST_CENTER_STATUS', F.regexp_replace(df.COST_CENTER_STATUS,'^\s+|\s+$|\r//g', ''))
df = df.withColumn('CURRENCY_CODE', F.regexp_replace(df.CURRENCY_CODE,'^\s+|\s+$|\r//g', ''))
df = df.withColumn('COUNTRY_CODE', F.regexp_replace(df.COUNTRY_CODE,'^\s+|\s+$|\r//g', ''))
df = df.withColumn('COUNTRY_DESC', F.regexp_replace(df.COUNTRY_DESC,'^\s+|\s+$|\r//g', ''))
df = df.withColumn('COST_TYPE', F.regexp_replace(df.COST_TYPE,'^\s+|\s+$|\r//g', ''))
df = df.withColumn('COST_TYPE_DESC', F.regexp_replace(df.COST_TYPE_DESC,'^\s+|\s+$|\r//g', ''))
df = df.withColumn('MARKET_CODE', F.regexp_replace(df.MARKET_CODE,'^\s+|\s+$|\r//g', ''))

# COMMAND ----------

df.createOrReplaceTempView("CC")

query='''SELECT CC.COST_CENTER_CODE,CC.COST_CENTER_DESCRIPTION,Dept_id as Department_Code,Dept_Description as Department_Description,SubDiv_id as Sub_Division_Code,SubDiv_Description as Sub_Division_Description,Div_id as Division_Code,Div_Description as Division_Description,Dir_id as Directorate_Code,Dir_Description as Directorate_Description,Org_id as Organisation_Code,Org_Description as Organisation_Description,Type as Organisation_Type,\
COST_CENTER_STATUS,CURRENCY_CODE,COUNTRY_CODE, COUNTRY_DESC as Country_Description,COST_TYPE,COST_TYPE_DESC as Cost_Type_Description ,CC.MARKET_CODE

FROM CC, (SELECT CC.COST_CENTER_CODE as Dept_id,CC.COST_CENTER_DESCRIPTION as Dept_Description,SubDiv_id,SubDiv_Description,Div_id,Div_Description,Dir_id,Dir_Description,Org_id,Org_Description,Type ,CC.MARKET_CODE

FROM CC, (SELECT CC.COST_CENTER_CODE as SubDiv_id,CC.COST_CENTER_DESCRIPTION as SubDiv_Description,Div_id,Div_Description,Dir_id,Dir_Description,Org_id,Org_Description,Type ,CC.MARKET_CODE

FROM CC, (SELECT CC.COST_CENTER_CODE as Div_id,CC.COST_CENTER_DESCRIPTION as Div_Description,Dir_id,Dir_Description,Org_id,Org_Description,Type ,CC.MARKET_CODE

FROM CC, (SELECT CC.COST_CENTER_CODE as Dir_id,CC.COST_CENTER_DESCRIPTION as Dir_Description,Org_id,Org_Description,Type ,CC.MARKET_CODE

FROM CC, (SELECT COST_CENTER_CODE as Org_id,COST_CENTER_DESCRIPTION as Org_Description,PARENT_CODE as Type ,CC.MARKET_CODE

FROM CC where PARENT_CODE='GSK Total')level1 WHERE CC.PARENT_CODE=Org_id) level2 WHERE CC.PARENT_CODE=Dir_id) level3 WHERE CC.PARENT_CODE=Div_id) level4  WHERE CC.PARENT_CODE=SubDiv_id) level5 WHERE CC.PARENT_CODE=Dept_id'''
ccDF = sqlContext.sql(query)

# COMMAND ----------

# read ENTITY_TO_FDR

df2 = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(foundationPath + "entity_to_fdr.txt")

df2 = df2.toDF(*(col.upper().replace('\r', '') for col in df2.columns))

#rename fields
df2 = df2.withColumnRenamed('ORGLEXPORTNAMEF', 'COST_CENTER_CODE')
df2 = df2.withColumnRenamed('ORGLEXPORTRBSF', 'RBS_CODE')

df2 = df2.withColumn('COST_CENTER_CODE', F.regexp_replace(df2.COST_CENTER_CODE, 'CC.', ''))
df2 = df2.withColumn('RBS_CODE', F.regexp_replace(df2.RBS_CODE, 'RBS.', ''))

# COMMAND ----------

# join cost_center and entity_to_fdr

final_df = ccDF.join(df2, ['COST_CENTER_CODE'], 'left')
# display(final_df)

# COMMAND ----------

final_df=final_df.groupBy(final_df.columns).count().where("count =1").select(final_df.columns)

# COMMAND ----------

# write flatten hierarchy to Azure foundation data lake gen 2 in curated layer

unique_run_id = runid + '-FlattenDRMCCHierarchy/'
csv_temp_curated = rawPath + unique_run_id + 'curated/'

final_df.coalesce(1).write\
    .option("sep", "|")\
    .option("header", "true")\
    .option("quote",  '"')\
    .option("escape", '"')\
    .option("nullValue", "null")\
    .option("quoteAll", "true")\
    .mode('overwrite')\
  .csv(csv_temp_curated)

  # copy part-* csv file to curated and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + 'cost_center_hierarchy.txt', recurse = True) 

  # remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)

# COMMAND ----------

