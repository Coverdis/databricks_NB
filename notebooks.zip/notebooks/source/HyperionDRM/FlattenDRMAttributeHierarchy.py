# Databricks notebook source
#File Name:FlattenDRMAttributeHierarchy
#ADF Pipeline Name: HypDRM_ADL
#Description:
  #Flatten attribute hierarchy file comming from Hyperion DRM
  #Writes flatten attribute hierarchy file in curated layer  

# COMMAND ----------

# MAGIC %run "/library/configFile"

# COMMAND ----------

dbutils.widgets.text("runid", "test-run-d2349-cwd2d-gryr5")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *

import pytz
import re
from datetime import datetime
processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

rawPath = 'dbfs:/mnt/raw/hyperion_drm/attribute'
foundationPath = 'dbfs:/mnt/foundation/hyperion_drm/'
curatedPath = 'dbfs:/mnt/curated/hyperion_drm/'

df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(foundationPath + "attributedims_to_fdr.txt")

df = df.toDF(*(c.replace('\r', '') for c in df.columns))

# COMMAND ----------

df.createOrReplaceTempView("ATTRIBUTE_HIERARCHY")

query="SELECT ah.CODE as level_0_code,ah.DESCRIPTION as level_0_description,level_1_code,level_1_description,level_2_code,level_2_description,level_3_code,level_3_description,level_4_code,level_4_description,level_5_code,level_5_description,level1.CODE_TYPE FROM \
(SELECT ah.CODE as level_1_code,ah.DESCRIPTION as level_1_description,level_2_code,level_2_description,level_3_code,level_3_description,level_4_code,level_4_description,level_5_code,level_5_description,level2.CODE_TYPE FROM \
(SELECT ah.CODE as level_2_code,ah.DESCRIPTION as level_2_description,level_3_code,level_3_description,level_4_code,level_4_description,level_5_code,level_5_description,level3.CODE_TYPE FROM \
(SELECT ah.CODE as level_3_code,ah.DESCRIPTION as level_3_description,level_4_code,level_4_description,level_5_code,level_5_description,level4.CODE_TYPE FROM \
(SELECT ah.CODE as level_4_code,ah.DESCRIPTION as level_4_description,level_5_code, level_5_description,level5.CODE_TYPE FROM \
(SELECT CODE as level_5_code,DESCRIPTION as level_5_description,CODE_TYPE  from ATTRIBUTE_HIERARCHY where parent in (SELECT distinct CODE_TYPE from ATTRIBUTE_HIERARCHY)) level5 \
left outer join ATTRIBUTE_HIERARCHY ah on (ah.PARENT=level5.level_5_code)) level4 \
left outer join ATTRIBUTE_HIERARCHY ah on (ah.PARENT=level4.level_4_code)) level3 \
left outer join ATTRIBUTE_HIERARCHY ah on (ah.PARENT=level3.level_3_code)) level2 \
left outer join ATTRIBUTE_HIERARCHY ah on (ah.PARENT=level2.level_2_code)) level1 \
left outer join ATTRIBUTE_HIERARCHY ah on (ah.PARENT=level1.level_1_code)"

attributeDF = sqlContext.sql(query)
attributeDF = attributeDF.withColumn('SOURCE', lit('DRM').cast(StringType()))

# COMMAND ----------

# write to curated
unique_run_id = runid + '-FlattenDRMAttributeHierarchy/'
csv_temp_curated = rawPath + unique_run_id + 'curated/'

attributeDF.coalesce(1).write\
            .option("sep", "|")\
            .option("header", "true")\
            .option("quote",  '"')\
            .option("escape", '"')\
            .option("nullValue", "null")\
            .option("quoteAll", "true")\
            .mode('overwrite')\
          .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + "attribute_hierarchy.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)