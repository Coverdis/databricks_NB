# Databricks notebook source
#File Name:FlattenDRMAccountHierarchy
#ADF Pipeline Name: 
#SQLDW: fin_stg.ACCOUNT_HIERARCHY
#Description:
  #Flatten account hierarchy file comming from Hyperion DRM
  #Writes flatten account hierarchy file in curated layer

# COMMAND ----------

# MAGIC %run "/library/configFile"

# COMMAND ----------

dbutils.widgets.text("runid", "ssad2-we23d-sd782-uhbg2-dfj34")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *

rawPath = 'dbfs:/mnt/raw/hyperion_drm/'
foundationPath = 'dbfs:/mnt/foundation/hyperion_drm/'
curatedPath = 'dbfs:/mnt/curated/hyperion_drm/'

# COMMAND ----------

df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(foundationPath + "account_to_fdr.txt")

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

# COMMAND ----------

df.createOrReplaceTempView("ACCOUNT_HIERARCHY")

query = "SELECT a.ACCTLEXPORTNAMEF as ACCOUNT_CODE, a.DESCR as ACCOUNT_DESCRIPTION, STANDARD_MINOR_ACCOUNT_CODE, STANDARD_MINOR_ACCOUNT_DESCRIPTION, MINOR_ACCOUNT_CODE, MINOR_ACCOUNT_DESCRIPTION, MAJOR_ACCOUNT_CODE, MAJOR_ACCOUNT_DESCRIPTION, TOTAL_ACCOUNT_CODE, TOTAL_ACCOUNT_DESCRIPTION FROM  ACCOUNT_HIERARCHY a, (SELECT a.ACCTLEXPORTNAMEF as STANDARD_MINOR_ACCOUNT_CODE, a.DESCR as STANDARD_MINOR_ACCOUNT_DESCRIPTION, MINOR_ACCOUNT_CODE, MINOR_ACCOUNT_DESCRIPTION, MAJOR_ACCOUNT_CODE, MAJOR_ACCOUNT_DESCRIPTION, TOTAL_ACCOUNT_CODE, TOTAL_ACCOUNT_DESCRIPTION FROM ACCOUNT_HIERARCHY a, (SELECT a.ACCTLEXPORTNAMEF as MINOR_ACCOUNT_CODE, a.DESCR as MINOR_ACCOUNT_DESCRIPTION, MAJOR_ACCOUNT_CODE, MAJOR_ACCOUNT_DESCRIPTION, TOTAL_ACCOUNT_CODE, TOTAL_ACCOUNT_DESCRIPTION FROM ACCOUNT_HIERARCHY a, (SELECT a.ACCTLEXPORTNAMEF as MAJOR_ACCOUNT_CODE, a.DESCR as MAJOR_ACCOUNT_DESCRIPTION, TOTAL_ACCOUNT_CODE, TOTAL_ACCOUNT_DESCRIPTION from ACCOUNT_HIERARCHY a, (SELECT ACCTLEXPORTNAMEF as TOTAL_ACCOUNT_CODE, DESCR as TOTAL_ACCOUNT_DESCRIPTION from ACCOUNT_HIERARCHY a where ACCTLEXPORTNAMEF = 'GSKCOA') lvl0 WHERE a.ACCTLEXPORTPARENTF=lvl0.TOTAL_ACCOUNT_CODE ORDER BY SORTORDER) lvl1 WHERE a.ACCTLEXPORTPARENTF = lvl1.MAJOR_ACCOUNT_CODE ORDER BY SORTORDER) lvl2 WHERE a.ACCTLEXPORTPARENTF=lvl2.MINOR_ACCOUNT_CODE ORDER BY SORTORDER) lvl3 WHERE a.ACCTLEXPORTPARENTF=lvl3.STANDARD_MINOR_ACCOUNT_CODE ORDER BY SORTORDER"

account = sqlContext.sql(query)

account = account.withColumn('ACCOUNT_CODE', F.regexp_replace('ACCOUNT_CODE', 'AC.', '').cast(StringType()))

# COMMAND ----------

unique_run_id = runid + '-FlattenDRMAccountHierarchy/'
csv_temp_curated = rawPath + unique_run_id + 'curated/'

account.coalesce(1).write\
          .option("sep", "|")\
          .option("header", "true")\
          .option("quote",  '"')\
          .option("escape", '"')\
          .option("nullValue", "null")\
          .option("quoteAll", "true")\
          .mode('overwrite')\
        .csv(csv_temp_curated)

# copy part-* csv file to foundation and rename
dbutils.fs.cp(dbutils.fs.ls(csv_temp_curated)[-1][0], curatedPath + "account_hierarchy.txt", recurse = True)

# remove temp folder
dbutils.fs.rm(rawPath + unique_run_id, recurse = True)