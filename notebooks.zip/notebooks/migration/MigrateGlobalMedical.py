# Databricks notebook source
#File Name: MigrateGlobalMedical
#ADF Pipeline Name: NA
#SQLDW Table: irm_stg.RESOURCE_FORECAST_MANUAL_LOAD
#Description:
  #Store GM spreadsheet

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

# MAGIC %run /source/Planisware/PLWConfig

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "lry43-hrow2-vsio1-d3kdm")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

filePath = "dbfs:/mnt/foundation/planisware/global_medical_spreadsheet.csv"

# read legacy planisware data and add source
df = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter",";")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(filePath)

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

# COMMAND ----------

df = df.withColumn('STD_FTES_FORECAST',F.col('FTE').cast(FloatType()))
df = df.withColumn('AMOUNT_GBP',F.col('STD_FTES_FORECAST') * 168)
df = df.withColumn('YEAR',F.col('YEAR').cast(IntegerType()))
df = df.withColumn('MONTH', F.col('MONTH').cast(StringType()))
df = df.withColumn('ACTIVITY_VERSION_TYPE', F.lit(None).cast(StringType()))
df = df.withColumn('ACTIVITY_BASELINE_NAME', F.lit(None).cast(StringType()))
df = df.withColumn('ACTIVITY_BASELINE_TYPE', F.lit(None).cast(StringType()))

df = df.withColumn('ORIGINAL_RATE', F.lit(None).cast(FloatType()))
df = df.withColumn('WBS_TYPE', F.lit(None).cast(StringType()))
df = df.withColumn('PLANNED_SITES', F.lit(None).cast(IntegerType()))
df = df.withColumn('FORECASTED_IN_CSAP', F.lit(None).cast(StringType()))
df = df.withColumn('REFERENCE_OBJECT_NUMBER', F.lit(None).cast(IntegerType()))

df = df.withColumn('RESOURCE_TYPE', F.lit('FTE').cast(StringType()))
df = df.withColumn('COST_TYPE', F.lit('IPE').cast(StringType()))
df = df.withColumn('COUNTRY', F.lit('Not-Defined').cast(StringType()))
df = df.withColumn('SOURCE', F.lit('PLW-NEW').cast(StringType()))
df = df.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
df = df.withColumn('CREATION_DATE', F.lit(processTime).cast(TimestampType()))
df = df.withColumn('CREATED_BY', F.lit('Databricks - MigrateGlobalMedical').cast(StringType()))
df = df.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
df = df.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))

# COMMAND ----------

df = df.select(
'ACTIVITY_OBJECT_NUMBER', 'RBS', 'STD_FTES_FORECAST', 'YEAR', 'MONTH', 'RESOURCE_TYPE', 'ACTIVITY_VERSION_TYPE', 'ACTIVITY_BASELINE_NAME', 'ACTIVITY_BASELINE_TYPE', 'ORIGINAL_RATE','PLAN_OBJECT_NUMBER','WBS_TYPE','AMOUNT_GBP','COST_TYPE','COUNTRY','PLANNED_SITES', 'FORECASTED_IN_CSAP','REFERENCE_OBJECT_NUMBER', 'SOURCE', 'RUN_ID', 'CREATION_DATE', 'CREATED_BY', 'UPDATION_DATE', 'UPDATED_BY'
)

# COMMAND ----------

# write to sql dw
df.write\
  .format("com.databricks.spark.sqldw")\
  .option("url", sqlDwUrl)\
  .option( "forward_spark_azure_storage_credentials", "True")\
  .option("tempdir", tempDir)\
  .option("dbtable", "irm_stg.RESOURCE_FORECAST_MANUAL_LOAD")\
  .option("maxStrLength","4000")\
  .mode("append")\
  .save()

# COMMAND ----------

#delete old data once new data has been inserted successfully
sql="delete from irm_stg.RESOURCE_FORECAST_MANUAL_LOAD where CREATION_DATE != '"+ processTime +"' and reference_object_number is null"
dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})