# Databricks notebook source
#File Name:LoadPerson
#ADF Pipeline Name: IRM_ADL_DW-PLWPlan-PLWActivity
#SQLDW Table:irm_stg.PERSON
#Description:
  #Delta is being inserted in SQL DW to maintain history in person staging table.

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

dbutils.widgets.text("runid", "ashg1-s28s2-dwjw2-2ewhd")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
import pytz
from datetime import datetime

unified_path = 'dbfs:/mnt/unified/person/'
process_time = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')
file_name = 'person.txt'

# COMMAND ----------

# read person data
person = spark.read.format("csv")\
      .option("inferSchema","false")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load(unified_path + file_name)

person = person.toDF(*(col.replace('\r', '') for col in person.columns))
print(person.count())

# COMMAND ----------

#adding Manager Name, MUD ID against Supervisory Org. Manager ID

#dummy person dfs
df1 = person
df2 = person


#function to self-join person(df1) with person(df2) to add Manager Name and Mud id in the df
def joinxr(df1, df2, field1, field2, field3):
  df1.createOrReplaceTempView('df1')
  df2.createOrReplaceTempView('df2')
  
  #query to add Manager Name
  query = "Select p1.*, concat(p2.FIRST_NAME,' ',p2.LAST_NAME) as " + str(field2) + " FROM df1 as p1\
  left outer join\
  (Select distinct EMP_ID, FIRST_NAME,LAST_NAME from df2) as p2\
  on (p1." + str(field1) + " = p2.EMP_ID)" 
  
  tempdf = sqlContext.sql(query)
  tempdf.createOrReplaceTempView('df1')
  
  #query to add MUD ID
  query2 = "Select p1.*, p2.PERSON_MUD_ID as " + str(field3) + " FROM df1 as p1\
  left outer join\
  (Select distinct EMP_ID, PERSON_MUD_ID from df2) as p2\
  on (p1." + str(field1) + " = p2.EMP_ID)"
  
  return sqlContext.sql(query2)
  
#loop to add Manager Name, Manager MUD ID against every VET(1-10)
for i in range(1, 11):
  field1 = "SUPERVISORY_ORG_MANAGER_ID_VET" + str(i)
  field2 = "MANAGER_NAME_VET" + str(i)  
  field3 = "MANAGER_MUD_ID_VET" + str(i)
  
  if i == 1: #pass the original copies of dummy person dfs for joining
    person_modified = joinxr(df1, df2, field1, field2, field3)
    
  if i > 1:  #pass the modified version of person df from previous iteration(s) for joining
    person_modified = joinxr(person_modified, df2, field1, field2, field3)

person_modified = person_modified.drop_duplicates(['EMP_ID'])
print(person_modified.count())

# COMMAND ----------

# selecting Regular workers
regemp = person_modified.filter('CONTRACT_TYPE_CODE = "R"')

# selecting Complementary workers with VET Hierarchy
cwemp = person_modified.filter('CONTRACT_TYPE_CODE in ("C","Z8") and SUPERVISORY_ORG_CODE is not NULL and MANAGER_MUD_ID is not NULL')

# selecting Complementary workers with no VET Hierarchy
cwemp_nv = person_modified.filter('CONTRACT_TYPE_CODE = "C" and SUPERVISORY_ORG_CODE is NULL and MANAGER_MUD_ID is not NULL')

# COMMAND ----------

# selecting VET Hierarchy columns for Regular workers
vetcols = ['SUPERVISORY_ORG_CODE','SUPERVISORY_ORG_CODE_VET1','SUPERVISORY_ORG_CODE_VET2','SUPERVISORY_ORG_CODE_VET3','SUPERVISORY_ORG_CODE_VET4','SUPERVISORY_ORG_CODE_VET5','SUPERVISORY_ORG_CODE_VET6','SUPERVISORY_ORG_CODE_VET7','SUPERVISORY_ORG_CODE_VET8','SUPERVISORY_ORG_CODE_VET9','SUPERVISORY_ORG_CODE_VET10','SUPERVISORY_ORG_DESC','SUPERVISORY_ORG_DESC_VET1','SUPERVISORY_ORG_DESC_VET2','SUPERVISORY_ORG_DESC_VET3','SUPERVISORY_ORG_DESC_VET4','SUPERVISORY_ORG_DESC_VET5','SUPERVISORY_ORG_DESC_VET6','SUPERVISORY_ORG_DESC_VET7','SUPERVISORY_ORG_DESC_VET8','SUPERVISORY_ORG_DESC_VET9','SUPERVISORY_ORG_DESC_VET10','SUPERVISORY_ORG_LEVEL','SUPERVISORY_ORG_MANAGER_ID_VET1','SUPERVISORY_ORG_MANAGER_ID_VET2','SUPERVISORY_ORG_MANAGER_ID_VET3','SUPERVISORY_ORG_MANAGER_ID_VET4','SUPERVISORY_ORG_MANAGER_ID_VET5','SUPERVISORY_ORG_MANAGER_ID_VET6','SUPERVISORY_ORG_MANAGER_ID_VET7','SUPERVISORY_ORG_MANAGER_ID_VET8','SUPERVISORY_ORG_MANAGER_ID_VET9','SUPERVISORY_ORG_MANAGER_ID_VET10','MANAGER_NAME_VET1','MANAGER_MUD_ID_VET1','MANAGER_NAME_VET2','MANAGER_MUD_ID_VET2','MANAGER_NAME_VET3','MANAGER_MUD_ID_VET3','MANAGER_NAME_VET4','MANAGER_MUD_ID_VET4','MANAGER_NAME_VET5','MANAGER_MUD_ID_VET5','MANAGER_NAME_VET6','MANAGER_MUD_ID_VET6','MANAGER_NAME_VET7','MANAGER_MUD_ID_VET7','MANAGER_NAME_VET8','MANAGER_MUD_ID_VET8','MANAGER_NAME_VET9','MANAGER_MUD_ID_VET9','MANAGER_NAME_VET10','MANAGER_MUD_ID_VET10']

regemp_t = regemp.select('PERSON_MUD_ID', *vetcols)
regemp_t = regemp_t.withColumnRenamed('PERSON_MUD_ID','MANAGER_MUD_ID_temp')

# droppping VET Hierarchy columns for Complementary workers
cwemp_nv = cwemp_nv.drop(*vetcols)

# COMMAND ----------

# adding Manager's VET Hierarchy to Complementary workers
cwemp_nv = cwemp_nv.join(regemp_t, cwemp_nv.MANAGER_MUD_ID == regemp_t.MANAGER_MUD_ID_temp, 'inner')

# COMMAND ----------

cwemp_nv = cwemp_nv.drop('MANAGER_MUD_ID_temp')

# COMMAND ----------

cols = ['PERSON_MUD_ID', 'SUPERVISORY_ORG_DESC_VET7', 'SUPERVISORY_ORG_MANAGER_ID_VET2', 'COMPANY_CODE', 'SERVICE_DATE', 'MANAGER_MUD_ID_VET6', 'SOURCE_SYS_ID', 'COST_CENTRE_NAME', 'EMAIL_ID', 'MANAGER_MUD_ID_VET2', 'INITIALS', 'COUNTRY', 'SUPERVISORY_ORG_DESC_VET9', 'COST_CENTRE_CODE', 'GSK_RESOURCE_TYPE', 'LEGAL_NAME_SUFFIX', 'SUPERVISORY_ORG_MANAGER_ID_VET10', 'JOB_PROFILE_JOB_TITLE', 'SUPERVISORY_ORG_DESC', 'CONTRACT_END_DATE', 'MANAGER_MUD_ID_VET5', 'PREFERRED_FULL_NAME', 'MANAGER_NAME_VET1', 'SUPERVISORY_ORG_DESC_VET8', 'SUPERVISORY_ORG_LEVEL', 'MANAGER_MUD_ID_VET9', 'MANAGER_EMP_ID', 'ORIGINAL_HIRE_DATE', 'SUPERVISORY_ORG_DESC_VET2', 'SUPERVISORY_ORG_MANAGER_ID_VET1', 'MANAGER_NAME_VET3', 'SUPERVISORY_ORG_MANAGER_ID_VET9', 'MANAGER_NAME_VET5', 'FIRST_NAME', 'GSK_PREFERRED_NAME', 'MANAGER_NAME_VET7', 'POS_TITLE', 'MANAGER_MUD_ID_VET7', 'SUPERVISORY_ORG_CODE_VET1', 'PERSON_KEY', 'EMP_ID', 'JOB_PROFILE_ID', 'SUPERVISORY_ORG_MANAGER_ID_VET7', 'MANAGEMENT_LEVEL_DESC', 'PREFERRED_MIDDLE_NAME', 'MANAGER_POS_NO', 'SUPERVISORY_ORG_MANAGER_ID_VET3', 'SUPERVISORY_ORG_MANAGER_ID_VET8', 'SUPERVISORY_ORG_CODE_VET9', 'SUPERVISORY_ORG_CODE_VET4', 'SUPERVISORY_ORG_DESC_VET6', 'SUPERVISORY_ORG_MANAGER_ID_VET4', 'EXPECTED_END_DATE', 'DISPLAY_NAME', 'GSK_GLOBAL_BUSINESS_CATEGORY', 'EMPLOYING_COMPANY', 'SUPERVISORY_ORG_CODE_VET7', 'LOCATION', 'LAST_NAME', 'POS_NUM', 'FTE', 'MANAGER_MUD_ID_VET10', 'MANAGER_MUD_ID', 'SUPERVISORY_ORG_DESC_VET5', 'DIVISION', 'EMPLOYEMENT_STATUS', 'CURRENT_HIRE_DATE', 'HOURS_WORKED', 'BUILDING_NAME', 'SUPERVISORY_ORG_CODE', 'SUPERVISORY_ORG_MANAGER_ID_VET5', 'SUPERVISORY_ORG_CODE_VET10', 'CW_SUPPLIER_NAME', 'MANAGER_NAME_VET2', 'SUPERVISORY_ORG_DESC_VET10', 'CONTRACT_TYPE_CODE', 'SUPERVISORY_ORG_CODE_VET3', 'MANAGER_MUD_ID_VET4', 'SUPERVISORY_ORG_CODE_VET8', 'WORKER_STATUS', 'SUPERVISORY_ORG_DESC_VET1', 'TELEPHONE_NUMBER', 'LAST_WORKED_DATE', 'BUSINESS_TITLE', 'MANAGEMENT_LEVEL_CODE', 'MANAGER_NAME_VET8', 'NUMERIC_GLOBAL_ID', 'MANAGER_NAME', 'LEGAL_MIDDLE_NAME', 'MANAGER_MUD_ID_VET8', 'SUPERVISORY_ORG_DESC_VET3', 'MANAGER_NAME_VET4', 'MANAGER_MUD_ID_VET3', 'WORKER_TYPE_DESC', 'MANAGER_NAME_VET6', 'PERSONAL_TITLE', 'GSK_SITE_CODE', 'GSK_DEPARTMENT_NAME', 'SUPERVISORY_ORG_CODE_VET2', 'MANAGER_MUD_ID_VET1', 'GSK_MAIL_STOP', 'STANDARD_WORKING_HOURS', 'SUPERVISORY_ORG_MANAGER_ID_VET6', 'SUPERVISORY_ORG_CODE_VET5', 'SUPERVISORY_ORG_DESC_VET4', 'LEGACY_EMP_ID', 'TERMINATION_DATE', 'MANAGER_NAME_VET10', 'WORKER_TYPE_CODE', 'MANAGER_NAME_VET9', 'MANAGER_USER_ID', 'SUPERVISORY_ORG_CODE_VET6', 'BUSINESS_CATEGORY', 'MANAGED_ORG_CODE', 'MANAGED_ORGANIZATION', 'PREFERRED_LAST_NAME', 'DEPARTMENT_NUMBER']

cwemp_nv = cwemp_nv.select(cols)
cwemp = cwemp.select(cols)
regemp = regemp.select(cols)

# COMMAND ----------

# merging to get complete dataset
un1 = cwemp_nv.union(cwemp)
person_modified = un1.union(regemp)

# COMMAND ----------

person_modified = person_modified.withColumn('CONTRACT_END_DATE', F.lit(person_modified.CONTRACT_END_DATE).cast(TimestampType()))
person_modified = person_modified.withColumn('CURRENT_HIRE_DATE', F.lit(person_modified.CURRENT_HIRE_DATE).cast(TimestampType()))
person_modified = person_modified.withColumn('EXPECTED_END_DATE', F.lit(person_modified.EXPECTED_END_DATE).cast(TimestampType()))
person_modified = person_modified.withColumn('LAST_WORKED_DATE', F.lit(person_modified.LAST_WORKED_DATE).cast(TimestampType()))
person_modified = person_modified.withColumn('ORIGINAL_HIRE_DATE', F.lit(person_modified.ORIGINAL_HIRE_DATE).cast(TimestampType()))
person_modified = person_modified.withColumn('SERVICE_DATE', F.lit(person_modified.SERVICE_DATE).cast(TimestampType()))
person_modified = person_modified.withColumn('TERMINATION_DATE', F.lit(person_modified.TERMINATION_DATE).cast(TimestampType()))
person_modified = person_modified.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
person_modified = person_modified.withColumn('CREATION_DATE', F.lit(process_time).cast(TimestampType()))
person_modified = person_modified.withColumn('CREATED_BY', F.lit('Databricks - LoadPerson').cast(StringType()))
person_modified = person_modified.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
person_modified = person_modified.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))

# COMMAND ----------

person_df = person_modified.select('PERSON_KEY', 'PERSON_MUD_ID', 'FIRST_NAME', 'LAST_NAME', 'EMAIL_ID', 'INITIALS', 'BUSINESS_CATEGORY', 'TELEPHONE_NUMBER', 'COUNTRY', 'DIVISION', 'BUSINESS_TITLE', 'MANAGER_USER_ID', 'PERSONAL_TITLE', 'EMPLOYING_COMPANY', 'LOCATION', 'DEPARTMENT_NUMBER', 'GSK_PREFERRED_NAME', 'GSK_DEPARTMENT_NAME', 'DISPLAY_NAME', 'BUILDING_NAME', 'GSK_SITE_CODE', 'GSK_MAIL_STOP', 'GSK_RESOURCE_TYPE', 'GSK_GLOBAL_BUSINESS_CATEGORY', 'COMPANY_CODE', 'CONTRACT_END_DATE', 'CONTRACT_TYPE_CODE', 'COST_CENTRE_CODE', 'COST_CENTRE_NAME', 'CURRENT_HIRE_DATE', 'MANAGER_NAME', 'MANAGER_MUD_ID', 'NUMERIC_GLOBAL_ID', 'EMP_ID', 'EMPLOYEMENT_STATUS', 'EXPECTED_END_DATE', 'FTE', 'HOURS_WORKED', 'STANDARD_WORKING_HOURS', 'JOB_PROFILE_ID', 'JOB_PROFILE_JOB_TITLE', 'LAST_WORKED_DATE', 'LEGACY_EMP_ID', 'LEGAL_MIDDLE_NAME', 'LEGAL_NAME_SUFFIX', 'MANAGEMENT_LEVEL_DESC', 'MANAGEMENT_LEVEL_CODE', 'ORIGINAL_HIRE_DATE', 'POS_NUM', 'POS_TITLE', 'PREFERRED_FULL_NAME', 'PREFERRED_MIDDLE_NAME', 'PREFERRED_LAST_NAME', 'MANAGER_EMP_ID', 'MANAGER_POS_NO', 'SERVICE_DATE', 'SUPERVISORY_ORG_CODE', 'SUPERVISORY_ORG_CODE_VET1', 'SUPERVISORY_ORG_CODE_VET2', 'SUPERVISORY_ORG_CODE_VET3', 'SUPERVISORY_ORG_CODE_VET4', 'SUPERVISORY_ORG_CODE_VET5', 'SUPERVISORY_ORG_CODE_VET6', 'SUPERVISORY_ORG_CODE_VET7', 'SUPERVISORY_ORG_CODE_VET8', 'SUPERVISORY_ORG_CODE_VET9', 'SUPERVISORY_ORG_CODE_VET10', 'SUPERVISORY_ORG_DESC', 'SUPERVISORY_ORG_DESC_VET1', 'SUPERVISORY_ORG_DESC_VET2', 'SUPERVISORY_ORG_DESC_VET3', 'SUPERVISORY_ORG_DESC_VET4', 'SUPERVISORY_ORG_DESC_VET5', 'SUPERVISORY_ORG_DESC_VET6', 'SUPERVISORY_ORG_DESC_VET7', 'SUPERVISORY_ORG_DESC_VET8', 'SUPERVISORY_ORG_DESC_VET9', 'SUPERVISORY_ORG_DESC_VET10', 'SUPERVISORY_ORG_LEVEL', 'SUPERVISORY_ORG_MANAGER_ID_VET1', 'MANAGER_MUD_ID_VET1', 'MANAGER_NAME_VET1', 'SUPERVISORY_ORG_MANAGER_ID_VET2', 'MANAGER_MUD_ID_VET2', 'MANAGER_NAME_VET2', 'SUPERVISORY_ORG_MANAGER_ID_VET3', 'MANAGER_MUD_ID_VET3', 'MANAGER_NAME_VET3', 'SUPERVISORY_ORG_MANAGER_ID_VET4', 'MANAGER_MUD_ID_VET4', 'MANAGER_NAME_VET4', 'SUPERVISORY_ORG_MANAGER_ID_VET5', 'MANAGER_MUD_ID_VET5', 'MANAGER_NAME_VET5', 'SUPERVISORY_ORG_MANAGER_ID_VET6', 'MANAGER_MUD_ID_VET6', 'MANAGER_NAME_VET6', 'SUPERVISORY_ORG_MANAGER_ID_VET7', 'MANAGER_MUD_ID_VET7', 'MANAGER_NAME_VET7', 'SUPERVISORY_ORG_MANAGER_ID_VET8', 'MANAGER_MUD_ID_VET8', 'MANAGER_NAME_VET8', 'SUPERVISORY_ORG_MANAGER_ID_VET9', 'MANAGER_MUD_ID_VET9', 'MANAGER_NAME_VET9', 'SUPERVISORY_ORG_MANAGER_ID_VET10', 'MANAGER_MUD_ID_VET10', 'MANAGER_NAME_VET10', 'SOURCE_SYS_ID','TERMINATION_DATE','WORKER_STATUS','WORKER_TYPE_CODE','WORKER_TYPE_DESC', 'CW_SUPPLIER_NAME', 'RUN_ID', 'CREATION_DATE', 'CREATED_BY', 'UPDATION_DATE', 'UPDATED_BY'
)

# COMMAND ----------

# write dataframe to DW using polybase
person_df.write\
      .format("com.databricks.spark.sqldw")\
      .option("url", sqlDwUrl)\
      .option( "forward_spark_azure_storage_credentials", "True")\
      .option("tempdir", tempDir)\
      .option("dbtable", "irm_stg.PERSON")\
      .option("maxStrLength","4000")\
      .mode("append")\
      .save()

# COMMAND ----------

sql="delete from irm_stg.PERSON where CREATION_DATE != '"+ process_time +"'"
dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})