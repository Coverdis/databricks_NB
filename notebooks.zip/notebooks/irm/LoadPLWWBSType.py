# Databricks notebook source
#File Name: LoadPLWWBSType
#ADF Pipeline Name: IRM_ADL_DW-PLWPlan-PLWActivity
#SQLDW Table: irm_stg.PLW_WBS_TYPE
#Description:
  #Read Planisware WBS_TYPE data from unified layer in ADL and load to staging table in SQL DW

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "sdijo32-bvdfo-vdfpiu-bvdkl3")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

# read new planisware data
df = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load('dbfs:/mnt/unified/project_management/wbs_type.txt')

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ' '))

# COMMAND ----------

df = df.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
df = df.withColumn('CREATION_DATE', F.lit(processTime).cast(TimestampType()))
df = df.withColumn('CREATED_BY', F.lit('Databricks - LoadPLWWBSType').cast(StringType()))
df = df.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
df = df.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))

# COMMAND ----------

df = df.select(
'WBS_TYPE', 'PRIMARY_SOURCE_PLAN_TYPE_NAME', 'SECONDARY_SOURCE_PLAN_TYPE_NAME', 'MDP_SYNCHRONISE_FLAG', 'PSAP_SYNCHRONISE_FLAG', 'CSAP_SYNCHRONISE_FLAG', 'STUDY_ID_USAGE_FLAG', 'ACTIVITY_PHASE_USAGE_FLAG', 'RUN_ID', 'CREATION_DATE', 'CREATED_BY', 'UPDATION_DATE', 'UPDATED_BY'
)

# COMMAND ----------

# write to sql dw
df.write\
  .format("com.databricks.spark.sqldw")\
  .option("url", sqlDwUrl)\
  .option( "forward_spark_azure_storage_credentials", "True")\
  .option("tempdir", tempDir)\
  .option("dbtable", "irm_stg.PLW_WBS_TYPE")\
  .option("maxStrLength","4000")\
  .mode("append")\
  .save()

# COMMAND ----------

#delete old data once new data has been inserted successfully
sql="delete from irm_stg.PLW_WBS_TYPE where CREATION_DATE != '"+ processTime +"'"
dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})