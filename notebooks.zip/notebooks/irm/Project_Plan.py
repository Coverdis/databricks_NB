# Databricks notebook source
# MAGIC %run "./configFile"

# COMMAND ----------

from pyspark.sql.types import *
import pytz
import re
from datetime import datetime
processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')


custom_schema = StructType([
	StructField("IS_ACTIVE", StringType(), True),
	StructField("PROGRAM", StringType(), True),
	StructField("COMMENTS", StringType(), True),
	StructField("MODIFICATION_DATE", TimestampType(), True),
	StructField("PLAN_TYPE", StringType(), True),
	StructField("NOTEPAD", StringType(), True),
	StructField("CURRENT_PHASE", StringType(), True),
	StructField("VERSION", StringType(), True),
	StructField("THERAPEUTIC_AREA", StringType(), True),
	StructField("PROJECT_GROUP", StringType(), True),
	StructField("DISEASE", StringType(), True),
	StructField("INDICATION", StringType(), True),
	StructField("CREATION_DATE", TimestampType(), True),
	StructField("DESCRIPTION", StringType(), True),
	StructField("END_DATE", StringType(), True),
	StructField("IPLS_COPIED_FOR_VERSION", StringType(), True),
	StructField("CURRENT_LINK_REQUEST_WORKFLOW", StringType(), True),
	StructField("SYNCHRO_PROJECT", StringType(), True),
	StructField("LAST_RESTORED_ON", StringType(), True),
	StructField("CSAP_BRAND_NAME", StringType(), True),
	StructField("PORTFOLIO_MANAGER", StringType(), True),
	StructField("ETRACK_STUDY_NUMBER", StringType(), True),
	StructField("TEMPORARY_STUDY", StringType(), True),
	StructField("HAS_SYNCHRO_LINKS", StringType(), True),
	StructField("IPL_PLAN_FILTER", StringType(), True),
	StructField("NON_TRADITIONAL_STUDY_PLAN", StringType(), True),
	StructField("PROJECT_VISIBLE_INTRANET_SITE", StringType(), True),
	StructField("DURATION", StringType(), True),
	StructField("FINISH_DATE", StringType(), True),
	StructField("NUMBER_OF_TASKS", StringType(), True),
	StructField("NUMBER_OF_VERSIONS", StringType(), True),
	StructField("DISEASE_DESC", StringType(), True),
	StructField("FULL_NAME", StringType(), True),
	StructField("INDICATION_DESC", StringType(), True),
	StructField("LAST_RESTORED_FROM", StringType(), True),
	StructField("MANAGING_ORG", StringType(), True),
	StructField("COMPOUNDS", StringType(), True),
	StructField("STUDY_NUMBERS", StringType(), True),
	StructField("PLAN_TYPE_DESCRIPTION", StringType(), True),
	StructField("PORTFOLIO_OWNER", StringType(), True),
	StructField("PROJECT_GROUPS_FULL_NAME", StringType(), True),
	StructField("PROJECT_PLAN_STATUS_DESC", StringType(), True),
	StructField("PROGRAM_DESC", StringType(), True),
	StructField("VERSION_COMPARE_INFO", StringType(), True),
	StructField("THERAPEUTIC_AREA_DESC", StringType(), True),
	StructField("PLAN_STATE", StringType(), True),
	StructField("VERSION_TYPE", StringType(), True),
	StructField("PROJECT_PLAN_STATUS", StringType(), True),
	StructField("STATUS_OF_THRESHOLDS", StringType(), True),
	StructField("INTERNAL_NUMBER", LongType(), False),
	StructField("NAME", StringType(), True),
	StructField("ORIGIN_DATE", StringType(), True),
	StructField("OWNER", StringType(), True),
	StructField("PROJECT_CALENDAR", StringType(), True),
	StructField("PLAN_TEAM", StringType(), True),
	StructField("STATE", StringType(), True),
	StructField("PROJECT_TEMPLATE", StringType(), True),
	StructField("TIME_NOW", StringType(), True),
	StructField("VERSION_DOCUMENTATION", StringType(), True),
	StructField("LAST_ACTUAL_HOURS_UPDATE_DATE", StringType(), True),
	StructField("OWNER_DESCRIPTION", StringType(), True),
	StructField("ORIGIN_PROJECT", StringType(), True),
	StructField("BASELINE_VERSION", StringType(), True)
])

df = spark.read.format("csv")\
          .option("badRecordsPath", "dbfs:/mnt/plan/opx2/bad_records/plan_info/{0}/load_time_check/".format(re.sub('\W+', '', processTime)))\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load("dbfs:/mnt/foundation/planisware/plw_plan_info.txt", schema = custom_schema)

# COMMAND ----------

# perform structure check for bad records
badRecords = df.filter("\
               (length(IS_ACTIVE) > 1) or \
               (length(PLAN_TYPE) > 255) or \
               (length(VERSION) > 255) or \
               (length(PROJECT_GROUP) > 255) or \
               (length(DESCRIPTION) > 255) or \
               (length(PLAN_STATE) > 80) or \
               (length(PROJECT_PLAN_STATUS) > 255) or \
               INTERNAL_NUMBER is NULL or \
               (length(NAME) > 80) or \
               (length(STATE) > 22) or \
               (length(OWNER_DESCRIPTION) > 255) \
")

if badRecords.count() > 0:
  badFilePath = "dbfs:/mnt/plan/opx2/bad_records/plan_info/" + re.sub('\W+', '', processTime) + "/structure_check/"
  badRecords.write.csv(badFilePath)

# COMMAND ----------

# check if load_time and structure_check bad records exists; if yes then raise error else continue
path = "dbfs:/mnt/plan/opx2/bad_records/plan_info/{0}/load_time_check/".format(processTime)
folderList = ''
badFiles = ''
loadTimeBadRecords = False
try:
  dbutils.fs.ls(path)
  folderList = dbutils.fs.ls(path)[0][1]
  badFiles = [item[0] for item in dbutils.fs.ls(path + folderList + 'bad_records')]
  for file in badFiles:
    tdf = spark.read.format("json").load(file)
    if tdf.count() > 0:
      loadTimeBadRecords = True
      break
except Exception:
  pass

if badRecords.count() > 0 or loadTimeBadRecords:
  raise ValueError('Data file has bad records.')

# COMMAND ----------

df.createOrReplaceTempView("PLANS")

query = "SELECT INTERNAL_NUMBER as PLANISWARE_INTERNAL_ID, NAME as PLAN_NAME, DESCRIPTION as PLAN_DESCRIPTION, CREATION_DATE as PLAN_CREATION_DATE, STATE as PLANISWARE_PLAN_STATE, PLAN_STATE as GSK_PLAN_STATE, PROJECT_GROUP as PROJECT_GROUP, PROJECT_PLAN_STATUS as PLAN_STATUS, PLAN_TYPE , MODIFICATION_DATE as PLAN_MODIFICATION, IS_ACTIVE as PLANISWARE_ACTIVE_FLAG, VERSION as PLAN_VERSION_NUMBER, to_timestamp('{0}') as CREATION_DATE, 'DataBricks - Project_Plan' as CREATED_BY, CAST(null as timestamp) as UPDATION_DATE, CAST(null as string) as UPDATED_BY, OWNER_DESCRIPTION as OWNER_DESCRIPTION FROM PLANS".format(processTime)

df2 = sqlContext.sql(query)

# COMMAND ----------

# write dataframe to DW using polybase
df2.write\
    .format("com.databricks.spark.sqldw")\
    .option("url", sqlDwUrl)\
    .option( "forward_spark_azure_storage_credentials", "True")\
    .option("tempdir", tempDir)\
    .option("dbtable", "pm.PROJECT_PLAN")\
    .mode("append")\
    .save()

# COMMAND ----------

#delete old data once new data has been inserted successfully 
sql="delete from pm.project_plan where CREATION_DATE!='"+ processTime +"'"
dbutils.notebook.run("DataLayer",0,{"query": sql})