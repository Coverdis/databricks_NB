# Databricks notebook source
#File Name:LoadProjectHierarchy
#ADF Pipeline Name: IRM_ADL_DW-PLWPlan-PLWActivity
#ADW Table name: irm_stg.PROJECT_HIERARCHY
#Description:
  #Identify delta between current file in unified and SQL DW
  #Delta is being inserted in SQL DW to maintain history in staging table.

# COMMAND ----------

# MAGIC %run "/library/configFile"

# COMMAND ----------

dbutils.widgets.text('runid', 'ldsfj2-34897-dfkjjhfkdhj-ewr234')
runid = dbutils.widgets.get("runid")

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.window import Window

import pytz
from datetime import datetime
from pyspark.sql import functions as F
process_time = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

unified_path = 'dbfs:/mnt/unified/finance/'

# COMMAND ----------

project_df = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(unified_path + "project_hierarchy.txt")

project_df = project_df.toDF(*(col.replace('\r', '') for col in project_df.columns))

for col_name in project_df.columns:
  project_df = project_df.withColumn(col_name, F.regexp_replace(col_name, '[\\r\\n]', ' '))

#project_df = project_df.drop('Type')

# COMMAND ----------

delta_flag = False
delta_df = None
try:
  pushdown_query = "(SELECT p.STUDY_CODE, STUDY_DESCRIPTION, PROJECT_CODE, PROJECT_DESCRIPTION, REPORTING_GROUP, \
                  REPORTING_GROUP_DESCRIPTION, THERAPY_AREA, THERAPY_AREA_DESCRIPTION, MANAGING_ORGANISATION, \
                  MANAGING_ORGANISATION_DESCRIPTION, ROOT, ROOT_DESCRIPTION, FUNDING_ORGANISATION, PCUDA, CEFLEXCOMM, SOURCE_FLAG \
                  FROM irm_stg.PROJECT_HIERARCHY p, \
                  (SELECT STUDY_CODE, CREATION_DATE, RANK() over \
                  (partition by STUDY_CODE order by CREATION_DATE desc) as RANK_ID FROM irm_stg.PROJECT_HIERARCHY) r \
                  where p.STUDY_CODE=r.STUDY_CODE and p.CREATION_DATE=r.CREATION_DATE and r.RANK_ID=1) ph"

  dw_ph = spark.read.jdbc(url = sqlDwUrl, table = pushdown_query)

  delta_df = project_df.subtract(dw_ph)
  
  if delta_df.count() > 0:
    delta_flag = True
  
  delta_df.createOrReplaceTempView("PROJECT_HIERARCHY")
  
except Exception as e:
  print(e)

# COMMAND ----------

if delta_flag:
  query = "SELECT STUDY_CODE, STUDY_DESCRIPTION, PROJECT_CODE, PROJECT_DESCRIPTION, REPORTING_GROUP, REPORTING_GROUP_DESCRIPTION, THERAPY_AREA, THERAPY_AREA_DESCRIPTION, MANAGING_ORGANISATION, MANAGING_ORGANISATION_DESCRIPTION, ROOT, ROOT_DESCRIPTION, FUNDING_ORGANISATION, PCUDA, CEFLEXCOMM, SOURCE_FLAG, 'DRM' as SOURCE, '{0}' as RUN_ID, to_timestamp('{1}') as CREATION_DATE, 'Databricks - LoadProjectHierarchy' as CREATED_BY, CAST(null as timestamp) as UPDATION_DATE, CAST(null as string) as UPDATED_BY FROM PROJECT_HIERARCHY".format(runid, process_time)

  df = sqlContext.sql(query)

  # write dataframe to DW using polybase
  df.write\
      .format("com.databricks.spark.sqldw")\
      .option("url", sqlDwUrl)\
      .option( "forward_spark_azure_storage_credentials", "True")\
      .option("tempdir", tempDir)\
      .option("dbtable", "irm_stg.PROJECT_HIERARCHY") \
      .mode("append")\
      .save()