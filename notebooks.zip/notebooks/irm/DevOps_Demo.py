# Databricks notebook source
print("Hello world")