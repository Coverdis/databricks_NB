# Databricks notebook source
#File Name: LoadPLWActivityTypeMapping
#ADF Pipeline Name: ADL_DW-IRM-PLWPlan-PLWActivity
#SQLDW Table: irm_stg.PLW_ACTIVITY_TYPE_MAPPING
#Description:
  # Activity Type ID mappings for old PLW environment vs. new PLW environment.

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *

processTime = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "111")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

# read new planisware data 
df = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load('dbfs:/mnt/curated/planisware/MappingTable.txt')

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ' '))

# COMMAND ----------

df = df.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
df = df.withColumn('CREATION_DATE', F.lit(processTime).cast(TimestampType()))
df = df.withColumn('CREATED_BY', F.lit('Databricks - LoadPLWActivityTypeMapping').cast(StringType()))
df = df.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
df = df.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))

# COMMAND ----------

# write to sql dw
df.write\
  .format("com.databricks.spark.sqldw")\
  .option("url", sqlDwUrl)\
  .option( "forward_spark_azure_storage_credentials", "True")\
  .option("tempdir", tempDir)\
  .option("dbtable", "irm_stg.PLW_ACTIVITY_TYPE_MAPPING")\
  .option("maxStrLength","4000")\
  .mode("append")\
  .save()

# COMMAND ----------

#delete old data once new data has been inserted successfully
sql="delete from irm_stg.PLW_ACTIVITY_TYPE_MAPPING where CREATION_DATE != '"+ processTime +"'"
dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})