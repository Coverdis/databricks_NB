# Databricks notebook source
#File Name:LoadCostCenterHierarchy
#ADF Pipeline Name: IRM_ADL_DW-PLWPlan-PLWActivity
#ADW Table name: irm_stg.COST_CENTER_HIERARCHY
#Description:
  #Identify delta between current file in unified and SQL DW
  #Delta is being inserted in SQL DW to maintain history in staging table.

# COMMAND ----------

# MAGIC %run "/library/configFile"

# COMMAND ----------

dbutils.widgets.text('runid', 'as222s-34897-dfkjjhfkdhj-ewr234')
runid = dbutils.widgets.get("runid")

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.window import Window

import pytz
from datetime import datetime
from pyspark.sql import functions as F
process_time = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

unified_path = 'dbfs:/mnt/unified/finance/'

# COMMAND ----------

ccDF = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(unified_path + "cost_center_hierarchy.txt")

ccDF = ccDF.toDF(*(col.replace('\r', '') for col in ccDF.columns))

for col_name in ccDF.columns:
  ccDF = ccDF.withColumn(col_name, F.regexp_replace(col_name, '[\\r\\n\\s+]', ' '))
  
ccDF = ccDF.select('COST_CENTER_CODE', 'COST_CENTER_DESCRIPTION', 'DEPARTMENT_CODE', 'DEPARTMENT_DESCRIPTION', 'SUB_DIVISION_CODE', 'SUB_DIVISION_DESCRIPTION', 'DIVISION_CODE', 'DIVISION_DESCRIPTION', 'DIRECTORATE_CODE', 'DIRECTORATE_DESCRIPTION', 'ORGANISATION_CODE', 'ORGANISATION_DESCRIPTION', 'ORGANISATION_TYPE', 'COST_CENTER_STATUS', 'CURRENCY_CODE', 'COUNTRY_CODE', 'COUNTRY_DESCRIPTION', 'COST_TYPE', 'COST_TYPE_DESCRIPTION', 'RBS_CODE', 'RBS_DESCRIPTION', 'OPT_IN_ET','MARKET_CODE')

#ccDF = ccDF.drop('Type')

# COMMAND ----------

delta_flag = False
delta_df = None
try:
  pushdown_query = "(SELECT c.COST_CENTER_CODE,COST_CENTER_DESCRIPTION,Department_Code,Department_Description,Sub_Division_Code,Sub_Division_Description,Division_Code,  Division_Description,Directorate_Code,Directorate_Description,Organisation_Code,Organisation_Description,ORGANISATION_TYPE,COST_CENTER_STATUS,CURRENCY_CODE,  COUNTRY_CODE,Country_Description,COST_TYPE,Cost_Type_Description, RBS_CODE, RBS_DESCRIPTION, OPT_IN_ET,MARKET_CODE FROM  irm_STG.COST_CENTER_HIERARCHY c, (SELECT COST_CENTER_CODE,Creation_date, rank() over  (partition by COST_CENTER_CODE order by creation_date desc) as rank_id FROM  irm_stg.COST_CENTER_HIERARCHY) r where c.COST_CENTER_CODE=r.COST_CENTER_CODE and c.creation_date=r.Creation_date and r.rank_id=1) cc"

  dw_cc = spark.read.jdbc(url = sqlDwUrl, table = pushdown_query)

  delta_df = ccDF.subtract(dw_cc)
  
  if delta_df.count() > 0:
    delta_flag = True
  
  delta_df.createOrReplaceTempView("COST_CENTER_HIERARCHY")
  
except Exception as e:
  print(e)

# COMMAND ----------

if delta_flag:
  query = "SELECT COST_CENTER_CODE, COST_CENTER_DESCRIPTION, Department_Code,Department_Description,Sub_Division_Code,Sub_Division_Description,Division_Code, Division_Description,Directorate_Code,Directorate_Description,Organisation_Code,Organisation_Description,ORGANISATION_TYPE, COST_CENTER_STATUS, CURRENCY_CODE, COUNTRY_CODE, Country_Description,COST_TYPE,Cost_Type_Description, RBS_CODE, RBS_DESCRIPTION, OPT_IN_ET,MARKET_CODE, '{0}' as RUN_ID, to_timestamp('{1}') as CREATION_DATE, 'Databricks - LoadCostCenterHierarchy' as CREATED_BY, CAST(null as timestamp) as UPDATION_DATE, CAST(null as string) as UPDATED_BY FROM COST_CENTER_HIERARCHY".format(runid, process_time)

  df = sqlContext.sql(query)

  # write dataframe to DW using polybase
  df.write\
      .format("com.databricks.spark.sqldw")\
      .option("url", sqlDwUrl)\
      .option( "forward_spark_azure_storage_credentials", "True")\
      .option("tempdir", tempDir)\
      .option("dbtable", "irm_stg.COST_CENTER_HIERARCHY") \
      .mode("append")\
      .save()

# COMMAND ----------

