# Databricks notebook source
#File Name: LoadPersonPosition
#ADF Pipeline Name: HRODS_ADL
#SQLDW: irm_stg.Position
#Description:
  # Write expense data to SQL DW from unified layer 

# COMMAND ----------

dbutils.widgets.text('runid', 'paj2s-ad83q-ajn88-stjs4')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
import pytz
from datetime import datetime, timedelta
import os
from glob import glob
import re

process_time = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')
print(process_time)

# COMMAND ----------

path = 'dbfs:/mnt/unified/person/person_position.txt'

# read file from Unified
df = spark.read.format('csv')\
      .option("inferSchema", "false")\
      .option("header", "true")\
      .option("multiLine", "true")\
      .option("delimiter", "|")\
      .option("quote", '"')\
      .option("escape", '"')\
      .option("nullValue", "null")\
    .load(path)

df = df.toDF(*(col.replace('\r', '') for col in df.columns))
for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ''))

# COMMAND ----------

#typecasting the attributes
df = df.withColumn('AVAILABLE_FROM_DATE', df.AVAILABLE_FROM_DATE.cast(TimestampType()))
df = df.withColumn('BUSINESS_UNIT_CODE', df.BUSINESS_UNIT_CODE.cast(StringType()))
df = df.withColumn('EARLIEST_HIRE_DATE', df.EARLIEST_HIRE_DATE.cast(TimestampType()))
df = df.withColumn('FUTURE_FILL_DATE', df.FUTURE_FILL_DATE.cast(TimestampType()))
df = df.withColumn('JOB_REQUIREMENT_DESC', df.JOB_REQUIREMENT_DESC.cast(StringType()))
df = df.withColumn('JOB_REQUIREMENT_ID', df.JOB_REQUIREMENT_ID.cast(StringType()))
df = df.withColumn('JOB_REQUIREMENT_OPEN_DATE', df.JOB_REQUIREMENT_OPEN_DATE.cast(TimestampType()))
df = df.withColumn('JOB_REQUIREMENT_STATUS', df.JOB_REQUIREMENT_STATUS.cast(StringType()))
df = df.withColumn('POSITION_CREATE_DATE', df.POSITION_CREATE_DATE.cast(TimestampType()))
df = df.withColumn('POS_DESC', df.POS_DESC.cast(StringType()))
df = df.withColumn('POS_NUM', df.POS_NUM.cast(StringType()))
df = df.withColumn('POS_WORK_COUNTRY', df.POS_WORK_COUNTRY.cast(StringType()))
df = df.withColumn('POS_WORK_SITE_ID', df.POS_WORK_SITE_ID.cast(StringType()))
df = df.withColumn('PRIMARY_WORK_SITE_ID', df.PRIMARY_WORK_SITE_ID.cast(StringType()))
df = df.withColumn('PRIMARY_WORK_SITE_NAME', df.PRIMARY_WORK_SITE_NAME.cast(StringType()))
df = df.withColumn('MANAGER_POS_NO', df.MANAGER_POS_NO.cast(StringType()))
df = df.withColumn('STAFFING_STATUS', df.STAFFING_STATUS.cast(StringType()))
df = df.withColumn('SUPERVISORY_ORG_CODE', df.PRIMARY_WORK_SITE_ID.cast(StringType()))
df = df.withColumn('SOURCE_SYS_ID', df.SOURCE_SYS_ID.cast(StringType()))

#create additional columns
df = df.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
df = df.withColumn('CREATION_DATE', F.lit(process_time).cast(TimestampType()))
df = df.withColumn('CREATED_BY', F.lit('Databricks - LoadPersonPosition').cast(StringType()))
df = df.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
df = df.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))

#display(df)

# COMMAND ----------

# write to sql dw
df.write\
  .format("com.databricks.spark.sqldw")\
  .option("url", sqlDwUrl)\
  .option( "forward_spark_azure_storage_credentials", "True")\
  .option("tempdir", tempDir)\
  .option("dbtable", "irm_stg.PERSON_POSITION")\
  .option("maxStrLength","4000")\
  .mode("append")\
  .save()

# COMMAND ----------

#delete old data once new data has been inserted successfully
sql="delete from irm_stg.PERSON_POSITION where CREATION_DATE != '"+ process_time +"'"
dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})