# Databricks notebook source
#File Name: LoadPortfolio
#ADF Pipeline Name: IRM_ADL_DW-PLWPlan-PLWActivity
#SQLDW Table: irm_stg.PORTFOLIO
#Description:
  # Load PDM portfolio data from unified to staging table

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *

process_time = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "cdnm3-eu32ws-vdio22-cdp22")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

# read active substance data
df = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load('dbfs:/mnt/unified/project_management/portfolio.txt')

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '[\\r\\n\\s+]', ' '))

# COMMAND ----------

df = df.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
df = df.withColumn('CREATION_DATE', F.lit(process_time).cast(TimestampType()))
df = df.withColumn('CREATED_BY', F.lit('Databricks - LoadPortfolio').cast(StringType()))
df = df.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
df = df.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))

# COMMAND ----------

df = df.select(
'PORTFOLIO_ID', 'PORTFOLIO_NAME', 'PORTFOLIO_TYPE', 'PORTFOLIO_GROUP_NAME', 'PORTFOLIO_OWNER', 'PORTFOLIO_PUBLIC_FLAG', 'PORTFOLIO_DUPLICATE_MEMBERS_FLAG', 'PORTFOLIO_SECURITY_FLAG', 'PORTFOLIO_COMMENT', 'PORTFOLIO_TYPENAME_ID', 'PORTFOLIO_CATEGORY_CODE', 'PORTFOLIO_CATEGORY_DESCRIPTION', 'RUN_ID', 'CREATION_DATE', 'CREATED_BY', 'UPDATION_DATE', 'UPDATED_BY'
)

# COMMAND ----------

# write to sql dw
df.write\
  .format("com.databricks.spark.sqldw")\
  .option("url", sqlDwUrl)\
  .option( "forward_spark_azure_storage_credentials", "True")\
  .option("tempdir", tempDir)\
  .option("dbtable", "irm_stg.PORTFOLIO")\
  .option("maxStrLength","4000")\
  .mode("append")\
  .save()

# COMMAND ----------

#delete old data once new data has been inserted successfully
sql="delete from irm_stg.PORTFOLIO where CREATION_DATE != '"+ process_time +"'"
dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})