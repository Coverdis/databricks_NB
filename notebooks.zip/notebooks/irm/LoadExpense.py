# Databricks notebook source
#File Name: LoadExpense
#ADF Pipeline Name: IRM_ADL_DW-PLWPlan-PLWActivity
#SQLDW: irm_stg.Expense
#Description:
  # Write expense data to SQL DW from unified layer 

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
import pytz
from datetime import datetime, timedelta
import os
from glob import glob
import re

process_time = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')
print(process_time)

# COMMAND ----------

dbutils.widgets.text("DeltaHours", "")
deltaHours = dbutils.widgets.get("DeltaHours")

dbutils.widgets.text("runid", "")
runid = dbutils.widgets.get("runid")

dbutils.widgets.text("expense_type", "")
expense_type = dbutils.widgets.get("expense_type")

unified_path = 'dbfs:/mnt/unified/'
file_path = '/dbfs/mnt/unified/'
print(expense_type)
print(runid)
if expense_type == 'actual':
  unified_path = unified_path + 'actual_expense/'
  file_path = file_path + 'actual_expense/'
  file_name = 'Expense_*.txt'
  source = 'Unified'
elif expense_type == 'estimated':
  unified_path = unified_path + 'estimated_expense/'
  file_path = file_path + 'estimated_expense/'
  file_name = 'Forecast_EPE_*.txt'
  source = 'Hyperion-Forecast'

# COMMAND ----------

# identify files modified within DeltaHours

process_flag = True

min_last_modified_time = datetime.now(pytz.timezone("UTC")) - timedelta(hours = float(deltaHours))

# list of files in unified
unified_files = [x.split('/')[-1:] for x in glob(file_path + file_name, recursive=True)]

# get last modified time and convert that to Eastern time for each unified file
last_modified= [datetime.fromtimestamp(os.path.getctime(file_path + '{0}'.format(unified_files[item][0]))).replace(tzinfo=pytz.utc) for item in range(0, len(unified_files))]


# list of updated files after max creation date
updated_files = [unified_files[idx] for idx, modified_time in enumerate(last_modified) if (modified_time >= min_last_modified_time)]


if len(updated_files) == 0:
  process_flag = False

# COMMAND ----------

print(process_flag)
print(updated_files)
print(file_path)
print(unified_path)

# COMMAND ----------

# find year and path of modified files

if process_flag:
  # updated files year-month
  year = tuple([''.join(re.findall(r'\d+', i[0])) for i in updated_files])
  year = str(year)
  year = year.replace(',)', ')')
  
  #updated files path from ADL
  updated_files_path = [unified_path + '/'.join(updated_files[idx]) for idx, n in enumerate(updated_files)]

# COMMAND ----------

# read modified files

if process_flag:
  df = spark.read.format('csv')\
      .option("inferSchema", "false")\
      .option("header", "true")\
      .option("multiLine", "true")\
      .option("delimiter", "|")\
      .option("quote", '"')\
      .option("escape", '"')\
      .option("nullValue", "null")\
    .load(updated_files_path)

  df = df.toDF(*(col.replace('\r', '') for col in df.columns))
  for col_name in df.columns:
    df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ''))
    
#   df = df.filter('RANK = 1')

# COMMAND ----------

if process_flag:
  if expense_type == "actual":
    df = df.withColumn('ACTUAL_OR_ESTIMATE_CODE', F.lit('Actual').cast(StringType()))
    df = df.withColumn('BEGINNING_BALANCE', F.lit(None).cast(StringType()))
    df = df.withColumn('PROJECT_PHASE', F.lit(None).cast(StringType()))
  if expense_type == "estimated":  
    df = df.withColumn('ITEM_TEXT', F.lit(None).cast(StringType()))
    df = df.withColumn('PURCHASE_DOCUMENT_NUMBER', F.lit(None).cast(StringType()))
    df = df.withColumn('DOCUMENT_DATE', F.lit(None).cast(StringType()))
    df = df.withColumn('POSTING_DATE', F.lit(None).cast(StringType()))
    df = df.withColumn('DOC_HD_TXT', F.lit(None).cast(StringType()))
    df = df.withColumn('REF_DOC_NO', F.lit(None).cast(StringType()))
    
  # change types
  df = df.withColumn('AMOUNT_LOC', df.AMOUNT_LOC.cast(DecimalType(31,5)))
  df = df.withColumn('AMOUNT_GBP', df.AMOUNT_GBP.cast(DecimalType(31,5)))
  df = df.withColumn('AMOUNT_HIST_GBP', df.AMOUNT_HIST_GBP.cast(DecimalType(31,5)))
  df = df.withColumn('FISCMONTH', df.FISCMONTH.cast(IntegerType()))
  df = df.withColumn('FISCYEAR', df.FISCYEAR.cast(IntegerType()))
  df = df.withColumn('DOCUMENT_DATE', df.DOCUMENT_DATE.cast(TimestampType()))
  df = df.withColumn('POSTING_DATE', df.POSTING_DATE.cast(TimestampType()))
  
  
  
  # Create additional columns
  df = df.withColumn('GL_PERIOD', F.concat_ws('-', df.FISCYEAR, df.FISCMONTH, F.lit(1)).cast(TimestampType()))
  df = df.withColumn('SOURCE', F.lit(source).cast(StringType()))
  df = df.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
  df = df.withColumn('CREATION_DATE', F.lit(process_time).cast(TimestampType()))
  df = df.withColumn('CREATED_BY', F.lit('Databricks - LoadExpense').cast(StringType()))
  df = df.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
  df = df.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))
  


  df = df.select(
   'GL_PERIOD',
 'COMP_CODE',
 'COST_CENTER_CODE',
 'ACCOUNT_CODE',
 'WBS_CODE',
 'BUDID_CODE',
 'DOCUMENT_NO',
 'AMOUNT_LOC',
 'AMOUNT_GBP',
 'AMOUNT_HIST_GBP',
 'CURRENCY_CODE',
 'FISCMONTH',
 'FISCYEAR',
 'SOURCE',
 'ACTUAL_OR_ESTIMATE_CODE',
 'COST_TYPE',
 'ITEM_TEXT',
 'PURCHASE_DOCUMENT_NUMBER',
 'POSTING_DATE',
 'REF_DOC_NO',
 'DOC_HD_TXT',
 'BEGINNING_BALANCE',
 'BUSINESS_UNIT',
 'PROJECT_PHASE',
 'RUN_ID',
 'CREATION_DATE',
 'CREATED_BY',
 'UPDATION_DATE',
 'UPDATED_BY'
)

# COMMAND ----------

# write to sql dw
if process_flag:
  df.write\
    .format("com.databricks.spark.sqldw")\
    .option("url", sqlDwUrl)\
    .option( "forward_spark_azure_storage_credentials", "True")\
    .option("tempdir", tempDir)\
    .option("dbtable", "irm_stg.EXPENSE")\
    .mode("append")\
    .save()

# COMMAND ----------

# delete old data once new data has been inserted successfully
if process_flag:
  sql = "delete from irm_stg.EXPENSE where SOURCE = '"+ source +"' and CREATION_DATE != '"+ process_time +"' and FISCYEAR IN " + year
  print(sql)
  dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})