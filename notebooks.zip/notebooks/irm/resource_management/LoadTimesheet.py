# Databricks notebook source
#File Name:LoadTimesheet
#ADF Pipeline Name: IRM_ADL_DW-PLWPlan-PLWActivity
#SQLDW Table: irm_stg.TIMESHEET
#Description:
  #Notebook to load Timesheet data from ADL to SQL DW

# COMMAND ----------

# MAGIC %run "/library/configFile"

# COMMAND ----------

dbutils.widgets.text("DeltaHours", "48")
runid = dbutils.widgets.text("runid", "xs233-segb2-ds232-cdkl2")

deltaHours = dbutils.widgets.get("DeltaHours")
runid = dbutils.widgets.get("runid")
print(deltaHours)

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
import pytz
from datetime import datetime, timedelta
import os
from glob import glob
import re

process_time = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

unified_path = 'dbfs:/mnt/unified/resource_management/timesheet/'

# COMMAND ----------

process_flag = True

min_last_modified_time = datetime.now(pytz.timezone("UTC")) - timedelta(hours = float(deltaHours))

# list of files in unified
unified_files = [x.split('/')[-2:] for x in glob('/dbfs/mnt/unified/resource_management/timesheet/**/timesheets-*.txt', recursive=True)]

# get last modified time and convert that to Eastern time for each unified file
last_modified= [datetime.fromtimestamp(os.path.getctime(('/dbfs/mnt/unified/resource_management/timesheet/{0}/{1}').format(unified_files[item][0], unified_files[item][1]))).replace(tzinfo=pytz.utc) for item in range(0, len(unified_files))]


# list of updated files after max creation date
updated_files = [unified_files[idx] for idx, modified_time in enumerate(last_modified) if (modified_time >= min_last_modified_time)]


if len(updated_files) == 0:
  process_flag = False

# COMMAND ----------

if process_flag:
  # updated files year-month
  year_month = tuple(['-'.join(re.findall(r'\d+', i[1])) for i in updated_files])
  delete_date = tuple(x + '-01' for x in year_month)
  delete_date = str(delete_date)
  delete_date = delete_date.replace(',)', ')')
  
  #updated files path from ADL
  updated_files_path = [unified_path + '/'.join(updated_files[idx]) for idx, n in enumerate(updated_files)]
  print(updated_files_path)

# COMMAND ----------

timesheet = None

if process_flag:
  timesheet = spark.read.format('csv')\
      .option("inferSchema", "false")\
      .option("header", "true")\
      .option("multiLine", "true")\
      .option("delimiter", "|")\
      .option("quote", '"')\
      .option("escape", '"')\
      .option("nullValue", "null")\
    .load(updated_files_path)

  timesheet = timesheet.toDF(*(col.replace('\r', '') for col in timesheet.columns))
  #for col_name in timesheet.columns:
  #  timesheet = timesheet.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r//g', ''))

# COMMAND ----------

if process_flag:
  #timesheet = timesheet.withColumnRenamed('RBSLevel6','LVL6_RBS_DESC')
  #timesheet = timesheet.withColumn('STANDARD_HOURS', F.lit(None).cast(StringType()))
  #timesheet = timesheet.withColumn('STANDARD_FTES', F.lit(None).cast(StringType()))
  #timesheet = timesheet.withColumn('USER_ID', F.lit(None).cast(StringType()))
  timesheet = timesheet.withColumn('SUBMITTED_DATE', F.lit(None).cast(TimestampType()))
  timesheet = timesheet.withColumn('START_DATE', F.lit(timesheet.START_DATE).cast(TimestampType()))
  timesheet = timesheet.withColumn('STATUS', F.lit(None).cast(StringType()))
  #timesheet = timesheet.withColumn('USER_NAME', F.lit(None).cast(StringType()))
  #timesheet = timesheet.withColumn('SOURCE_SYSTEM', F.lit(None).cast(DecimalType(5, 2)))
  timesheet = timesheet.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
  timesheet = timesheet.withColumn('CREATION_DATE', F.lit(process_time).cast(TimestampType()))
  timesheet = timesheet.withColumn('CREATED_BY', F.lit('Databricks - LoadTimesheet').cast(StringType()))
  timesheet = timesheet.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
  timesheet = timesheet.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))

  timesheet = timesheet.selectExpr(
    "PROJECT_CODE",
    "PROJECT_NAME",
    "PROJECT_CATEGORY_DESC",
    "ACTIVITY_CODE",
    "COST_CENTER_CODE",
    "LVL6_RBS_DESC",
    "RBS_ID",
    "USER_ID",
    "FTES_COVERED",
    "STANDARD_HOURS",
    "STANDARD_FTES",
    "ACTUAL_HOURS",
    "ACTUAL_FTES",
    "START_DATE",
    "SUBMITTED_DATE",
    "STATUS",
    "USER_NAME",
    "AMOUNT_GBP",
    "COST_TYPE",
    "ACTIVITY_RESOURCE_ID",
    "PROJECT_RECOMMENDED_FLAG",
    "ACTIVITY_RECOMMENDED_FLAG",
    "SOURCE",
    "RUN_ID",
    "CREATION_DATE",
    "CREATED_BY",
    "UPDATION_DATE",
    "UPDATED_BY"
  )

# COMMAND ----------

if process_flag:
  # write dataframe to DW using polybase
  timesheet.write\
    .format("com.databricks.spark.sqldw")\
    .option("url", sqlDwUrl)\
    .option( "forward_spark_azure_storage_credentials", "True")\
    .option("tempdir", tempDir)\
    .option("dbtable", "irm_stg.TIMESHEET")\
    .mode("append")\
    .save()

# COMMAND ----------

if process_flag:
  # delete old data once new data has been inserted successfully
  sql="delete from irm_stg.TIMESHEET where CREATION_DATE!='"+ process_time +"' and source='ET' and START_DATE in " +  ''.join(delete_date)
  dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})