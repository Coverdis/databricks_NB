# Databricks notebook source
#File Name: LoadPersonPosition
#ADF Pipeline Name: HRODS_ADL
#SQLDW: irm_stg.Position
#Description:
  # Write expense data to SQL DW from unified layer 

# COMMAND ----------

dbutils.widgets.text('runid', 'paj2s-ad83q-ajn88-stjs4')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
import pytz
from datetime import datetime, timedelta
import os
from glob import glob
import re

process_time = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')
print(process_time)

# COMMAND ----------

path = 'dbfs:/mnt/unified/et/et_expected_users.txt'

# read file from Unified
df = spark.read.format('csv')\
      .option("inferSchema", "false")\
      .option("header", "true")\
      .option("multiLine", "true")\
      .option("delimiter", "|")\
      .option("quote", '"')\
      .option("escape", '"')\
      .option("nullValue", "null")\
    .load(path)

df = df.toDF(*(col.replace('\r', '') for col in df.columns))
for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ''))

# COMMAND ----------

#typecasting the attributes


#create additional columns
df = df.withColumn('USER_DATE', F.add_months(F.trunc(F.lit(process_time).cast(TimestampType()),"month"),-1)) #first day of the last month
df = df.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
df = df.withColumn('CREATION_DATE', F.lit(process_time).cast(TimestampType()))
df = df.withColumn('CREATED_BY', F.lit('Databricks - LoadETExpectedUsers').cast(StringType()))
df = df.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
df = df.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))


# COMMAND ----------

# write to sql dw
df.write\
  .format("com.databricks.spark.sqldw")\
  .option("url", sqlDwUrl)\
  .option( "forward_spark_azure_storage_credentials", "True")\
  .option("tempdir", tempDir)\
  .option("dbtable", "irm_stg.ET_USERS")\
  .option("maxStrLength","4000")\
  .mode("append")\
  .save()

# COMMAND ----------

#delete old data once new data has been inserted successfully
sql="delete from irm_stg.ET_USERS where CREATION_DATE != '"+ process_time +"'"
dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})