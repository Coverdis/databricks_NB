# Databricks notebook source
#File Name:LoadPersonRoleMapping
#ADF Pipeline Name: IRM_ADL_DW-Resource_Management
#SQLDW Table: irm_stg.PERSON_ROLE_MAPPING
#Description:
  #Notebook to load person role mapping data from ADL to SQL DW

# COMMAND ----------

# MAGIC %run "/library/configFile"

# COMMAND ----------

dbutils.widgets.text("DeltaHours", "48")
runid = dbutils.widgets.text("runid", "xs233-segb2-ds232-cdkl2")

deltaHours = dbutils.widgets.get("DeltaHours")
runid = dbutils.widgets.get("runid")
print(deltaHours)

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
import pytz
from datetime import datetime, timedelta
import os
from glob import glob
import re

process_time = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

unified_path = 'dbfs:/mnt/unified/resource_management/person_role_mapping/'

print(process_time)

# COMMAND ----------

process_flag = True

min_last_modified_time = datetime.now(pytz.timezone("UTC")) - timedelta(hours = float(deltaHours))

# list of files in unified
unified_files = [x.split('/')[-1:] for x in glob('/dbfs/mnt/unified/resource_management/person_role_mapping/person_role_mapping-*.txt', recursive=True)]

print(unified_files)

# COMMAND ----------


# get last modified time and convert that to Eastern time for each unified file
last_modified= [datetime.fromtimestamp(os.path.getctime(('/dbfs/mnt/unified/resource_management/person_role_mapping/{0}').format(unified_files[item][0]))).replace(tzinfo=pytz.utc) for item in range(0, len(unified_files))]

# list of updated files after max creation date
updated_files = [unified_files[idx] for idx, modified_time in enumerate(last_modified) if (modified_time >= min_last_modified_time)]
  
if len(updated_files) == 0:
  process_flag = False

# COMMAND ----------

if process_flag:
  #updated files path from ADL
  updated_files_path = [unified_path + '/'.join(updated_files[idx]) for idx, n in enumerate(updated_files)]
  print(updated_files_path)

# COMMAND ----------

person_role_mapping = None

if process_flag:
  person_role_mapping = spark.read.format('csv')\
      .option("inferSchema", "false")\
      .option("header", "true")\
      .option("multiLine", "true")\
      .option("delimiter", "|")\
      .option("quote", '"')\
      .option("escape", '"')\
      .option("nullValue", "null")\
    .load(updated_files_path)

  person_role_mapping = person_role_mapping.withColumn("filename", F.input_file_name())
  
  person_role_mapping = person_role_mapping.toDF(*(col.replace('\r', '') for col in person_role_mapping.columns))

# COMMAND ----------

if process_flag:
  person_role_mapping = person_role_mapping.withColumn("PROCESS_DATE", F.to_date(F.concat(person_role_mapping.filename.substr(F.lit(79), F.lit(7)), F.lit('-01')).cast(StringType()), "yyyy-MM-dd"))
  person_role_mapping = person_role_mapping.withColumn("LAST_UPDATION_DATE", F.to_date("LAST_UPDATE_DATE", "MM-dd-yyyy"))
  person_role_mapping = person_role_mapping.withColumn('SOURCE', F.lit('Role Mapping Spreadsheet').cast(StringType()))
  person_role_mapping = person_role_mapping.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
  person_role_mapping = person_role_mapping.withColumn('CREATION_DATE', F.lit(process_time).cast(TimestampType()))
  person_role_mapping = person_role_mapping.withColumn('CREATED_BY', F.lit('Databricks - LoadTimesheet').cast(StringType()))
  person_role_mapping = person_role_mapping.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
  person_role_mapping = person_role_mapping.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))

  person_role_mapping = person_role_mapping.selectExpr(
    "PROCESS_DATE",
    "PERSON_CODE",
    "RBS_LEVEL_1",
    "RBS_LEVEL_2",
    "RBS_LEVEL_3",
    "RBS_LEVEL_4",
    "RBS_LEVEL_5",
    "RBS_LEVEL_6",
    "PERSON_ROLE_CODE",
    "LAST_UPDATION_DATE",
    "SOURCE",
    "RUN_ID",
    "CREATION_DATE",
    "CREATED_BY",
    "UPDATION_DATE",
    "UPDATED_BY"
  )

# COMMAND ----------

if process_flag:
  # write dataframe to DW using polybase
  person_role_mapping.write\
    .format("com.databricks.spark.sqldw")\
    .option("url", sqlDwUrl)\
    .option( "forward_spark_azure_storage_credentials", "True")\
    .option("tempdir", tempDir)\
    .option("dbtable", "irm_stg.PERSON_ROLE_MAPPING")\
    .mode("append")\
    .save()

# COMMAND ----------

if process_flag:
  # delete old data once new data has been inserted successfully
  for x in updated_files:
    for filename in x:
      sql="delete from irm_stg.PERSON_ROLE_MAPPING where CREATION_DATE!='"+ process_time +"' and PROCESS_DATE = convert(DATE,'"+filename[-11:-4]+"-01')"
      dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})