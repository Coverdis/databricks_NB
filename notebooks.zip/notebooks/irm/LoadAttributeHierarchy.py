# Databricks notebook source
#File Name:LoadAttributeHierarchy
#ADF Pipeline Name: IRM_ADL_DW-PLWPlan-PLWActivity
#ADW Table name: irm_stg.ATTRIBUTE_HIERARCHY
#Description:
  #Identify delta between current file in unified and SQL DW
  #Delta is being inserted in SQL DW to maintain history in staging table.

# COMMAND ----------

# MAGIC %run "/library/configFile"

# COMMAND ----------

dbutils.widgets.text('runid', 'as222s-34897-dfkjjhfkdhj-ewr234')
runid = dbutils.widgets.get("runid")

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.window import Window

import pytz
from datetime import datetime
from pyspark.sql import functions as F
process_time = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

unified_path = 'dbfs:/mnt/unified/finance/'

# COMMAND ----------

df = spark.read.format("csv")\
          .option("inferSchema","true")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load(unified_path + "attribute_hierarchy.txt")

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

#for col_name in df.columns:
#  df = df.withColumn(col_name, F.regexp_replace(col_name, '[\\r\\n\\s+]', ' '))


# COMMAND ----------

df=df.select('level_0_code','level_0_description','level_1_code','level_1_description','level_2_code','level_2_description','level_3_code','level_3_description','level_4_code','level_4_description','level_5_code','level_5_description','CODE_TYPE','source')

# COMMAND ----------

df = df.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
df = df.withColumn('CREATION_DATE', F.lit(process_time).cast(TimestampType()))
df = df.withColumn('CREATED_BY', F.lit('Databricks - LoadAttributeHierarchy').cast(StringType()))
df = df.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
df = df.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))

# COMMAND ----------

# write dataframe to DW using polybase
df.write\
  .format("com.databricks.spark.sqldw")\
  .option("url", sqlDwUrl)\
  .option( "forward_spark_azure_storage_credentials", "True")\
  .option("tempdir", tempDir)\
  .option("dbtable", "irm_stg.ATTRIBUTE_HIERARCHY") \
  .option("maxStrLength","4000")\
  .mode("append")\
  .save()

# COMMAND ----------

# delete old data once new data has been inserted successfully

sql = "delete from irm_stg.ATTRIBUTE_HIERARCHY where CREATION_DATE != '"+ process_time +"'"
print(sql)
dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})