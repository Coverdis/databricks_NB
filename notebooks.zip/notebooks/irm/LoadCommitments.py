# Databricks notebook source
#File Name: LoadCommitments
#ADF Pipeline Name: IRM_ADL_DW-PLWPlan-PLWActivity
#SQLDW: irm_stg.Expense
#Description:
  # Write expense data to SQL DW from unified layer 

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
import pytz
from datetime import datetime, timedelta
import os
from glob import glob
import re

process_time = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

# COMMAND ----------

dbutils.widgets.text("DeltaHours", "48")
deltaHours = dbutils.widgets.get("DeltaHours")

dbutils.widgets.text("runid", "asas22-segb2-vfk23-cdkl2")
runid = dbutils.widgets.get("runid")

unified_path = 'dbfs:/mnt/unified/finance/po/'
file_path = '/dbfs/mnt/unified/finance/po/'
file_name = 'po-*.txt'

# COMMAND ----------

# identify files modified within DeltaHours

process_flag = True

min_last_modified_time = datetime.now(pytz.timezone("UTC")) - timedelta(hours = float(deltaHours))

# list of files in unified
unified_files = [x.split('/')[-1:] for x in glob(file_path + file_name, recursive=True)]

# get last modified time and convert that to Eastern time for each unified file
last_modified= [datetime.fromtimestamp(os.path.getctime(file_path + '{0}'.format(unified_files[item][0]))).replace(tzinfo=pytz.utc) for item in range(0, len(unified_files))]


# list of updated files after max creation date
updated_files = [unified_files[idx] for idx, modified_time in enumerate(last_modified) if (modified_time >= min_last_modified_time)]


if len(updated_files) == 0:
  process_flag = False

# COMMAND ----------

# find year and path of modified files

if process_flag:
  # updated files year-month
  year = tuple([''.join(re.findall(r'\d+', i[0])) for i in updated_files])
  year = str(year)
  year = year.replace(',)', ')')
  
  #updated files path from ADL
  updated_files_path = [unified_path + '/'.join(updated_files[idx]) for idx, n in enumerate(updated_files)]

# COMMAND ----------

# read modified files

if process_flag:
  df = spark.read.format('csv')\
      .option("inferSchema", "false")\
      .option("header", "true")\
      .option("multiLine", "true")\
      .option("delimiter", "|")\
      .option("quote", '"')\
      .option("escape", '"')\
      .option("nullValue", "null")\
    .load(updated_files_path)

  df = df.toDF(*(col.replace('\r', '') for col in df.columns))
  for col_name in df.columns:
    df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ''))
    
#   df = df.filter('RANK = 1')

# COMMAND ----------

process_flag

# COMMAND ----------

if process_flag:
  # change types
  df = df.withColumn('AMOUNT_LOC', df.AMOUNT_LOC.cast(DecimalType(31,5)))
  df = df.withColumn('AMOUNT_GBP', df.AMOUNT_GBP.cast(DecimalType(31,5)))
  df = df.withColumn('INVOICE_VALUE', df.INVOICE_VALUE.cast(DecimalType(31,5)))
  df = df.withColumn('INVOICE_VALUE_GBP', df.INVOICE_VALUE_GBP.cast(DecimalType(31,5)))
  
  df = df.withColumn('FISCMONTH', df.FISCMONTH.cast(IntegerType()))
  df = df.withColumn('FISCYEAR', df.FISCYEAR.cast(IntegerType()))
  #df = df.withColumn('PURCHASE_DOCUMENT_NUMBER', df.PURCHASE_DOCUMENT_NUMBER.cast(IntegerType()))
  #df = df.withColumn('VENDOR_ID', df.VENDOR_ID.cast(IntegerType()))
  df = df.withColumn('DOCUMENT_DATE', df.DOCUMENT_DATE.cast(TimestampType()))
  df = df.withColumn('POSTING_DATE', df.POSTING_DATE.cast(TimestampType()))

  # Create additional columns
  df = df.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
  df = df.withColumn('CREATION_DATE', F.lit(process_time).cast(TimestampType()))
  df = df.withColumn('CREATED_BY', F.lit('Databricks - LoadCommitments').cast(StringType()))
  df = df.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
  df = df.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))
  
  df = df.select(
    'GL_PERIOD',
    'COMP_CODE',
    'COST_CENTER_CODE',
    'ACCOUNT_CODE',
    'WBS_CODE',
    'BUDID_CODE',   
    'AMOUNT_LOC',
    'AMOUNT_GBP',
    'CURRENCY_CODE',
    'FISCMONTH',
    'FISCYEAR',
    'ACTUAL_OR_ESTIMATE_CODE',
    'COST_TYPE',
    'PURCHASE_DOCUMENT_NUMBER',
	'VENDOR_ID',
	'INVOICE_VALUE',
    'INVOICE_VALUE_GBP',
	'DOCUMENT_DATE',
	'POSTING_DATE',
    'REQUESTER',
    'PO_DESCRIPTION',
    'RANK',
    'SOURCE',
    'RUN_ID',
    'CREATION_DATE',
    'CREATED_BY',
    'UPDATION_DATE',
    'UPDATED_BY'
  )

# COMMAND ----------

# write to sql dw
if process_flag:
  df.write\
    .format("com.databricks.spark.sqldw")\
    .option("url", sqlDwUrl)\
    .option( "forward_spark_azure_storage_credentials", "True")\
    .option("tempdir", tempDir)\
    .option("dbtable", "irm_stg.COMMITMENTS") \
    .mode("append")\
    .save()

# COMMAND ----------

# delete old data once new data has been inserted successfully
if process_flag:
  sql = "delete from irm_stg.COMMITMENTS where SOURCE = 'CERPS' and CREATION_DATE != '"+ process_time +"' and FISCYEAR IN " + year
  dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})