# Databricks notebook source
#File Name: LoadBudget
#ADF Pipeline Name: IRM_ADL_DW-PLWPlan-PLWActivity
#SQLDW: irm_stg.Expense
#Description:
  # Write expense data to SQL DW from unified layer 

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
import pytz
from datetime import datetime, timedelta
import os
from glob import glob
import re

process_time = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')
print(process_time)

# COMMAND ----------

dbutils.widgets.text("runid", "asas22-segb2-vfk23-cdkl2")
runid = dbutils.widgets.get("runid")
file_path = '/mnt/unified/finance/epe_budget.txt'

# COMMAND ----------

# read modified files
df = spark.read.format('csv')\
      .option("inferSchema", "false")\
      .option("header", "true")\
      .option("multiLine", "true")\
      .option("delimiter", "|")\
      .option("quote", '"')\
      .option("escape", '"')\
      .option("nullValue", "null")\
    .load(file_path)

df = df.toDF(*(col.replace('\r', '') for col in df.columns))
for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ''))

# COMMAND ----------


# change types
df = df.withColumn('AMOUNT_LOC', df.AMOUNT_LOC.cast(DecimalType(31,5)))
df = df.withColumn('AMOUNT_GBP', df.AMOUNT_GBP.cast(DecimalType(31,5)))
df = df.withColumn('FISCMONTH', df.FISCMONTH.cast(IntegerType()))
df = df.withColumn('FISCYEAR', df.FISCYEAR.cast(IntegerType()))
df = df.withColumn('ITEM_TEXT', F.lit(None).cast(StringType()))
df = df.withColumn('PURCHASE_DOCUMENT_NUMBER', F.lit(None).cast(StringType()))
df = df.withColumn('DOCUMENT_DATE', F.lit(None).cast(StringType()))
df = df.withColumn('POSTING_DATE', F.lit(None).cast(StringType()))

df = df.withColumn('DOC_HD_TXT', F.lit(None).cast(StringType()))
df = df.withColumn('REF_DOC_NO', F.lit(None).cast(StringType()))

df = df.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
df = df.withColumn('CREATION_DATE', F.lit(process_time).cast(TimestampType()))
df = df.withColumn('CREATED_BY', F.lit('Databricks - LoadBudget').cast(StringType()))
df = df.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
df = df.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))
df = df.withColumn('AMOUNT_HIST_GBP', df.AMOUNT_GBP)
df = df.select(
  'GL_PERIOD',
  'COMP_CODE',
  'COST_CENTER_CODE',
  'ACCOUNT_CODE',
  'WBS_CODE',
  'BUDID_CODE',
  'DOCUMENT_NO',
  'AMOUNT_LOC',
  'AMOUNT_GBP',
  'AMOUNT_HIST_GBP',
  'CURRENCY_CODE',
  'FISCMONTH',
  'FISCYEAR',
  'SOURCE',
  'ACTUAL_OR_ESTIMATE_CODE',
  'COST_TYPE',
  'ITEM_TEXT',
  'PURCHASE_DOCUMENT_NUMBER',
  'POSTING_DATE',
  'REF_DOC_NO',
  'DOC_HD_TXT',
  'BEGINNING_BALANCE',
  'BUSINESS_UNIT',
  'PROJECT_PHASE',
  'RUN_ID',
  'CREATION_DATE',
  'CREATED_BY',
  'UPDATION_DATE',
  'UPDATED_BY'
)

# COMMAND ----------

print(df.count())

# COMMAND ----------

# write to sql dw

df.write\
  .format("com.databricks.spark.sqldw")\
  .option("url", sqlDwUrl)\
  .option( "forward_spark_azure_storage_credentials", "True")\
  .option("tempdir", tempDir)\
  .option("dbtable", "irm_stg.EXPENSE") \
  .mode("append")\
  .save()

# COMMAND ----------

# delete old data once new data has been inserted successfully

sql = "delete from irm_stg.EXPENSE where SOURCE = 'Hyperion-Budget' and CREATION_DATE != '"+ process_time +"'"
print(sql)
dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})

# COMMAND ----------

