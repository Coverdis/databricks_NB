# Databricks notebook source
#File Name: LoadVETHierarchy
#ADF Pipeline Name: HRODS_ADL
#SQLDW: irm_stg.VET_HIERARCHY
#Description:
  # Write VET Hierarchy data to SQL DW from unified layer

# COMMAND ----------

dbutils.widgets.text('runid', 'jap8s-ad830-88n00-stjs4')
runid = dbutils.widgets.get('runid')

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
import pytz
from datetime import datetime, timedelta
import os
from glob import glob
import re

process_time = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')
print(process_time)

# COMMAND ----------

path = 'dbfs:/mnt/unified/person/person.txt'

# read file from Unified
df = spark.read.format('csv')\
      .option("inferSchema", "false")\
      .option("header", "true")\
      .option("multiLine", "true")\
      .option("delimiter", "|")\
      .option("quote", '"')\
      .option("escape", '"')\
      .option("nullValue", "null")\
    .load(path)

df = df.toDF(*(col.replace('\r', '') for col in df.columns))
for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '^\s+|\s+$|\r+|\n+//g', ''))

# COMMAND ----------

df.createOrReplaceTempView('df')

query = "SELECT DISTINCT SUPERVISORY_ORG_LEVEL, SUPERVISORY_ORG_CODE, SUPERVISORY_ORG_CODE_VET1, SUPERVISORY_ORG_CODE_VET2, SUPERVISORY_ORG_CODE_VET3, SUPERVISORY_ORG_CODE_VET4, SUPERVISORY_ORG_CODE_VET5, SUPERVISORY_ORG_CODE_VET6, SUPERVISORY_ORG_CODE_VET7, SUPERVISORY_ORG_CODE_VET8, SUPERVISORY_ORG_CODE_VET9, SUPERVISORY_ORG_CODE_VET10, SUPERVISORY_ORG_DESC_VET1, SUPERVISORY_ORG_DESC_VET2, SUPERVISORY_ORG_DESC_VET3, SUPERVISORY_ORG_DESC_VET4, SUPERVISORY_ORG_DESC_VET5, SUPERVISORY_ORG_DESC_VET6, SUPERVISORY_ORG_DESC_VET7, SUPERVISORY_ORG_DESC_VET8, SUPERVISORY_ORG_DESC_VET9, SUPERVISORY_ORG_DESC_VET10 FROM df WHERE SUPERVISORY_ORG_LEVEL is not null"

df = sqlContext.sql(query)

# COMMAND ----------

#typecasting the attributes
df = df.withColumn('SUPERVISORY_ORG_LEVEL', df.SUPERVISORY_ORG_LEVEL.cast(IntegerType()))
df = df.withColumn('SUPERVISORY_ORG_CODE', df.SUPERVISORY_ORG_CODE.cast(StringType()))
df = df.withColumn('SUPERVISORY_ORG_CODE_VET1', df.SUPERVISORY_ORG_CODE_VET1.cast(StringType()))
df = df.withColumn('SUPERVISORY_ORG_CODE_VET2', df.SUPERVISORY_ORG_CODE_VET2.cast(StringType()))
df = df.withColumn('SUPERVISORY_ORG_CODE_VET3', df.SUPERVISORY_ORG_CODE_VET3.cast(StringType()))
df = df.withColumn('SUPERVISORY_ORG_CODE_VET4', df.SUPERVISORY_ORG_CODE_VET4.cast(StringType()))
df = df.withColumn('SUPERVISORY_ORG_CODE_VET5', df.SUPERVISORY_ORG_CODE_VET5.cast(StringType()))
df = df.withColumn('SUPERVISORY_ORG_CODE_VET6', df.SUPERVISORY_ORG_CODE_VET6.cast(StringType()))
df = df.withColumn('SUPERVISORY_ORG_CODE_VET7', df.SUPERVISORY_ORG_CODE_VET7.cast(StringType()))
df = df.withColumn('SUPERVISORY_ORG_CODE_VET8', df.SUPERVISORY_ORG_CODE_VET8.cast(StringType()))
df = df.withColumn('SUPERVISORY_ORG_CODE_VET9', df.SUPERVISORY_ORG_CODE_VET9.cast(StringType()))
df = df.withColumn('SUPERVISORY_ORG_CODE_VET10', df.SUPERVISORY_ORG_CODE_VET10.cast(StringType()))
df = df.withColumn('SUPERVISORY_ORG_DESC_VET1', df.SUPERVISORY_ORG_DESC_VET1.cast(StringType()))
df = df.withColumn('SUPERVISORY_ORG_DESC_VET2', df.SUPERVISORY_ORG_DESC_VET2.cast(StringType()))
df = df.withColumn('SUPERVISORY_ORG_DESC_VET3', df.SUPERVISORY_ORG_DESC_VET3.cast(StringType()))
df = df.withColumn('SUPERVISORY_ORG_DESC_VET4', df.SUPERVISORY_ORG_DESC_VET4.cast(StringType()))
df = df.withColumn('SUPERVISORY_ORG_DESC_VET5', df.SUPERVISORY_ORG_DESC_VET5.cast(StringType()))
df = df.withColumn('SUPERVISORY_ORG_DESC_VET6', df.SUPERVISORY_ORG_DESC_VET6.cast(StringType()))
df = df.withColumn('SUPERVISORY_ORG_DESC_VET7', df.SUPERVISORY_ORG_DESC_VET7.cast(StringType()))
df = df.withColumn('SUPERVISORY_ORG_DESC_VET8', df.SUPERVISORY_ORG_DESC_VET8.cast(StringType()))
df = df.withColumn('SUPERVISORY_ORG_DESC_VET9', df.SUPERVISORY_ORG_DESC_VET9.cast(StringType()))
df = df.withColumn('SUPERVISORY_ORG_DESC_VET10', df.SUPERVISORY_ORG_DESC_VET10.cast(StringType()))

#create additional columns
df = df.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
df = df.withColumn('CREATION_DATE', F.lit(process_time).cast(TimestampType()))
df = df.withColumn('CREATED_BY', F.lit('Databricks - LoadVETHierarchy').cast(StringType()))
df = df.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
df = df.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))

# COMMAND ----------

df = df.select(
                        'SUPERVISORY_ORG_LEVEL',
                        'SUPERVISORY_ORG_CODE',
                        'SUPERVISORY_ORG_CODE_VET1',                        
                        'SUPERVISORY_ORG_CODE_VET2',
                        'SUPERVISORY_ORG_CODE_VET3',
                        'SUPERVISORY_ORG_CODE_VET4',
                        'SUPERVISORY_ORG_CODE_VET5',
                        'SUPERVISORY_ORG_CODE_VET6',
                        'SUPERVISORY_ORG_CODE_VET7',
                        'SUPERVISORY_ORG_CODE_VET8',
                        'SUPERVISORY_ORG_CODE_VET9',                           
                        'SUPERVISORY_ORG_CODE_VET10',
                        'SUPERVISORY_ORG_DESC_VET1',                        
                        'SUPERVISORY_ORG_DESC_VET2',
                        'SUPERVISORY_ORG_DESC_VET3',
                        'SUPERVISORY_ORG_DESC_VET4',
                        'SUPERVISORY_ORG_DESC_VET5',
                        'SUPERVISORY_ORG_DESC_VET6',
                        'SUPERVISORY_ORG_DESC_VET7',
                        'SUPERVISORY_ORG_DESC_VET8',
                        'SUPERVISORY_ORG_DESC_VET9',
                        'SUPERVISORY_ORG_DESC_VET10',
                        'RUN_ID',
                        'CREATION_DATE',
                        'CREATED_BY',
                        'UPDATION_DATE',
                        'UPDATED_BY'
                      )

# COMMAND ----------

# write to sql dw
df.write\
  .format("com.databricks.spark.sqldw")\
  .option("url", sqlDwUrl)\
  .option( "forward_spark_azure_storage_credentials", "True")\
  .option("tempdir", tempDir)\
  .option("dbtable", "irm_stg.VET_HIERARCHY")\
  .option("maxStrLength","4000")\
  .mode("append")\
  .save()

# COMMAND ----------

#delete old data once new data has been inserted successfully
sql="delete from irm_stg.VET_HIERARCHY where CREATION_DATE != '"+ process_time +"'"
dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})