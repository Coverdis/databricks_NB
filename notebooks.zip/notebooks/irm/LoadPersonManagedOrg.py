# Databricks notebook source
#File Name:LoadPerson
#ADF Pipeline Name: IRM_ADL_DW-PLWPlan-PLWActivity
#SQLDW Table:irm_stg.PERSON_MANAGED_ORG
#Description:
  #Load Managed Org data to staging table

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

dbutils.widgets.text("runid", "sssa4-s28s5-kpss5-2bcss")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
import pytz
from datetime import datetime

unified_path = 'dbfs:/mnt/unified/person/'
process_time = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')
file_name = 'person_managed_org.txt'

# COMMAND ----------

# read person data
person = spark.read.format("csv")\
      .option("inferSchema","false")\
      .option("header","true")\
      .option("multiLine","true")\
      .option("delimiter","|")\
      .option("quote", '"')\
      .option("escape",'"')\
      .option("nullValue","null")\
  .load(unified_path + file_name)

person = person.toDF(*(col.replace('\r', '') for col in person.columns))

# COMMAND ----------

person = person.select('PERSON_MUD_ID', 'MANAGED_ORG_CODE', 'MANAGED_ORGANIZATION')

# COMMAND ----------

person = person.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
person = person.withColumn('CREATION_DATE', F.lit(process_time).cast(TimestampType()))
person = person.withColumn('CREATED_BY', F.lit('Databricks - LoadPersonManagedOrg').cast(StringType()))
person = person.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
person = person.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))

# COMMAND ----------

person.write\
      .format("com.databricks.spark.sqldw")\
      .option("url", sqlDwUrl)\
      .option( "forward_spark_azure_storage_credentials", "True")\
      .option("tempdir", tempDir)\
      .option("dbtable", "irm_stg.PERSON_MANAGED_ORG")\
      .option("maxStrLength","4000")\
      .mode("append")\
      .save()

# COMMAND ----------

sql="delete from irm_stg.PERSON_MANAGED_ORG where CREATION_DATE != '"+ process_time +"'"
dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})