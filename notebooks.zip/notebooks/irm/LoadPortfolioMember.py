# Databricks notebook source
#File Name: LoadPortfolioMember
#ADF Pipeline Name: IRM_ADL_DW-PLWPlan-PLWActivity
#SQLDW Table: irm_stg.PORTFOLIO_MEMBER
#Description:
  # Load PDM Portfolio Member data from unified to staging table

# COMMAND ----------

# MAGIC %run /library/configFile

# COMMAND ----------

import pytz
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import *

process_time = datetime.now(pytz.timezone("UTC")).strftime('%Y-%m-%dT%H:%M:%S')

dbutils.widgets.text("runid", "xdwsk2-poqwm2-xwskm1-kljsdsc1")
runid = dbutils.widgets.get("runid")

# COMMAND ----------

# read active substance data
df = spark.read.format("csv")\
          .option("inferSchema","false")\
          .option("header","true")\
          .option("multiLine","true")\
          .option("delimiter","|")\
          .option("quote", '"')\
          .option("escape",'"')\
          .option("nullValue","null")\
    .load('dbfs:/mnt/unified/project_management/portfolio_member.txt')

df = df.toDF(*(col.replace('\r', '') for col in df.columns))

for col_name in df.columns:
  df = df.withColumn(col_name, F.regexp_replace(col_name, '[\\r\\n\\s+]', ' '))

# COMMAND ----------

df = df.withColumn('RUN_ID', F.lit(runid).cast(StringType()))
df = df.withColumn('CREATION_DATE', F.lit(process_time).cast(TimestampType()))
df = df.withColumn('CREATED_BY', F.lit('Databricks - LoadPortfolioMember').cast(StringType()))
df = df.withColumn('UPDATION_DATE', F.lit(None).cast(TimestampType()))
df = df.withColumn('UPDATED_BY', F.lit(None).cast(StringType()))

# COMMAND ----------

df = df.select(
'PORTFOLIO_MEMBER_ID', 'PORTFOLIO_ID', 'MEMBER_KEY', 'MEMBER_TYPE', 'MEMBER_TYPE_DESCRIPTION', 'PROJECT_CODE', 'RUN_ID', 'CREATION_DATE', 'CREATED_BY', 'UPDATION_DATE', 'UPDATED_BY'
)

# COMMAND ----------

# write to sql dw
df.write\
  .format("com.databricks.spark.sqldw")\
  .option("url", sqlDwUrl)\
  .option( "forward_spark_azure_storage_credentials", "True")\
  .option("tempdir", tempDir)\
  .option("dbtable", "irm_stg.PORTFOLIO_MEMBER")\
  .option("maxStrLength","4000")\
  .mode("append")\
  .save()

# COMMAND ----------

#delete old data once new data has been inserted successfully
sql="delete from irm_stg.PORTFOLIO_MEMBER where CREATION_DATE != '"+ process_time +"'"
dbutils.notebook.run("/library/DataLayer", 0, {"query" : sql})